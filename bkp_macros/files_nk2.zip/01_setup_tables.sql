-- =================================================================
-- 01_setup_tables.sql
-- Run ONCE. Creates every table, format, and view the framework needs.
-- Open in Snowsight → Select All → Run
-- =================================================================

USE ROLE ACCOUNTADMIN;
CREATE DATABASE IF NOT EXISTS RAMU;
USE DATABASE RAMU;
CREATE SCHEMA IF NOT EXISTS PUBLIC;
CREATE SCHEMA IF NOT EXISTS RAW;
USE SCHEMA PUBLIC;

CREATE WAREHOUSE IF NOT EXISTS COMPUTE_WH
    WAREHOUSE_SIZE = 'XSMALL'
    AUTO_SUSPEND   = 60
    AUTO_RESUME    = TRUE;

-- ── File formats ──────────────────────────────────────────────
CREATE OR REPLACE FILE FORMAT CSV_FORMAT
    TYPE                         = CSV
    SKIP_HEADER                  = 1
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    NULL_IF                      = ('NULL','null','')
    EMPTY_FIELD_AS_NULL          = TRUE;

CREATE OR REPLACE FILE FORMAT PARQUET_FORMAT
    TYPE = PARQUET;

CREATE OR REPLACE FILE FORMAT JSON_FORMAT
    TYPE              = JSON
    STRIP_OUTER_ARRAY = TRUE;

-- ── INGEST_CONFIG ─────────────────────────────────────────────
-- The single control table. One row per table.
-- LOAD_MODE drives which stored procedure is called.
--
-- LOAD_MODE values:
--   INCREMENTAL  — COPY INTO, skips already-loaded files, tracks watermark
--   FULL_LOAD    — TRUNCATE then COPY INTO all files (FORCE=TRUE)
--   CDC_MERGE    — stages files then MERGE INTO on merge_keys (INSERT/UPDATE/DELETE)
CREATE OR REPLACE TABLE INGEST_CONFIG (
    CONFIG_ID        NUMBER        AUTOINCREMENT PRIMARY KEY,
    TABLE_NAME       VARCHAR(255)  NOT NULL,
    TARGET_SCHEMA    VARCHAR(100)  DEFAULT 'PUBLIC',
    STAGE_NAME       VARCHAR(500)  NOT NULL,
    FILE_FORMAT      VARCHAR(100)  NOT NULL,
    FILE_PATTERN     VARCHAR(500)  DEFAULT '.*',
    LOAD_MODE        VARCHAR(20)   NOT NULL
                     CHECK (LOAD_MODE IN ('INCREMENTAL','FULL_LOAD','CDC_MERGE')),
    -- CDC_MERGE only: comma-separated key columns e.g. 'CUSTOMER_ID' or 'ORDER_ID,LINE_ID'
    MERGE_KEYS       VARCHAR(500),
    -- CDC_MERGE only: column holding DML type ('I','U','D' or 'INSERT','UPDATE','DELETE')
    CDC_OP_COLUMN    VARCHAR(100),
    -- INCREMENTAL only: column to use as watermark (e.g. LOAD_DATE, FILE_DATE)
    WATERMARK_COLUMN VARCHAR(100),
    IS_ACTIVE        BOOLEAN       DEFAULT TRUE,
    PRIORITY         NUMBER        DEFAULT 100,
    -- Parallel degree: how many files to load at once inside Snowflake (1-10)
    BATCH_SIZE       NUMBER        DEFAULT 5,
    NOTES            VARCHAR(1000),
    CREATED_AT       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_AT       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP()
);

-- Sample rows covering all three modes
INSERT INTO INGEST_CONFIG
    (TABLE_NAME, STAGE_NAME, FILE_FORMAT, LOAD_MODE, PRIORITY, NOTES)
VALUES
    ('ORDERS',   '@RAW.ORDERS_STAGE',   'PARQUET_FORMAT', 'INCREMENTAL', 10, 'Daily orders — append new files only'),
    ('CUSTOMER', '@RAW.CUSTOMER_STAGE', 'CSV_FORMAT',     'FULL_LOAD',   20, 'Full customer refresh every day');

INSERT INTO INGEST_CONFIG
    (TABLE_NAME, STAGE_NAME, FILE_FORMAT, LOAD_MODE, MERGE_KEYS, CDC_OP_COLUMN, PRIORITY, NOTES)
VALUES
    ('PRODUCTS', '@RAW.PRODUCTS_STAGE', 'JSON_FORMAT', 'CDC_MERGE', 'PRODUCT_ID', 'OP_TYPE', 30, 'CDC feed with I/U/D markers');

-- ── ETL_AUDIT ─────────────────────────────────────────────────
-- One row per SP run. DURATION_SECS is virtual (auto-computed).
CREATE OR REPLACE TABLE ETL_AUDIT (
    AUDIT_ID         NUMBER        AUTOINCREMENT PRIMARY KEY,
    RUN_ID           VARCHAR(64)   NOT NULL,
    AIRFLOW_RUN_ID   VARCHAR(500),
    DAG_ID           VARCHAR(255),
    TABLE_NAME       VARCHAR(255)  NOT NULL,
    TARGET_SCHEMA    VARCHAR(100),
    STAGE_NAME       VARCHAR(500),
    LOAD_MODE        VARCHAR(20),
    START_TIME       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP(),
    END_TIME         TIMESTAMP,
    DURATION_SECS    NUMBER        GENERATED ALWAYS AS
                     (DATEDIFF('second', START_TIME, END_TIME)) VIRTUAL,
    STATUS           VARCHAR(20)   CHECK (STATUS IN ('STARTED','SUCCESS','FAILED','SKIPPED')),
    ROWS_LOADED      NUMBER        DEFAULT 0,
    ROWS_DELETED     NUMBER        DEFAULT 0,   -- CDC deletes
    ROWS_UPDATED     NUMBER        DEFAULT 0,   -- CDC updates
    FILES_LOADED     NUMBER        DEFAULT 0,
    BYTES_LOADED     NUMBER        DEFAULT 0,
    ERROR_MESSAGE    VARCHAR(5000),
    CREATED_AT       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP()
);

-- ── ETL_ERROR_LOG ─────────────────────────────────────────────
CREATE OR REPLACE TABLE ETL_ERROR_LOG (
    ERROR_ID         NUMBER        AUTOINCREMENT PRIMARY KEY,
    RUN_ID           VARCHAR(64),
    AIRFLOW_RUN_ID   VARCHAR(500),
    TABLE_NAME       VARCHAR(255),
    STAGE_NAME       VARCHAR(500),
    LOAD_MODE        VARCHAR(20),
    ERROR_TIME       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP(),
    ERROR_TYPE       VARCHAR(100),
    ERROR_MESSAGE    VARCHAR(5000),
    STACK_TRACE      VARCHAR(10000),
    IS_RESOLVED      BOOLEAN       DEFAULT FALSE,
    RESOLVED_AT      TIMESTAMP,
    RESOLVED_BY      VARCHAR(100)
);

-- ── ETL_COPY_RESULTS ──────────────────────────────────────────
-- Per-file COPY INTO output. First place to check when a load fails.
CREATE OR REPLACE TABLE ETL_COPY_RESULTS (
    RESULT_ID             NUMBER AUTOINCREMENT PRIMARY KEY,
    RUN_ID                VARCHAR(64),
    TABLE_NAME            VARCHAR(255),
    FILE_NAME             VARCHAR(1000),
    STATUS                VARCHAR(50),
    ROWS_PARSED           NUMBER,
    ROWS_LOADED           NUMBER,
    ERRORS_SEEN           NUMBER,
    FIRST_ERROR           VARCHAR(2000),
    FIRST_ERROR_LINE      NUMBER,
    FIRST_ERROR_CHARACTER NUMBER,
    ERROR_COLUMN_NAME     VARCHAR(255),
    CREATED_AT            TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- ── ETL_WATERMARK ─────────────────────────────────────────────
-- Tracks the last-loaded value for INCREMENTAL mode.
-- The SP reads this before COPY and updates it after.
CREATE OR REPLACE TABLE ETL_WATERMARK (
    WATERMARK_ID     NUMBER        AUTOINCREMENT PRIMARY KEY,
    TABLE_NAME       VARCHAR(255)  NOT NULL UNIQUE,
    LAST_LOADED_FILE VARCHAR(1000),           -- last file name successfully loaded
    LAST_LOADED_TS   TIMESTAMP,               -- timestamp of last successful load
    LAST_RUN_ID      VARCHAR(64),
    UPDATED_AT       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP()
);

-- ── Reporting views ───────────────────────────────────────────
CREATE OR REPLACE VIEW V_LATEST_STATUS AS
SELECT
    TABLE_NAME,
    MAX_BY(LOAD_MODE,     START_TIME) AS LOAD_MODE,
    MAX_BY(STATUS,        START_TIME) AS LAST_STATUS,
    MAX(START_TIME)                   AS LAST_RUN_AT,
    MAX_BY(ROWS_LOADED,   START_TIME) AS LAST_ROWS_LOADED,
    MAX_BY(DURATION_SECS, START_TIME) AS LAST_DURATION_SECS
FROM ETL_AUDIT
GROUP BY TABLE_NAME;

CREATE OR REPLACE VIEW V_DAILY_SUMMARY AS
SELECT
    DATE_TRUNC('day', START_TIME)                            AS RUN_DATE,
    LOAD_MODE,
    COUNT(*)                                                 AS TOTAL_TABLES,
    SUM(CASE WHEN STATUS='SUCCESS' THEN 1 ELSE 0 END)       AS SUCCESS,
    SUM(CASE WHEN STATUS='FAILED'  THEN 1 ELSE 0 END)       AS FAILED,
    SUM(ROWS_LOADED)                                         AS TOTAL_ROWS_LOADED,
    ROUND(AVG(DURATION_SECS),1)                              AS AVG_DURATION_SECS
FROM ETL_AUDIT
GROUP BY 1,2 ORDER BY 1 DESC,2;

CREATE OR REPLACE VIEW V_OPEN_ERRORS AS
SELECT
    e.ERROR_ID, e.TABLE_NAME, e.LOAD_MODE,
    e.ERROR_TIME, e.ERROR_TYPE, e.ERROR_MESSAGE,
    e.STACK_TRACE, a.AIRFLOW_RUN_ID
FROM ETL_ERROR_LOG  e
JOIN ETL_AUDIT      a ON e.RUN_ID = a.RUN_ID
WHERE e.IS_RESOLVED = FALSE
ORDER BY e.ERROR_TIME DESC;

CREATE OR REPLACE VIEW V_WATERMARKS AS
SELECT
    w.TABLE_NAME,
    w.LAST_LOADED_FILE,
    w.LAST_LOADED_TS,
    w.UPDATED_AT,
    c.LOAD_MODE,
    c.WATERMARK_COLUMN
FROM ETL_WATERMARK  w
JOIN INGEST_CONFIG  c ON w.TABLE_NAME = c.TABLE_NAME;
