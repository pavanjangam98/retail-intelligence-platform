-- =================================================================
-- 04_sp_copy_results_writer.sql
-- Saves per-file COPY INTO output to ETL_COPY_RESULTS.
-- Runs INSIDE Snowflake — replaces copy_results_writer.py.
-- =================================================================

CREATE OR REPLACE PROCEDURE sp_copy_results_write(
    run_id     STRING,
    table_name STRING,
    copy_rows  VARIANT   -- array of COPY INTO result rows
)
RETURNS STRING
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'write_results'
AS $$
import json
import logging
log = logging.getLogger(__name__)

def _e(v):
    return str(v or '').replace("'", "''")[:2000]

def write_results(session, run_id, table_name, copy_rows):
    """
    Bulk-inserts all COPY INTO file results into ETL_COPY_RESULTS.
    copy_rows is the raw list returned by session.sql(copy_sql).collect()
    converted to a variant (list of dicts) by the caller.
    """
    if not copy_rows:
        log.info(f"[sp_copy_results_write] No rows for table={table_name}")
        return 'SKIPPED'

    rows = copy_rows if isinstance(copy_rows, list) else [copy_rows]
    value_parts = []

    for r in rows:
        file_name    = _e(r.get('file',         r.get('"file"',         '')))
        status       = _e(r.get('status',       r.get('"status"',       '')))
        rows_parsed  = int(r.get('rows_parsed',  r.get('"rows_parsed"',  0)) or 0)
        rows_loaded  = int(r.get('rows_loaded',  r.get('"rows_loaded"',  0)) or 0)
        errors_seen  = int(r.get('errors_seen',  r.get('"errors_seen"',  0)) or 0)
        first_error  = _e(r.get('first_error',   r.get('"first_error"',  '')))
        err_line     = r.get('first_error_line', r.get('"first_error_line"', None))
        err_char     = r.get('first_error_character', r.get('"first_error_character"', None))
        err_col      = _e(r.get('first_error_column_name', r.get('"first_error_column_name"', '')))

        err_line_sql = str(int(err_line)) if err_line is not None else 'NULL'
        err_char_sql = str(int(err_char)) if err_char is not None else 'NULL'

        value_parts.append(
            f"('{_e(run_id)}','{_e(table_name)}','{file_name}','{status}',"
            f"{rows_parsed},{rows_loaded},{errors_seen},"
            f"'{first_error}',{err_line_sql},{err_char_sql},'{err_col}')"
        )

    if value_parts:
        session.sql(f"""
            INSERT INTO ETL_COPY_RESULTS
                (RUN_ID, TABLE_NAME, FILE_NAME, STATUS,
                 ROWS_PARSED, ROWS_LOADED, ERRORS_SEEN, FIRST_ERROR,
                 FIRST_ERROR_LINE, FIRST_ERROR_CHARACTER, ERROR_COLUMN_NAME)
            VALUES {','.join(value_parts)}
        """).collect()
        log.info(f"[sp_copy_results_write] Wrote {len(value_parts)} file result(s) for table={table_name}")

    return f'WROTE:{len(value_parts)}'
$$;
