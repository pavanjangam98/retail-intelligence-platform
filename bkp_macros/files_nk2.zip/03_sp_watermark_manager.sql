-- =================================================================
-- 03_sp_watermark_manager.sql
-- Manages the ETL_WATERMARK table for INCREMENTAL loads.
-- Tracks the last file successfully loaded so the next run
-- only picks up new files — no double-loading.
-- =================================================================

CREATE OR REPLACE PROCEDURE sp_watermark_get(table_name STRING)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'watermark_get'
AS $$
import json

def watermark_get(session, table_name):
    """
    Returns the current watermark for a table as a JSON object:
      { "last_loaded_file": "...", "last_loaded_ts": "..." }
    Returns { "last_loaded_file": null } if no watermark exists yet
    (meaning: load everything in the stage on first run).
    """
    rows = session.sql(f"""
        SELECT LAST_LOADED_FILE, LAST_LOADED_TS
        FROM   ETL_WATERMARK
        WHERE  TABLE_NAME = '{table_name}'
    """).collect()

    if not rows:
        return {"last_loaded_file": None, "last_loaded_ts": None}

    return {
        "last_loaded_file": rows[0]["LAST_LOADED_FILE"],
        "last_loaded_ts"  : str(rows[0]["LAST_LOADED_TS"]) if rows[0]["LAST_LOADED_TS"] else None
    }
$$;


CREATE OR REPLACE PROCEDURE sp_watermark_set(
    table_name       STRING,
    last_loaded_file STRING,
    run_id           STRING
)
RETURNS STRING
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'watermark_set'
AS $$
def _e(v):
    return str(v or '').replace("'", "''")

def watermark_set(session, table_name, last_loaded_file, run_id):
    """
    MERGE into ETL_WATERMARK — updates if exists, inserts if not.
    Called after a successful INCREMENTAL load.
    """
    session.sql(f"""
        MERGE INTO ETL_WATERMARK w
        USING (SELECT
                   '{_e(table_name)}'        AS TABLE_NAME,
                   '{_e(last_loaded_file)}'  AS LAST_LOADED_FILE,
                   CURRENT_TIMESTAMP()       AS LAST_LOADED_TS,
                   '{_e(run_id)}'            AS LAST_RUN_ID
              ) src
        ON w.TABLE_NAME = src.TABLE_NAME
        WHEN MATCHED THEN UPDATE SET
            LAST_LOADED_FILE = src.LAST_LOADED_FILE,
            LAST_LOADED_TS   = src.LAST_LOADED_TS,
            LAST_RUN_ID      = src.LAST_RUN_ID,
            UPDATED_AT       = CURRENT_TIMESTAMP()
        WHEN NOT MATCHED THEN INSERT
            (TABLE_NAME, LAST_LOADED_FILE, LAST_LOADED_TS, LAST_RUN_ID)
        VALUES
            (src.TABLE_NAME, src.LAST_LOADED_FILE, src.LAST_LOADED_TS, src.LAST_RUN_ID)
    """).collect()
    return 'OK'
$$;
