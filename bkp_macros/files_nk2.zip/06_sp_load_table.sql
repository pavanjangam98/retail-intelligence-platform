-- =================================================================
-- 06_sp_load_table.sql
-- The ONE stored procedure Airflow calls per table.
-- Reads INGEST_CONFIG, dispatches to the correct load mode SP,
-- and handles all audit logging — entirely inside Snowflake.
-- =================================================================

CREATE OR REPLACE PROCEDURE sp_load_table(
    table_name     STRING,
    run_id         STRING,
    airflow_run_id STRING,
    dag_id         STRING
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'load_table'
AS $$
import traceback, logging
log = logging.getLogger(__name__)

def load_table(session, table_name, run_id, airflow_run_id, dag_id):
    """
    Main dispatcher. Reads config from INGEST_CONFIG, then:
      INCREMENTAL → sp_incremental_load
      FULL_LOAD   → sp_full_load
      CDC_MERGE   → sp_cdc_merge

    All audit writes happen inside this SP — no Airflow involvement.
    Returns a VARIANT so Airflow can log the summary if needed.
    """

    # ── Step 1: Read config ───────────────────────────────────
    config_rows = session.sql(f"""
        SELECT
            TABLE_NAME, TARGET_SCHEMA, STAGE_NAME, FILE_FORMAT,
            COALESCE(FILE_PATTERN, '.*')  AS FILE_PATTERN,
            LOAD_MODE,
            MERGE_KEYS, CDC_OP_COLUMN, WATERMARK_COLUMN
        FROM INGEST_CONFIG
        WHERE TABLE_NAME = '{table_name}'
          AND IS_ACTIVE  = TRUE
    """).collect()

    if not config_rows:
        log.warning(f"[sp_load_table] No active config for table={table_name}")
        return {"status": "SKIPPED", "reason": "No active config found"}

    c = config_rows[0].as_dict()
    target_schema  = c['TARGET_SCHEMA']
    stage_name     = c['STAGE_NAME']
    file_format    = c['FILE_FORMAT']
    file_pattern   = c['FILE_PATTERN']
    load_mode      = c['LOAD_MODE']
    merge_keys     = c.get('MERGE_KEYS', '')
    cdc_op_column  = c.get('CDC_OP_COLUMN', '')

    log.info(f"[sp_load_table] START table={table_name} mode={load_mode} run_id={run_id}")

    # ── Step 2: Record STARTED ────────────────────────────────
    session.call('sp_audit_start',
                 run_id, table_name, target_schema,
                 stage_name, load_mode, airflow_run_id, dag_id)

    # ── Step 3: Dispatch to load mode ─────────────────────────
    try:
        if load_mode == 'INCREMENTAL':
            result = session.call('sp_incremental_load',
                                  run_id, table_name, target_schema,
                                  stage_name, file_format, file_pattern)

        elif load_mode == 'FULL_LOAD':
            result = session.call('sp_full_load',
                                  run_id, table_name, target_schema,
                                  stage_name, file_format, file_pattern)

        elif load_mode == 'CDC_MERGE':
            if not merge_keys:
                raise ValueError(f"CDC_MERGE requires MERGE_KEYS to be set for table={table_name}")
            if not cdc_op_column:
                raise ValueError(f"CDC_MERGE requires CDC_OP_COLUMN to be set for table={table_name}")
            result = session.call('sp_cdc_merge',
                                  run_id, table_name, target_schema,
                                  stage_name, file_format, file_pattern,
                                  merge_keys, cdc_op_column)
        else:
            raise ValueError(f"Unknown LOAD_MODE='{load_mode}' for table={table_name}")

    except Exception as exc:
        # ── Failure path ──────────────────────────────────────
        tb = traceback.format_exc()
        session.call('sp_audit_failure',
                     run_id, type(exc).__name__, str(exc)[:4990],
                     tb[:9990], table_name, stage_name,
                     load_mode, airflow_run_id)
        log.error(f"[sp_load_table] FAILED table={table_name} error={str(exc)[:300]}")
        raise

    # ── Step 4: Save per-file COPY results ────────────────────
    file_results = result.get('file_results', []) if isinstance(result, dict) else []
    if file_results:
        session.call('sp_copy_results_write', run_id, table_name, file_results)

    # ── Step 5: Record SUCCESS ────────────────────────────────
    rows_loaded  = int((result or {}).get('rows_loaded',  0) or 0)
    rows_updated = int((result or {}).get('rows_updated', 0) or 0)
    rows_deleted = int((result or {}).get('rows_deleted', 0) or 0)
    files_loaded = int((result or {}).get('files_loaded', 0) or 0)

    session.call('sp_audit_success',
                 run_id, rows_loaded, rows_updated, rows_deleted, files_loaded, 0)

    log.info(f"[sp_load_table] SUCCESS table={table_name} "
             f"rows={rows_loaded} updated={rows_updated} deleted={rows_deleted}")

    return {
        "status"       : "SUCCESS",
        "table_name"   : table_name,
        "load_mode"    : load_mode,
        "rows_loaded"  : rows_loaded,
        "rows_updated" : rows_updated,
        "rows_deleted" : rows_deleted,
        "files_loaded" : files_loaded,
        "files_failed" : int((result or {}).get('files_failed', 0) or 0),
        "run_id"       : run_id
    }
$$;
