"""
snowflake_bulk_ingestion.py  —  Option 3: Hybrid DAG
======================================================
Airflow's only job here is:
  1. Read which tables are active (get_configs)
  2. Check files exist in the stage (check_file)
  3. Call ONE stored procedure per table (load_table)
  4. Send a summary email (send_summary_email)

ALL data logic — COPY INTO, TRUNCATE, MERGE, audit writes,
watermark tracking — runs INSIDE Snowflake stored procedures.
This DAG has zero SQL beyond SELECT and CALL.

Supporting 100+ tables:
  Dynamic task mapping (.expand) creates one parallel task per table.
  Airflow itself is stateless between tasks — no Python objects shared.
  Each task calls Snowflake and lets it do the work.
"""

import logging
import uuid
from datetime import datetime, timedelta

from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
from airflow.utils.email import send_email

log = logging.getLogger(__name__)

SNOWFLAKE_CONN_ID = Variable.get("SNOWFLAKE_CONN_ID", default_var="snowflake_default")
ALERT_EMAIL       = Variable.get("ALERT_EMAIL",        default_var="")

DEFAULT_ARGS = {
    "owner"                    : "data-engineering",
    "depends_on_past"          : False,
    "email_on_failure"         : bool(ALERT_EMAIL),
    "email"                    : [ALERT_EMAIL] if ALERT_EMAIL else [],
    "retries"                  : 3,
    "retry_delay"              : timedelta(minutes=5),
    "retry_exponential_backoff": True,
}


def hook() -> SnowflakeHook:
    return SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)


@dag(
    dag_id         = "snowflake_bulk_ingestion",
    description    = "Hybrid: Airflow orchestrates, Snowflake executes (100+ tables)",
    schedule       = "@daily",
    start_date     = datetime(2025, 1, 1),
    catchup        = False,
    default_args   = DEFAULT_ARGS,
    max_active_runs= 1,
    tags           = ["snowflake", "ingestion", "hybrid"],
)
def snowflake_bulk_ingestion():

    # ──────────────────────────────────────────────────────────
    # TASK 1: get_configs
    # Reads all IS_ACTIVE=TRUE rows from INGEST_CONFIG.
    # Returns list of dicts — one per table.
    # Airflow fans this into N parallel tasks via .expand().
    # ──────────────────────────────────────────────────────────
    @task
    def get_configs(**context) -> list[dict]:
        records = hook().get_records("""
            SELECT
                TABLE_NAME,
                TARGET_SCHEMA,
                STAGE_NAME,
                LOAD_MODE,
                COALESCE(FILE_PATTERN, '.*') AS FILE_PATTERN
            FROM INGEST_CONFIG
            WHERE IS_ACTIVE = TRUE
            ORDER BY COALESCE(PRIORITY, 100), TABLE_NAME
        """)

        if not records:
            log.warning("[get_configs] No active configs in INGEST_CONFIG")
            return []

        configs = [
            {
                "table_name"    : r[0],
                "target_schema" : r[1],
                "stage_name"    : r[2],
                "load_mode"     : r[3],
                "file_pattern"  : r[4],
                "airflow_run_id": context["run_id"],
                "dag_id"        : context["dag"].dag_id,
            }
            for r in records
        ]
        log.info("[get_configs] Found %d active table(s): %s",
                 len(configs), [c["table_name"] for c in configs])
        return configs

    # ──────────────────────────────────────────────────────────
    # TASK 2: check_file
    # Verifies files exist in the stage before trying to load.
    # Uses LIST @stage — runs a quick check on the stage metadata,
    # not the data itself. Fails fast if the stage is unexpectedly empty.
    # ──────────────────────────────────────────────────────────
    @task
    def check_file(config: dict) -> dict:
        table_name   = config["table_name"]
        stage_name   = config["stage_name"]
        file_pattern = config.get("file_pattern", ".*")

        log.info("[check_file] Checking stage: %s for table: %s", stage_name, table_name)

        try:
            rows = hook().get_records(f"LIST {stage_name}")
        except Exception as exc:
            raise RuntimeError(
                f"Cannot LIST stage {stage_name} for table {table_name}: {exc}"
            ) from exc

        if not rows:
            log.warning("[check_file] Stage %s is empty — skipping table %s",
                        stage_name, table_name)
            # Return config with skip flag — load_table will honour it
            return {**config, "skip": True, "skip_reason": "Stage is empty"}

        log.info("[check_file] Stage %s has %d file(s)", stage_name, len(rows))
        return {**config, "skip": False}

    # ──────────────────────────────────────────────────────────
    # TASK 3: load_table
    # ONE stored procedure call. Snowflake does everything:
    #   — reads its own config from INGEST_CONFIG
    #   — runs COPY INTO / TRUNCATE / MERGE depending on LOAD_MODE
    #   — writes ETL_AUDIT, ETL_ERROR_LOG, ETL_COPY_RESULTS
    #   — updates ETL_WATERMARK for incremental tables
    # Airflow just logs the result and handles retries.
    # ──────────────────────────────────────────────────────────
    @task
    def load_table(config: dict) -> None:
        if config.get("skip"):
            log.info("[load_table] Skipping table=%s reason=%s",
                     config["table_name"], config.get("skip_reason"))
            return

        table_name     = config["table_name"]
        airflow_run_id = config.get("airflow_run_id", "")
        dag_id         = config.get("dag_id", "")
        run_id         = str(uuid.uuid4())

        log.info("[load_table] CALL sp_load_table table=%s run_id=%s mode=%s",
                 table_name, run_id, config.get("load_mode"))

        try:
            result = hook().get_first(f"""
                CALL sp_load_table(
                    '{table_name}',
                    '{run_id}',
                    '{airflow_run_id}',
                    '{dag_id}'
                )
            """)
        except Exception as exc:
            log.error("[load_table] SP call FAILED table=%s error=%s", table_name, str(exc)[:300])
            raise

        # Log the result Snowflake returned
        if result and result[0]:
            r = result[0]
            log.info(
                "[load_table] DONE table=%s status=%s rows_loaded=%s "
                "rows_updated=%s rows_deleted=%s files=%s",
                table_name,
                r.get("status"),
                r.get("rows_loaded", 0),
                r.get("rows_updated", 0),
                r.get("rows_deleted", 0),
                r.get("files_loaded", 0),
            )

    # ──────────────────────────────────────────────────────────
    # TASK 4: send_summary_email
    # trigger_rule="all_done" — runs even if some tables failed.
    # Queries Snowflake for the batch summary, emails it.
    # ──────────────────────────────────────────────────────────
    @task(trigger_rule="all_done")
    def send_summary_email(**context) -> None:
        if not ALERT_EMAIL:
            return

        airflow_run_id = context["run_id"]
        rows = hook().get_records(f"""
            SELECT
                TABLE_NAME, LOAD_MODE, STATUS,
                ROWS_LOADED, ROWS_UPDATED, ROWS_DELETED,
                DURATION_SECS, ERROR_MESSAGE
            FROM ETL_AUDIT
            WHERE AIRFLOW_RUN_ID = '{airflow_run_id}'
            ORDER BY STATUS DESC, TABLE_NAME
        """)

        table_rows = ""
        for r in rows:
            tbl, mode, status, loaded, updated, deleted, dur, err = r
            color = "#2e7d32" if status == "SUCCESS" else "#c62828"
            table_rows += (
                f"<tr>"
                f"<td>{tbl}</td>"
                f"<td style='font-family:monospace'>{mode}</td>"
                f"<td style='color:{color};font-weight:500'>{status}</td>"
                f"<td>{(loaded or 0):,}</td>"
                f"<td>{(updated or 0):,}</td>"
                f"<td>{(deleted or 0):,}</td>"
                f"<td>{dur or '—'}s</td>"
                f"<td style='color:#c62828;font-size:11px'>{(err or '')[:120]}</td>"
                f"</tr>"
            )

        run_date = context["logical_date"].strftime("%Y-%m-%d")
        html = f"""
        <h2 style='font-family:sans-serif'>Snowflake Ingestion — {run_date}</h2>
        <p style='font-family:sans-serif;color:#555'>Airflow run: <code>{airflow_run_id}</code></p>
        <table border='1' cellpadding='7' cellspacing='0'
               style='border-collapse:collapse;font-family:sans-serif;font-size:13px'>
          <thead style='background:#f5f5f5'>
            <tr>
              <th>Table</th><th>Mode</th><th>Status</th>
              <th>Inserted</th><th>Updated</th><th>Deleted</th>
              <th>Duration</th><th>Error</th>
            </tr>
          </thead>
          <tbody>{table_rows}</tbody>
        </table>
        <p style='font-family:sans-serif;font-size:11px;color:#888;margin-top:12px'>
          Debug: Snowflake → ETL_AUDIT, ETL_ERROR_LOG, ETL_COPY_RESULTS
        </p>
        """

        send_email(
            to           = ALERT_EMAIL,
            subject      = f"[Snowflake Ingestion] {run_date} batch summary",
            html_content = html,
        )
        log.info("[send_summary_email] Sent to %s", ALERT_EMAIL)

    # ── Wire up ────────────────────────────────────────────────
    configs  = get_configs()
    checked  = check_file.expand(config=configs)      # N parallel file checks
    loaded   = load_table.expand(config=checked)      # N parallel SP calls
    loaded >> send_summary_email()


dag = snowflake_bulk_ingestion()
