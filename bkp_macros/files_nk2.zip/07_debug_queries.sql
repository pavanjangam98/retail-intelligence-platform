-- =================================================================
-- 07_debug_queries.sql
-- Use these in Snowsight when a load fails.
-- Open a new worksheet, replace placeholders, run.
-- =================================================================

USE DATABASE RAMU;
USE SCHEMA PUBLIC;


-- ═══════════════════════════════════════════════════════════════
-- STEP 1: What failed in the last 24 hours?
-- ═══════════════════════════════════════════════════════════════
SELECT
    TABLE_NAME, LOAD_MODE, STATUS,
    START_TIME, DURATION_SECS,
    ROWS_LOADED, ROWS_UPDATED, ROWS_DELETED,
    ERROR_MESSAGE
FROM ETL_AUDIT
WHERE STATUS     = 'FAILED'
  AND START_TIME >= DATEADD('hour', -24, CURRENT_TIMESTAMP())
ORDER BY START_TIME DESC;


-- ═══════════════════════════════════════════════════════════════
-- STEP 2: Which FILE caused it? (line + column)
-- Paste RUN_ID from Step 1
-- ═══════════════════════════════════════════════════════════════
SELECT
    FILE_NAME, STATUS,
    ROWS_PARSED, ROWS_LOADED, ERRORS_SEEN,
    FIRST_ERROR, FIRST_ERROR_LINE,
    FIRST_ERROR_CHARACTER, ERROR_COLUMN_NAME
FROM ETL_COPY_RESULTS
WHERE RUN_ID = '<paste RUN_ID here>'
ORDER BY STATUS DESC;


-- ═══════════════════════════════════════════════════════════════
-- STEP 3: Full error traceback
-- ═══════════════════════════════════════════════════════════════
SELECT
    ERROR_TYPE, ERROR_MESSAGE, STACK_TRACE, ERROR_TIME
FROM ETL_ERROR_LOG
WHERE RUN_ID = '<paste RUN_ID here>';


-- ═══════════════════════════════════════════════════════════════
-- STEP 4: Check watermarks (INCREMENTAL tables)
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_WATERMARKS ORDER BY TABLE_NAME;

-- Reset a watermark to force a full reload on next run:
-- UPDATE ETL_WATERMARK
-- SET LAST_LOADED_FILE = NULL, LAST_LOADED_TS = NULL
-- WHERE TABLE_NAME = 'ORDERS';


-- ═══════════════════════════════════════════════════════════════
-- STEP 5: Check stage files
-- ═══════════════════════════════════════════════════════════════
-- LIST @RAW.ORDERS_STAGE;    -- replace with your stage


-- ═══════════════════════════════════════════════════════════════
-- STEP 6: Dry-run validation (see errors without loading)
-- ═══════════════════════════════════════════════════════════════
-- COPY INTO PUBLIC.ORDERS
-- FROM @RAW.ORDERS_STAGE
-- FILE_FORMAT = (FORMAT_NAME = PARQUET_FORMAT)
-- VALIDATION_MODE = RETURN_ERRORS;


-- ═══════════════════════════════════════════════════════════════
-- OPERATIONAL: Current status per table
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_LATEST_STATUS ORDER BY TABLE_NAME;


-- OPERATIONAL: Daily summary
SELECT * FROM V_DAILY_SUMMARY LIMIT 30;


-- OPERATIONAL: Open unresolved errors
SELECT * FROM V_OPEN_ERRORS;


-- OPERATIONAL: CDC — check staging table leftovers (should be empty)
-- SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
-- WHERE TABLE_SCHEMA = 'PUBLIC' AND TABLE_NAME LIKE 'STG_%';


-- Mark an error resolved after fixing it:
-- UPDATE ETL_ERROR_LOG
-- SET IS_RESOLVED = TRUE, RESOLVED_AT = CURRENT_TIMESTAMP(), RESOLVED_BY = 'your_name'
-- WHERE ERROR_ID = <id>;


-- ═══════════════════════════════════════════════════════════════
-- PERFORMANCE: Slowest tables (last 30 days)
-- ═══════════════════════════════════════════════════════════════
SELECT
    TABLE_NAME, LOAD_MODE,
    COUNT(*)                     AS RUNS,
    ROUND(AVG(DURATION_SECS), 1) AS AVG_SECS,
    MAX(DURATION_SECS)           AS MAX_SECS,
    SUM(ROWS_LOADED)             AS TOTAL_ROWS
FROM ETL_AUDIT
WHERE STATUS     = 'SUCCESS'
  AND START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY TABLE_NAME, LOAD_MODE
ORDER BY AVG_SECS DESC;


-- ═══════════════════════════════════════════════════════════════
-- CONFIG: All active tables and their modes
-- ═══════════════════════════════════════════════════════════════
SELECT
    TABLE_NAME, LOAD_MODE, STAGE_NAME,
    FILE_FORMAT, MERGE_KEYS, CDC_OP_COLUMN,
    WATERMARK_COLUMN, IS_ACTIVE, PRIORITY, NOTES
FROM INGEST_CONFIG
ORDER BY IS_ACTIVE DESC, PRIORITY, TABLE_NAME;
