-- =================================================================
-- 02_sp_audit_logger.sql
-- Snowpark Python stored procedure.
-- Replaces audit_logger.py — runs INSIDE Snowflake, no network calls.
-- =================================================================

CREATE OR REPLACE PROCEDURE sp_audit_start(
    run_id        STRING,
    table_name    STRING,
    target_schema STRING,
    stage_name    STRING,
    load_mode     STRING,
    airflow_run_id STRING,
    dag_id        STRING
)
RETURNS STRING
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'audit_start'
AS $$
import logging
log = logging.getLogger(__name__)

def _e(v):
    return str(v).replace("'", "''")

def audit_start(session, run_id, table_name, target_schema,
                stage_name, load_mode, airflow_run_id, dag_id):
    """
    Insert a STARTED row into ETL_AUDIT.
    Called at the very beginning of sp_load_table so the run is
    visible even if something crashes mid-load.
    """
    log.info(f"[sp_audit_start] table={table_name} run_id={run_id}")
    session.sql(f"""
        INSERT INTO ETL_AUDIT
            (RUN_ID, AIRFLOW_RUN_ID, DAG_ID,
             TABLE_NAME, TARGET_SCHEMA, STAGE_NAME, LOAD_MODE,
             START_TIME, STATUS)
        VALUES
            ('{_e(run_id)}', '{_e(airflow_run_id)}', '{_e(dag_id)}',
             '{_e(table_name)}', '{_e(target_schema)}', '{_e(stage_name)}',
             '{_e(load_mode)}', CURRENT_TIMESTAMP(), 'STARTED')
    """).collect()
    return 'OK'
$$;


CREATE OR REPLACE PROCEDURE sp_audit_success(
    run_id       STRING,
    rows_loaded  NUMBER,
    rows_updated NUMBER,
    rows_deleted NUMBER,
    files_loaded NUMBER,
    bytes_loaded NUMBER
)
RETURNS STRING
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'audit_success'
AS $$
import logging
log = logging.getLogger(__name__)

def audit_success(session, run_id, rows_loaded, rows_updated,
                  rows_deleted, files_loaded, bytes_loaded):
    """
    Update ETL_AUDIT row to SUCCESS with counts.
    Called at the end of a successful sp_load_table run.
    """
    log.info(f"[sp_audit_success] run_id={run_id} rows={rows_loaded}")
    session.sql(f"""
        UPDATE ETL_AUDIT
        SET
            END_TIME     = CURRENT_TIMESTAMP(),
            STATUS       = 'SUCCESS',
            ROWS_LOADED  = {int(rows_loaded  or 0)},
            ROWS_UPDATED = {int(rows_updated or 0)},
            ROWS_DELETED = {int(rows_deleted or 0)},
            FILES_LOADED = {int(files_loaded or 0)},
            BYTES_LOADED = {int(bytes_loaded or 0)}
        WHERE RUN_ID = '{run_id}'
    """).collect()
    return 'OK'
$$;


CREATE OR REPLACE PROCEDURE sp_audit_failure(
    run_id        STRING,
    error_type    STRING,
    error_message STRING,
    stack_trace   STRING,
    table_name    STRING,
    stage_name    STRING,
    load_mode     STRING,
    airflow_run_id STRING
)
RETURNS STRING
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'audit_failure'
AS $$
import logging
log = logging.getLogger(__name__)

def _e(v):
    return str(v or '').replace("'", "''")[:4990]

def audit_failure(session, run_id, error_type, error_message,
                  stack_trace, table_name, stage_name,
                  load_mode, airflow_run_id):
    """
    1. INSERT into ETL_ERROR_LOG (full details).
    2. UPDATE ETL_AUDIT to FAILED.
    Never raises — audit failures must not hide the original load error.
    """
    log.error(f"[sp_audit_failure] table={table_name} run_id={run_id} error={error_message[:200]}")

    try:
        session.sql(f"""
            INSERT INTO ETL_ERROR_LOG
                (RUN_ID, AIRFLOW_RUN_ID, TABLE_NAME, STAGE_NAME,
                 LOAD_MODE, ERROR_TYPE, ERROR_MESSAGE, STACK_TRACE)
            VALUES
                ('{_e(run_id)}', '{_e(airflow_run_id)}',
                 '{_e(table_name)}', '{_e(stage_name)}', '{_e(load_mode)}',
                 '{_e(error_type)}', '{_e(error_message)}', '{_e(stack_trace)}')
        """).collect()
    except Exception as inner:
        log.error(f"[sp_audit_failure] Could not write ETL_ERROR_LOG: {inner}")

    try:
        session.sql(f"""
            UPDATE ETL_AUDIT
            SET
                END_TIME      = CURRENT_TIMESTAMP(),
                STATUS        = 'FAILED',
                ERROR_MESSAGE = '{_e(error_message)}'
            WHERE RUN_ID = '{_e(run_id)}'
        """).collect()
    except Exception as inner:
        log.error(f"[sp_audit_failure] Could not update ETL_AUDIT: {inner}")

    return 'OK'
$$;
