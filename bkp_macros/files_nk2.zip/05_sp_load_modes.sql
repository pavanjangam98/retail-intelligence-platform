-- =================================================================
-- 05_sp_load_modes.sql
-- Three stored procedures — one per LOAD_MODE.
-- All run inside Snowflake compute. No Airflow Python involved.
-- =================================================================


-- ─────────────────────────────────────────────────────────────
-- INCREMENTAL LOAD
-- Copies only NEW files from the stage (skips already-loaded ones).
-- Uses FORCE=FALSE so Snowflake's metadata cache prevents re-loads.
-- Updates ETL_WATERMARK after a successful load.
-- ─────────────────────────────────────────────────────────────
CREATE OR REPLACE PROCEDURE sp_incremental_load(
    run_id        STRING,
    table_name    STRING,
    target_schema STRING,
    stage_name    STRING,
    file_format   STRING,
    file_pattern  STRING
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'incremental_load'
AS $$
import json, traceback, logging
log = logging.getLogger(__name__)

def incremental_load(session, run_id, table_name, target_schema,
                     stage_name, file_format, file_pattern):
    """
    COPY INTO with FORCE=FALSE — Snowflake automatically skips
    files it has already loaded. Safe to re-run: no double-loading.

    Returns a dict with rows_loaded, files_loaded, file_results.
    """
    full_table  = f"{target_schema}.{table_name}"
    pattern_sql = f"PATTERN = '{file_pattern}'" if file_pattern and file_pattern != '.*' else ""

    log.info(f"[sp_incremental_load] table={full_table} stage={stage_name}")

    copy_sql = f"""
        COPY INTO {full_table}
        FROM   {stage_name}
        FILE_FORMAT          = (FORMAT_NAME = {file_format})
        {pattern_sql}
        MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
        ON_ERROR             = CONTINUE
        FORCE                = FALSE
    """

    try:
        raw = session.sql(copy_sql).collect()
    except Exception as exc:
        raise RuntimeError(f"COPY INTO failed for {full_table}: {exc}") from exc

    rows_loaded = 0
    files_ok    = 0
    files_fail  = 0
    last_file   = None
    file_results = []

    for r in raw:
        rd = r.as_dict()
        status     = rd.get('status', '')
        n_loaded   = int(rd.get('rows_loaded', 0) or 0)
        rows_loaded += n_loaded
        file_name   = rd.get('file', '')

        if status == 'LOADED':
            files_ok += 1
            last_file = file_name
        else:
            files_fail += 1
            log.warning(f"[sp_incremental_load] File error: {file_name} status={status} "
                        f"error={rd.get('first_error','')[:200]}")
        file_results.append(rd)

    # Update watermark only on full success
    if last_file and files_fail == 0:
        session.call('sp_watermark_set', table_name, last_file, run_id)

    return {
        "rows_loaded"  : rows_loaded,
        "files_loaded" : files_ok,
        "files_failed" : files_fail,
        "file_results" : file_results
    }
$$;


-- ─────────────────────────────────────────────────────────────
-- FULL LOAD
-- TRUNCATE the target table, then reload ALL files.
-- FORCE=TRUE overrides Snowflake's "already loaded" file cache.
-- Use for dimension tables that are fully replaced each run.
-- ─────────────────────────────────────────────────────────────
CREATE OR REPLACE PROCEDURE sp_full_load(
    run_id        STRING,
    table_name    STRING,
    target_schema STRING,
    stage_name    STRING,
    file_format   STRING,
    file_pattern  STRING
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'full_load'
AS $$
import json, traceback, logging
log = logging.getLogger(__name__)

def full_load(session, run_id, table_name, target_schema,
              stage_name, file_format, file_pattern):
    """
    TRUNCATE then COPY INTO with FORCE=TRUE.
    WARNING: data is gone after TRUNCATE. If COPY fails, the table
    will be empty until the next run or manual recovery.
    """
    full_table  = f"{target_schema}.{table_name}"
    pattern_sql = f"PATTERN = '{file_pattern}'" if file_pattern and file_pattern != '.*' else ""

    log.info(f"[sp_full_load] TRUNCATE {full_table}")
    session.sql(f"TRUNCATE TABLE {full_table}").collect()

    log.info(f"[sp_full_load] COPY INTO {full_table} from {stage_name}")
    copy_sql = f"""
        COPY INTO {full_table}
        FROM   {stage_name}
        FILE_FORMAT          = (FORMAT_NAME = {file_format})
        {pattern_sql}
        MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
        ON_ERROR             = CONTINUE
        FORCE                = TRUE
    """

    try:
        raw = session.sql(copy_sql).collect()
    except Exception as exc:
        raise RuntimeError(f"COPY INTO failed for {full_table} after TRUNCATE: {exc}") from exc

    rows_loaded = 0
    files_ok    = 0
    files_fail  = 0
    file_results = []

    for r in raw:
        rd = r.as_dict()
        rows_loaded += int(rd.get('rows_loaded', 0) or 0)
        if rd.get('status') == 'LOADED':
            files_ok += 1
        else:
            files_fail += 1
            log.warning(f"[sp_full_load] File error: {rd.get('file','')} "
                        f"error={rd.get('first_error','')[:200]}")
        file_results.append(rd)

    return {
        "rows_loaded"  : rows_loaded,
        "files_loaded" : files_ok,
        "files_failed" : files_fail,
        "file_results" : file_results
    }
$$;


-- ─────────────────────────────────────────────────────────────
-- CDC MERGE
-- 1. COPY files into a temp staging table (same schema as target).
-- 2. MERGE staging INTO target on merge_keys:
--      INSERT if new key
--      UPDATE if key exists
--      DELETE if CDC op column = 'D' or 'DELETE'
-- 3. DROP the staging table.
-- ─────────────────────────────────────────────────────────────
CREATE OR REPLACE PROCEDURE sp_cdc_merge(
    run_id         STRING,
    table_name     STRING,
    target_schema  STRING,
    stage_name     STRING,
    file_format    STRING,
    file_pattern   STRING,
    merge_keys     STRING,   -- comma-separated: 'CUSTOMER_ID' or 'ORDER_ID,LINE_ID'
    cdc_op_column  STRING    -- column holding 'I','U','D' or 'INSERT','UPDATE','DELETE'
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'cdc_merge'
AS $$
import uuid, traceback, logging
log = logging.getLogger(__name__)

def _build_merge_condition(merge_keys):
    """Build: tgt.KEY1 = src.KEY1 AND tgt.KEY2 = src.KEY2"""
    keys = [k.strip() for k in merge_keys.split(',')]
    return ' AND '.join(f'tgt.{k} = src.{k}' for k in keys)

def _build_update_set(columns, skip_cols):
    """Build: col1 = src.col1, col2 = src.col2 (excluding keys and op column)"""
    return ', '.join(f'tgt.{c} = src.{c}'
                     for c in columns if c not in skip_cols)

def cdc_merge(session, run_id, table_name, target_schema,
              stage_name, file_format, file_pattern,
              merge_keys, cdc_op_column):

    full_table   = f"{target_schema}.{table_name}"
    staging      = f"{target_schema}.STG_{table_name}_{uuid.uuid4().hex[:8].upper()}"
    pattern_sql  = f"PATTERN = '{file_pattern}'" if file_pattern and file_pattern != '.*' else ""
    key_list     = [k.strip() for k in merge_keys.split(',')]
    skip_cols    = set(key_list + [cdc_op_column])

    log.info(f"[sp_cdc_merge] staging={staging} target={full_table}")

    rows_inserted = 0
    rows_updated  = 0
    rows_deleted  = 0
    files_ok      = 0
    files_fail    = 0
    file_results  = []

    try:
        # Step 1: Create staging table with same structure
        session.sql(f"CREATE TEMP TABLE {staging} LIKE {full_table}").collect()

        # Add CDC op column if target doesn't have it (staging always needs it)
        # We add it only if it's not already in the target schema
        try:
            session.sql(f"ALTER TABLE {staging} ADD COLUMN {cdc_op_column} VARCHAR(10)").collect()
        except Exception:
            pass   # column already exists from LIKE

        # Step 2: COPY INTO staging
        copy_sql = f"""
            COPY INTO {staging}
            FROM   {stage_name}
            FILE_FORMAT          = (FORMAT_NAME = {file_format})
            {pattern_sql}
            MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
            ON_ERROR             = CONTINUE
            FORCE                = FALSE
        """
        raw = session.sql(copy_sql).collect()
        for r in raw:
            rd = r.as_dict()
            files_ok   += 1 if rd.get('status') == 'LOADED' else 0
            files_fail += 0 if rd.get('status') == 'LOADED' else 1
            file_results.append(rd)

        # Step 3: Get target columns for UPDATE SET clause
        col_rows = session.sql(f"""
            SELECT COLUMN_NAME
            FROM   INFORMATION_SCHEMA.COLUMNS
            WHERE  TABLE_SCHEMA = '{target_schema.upper()}'
              AND  TABLE_NAME   = '{table_name.upper()}'
            ORDER  BY ORDINAL_POSITION
        """).collect()
        all_columns = [r['COLUMN_NAME'] for r in col_rows]

        merge_cond   = _build_merge_condition(merge_keys)
        update_set   = _build_update_set(all_columns, skip_cols)
        insert_cols  = ', '.join(c for c in all_columns if c != cdc_op_column)
        insert_vals  = ', '.join(f'src.{c}' for c in all_columns if c != cdc_op_column)

        # Step 4: MERGE INTO target
        # Handles I=INSERT, U=UPDATE, D=DELETE in one pass
        merge_sql = f"""
            MERGE INTO {full_table} tgt
            USING (
                SELECT * FROM {staging}
                WHERE UPPER({cdc_op_column}) NOT IN ('D','DELETE')
            ) src
            ON {merge_cond}
            WHEN MATCHED AND UPPER(src.{cdc_op_column}) IN ('U','UPDATE') THEN
                UPDATE SET {update_set}
            WHEN NOT MATCHED AND UPPER(src.{cdc_op_column}) IN ('I','INSERT') THEN
                INSERT ({insert_cols}) VALUES ({insert_vals})
        """
        merge_result = session.sql(merge_sql).collect()
        if merge_result:
            mr = merge_result[0].as_dict()
            rows_inserted = int(mr.get('number of rows inserted', 0) or 0)
            rows_updated  = int(mr.get('number of rows updated',  0) or 0)

        # Step 5: Handle DELETEs separately (MERGE doesn't support WHEN MATCHED DELETE cleanly)
        key_in_staging = ' AND '.join(
            f"tgt.{k} IN (SELECT {k} FROM {staging} WHERE UPPER({cdc_op_column}) IN ('D','DELETE'))"
            for k in key_list
        )
        del_result = session.sql(f"""
            DELETE FROM {full_table} tgt
            WHERE EXISTS (
                SELECT 1 FROM {staging} src
                WHERE {merge_cond}
                  AND UPPER(src.{cdc_op_column}) IN ('D','DELETE')
            )
        """).collect()
        if del_result:
            rows_deleted = int(del_result[0].as_dict().get('number of rows deleted', 0) or 0)

        log.info(f"[sp_cdc_merge] inserted={rows_inserted} updated={rows_updated} "
                 f"deleted={rows_deleted}")

    finally:
        # Always clean up staging table — even if MERGE failed
        try:
            session.sql(f"DROP TABLE IF EXISTS {staging}").collect()
        except Exception:
            pass

    return {
        "rows_loaded"  : rows_inserted,
        "rows_updated" : rows_updated,
        "rows_deleted" : rows_deleted,
        "files_loaded" : files_ok,
        "files_failed" : files_fail,
        "file_results" : file_results
    }
$$;
