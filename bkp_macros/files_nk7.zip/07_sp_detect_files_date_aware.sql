-- =================================================================
-- 07_sp_detect_files.sql  (updated)
-- File-arrival detection — supports two modes:
--
-- MODE A: TIMESTAMP-BASED (FILE_PATTERN has no date token)
--   Compares newest file's LAST_MODIFIED against the prior poll.
--   Works for any filename pattern. Original behaviour preserved.
--
-- MODE B: FILENAME-BASED (FILE_PATTERN contains yyyymmdd/yyyyMMdd)
--   Resolves the expected filename for today + DATE_OFFSET, then
--   checks whether that exact filename exists in the stage.
--   e.g. FILE_PATTERN='customer_yyyyMMdd.csv', DATE_OFFSET=0
--   → looks for 'customer_20240115.csv' on a Jan 15 run
--   e.g. FILE_PATTERN='address_yyyyMMdd.csv', DATE_OFFSET=-1
--   → looks for 'address_20240114.csv' on a Jan 15 run
--
-- IS_MANDATORY controls error behaviour per table:
--   TRUE  → missing expected file raises an error (fails the sensor)
--   FALSE → missing expected file logs a warning, continues
--
-- Called by the Airflow wait_for_files sensor task with the current
-- run date passed in as run_date_str (format: 'YYYY-MM-DD').
-- =================================================================

CREATE OR REPLACE PROCEDURE sp_detect_new_files(
    source_schema STRING,
    run_date_str  STRING    -- 'YYYY-MM-DD', passed by Airflow sensor task
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'detect_files'
AS $$
import re
import logging
from datetime import datetime, timedelta

log = logging.getLogger(__name__)

def _e(v):
    return str(v or '').replace("'", "''")

def _has_date_token(pattern):
    """Returns True if the FILE_PATTERN contains a date placeholder."""
    if not pattern:
        return False
    p = pattern.lower()
    return 'yyyymmdd' in p or 'yyyymm' in p

def _resolve_filename(pattern, run_date, offset_days):
    """
    Replaces date tokens in FILE_PATTERN with the actual resolved date.

    Supported tokens (case-insensitive in detection, replaced as written):
      yyyyMMdd  → 20240115   (ISO date, uppercase MM = month)
      yyyymmdd  → 20240115   (same value, lowercase token)
      yyyyMM    → 202401     (year-month only)
      yyyy      → 2024

    DATE_OFFSET shifts the date: 0=today, -1=yesterday, -7=last week.
    """
    target = run_date + timedelta(days=int(offset_days or 0))
    yyyy   = target.strftime('%Y')
    MM     = target.strftime('%m')
    dd     = target.strftime('%d')

    resolved = pattern
    # Order matters — replace longer tokens first
    resolved = re.sub(r'yyyyMMdd', f'{yyyy}{MM}{dd}', resolved)
    resolved = re.sub(r'yyyymmdd', f'{yyyy}{MM}{dd}', resolved, flags=re.IGNORECASE)
    resolved = re.sub(r'yyyyMM',   f'{yyyy}{MM}',     resolved)
    resolved = re.sub(r'yyyymm',   f'{yyyy}{MM}',     resolved, flags=re.IGNORECASE)
    resolved = re.sub(r'yyyy',     f'{yyyy}',         resolved, flags=re.IGNORECASE)
    return resolved

def detect_files(session, source_schema, run_date_str):
    """
    Main detection function. Iterates every active table for this source.
    Groups tables by stage, lists each stage once, then checks per-table.
    """
    # Parse run date
    try:
        run_date = datetime.strptime(run_date_str.strip(), '%Y-%m-%d').date()
        from datetime import date
        run_date = datetime(run_date.year, run_date.month, run_date.day)
    except Exception as exc:
        return {"any_new_files": False, "error": f"Invalid run_date_str '{run_date_str}': {exc}"}

    # Load all active tables for this source
    table_rows = session.sql(f"""
        SELECT TABLE_NAME, STAGE_NAME, FILE_PATTERN,
               COALESCE(DATE_OFFSET, 0)   AS DATE_OFFSET,
               COALESCE(IS_MANDATORY, TRUE) AS IS_MANDATORY
        FROM CONFIG.INGEST_CONFIG
        WHERE SOURCE_SCHEMA = '{_e(source_schema)}'
          AND IS_ACTIVE     = TRUE
        ORDER BY TABLE_NAME
    """).collect()

    if not table_rows:
        return {
            "any_new_files": False, "stages_checked": 0,
            "missing_mandatory": [], "details": [],
            "reason": "No active tables configured for this source"
        }

    # List each distinct stage ONCE and cache results
    stage_file_sets = {}
    stage_newest_ts = {}

    distinct_stages = set(r['STAGE_NAME'] for r in table_rows)
    for stage_name in distinct_stages:
        try:
            raw = session.sql(f"LIST {stage_name}").collect()
        except Exception as exc:
            log.error(f"[sp_detect_new_files] LIST failed for {stage_name}: {exc}")
            stage_file_sets[stage_name] = set()
            stage_newest_ts[stage_name] = None
            continue

        # Build a set of just the bare filenames (strip directory prefix)
        filenames = set()
        newest_ts = None
        for f in raw:
            fd = f.as_dict()
            full_name = fd.get('name', '')
            # LIST returns 'stagename/filename' — keep only the filename part
            bare = full_name.split('/')[-1]
            filenames.add(bare)
            filenames.add(full_name)   # also index the full path for safety

            ts = fd.get('last_modified')
            if ts and (newest_ts is None or ts > newest_ts):
                newest_ts = ts

        stage_file_sets[stage_name] = filenames
        stage_newest_ts[stage_name] = newest_ts

    # Evaluate per table
    all_ready       = True
    missing_mandatory = []
    details         = []
    any_new_ts      = False   # for timestamp-based tables

    for r in table_rows:
        table_name   = r['TABLE_NAME']
        stage_name   = r['STAGE_NAME']
        file_pattern = r['FILE_PATTERN'] or '.*'
        date_offset  = r['DATE_OFFSET']
        is_mandatory = r['IS_MANDATORY']

        filenames = stage_file_sets.get(stage_name, set())
        use_date_mode = _has_date_token(file_pattern)

        if use_date_mode:
            # ── MODE B: filename-based ────────────────────────────────
            expected = _resolve_filename(file_pattern, run_date, date_offset)
            found = any(
                expected.lower() in fname.lower()
                for fname in filenames
            )
            status = "FOUND" if found else "MISSING"
            details.append({
                "table_name"  : table_name,
                "stage_name"  : stage_name,
                "mode"        : "FILENAME",
                "expected_file": expected,
                "status"      : status,
                "is_mandatory": is_mandatory,
            })
            log.info(f"[sp_detect_new_files] table={table_name} expected={expected} status={status}")
            if not found:
                if is_mandatory:
                    missing_mandatory.append(expected)
                    all_ready = False
                else:
                    log.warning(f"[sp_detect_new_files] OPTIONAL file missing: {expected} — continuing")
        else:
            # ── MODE A: timestamp-based (original behaviour) ──────────
            newest_ts = stage_newest_ts.get(stage_name)
            prior_ts  = _get_prior_ts(session, stage_name)
            is_new = (newest_ts is not None and
                      (prior_ts is None or newest_ts > prior_ts))
            if is_new:
                any_new_ts = True
            details.append({
                "table_name"  : table_name,
                "stage_name"  : stage_name,
                "mode"        : "TIMESTAMP",
                "is_new"      : is_new,
                "is_mandatory": is_mandatory,
            })

    # Update ETL_STAGE_DETECTION for timestamp-based stages
    for stage_name in distinct_stages:
        newest_ts = stage_newest_ts.get(stage_name)
        file_count = len([f for f in stage_file_sets.get(stage_name, set())
                          if '/' not in f])   # count bare filenames only
        _upsert_detection(session, stage_name, source_schema,
                          newest_ts, file_count, any_new_ts)

    # Final verdict
    date_mode_tables = [d for d in details if d['mode'] == 'FILENAME']
    ts_mode_tables   = [d for d in details if d['mode'] == 'TIMESTAMP']

    if date_mode_tables:
        # Date-pattern mode: ready when ALL mandatory files are present
        overall_ready = len(missing_mandatory) == 0
    else:
        # Timestamp mode: ready when any stage has advanced
        overall_ready = any_new_ts

    if missing_mandatory:
        log.warning(f"[sp_detect_new_files] Missing mandatory files: {missing_mandatory}")

    return {
        "any_new_files"    : overall_ready,
        "source_schema"    : source_schema,
        "run_date"         : run_date_str,
        "stages_checked"   : len(distinct_stages),
        "missing_mandatory": missing_mandatory,
        "details"          : details,
    }


def _get_prior_ts(session, stage_name):
    """Read the last-seen timestamp for a stage from ETL_STAGE_DETECTION."""
    rows = session.sql(f"""
        SELECT LAST_FILE_SEEN_TS
        FROM CONFIG.ETL_STAGE_DETECTION
        WHERE STAGE_NAME = '{_e(stage_name)}'
    """).collect()
    return rows[0]['LAST_FILE_SEEN_TS'] if rows else None


def _upsert_detection(session, stage_name, source_schema,
                      newest_ts, file_count, is_new):
    """Persist latest poll result to ETL_STAGE_DETECTION."""
    ts_sql = f"'{newest_ts}'" if newest_ts else "NULL"
    session.sql(f"""
        MERGE INTO CONFIG.ETL_STAGE_DETECTION tgt
        USING (SELECT
                   '{_e(stage_name)}'    AS STAGE_NAME,
                   '{_e(source_schema)}' AS SOURCE_SCHEMA,
                   CURRENT_TIMESTAMP()   AS LAST_POLLED_AT,
                   {ts_sql}             AS NEWEST_TS,
                   {file_count}         AS FILES_FOUND,
                   {str(is_new).upper()} AS IS_NEW
              ) src
        ON tgt.STAGE_NAME = src.STAGE_NAME
        WHEN MATCHED THEN UPDATE SET
            LAST_POLLED_AT        = src.LAST_POLLED_AT,
            LAST_FILE_SEEN_TS     = CASE WHEN src.IS_NEW THEN src.NEWEST_TS
                                         ELSE tgt.LAST_FILE_SEEN_TS END,
            FILES_FOUND_LAST_POLL = src.FILES_FOUND,
            NEW_FILES_DETECTED    = src.IS_NEW,
            POLL_COUNT            = tgt.POLL_COUNT + 1,
            UPDATED_AT            = CURRENT_TIMESTAMP()
        WHEN NOT MATCHED THEN INSERT
            (STAGE_NAME, SOURCE_SCHEMA, LAST_POLLED_AT, LAST_FILE_SEEN_TS,
             FILES_FOUND_LAST_POLL, NEW_FILES_DETECTED, POLL_COUNT)
        VALUES
            (src.STAGE_NAME, src.SOURCE_SCHEMA, src.LAST_POLLED_AT,
             CASE WHEN src.IS_NEW THEN src.NEWEST_TS ELSE NULL END,
             src.FILES_FOUND, src.IS_NEW, 1)
    """).collect()
$$;
