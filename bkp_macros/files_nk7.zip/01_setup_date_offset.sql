-- =================================================================
-- 01_setup_scaled.sql
-- Run ONCE. Adds: dedicated warehouses, resource monitor,
-- batch-aware INGEST_CONFIG, persistent CDC staging registry.
-- =================================================================

USE ROLE ACCOUNTADMIN;
CREATE DATABASE IF NOT EXISTS RAMU;
USE DATABASE RAMU;
CREATE SCHEMA IF NOT EXISTS CONFIG;    -- control tables AND stored procedures
CREATE SCHEMA IF NOT EXISTS RAW;       -- final landed/target tables
CREATE SCHEMA IF NOT EXISTS STAGING;   -- persistent CDC staging tables live here
USE SCHEMA CONFIG;

-- ── Resource monitor — hard credit cap ───────────────────────
-- This is your safety net. If something runs away (bad regex,
-- infinite retry loop, runaway CDC job), the warehouse suspends
-- itself instead of burning credits unattended.
CREATE OR REPLACE RESOURCE MONITOR rm_ingestion_guard
    WITH
        CREDIT_QUOTA = 500                      -- adjust to your monthly budget
        FREQUENCY    = MONTHLY
        START_TIMESTAMP = IMMEDIATELY
        TRIGGERS
            ON 75  PERCENT DO NOTIFY
            ON 90  PERCENT DO NOTIFY
            ON 100 PERCENT DO SUSPEND            -- finishes running queries, blocks new ones
            ON 110 PERCENT DO SUSPEND_IMMEDIATE; -- kills everything, last resort

-- ── Two warehouses — isolate CDC from simple loads ───────────
-- INCREMENTAL/FULL_LOAD are cheap COPY operations — small warehouse,
-- scales out wide (more concurrent batches).
CREATE WAREHOUSE IF NOT EXISTS WH_INCREMENTAL
    WAREHOUSE_SIZE          = 'SMALL'
    MIN_CLUSTER_COUNT       = 1
    MAX_CLUSTER_COUNT       = 4        -- scales OUT for concurrency, not UP for size
    SCALING_POLICY          = 'STANDARD'
    AUTO_SUSPEND             = 60
    AUTO_RESUME              = TRUE
    RESOURCE_MONITOR         = rm_ingestion_guard
    COMMENT                  = 'Incremental + full-load batches';

-- CDC does staging + MERGE + DELETE — heavier per-table, but fewer
-- tables are usually CDC. Bigger warehouse, less concurrency needed.
CREATE WAREHOUSE IF NOT EXISTS WH_CDC
    WAREHOUSE_SIZE          = 'MEDIUM'
    MIN_CLUSTER_COUNT       = 1
    MAX_CLUSTER_COUNT       = 2
    SCALING_POLICY          = 'STANDARD'
    AUTO_SUSPEND             = 60
    AUTO_RESUME              = TRUE
    RESOURCE_MONITOR         = rm_ingestion_guard
    COMMENT                  = 'CDC merge batches — isolated from incremental load';

-- ── File formats (unchanged) ──────────────────────────────────
CREATE OR REPLACE FILE FORMAT CSV_FORMAT
    TYPE = CSV SKIP_HEADER = 1
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    NULL_IF = ('NULL','null','') EMPTY_FIELD_AS_NULL = TRUE;
CREATE OR REPLACE FILE FORMAT PARQUET_FORMAT TYPE = PARQUET;
CREATE OR REPLACE FILE FORMAT JSON_FORMAT TYPE = JSON STRIP_OUTER_ARRAY = TRUE;

-- ── INGEST_CONFIG — now batch-aware ───────────────────────────
-- BATCH_GROUP: tables sharing the same batch run together in one
--              stored procedure CALL (loop happens inside Snowflake).
-- WAREHOUSE_NAME: which warehouse runs this table's batch.
-- Both are computed automatically by sp_assign_batches if left NULL —
-- see 03_sp_batch_assignment.sql.
CREATE OR REPLACE TABLE INGEST_CONFIG (
    CONFIG_ID        NUMBER        AUTOINCREMENT PRIMARY KEY,
    TABLE_NAME       VARCHAR(255)  NOT NULL,
    -- SOURCE_SCHEMA: the source system / feed this table's files come from.
    -- This is now the DAG boundary — one DAG per SOURCE_SCHEMA.
    SOURCE_SCHEMA    VARCHAR(100)  NOT NULL,
    -- TARGET_SCHEMA: where the table actually lands in Snowflake.
    -- Independent of SOURCE_SCHEMA — most tables land in RAW, but a
    -- source can in principle write into more than one target schema
    -- (e.g. a source feeding both RAW and a smaller QUARANTINE schema
    -- for rejected records). One row = one table = one fixed target.
    TARGET_SCHEMA    VARCHAR(100)  DEFAULT 'RAW',
    STAGE_NAME       VARCHAR(500)  NOT NULL,
    FILE_FORMAT      VARCHAR(100)  NOT NULL,
    FILE_PATTERN     VARCHAR(500)  DEFAULT '.*',
    LOAD_MODE        VARCHAR(20)   NOT NULL
                     CHECK (LOAD_MODE IN ('INCREMENTAL','FULL_LOAD','CDC_MERGE')),
    MERGE_KEYS       VARCHAR(500),
    CDC_OP_COLUMN    VARCHAR(100),
    WATERMARK_COLUMN VARCHAR(100),
    IS_ACTIVE        BOOLEAN       DEFAULT TRUE,
    PRIORITY         NUMBER        DEFAULT 100,
    -- Batching — auto-assigned, or set manually for fine control
    BATCH_GROUP       NUMBER,
    WAREHOUSE_NAME    VARCHAR(100),
    -- Persistent CDC staging table name (created once, reused forever)
    STAGING_TABLE     VARCHAR(255),
    -- Date-pattern file detection columns (from image: DATE_OFFSET, MANDATORY)
    -- FILE_PATTERN already exists above — holds the regex/template like
    -- 'customer_yyyyMMdd.csv'. The tokens yyyyMMdd / yyyymmdd are resolved
    -- at detection time using today's date plus DATE_OFFSET days.
    DATE_OFFSET       NUMBER        DEFAULT 0,
    -- 0  = today's date    (customer_20240115.csv for a Jan 15 run)
    -- -1 = yesterday       (address_20240114.csv  for a Jan 15 run)
    -- -7 = one week ago
    IS_MANDATORY      BOOLEAN       DEFAULT TRUE,
    -- TRUE  = missing expected file → FAIL the sensor task immediately
    -- FALSE = missing expected file → log warning, continue processing
    NOTES             VARCHAR(1000),
    CREATED_AT        TIMESTAMP     DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_AT        TIMESTAMP     DEFAULT CURRENT_TIMESTAMP(),
    -- SAFETY CONSTRAINT: one (TARGET_SCHEMA, TABLE_NAME) pair can only
    -- ever belong to ONE row, which means ONE SOURCE_SCHEMA. This is
    -- what makes it safe for two source-DAGs to run concurrently even
    -- though they may write into the same target schema — they can
    -- never claim the same target TABLE, because the table is uniquely
    -- owned by exactly one source at the config level.
    CONSTRAINT UQ_TARGET_TABLE UNIQUE (TARGET_SCHEMA, TABLE_NAME)
);

-- Sample rows demonstrating both timestamp-mode and filename-mode detection.
-- FILE_PATTERN with yyyyMMdd tokens → sp_detect_new_files uses Mode B (filename check).
-- FILE_PATTERN without date tokens  → sp_detect_new_files uses Mode A (timestamp check).
INSERT INTO INGEST_CONFIG
    (TABLE_NAME, SOURCE_SCHEMA, TARGET_SCHEMA, STAGE_NAME, FILE_FORMAT,
     FILE_PATTERN, DATE_OFFSET, IS_MANDATORY, LOAD_MODE, PRIORITY, NOTES)
VALUES
    -- customer file: today's date, mandatory, fail sensor if missing
    ('ORDERS',   'SAP_ERP', 'RAW', '@STAGING.SAP_ORDERS_STAGE', 'PARQUET_FORMAT',
     'orders_yyyyMMdd.parquet', 0, TRUE, 'INCREMENTAL', 10, 'SAP feeds RAW.ORDERS — date pattern'),
    -- GL entries use yesterday's date (closes on D-1), mandatory
    ('GL_ENTRIES','SAP_ERP', 'RAW', '@STAGING.SAP_GL_STAGE', 'CSV_FORMAT',
     'gl_entries_yyyyMMdd.csv', -1, TRUE, 'INCREMENTAL', 10, 'Yesterday date offset'),
    -- Leads: no date pattern, sensor falls back to timestamp mode
    ('LEADS',    'SALESFORCE', 'RAW', '@STAGING.SFDC_LEADS_STAGE', 'JSON_FORMAT',
     '.*leads.*\.json', 0, TRUE, 'FULL_LOAD', 20, 'Timestamp mode — no date token in pattern'),
    -- Discount: optional file, missing it is a warning not a failure
    ('CAMPAIGNS', 'SALESFORCE', 'RAW', '@STAGING.SFDC_CAMPAIGNS_STAGE', 'JSON_FORMAT',
     'campaigns_yyyyMMdd.json', 0, FALSE, 'FULL_LOAD', 20, 'Optional — missing file = warning only');

INSERT INTO INGEST_CONFIG
    (TABLE_NAME, SOURCE_SCHEMA, TARGET_SCHEMA, STAGE_NAME, FILE_FORMAT,
     FILE_PATTERN, DATE_OFFSET, IS_MANDATORY, LOAD_MODE, MERGE_KEYS, CDC_OP_COLUMN, PRIORITY, NOTES)
VALUES
    ('AR_TRANSACTIONS', 'KAFKA_CDC', 'RAW', '@STAGING.KAFKA_AR_STAGE', 'JSON_FORMAT',
     'ar_txn_yyyyMMdd.json', 0, TRUE, 'CDC_MERGE', 'TXN_ID', 'OP_TYPE', 30,
     'Near-real-time CDC with date-pattern filename');

-- ── SOURCE_REGISTRY — one row per source system, drives DAG factory ──
-- The dag_factory.py reads this table at parse time to know which
-- DAGs to generate and what schedule/owner/email each one gets.
-- DAG boundary = SOURCE_SCHEMA, not TARGET_SCHEMA, because ingestion
-- timing, retry policy, and ownership naturally follow the *source*
-- system (when does SAP_ERP drop files?) not the destination.
-- Add a row here whenever onboarding a brand-new source system.
CREATE OR REPLACE TABLE SOURCE_REGISTRY (
    SOURCE_SCHEMA   VARCHAR(100)  PRIMARY KEY,
    SCHEDULE_CRON   VARCHAR(100)  DEFAULT '@daily',  -- Airflow cron/preset per source
    OWNER           VARCHAR(100)  DEFAULT 'data-engineering',
    ALERT_EMAIL     VARCHAR(255),
    MAX_ACTIVE_TASKS NUMBER       DEFAULT 5,          -- concurrency cap for this source's DAG
    -- File-arrival detection — the DAG waits for new files before loading
    ENABLE_FILE_SENSOR  BOOLEAN  DEFAULT TRUE,        -- FALSE = skip detection, run on cron alone
    SENSOR_POKE_INTERVAL_SECS NUMBER DEFAULT 300,     -- how often to poll stages (5 min default)
    SENSOR_TIMEOUT_SECS       NUMBER DEFAULT 7200,    -- give up waiting after 2 hours (default)
    SENSOR_MODE         VARCHAR(20) DEFAULT 'reschedule'  -- 'reschedule' frees the worker slot between polls
                        CHECK (SENSOR_MODE IN ('poke','reschedule')),
    IS_ACTIVE       BOOLEAN       DEFAULT TRUE,
    NOTES           VARCHAR(1000),
    CREATED_AT      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP()
);

-- Sample rows — one per source system
-- KAFKA_CDC polls every 60s with a 20min timeout since it's near-real-time.
-- SAP_ERP polls every 5min with a 2hr timeout — nightly batch, less urgent.
INSERT INTO SOURCE_REGISTRY
    (SOURCE_SCHEMA, SCHEDULE_CRON, OWNER, ALERT_EMAIL, MAX_ACTIVE_TASKS,
     SENSOR_POKE_INTERVAL_SECS, SENSOR_TIMEOUT_SECS, NOTES)
VALUES
    ('SAP_ERP',     '0 2 * * *',    'erp-integration-team', 'erp-integration@company.com', 8,
     300, 7200,  'Nightly SAP extract, lands in RAW'),
    ('SALESFORCE',  '@daily',       'crm-data-eng',          'crm-data-eng@company.com',    6,
     300, 7200,  'Daily CRM export, lands in RAW'),
    ('KAFKA_CDC',   '*/15 * * * *', 'streaming-team',        'streaming-team@company.com',  4,
     60,  1200,  'CDC topic dump every 15 min, lands in RAW');

-- ── ETL_AUDIT — same shape, but now BATCH_ID groups many tables ──
CREATE OR REPLACE TABLE ETL_AUDIT (
    AUDIT_ID         NUMBER        AUTOINCREMENT PRIMARY KEY,
    RUN_ID           VARCHAR(64)   NOT NULL,
    BATCH_ID         VARCHAR(64),             -- groups all tables loaded in one SP call
    SOURCE_SCHEMA    VARCHAR(100),            -- which source-DAG produced this row
    TARGET_SCHEMA    VARCHAR(100),            -- where the table actually landed
    AIRFLOW_RUN_ID   VARCHAR(500),
    DAG_ID           VARCHAR(255),
    TABLE_NAME       VARCHAR(255)  NOT NULL,
    TARGET_SCHEMA    VARCHAR(100),
    STAGE_NAME       VARCHAR(500),
    LOAD_MODE        VARCHAR(20),
    WAREHOUSE_NAME   VARCHAR(100),
    START_TIME       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP(),
    END_TIME         TIMESTAMP,
    DURATION_SECS    NUMBER GENERATED ALWAYS AS (DATEDIFF('second', START_TIME, END_TIME)) VIRTUAL,
    STATUS           VARCHAR(20)   CHECK (STATUS IN ('STARTED','SUCCESS','FAILED','SKIPPED')),
    ROWS_LOADED      NUMBER DEFAULT 0,
    ROWS_UPDATED     NUMBER DEFAULT 0,
    ROWS_DELETED     NUMBER DEFAULT 0,
    FILES_LOADED     NUMBER DEFAULT 0,
    ERROR_MESSAGE    VARCHAR(5000),
    CREATED_AT       TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE ETL_ERROR_LOG (
    ERROR_ID       NUMBER AUTOINCREMENT PRIMARY KEY,
    RUN_ID         VARCHAR(64),
    BATCH_ID       VARCHAR(64),
    TABLE_NAME     VARCHAR(255),
    LOAD_MODE      VARCHAR(20),
    ERROR_TIME     TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
    ERROR_TYPE     VARCHAR(100),
    ERROR_MESSAGE  VARCHAR(5000),
    STACK_TRACE    VARCHAR(10000),
    IS_RESOLVED    BOOLEAN DEFAULT FALSE,
    RESOLVED_AT    TIMESTAMP,
    RESOLVED_BY    VARCHAR(100)
);

CREATE OR REPLACE TABLE ETL_COPY_RESULTS (
    RESULT_ID             NUMBER AUTOINCREMENT PRIMARY KEY,
    RUN_ID                VARCHAR(64),
    BATCH_ID               VARCHAR(64),
    TABLE_NAME             VARCHAR(255),
    FILE_NAME              VARCHAR(1000),
    STATUS                 VARCHAR(50),
    ROWS_PARSED             NUMBER,
    ROWS_LOADED             NUMBER,
    ERRORS_SEEN             NUMBER,
    FIRST_ERROR             VARCHAR(2000),
    FIRST_ERROR_LINE        NUMBER,
    ERROR_COLUMN_NAME       VARCHAR(255),
    CREATED_AT              TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE ETL_WATERMARK (
    WATERMARK_ID     NUMBER AUTOINCREMENT PRIMARY KEY,
    TABLE_NAME       VARCHAR(255) NOT NULL UNIQUE,
    LAST_LOADED_FILE VARCHAR(1000),
    LAST_LOADED_TS   TIMESTAMP,
    LAST_RUN_ID      VARCHAR(64),
    UPDATED_AT       TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- ── ETL_STAGE_DETECTION — tracks file-arrival polling per stage ──────
-- One row per distinct STAGE_NAME. The file-sensor task updates this
-- on every poll, whether or not new files were found, so you always
-- know when a stage was last checked and what was seen.
CREATE OR REPLACE TABLE ETL_STAGE_DETECTION (
    DETECTION_ID       NUMBER AUTOINCREMENT PRIMARY KEY,
    STAGE_NAME         VARCHAR(500)  NOT NULL UNIQUE,
    SOURCE_SCHEMA       VARCHAR(100),
    LAST_POLLED_AT      TIMESTAMP,
    LAST_FILE_SEEN      VARCHAR(1000),       -- most recent file name at last poll
    LAST_FILE_SEEN_TS   TIMESTAMP,           -- that file's LAST_MODIFIED from LIST
    FILES_FOUND_LAST_POLL NUMBER DEFAULT 0,
    NEW_FILES_DETECTED  BOOLEAN DEFAULT FALSE,  -- true if LAST_FILE_SEEN_TS advanced since prior poll
    POLL_COUNT          NUMBER DEFAULT 0,
    UPDATED_AT          TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- Per-source detection summary — what the sensor saw on its last poll
CREATE OR REPLACE VIEW V_STAGE_DETECTION_STATUS AS
SELECT
    SOURCE_SCHEMA,
    STAGE_NAME,
    LAST_POLLED_AT,
    LAST_FILE_SEEN,
    LAST_FILE_SEEN_TS,
    FILES_FOUND_LAST_POLL,
    NEW_FILES_DETECTED,
    DATEDIFF('minute', LAST_POLLED_AT, CURRENT_TIMESTAMP()) AS MINUTES_SINCE_POLL
FROM ETL_STAGE_DETECTION
ORDER BY SOURCE_SCHEMA, STAGE_NAME;

-- ── Batch run summary view — for monitoring 1000 tables at a glance ──
CREATE OR REPLACE VIEW V_BATCH_SUMMARY AS
SELECT
    BATCH_ID,
    SOURCE_SCHEMA,
    TARGET_SCHEMA,
    WAREHOUSE_NAME,
    LOAD_MODE,
    MIN(START_TIME)                                    AS BATCH_START,
    MAX(END_TIME)                                       AS BATCH_END,
    COUNT(*)                                            AS TABLE_COUNT,
    SUM(CASE WHEN STATUS='SUCCESS' THEN 1 ELSE 0 END)  AS SUCCESS_COUNT,
    SUM(CASE WHEN STATUS='FAILED'  THEN 1 ELSE 0 END)  AS FAILED_COUNT,
    SUM(ROWS_LOADED)                                    AS TOTAL_ROWS
FROM ETL_AUDIT
GROUP BY BATCH_ID, SOURCE_SCHEMA, TARGET_SCHEMA, WAREHOUSE_NAME, LOAD_MODE
ORDER BY BATCH_START DESC;

-- Per-source rollup — what each source-DAG's last run looked like
CREATE OR REPLACE VIEW V_SOURCE_SUMMARY AS
SELECT
    SOURCE_SCHEMA,
    DATE_TRUNC('day', START_TIME)                       AS RUN_DATE,
    COUNT(DISTINCT TABLE_NAME)                           AS TABLE_COUNT,
    COUNT(DISTINCT TARGET_SCHEMA)                        AS TARGET_SCHEMA_COUNT,
    SUM(CASE WHEN STATUS='SUCCESS' THEN 1 ELSE 0 END)  AS SUCCESS_COUNT,
    SUM(CASE WHEN STATUS='FAILED'  THEN 1 ELSE 0 END)  AS FAILED_COUNT,
    SUM(ROWS_LOADED)                                    AS TOTAL_ROWS,
    ROUND(AVG(DURATION_SECS), 1)                         AS AVG_DURATION_SECS
FROM ETL_AUDIT
GROUP BY SOURCE_SCHEMA, 2
ORDER BY 2 DESC, 1;

-- Fan-out map — which sources write into which targets (for impact analysis)
-- e.g. "if SAP_ERP's DAG fails, which target schemas are affected?"
CREATE OR REPLACE VIEW V_SOURCE_TARGET_MAP AS
SELECT
    SOURCE_SCHEMA,
    TARGET_SCHEMA,
    COUNT(*)         AS TABLE_COUNT,
    LISTAGG(DISTINCT LOAD_MODE, ', ') WITHIN GROUP (ORDER BY LOAD_MODE) AS LOAD_MODES
FROM INGEST_CONFIG
WHERE IS_ACTIVE = TRUE
GROUP BY SOURCE_SCHEMA, TARGET_SCHEMA
ORDER BY SOURCE_SCHEMA, TARGET_SCHEMA;

CREATE OR REPLACE VIEW V_LATEST_STATUS AS
SELECT
    TABLE_NAME,
    MAX_BY(LOAD_MODE,     START_TIME) AS LOAD_MODE,
    MAX_BY(STATUS,        START_TIME) AS LAST_STATUS,
    MAX(START_TIME)                   AS LAST_RUN_AT,
    MAX_BY(ROWS_LOADED,   START_TIME) AS LAST_ROWS_LOADED,
    MAX_BY(DURATION_SECS, START_TIME) AS LAST_DURATION_SECS
FROM ETL_AUDIT
GROUP BY TABLE_NAME;

CREATE OR REPLACE VIEW V_OPEN_ERRORS AS
SELECT e.ERROR_ID, e.TABLE_NAME, e.LOAD_MODE, e.ERROR_TIME,
       e.ERROR_TYPE, e.ERROR_MESSAGE, a.BATCH_ID
FROM ETL_ERROR_LOG e JOIN ETL_AUDIT a ON e.RUN_ID = a.RUN_ID
WHERE e.IS_RESOLVED = FALSE ORDER BY e.ERROR_TIME DESC;

-- ── Warehouse credit usage — watch this weekly ────────────────
CREATE OR REPLACE VIEW V_WAREHOUSE_COST AS
SELECT
    WAREHOUSE_NAME,
    DATE_TRUNC('day', START_TIME) AS USAGE_DATE,
    SUM(CREDITS_USED)             AS CREDITS_USED
FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
WHERE WAREHOUSE_NAME IN ('WH_INCREMENTAL', 'WH_CDC')
GROUP BY 1, 2
ORDER BY 2 DESC, 1;

-- ── Grants ────────────────────────────────────────────────────
-- Tables and procedures share the CONFIG schema, but grant them
-- SEPARATELY so a role that needs to read audit history doesn't
-- automatically gain the ability to trigger loads.
--
-- Adjust role names to match your account. These are illustrative —
-- replace DATA_ENGINEER / DATA_MONITOR with your actual roles.

-- Data engineering role: full access — can call procedures and
-- read/write every control table.
GRANT USAGE  ON SCHEMA CONFIG TO ROLE DATA_ENGINEER;
GRANT USAGE  ON SCHEMA RAW    TO ROLE DATA_ENGINEER;
GRANT USAGE  ON SCHEMA STAGING TO ROLE DATA_ENGINEER;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES    IN SCHEMA CONFIG TO ROLE DATA_ENGINEER;
GRANT SELECT, INSERT, UPDATE, DELETE ON FUTURE TABLES  IN SCHEMA CONFIG TO ROLE DATA_ENGINEER;
GRANT EXECUTE  ON ALL PROCEDURES    IN SCHEMA CONFIG TO ROLE DATA_ENGINEER;
GRANT EXECUTE  ON FUTURE PROCEDURES IN SCHEMA CONFIG TO ROLE DATA_ENGINEER;
GRANT ALL      ON ALL TABLES        IN SCHEMA RAW     TO ROLE DATA_ENGINEER;
GRANT ALL      ON ALL TABLES        IN SCHEMA STAGING  TO ROLE DATA_ENGINEER;

-- Monitoring / BI role: read-only on audit and reporting views —
-- explicitly NO procedure execution rights, so this role can never
-- trigger a load, only observe past runs.
GRANT USAGE  ON SCHEMA CONFIG TO ROLE DATA_MONITOR;
GRANT SELECT ON TABLE  ETL_AUDIT             TO ROLE DATA_MONITOR;
GRANT SELECT ON TABLE  ETL_ERROR_LOG         TO ROLE DATA_MONITOR;
GRANT SELECT ON TABLE  ETL_COPY_RESULTS      TO ROLE DATA_MONITOR;
GRANT SELECT ON TABLE  ETL_STAGE_DETECTION   TO ROLE DATA_MONITOR;
GRANT SELECT ON VIEW   V_LATEST_STATUS       TO ROLE DATA_MONITOR;
GRANT SELECT ON VIEW   V_BATCH_SUMMARY       TO ROLE DATA_MONITOR;
GRANT SELECT ON VIEW   V_SOURCE_SUMMARY      TO ROLE DATA_MONITOR;
GRANT SELECT ON VIEW   V_SOURCE_TARGET_MAP   TO ROLE DATA_MONITOR;
GRANT SELECT ON VIEW   V_OPEN_ERRORS         TO ROLE DATA_MONITOR;
GRANT SELECT ON VIEW   V_STAGE_DETECTION_STATUS TO ROLE DATA_MONITOR;
GRANT SELECT ON VIEW   V_WAREHOUSE_COST      TO ROLE DATA_MONITOR;

-- Airflow's Snowflake connection should use DATA_ENGINEER (or a
-- narrower role with the same CONFIG-schema grants) — it needs to
-- both call procedures (CALL sp_load_batch) and read INGEST_CONFIG /
-- SOURCE_REGISTRY directly for get_batches / dag_factory.py.
