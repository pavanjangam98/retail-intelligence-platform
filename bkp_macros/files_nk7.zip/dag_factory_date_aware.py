"""
dag_factory.py — Generates one DAG per SOURCE_SCHEMA
========================================================
DAG BOUNDARY = SOURCE SYSTEM, NOT TARGET SCHEMA

This is the key structural change from the target-schema version:
each generated DAG represents one upstream SOURCE system (SAP_ERP,
SALESFORCE, KAFKA_CDC, ...), not one destination schema.

WHY SOURCE IS THE RIGHT DAG BOUNDARY

  - Scheduling naturally follows the source: "SAP drops files at 2am",
    "Kafka CDC topic is near-real-time, poll every 15 min" — these are
    properties of the SOURCE, not of wherever the data ends up.
  - Ownership follows the source: the team that owns the SAP
    integration cares about SAP's DAG succeeding, regardless of how
    many different target schemas SAP's tables happen to land in.
  - Retry/backoff policy follows the source: a flaky SFTP drop from
    one vendor needs different retry behavior than a Kafka topic.

ONE SOURCE CAN FAN OUT TO MANY TARGET SCHEMAS

In this deployment, most tables land in RAW — but the design supports
a source writing into more than one destination (e.g. RAW plus a
QUARANTINE schema for rejected records) without any DAG changes.
sp_load_batch reads TARGET_SCHEMA per table from INGEST_CONFIG, so a
single SOURCE_SCHEMA's batch can write into multiple destinations in
one stored procedure call. The DAG doesn't need to know or care.

NO TWO SOURCE-DAGS CAN EVER COLLIDE ON THE SAME TARGET TABLE

INGEST_CONFIG has a UNIQUE constraint on (TARGET_SCHEMA, TABLE_NAME) —
a given destination table belongs to exactly one source, enforced at
the database level. Two source-DAGs can both write into RAW
concurrently, but never into the same RAW table.

HOW NEW SOURCES GET ONBOARDED

INSERT one row into SOURCE_REGISTRY. No new Python file, no deploy.
The next scheduler parse generates the new DAG automatically.
"""

import logging
from datetime import datetime, timedelta

from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
from airflow.sensors.base import PokeReturnValue
from airflow.utils.email import send_email

log = logging.getLogger(__name__)

SNOWFLAKE_CONN_ID = Variable.get("SNOWFLAKE_CONN_ID", default_var="snowflake_default")


def hook() -> SnowflakeHook:
    return SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)


# ──────────────────────────────────────────────────────────────────
# STEP 1: Read the source registry at PARSE TIME
# ──────────────────────────────────────────────────────────────────
def _get_active_sources() -> list[dict]:
    try:
        records = hook().get_records("""
            SELECT
                SOURCE_SCHEMA, SCHEDULE_CRON, OWNER,
                ALERT_EMAIL, MAX_ACTIVE_TASKS,
                ENABLE_FILE_SENSOR, SENSOR_POKE_INTERVAL_SECS,
                SENSOR_TIMEOUT_SECS, SENSOR_MODE
            FROM SOURCE_REGISTRY
            WHERE IS_ACTIVE = TRUE
            ORDER BY SOURCE_SCHEMA
        """)
    except Exception as exc:
        log.error("[dag_factory] Could not read SOURCE_REGISTRY: %s", exc)
        return []

    return [
        {
            "source_schema"      : r[0],
            "schedule_cron"      : r[1] or "@daily",
            "owner"              : r[2] or "data-engineering",
            "alert_email"        : r[3] or "",
            "max_active_tasks"   : r[4] or 5,
            "enable_file_sensor" : r[5] if r[5] is not None else True,
            "sensor_poke_interval": r[6] or 300,
            "sensor_timeout"     : r[7] or 7200,
            "sensor_mode"        : r[8] or "reschedule",
        }
        for r in records
    ]


# ──────────────────────────────────────────────────────────────────
# STEP 2: Build one DAG for a single source system
# ──────────────────────────────────────────────────────────────────
def _build_source_dag(source_config: dict):
    source_schema       = source_config["source_schema"]
    schedule_cron       = source_config["schedule_cron"]
    owner               = source_config["owner"]
    alert_email         = source_config["alert_email"]
    max_active_tasks    = source_config["max_active_tasks"]
    enable_file_sensor  = source_config["enable_file_sensor"]
    sensor_poke_interval= source_config["sensor_poke_interval"]
    sensor_timeout      = source_config["sensor_timeout"]
    sensor_mode         = source_config["sensor_mode"]

    default_args = {
        "owner"                    : owner,
        "depends_on_past"          : False,
        "email_on_failure"         : bool(alert_email),
        "email"                    : [alert_email] if alert_email else [],
        "retries"                  : 2,
        "retry_delay"              : timedelta(minutes=5),
        "retry_exponential_backoff": True,
    }

    @dag(
        dag_id           = f"ingest_{source_schema.lower()}",
        description      = f"Batched ingestion from source: {source_schema}",
        schedule          = schedule_cron,
        start_date        = datetime(2025, 1, 1),
        catchup           = False,
        default_args      = default_args,
        max_active_runs   = 1,
        max_active_tasks  = max_active_tasks,
        tags              = ["snowflake", "ingestion", "source", source_schema.lower()],
    )
    def source_dag():

        # ── TASK 0: wait_for_files (file-arrival detection) ─────────
        # Polls every distinct stage this source owns via sp_detect_new_files.
        # mode="reschedule" releases the Airflow worker slot between polls
        # (it sleeps as a deferred task, not a busy-wait) — important at
        # 1000+ tables where many source-DAGs may be sensing concurrently.
        #
        # If ENABLE_FILE_SENSOR is FALSE for this source, this task is
        # skipped entirely and the DAG behaves like the pure-cron version —
        # useful for sources where files are guaranteed present by schedule
        # time (e.g. a source team commits to "always done by 2am").
        @task.sensor(
            poke_interval = sensor_poke_interval,
            timeout       = sensor_timeout,
            mode          = sensor_mode,
        )
        def wait_for_files(**context) -> PokeReturnValue:
            if not enable_file_sensor:
                log.info("[%s.wait_for_files] Sensor disabled for this source — proceeding immediately",
                         source_schema)
                return PokeReturnValue(is_done=True)

            # Pass today's run date so the SP can resolve date-pattern
            # filenames like customer_yyyyMMdd.csv → customer_20240115.csv
            run_date_str = context["logical_date"].strftime("%Y-%m-%d")

            result = hook().get_first(
                f"CALL sp_detect_new_files('{source_schema}', '{run_date_str}')"
            )
            summary = result[0] if result and result[0] else {}

            any_new  = summary.get("any_new_files", False)
            checked  = summary.get("stages_checked", 0)
            with_new = summary.get("stages_with_new_files", [])
            missing  = summary.get("missing_mandatory", [])

            if checked == 0:
                # No stages configured at all — proceed so get_batches
                # can report the real "no config" warning downstream.
                log.warning("[%s.wait_for_files] No stages configured — proceeding without files",
                           source_schema)
                return PokeReturnValue(is_done=True)

            # Missing mandatory files → raise immediately, do not retry.
            # The sensor times out on its own if they never appear.
            if missing:
                log.warning(
                    "[%s.wait_for_files] Mandatory file(s) missing for run_date=%s: %s",
                    source_schema, run_date_str, missing
                )
                # Return is_done=False so the sensor keeps polling
                # until the mandatory file appears or the timeout fires.
                return PokeReturnValue(is_done=False)

            if any_new:
                log.info("[%s.wait_for_files] Files ready for run_date=%s — proceeding",
                         source_schema, run_date_str)
                return PokeReturnValue(is_done=True)

            log.info("[%s.wait_for_files] No new files yet (%d stage(s) checked) — will poll again in %ds",
                     source_schema, checked, sensor_poke_interval)
            return PokeReturnValue(is_done=False)

        # ── TASK 1: get_batches (scoped to this SOURCE only) ────────
        @task
        def get_batches(**context) -> list[dict]:
            records = hook().get_records(f"""
                SELECT DISTINCT
                    BATCH_GROUP,
                    LOAD_MODE,
                    COUNT(*) OVER (PARTITION BY BATCH_GROUP, LOAD_MODE) AS TABLE_COUNT
                FROM INGEST_CONFIG
                WHERE IS_ACTIVE     = TRUE
                  AND SOURCE_SCHEMA = '{source_schema}'
                  AND BATCH_GROUP IS NOT NULL
                ORDER BY LOAD_MODE, BATCH_GROUP
            """)

            if not records:
                log.warning(
                    "[%s.get_batches] No batches found for source=%s. "
                    "Run CALL sp_assign_batches(25); in Snowflake first.",
                    source_schema, source_schema
                )
                return []

            batches = [
                {
                    "source_schema" : source_schema,
                    "batch_group"   : r[0],
                    "load_mode"     : r[1],
                    "table_count"   : r[2],
                    "airflow_run_id": context["run_id"],
                    "dag_id"        : context["dag"].dag_id,
                }
                for r in records
            ]
            log.info("[%s.get_batches] %d batch(es) covering %d table-runs",
                     source_schema, len(batches), sum(b["table_count"] for b in batches))
            return batches

        # ── TASK 2: load_batch (scoped to this SOURCE only) ─────────
        # Note: a single batch call may write into MULTIPLE target
        # schemas — that's resolved inside sp_load_batch per table,
        # not here. The Airflow task doesn't need to know targets.
        @task
        def load_batch(batch: dict) -> dict:
            log.info("[%s.load_batch] CALL sp_load_batch batch_group=%s mode=%s tables=%d",
                     source_schema, batch["batch_group"], batch["load_mode"], batch["table_count"])

            try:
                result = hook().get_first(f"""
                    CALL sp_load_batch(
                        '{batch["source_schema"]}',
                        {batch["batch_group"]},
                        '{batch["load_mode"]}',
                        '{batch["airflow_run_id"]}',
                        '{batch["dag_id"]}'
                    )
                """)
            except Exception as exc:
                log.error("[%s.load_batch] SP call FAILED batch_group=%s error=%s",
                          source_schema, batch["batch_group"], str(exc)[:300])
                raise

            summary = result[0] if result and result[0] else {}
            targets = summary.get("target_schemas_touched", [])
            log.info("[%s.load_batch] DONE batch_id=%s status=%s success=%s/%s targets=%s",
                     source_schema, summary.get("batch_id"), summary.get("status"),
                     summary.get("tables_success"), summary.get("tables_total"), targets)

            if summary.get("tables_failed", 0) > 0:
                log.warning("[%s.load_batch] %d table(s) failed in batch_group=%s — check V_OPEN_ERRORS",
                           source_schema, summary.get("tables_failed"), batch["batch_group"])
            return summary

        # ── TASK 3: send_summary_email (scoped to this SOURCE) ──────
        @task(trigger_rule="all_done")
        def send_summary_email(**context) -> None:
            if not alert_email:
                return

            rows = hook().get_records(f"""
                SELECT TARGET_SCHEMA, WAREHOUSE_NAME, LOAD_MODE, TABLE_COUNT,
                       SUCCESS_COUNT, FAILED_COUNT, TOTAL_ROWS
                FROM V_BATCH_SUMMARY
                WHERE SOURCE_SCHEMA = '{source_schema}'
                  AND BATCH_START >= DATEADD('hour', -6, CURRENT_TIMESTAMP())
                ORDER BY TARGET_SCHEMA, LOAD_MODE
            """)

            table_rows, total_tables, total_failed = "", 0, 0
            for r in rows:
                target, wh, mode, count, success, failed, total_rows = r
                total_tables += count
                total_failed += failed
                color = "#2e7d32" if failed == 0 else "#c62828"
                table_rows += (
                    f"<tr><td>{target}</td><td>{mode}</td><td>{wh}</td><td>{count}</td>"
                    f"<td style='color:{color}'>{success} ok / {failed} failed</td>"
                    f"<td>{(total_rows or 0):,}</td></tr>"
                )

            run_date = context["logical_date"].strftime("%Y-%m-%d")
            html = f"""
            <h2 style='font-family:sans-serif'>{source_schema} Ingestion — {run_date}</h2>
            <p style='font-family:sans-serif;color:#555'>
                {total_tables} tables processed, {total_failed} failed — source: {source_schema}
            </p>
            <table border='1' cellpadding='7' cellspacing='0'
                   style='border-collapse:collapse;font-family:sans-serif;font-size:13px'>
              <thead style='background:#f5f5f5'>
                <tr><th>Target schema</th><th>Mode</th><th>Warehouse</th><th>Tables</th><th>Result</th><th>Rows</th></tr>
              </thead>
              <tbody>{table_rows}</tbody>
            </table>
            <p style='font-family:sans-serif;font-size:11px;color:#888;margin-top:12px'>
              SELECT * FROM V_LATEST_STATUS WHERE TABLE_NAME IN
              (SELECT TABLE_NAME FROM INGEST_CONFIG WHERE SOURCE_SCHEMA = '{source_schema}');
            </p>
            """
            send_email(
                to      = alert_email,
                subject = f"[{source_schema} Ingestion] {run_date} — {total_tables} tables, {total_failed} failed",
                html_content = html,
            )

        # ── Wire up this source's pipeline ───────────────────────────
        sensed  = wait_for_files()
        batches = get_batches()
        sensed >> batches
        results = load_batch.expand(batch=batches)
        results >> send_summary_email()

    return source_dag()


# ──────────────────────────────────────────────────────────────────
# STEP 3: Generate a DAG object per active source and register
# each one into globals() so Airflow's DagBag discovers them all
# from this single file.
# ──────────────────────────────────────────────────────────────────
for _source_config in _get_active_sources():
    _dag_id = f"ingest_{_source_config['source_schema'].lower()}"
    globals()[_dag_id] = _build_source_dag(_source_config)
    log.info("[dag_factory] Registered DAG: %s (schedule=%s, owner=%s)",
             _dag_id, _source_config["schedule_cron"], _source_config["owner"])
