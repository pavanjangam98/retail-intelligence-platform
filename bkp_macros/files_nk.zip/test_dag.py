"""
Tests for snowflake_bulk_ingestion DAG
Run: pytest tests/test_dag.py -v
"""

import importlib
import sys
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Stub out Airflow & provider imports so tests run without a full Airflow env
# ---------------------------------------------------------------------------
AIRFLOW_STUBS = {
    "airflow"                                             : MagicMock(),
    "airflow.decorators"                                  : MagicMock(),
    "airflow.models"                                      : MagicMock(),
    "airflow.providers"                                   : MagicMock(),
    "airflow.providers.snowflake"                         : MagicMock(),
    "airflow.providers.snowflake.hooks"                   : MagicMock(),
    "airflow.providers.snowflake.hooks.snowflake"         : MagicMock(),
    "airflow.utils"                                       : MagicMock(),
    "airflow.utils.email"                                 : MagicMock(),
}
for mod, stub in AIRFLOW_STUBS.items():
    sys.modules[mod] = stub


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------
def make_config(**overrides) -> dict:
    base = {
        "table_name"    : "CUSTOMER",
        "stage_name"    : "@RAW.CUSTOMER_STAGE",
        "file_format"   : "CSV_FORMAT",
        "file_pattern"  : ".*\\.csv",
        "target_schema" : "PUBLIC",
        "load_mode"     : "APPEND",
        "airflow_run_id": "manual__2025-01-01",
        "dag_id"        : "snowflake_bulk_ingestion",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Tests: _esc
# ---------------------------------------------------------------------------
class TestEscapeHelper:
    def setup_method(self):
        # Import only the helper – avoid executing @dag at module level
        import sys, types
        mod = types.ModuleType("dag_module")
        exec(
            open("dags/snowflake_bulk_ingestion.py").read()
            .split("@dag")[0],  # everything before the @dag decorator
            mod.__dict__,
        )
        self._esc = mod._esc

    def test_no_quotes(self):
        assert self._esc("hello") == "hello"

    def test_single_quote_escaped(self):
        assert self._esc("it's") == "it''s"

    def test_multiple_quotes(self):
        assert self._esc("a'b'c") == "a''b''c"

    def test_empty_string(self):
        assert self._esc("") == ""


# ---------------------------------------------------------------------------
# Tests: get_active_configs (mocked hook)
# ---------------------------------------------------------------------------
class TestGetActiveConfigs:
    @patch("airflow.providers.snowflake.hooks.snowflake.SnowflakeHook")
    def test_returns_configs(self, MockHook):
        hook_instance = MockHook.return_value
        hook_instance.get_records.return_value = [
            ("CUSTOMER", "@RAW.CUSTOMER_STAGE", "CSV_FORMAT", ".*", "PUBLIC", "APPEND"),
            ("ORDERS",   "@RAW.ORDERS_STAGE",   "PARQUET_FORMAT", ".*", "PUBLIC", "APPEND"),
        ]

        # Inline the logic (avoids @task decorator complexity in unit tests)
        records = hook_instance.get_records("")
        configs = [
            {
                "table_name"   : r[0],
                "stage_name"   : r[1],
                "file_format"  : r[2],
                "file_pattern" : r[3],
                "target_schema": r[4],
                "load_mode"    : r[5],
            }
            for r in records
        ]

        assert len(configs) == 2
        assert configs[0]["table_name"] == "CUSTOMER"
        assert configs[1]["load_mode"]  == "APPEND"

    @patch("airflow.providers.snowflake.hooks.snowflake.SnowflakeHook")
    def test_empty_config(self, MockHook):
        hook_instance = MockHook.return_value
        hook_instance.get_records.return_value = []
        records = hook_instance.get_records("")
        assert records == []


# ---------------------------------------------------------------------------
# Tests: COPY SQL building logic
# ---------------------------------------------------------------------------
class TestCopySqlLogic:
    def _build_copy_sql(self, config: dict) -> str:
        return (
            f"COPY INTO {config['target_schema']}.{config['table_name']}\n"
            f"FROM {config['stage_name']}\n"
            f"FILE_FORMAT          = (FORMAT_NAME = {config['file_format']})\n"
            f"PATTERN              = '{config['file_pattern']}'\n"
            f"MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE\n"
            f"ON_ERROR             = CONTINUE\n"
            f"FORCE                = FALSE"
        )

    def test_csv_copy_sql(self):
        sql = self._build_copy_sql(make_config())
        assert "CUSTOMER" in sql
        assert "CSV_FORMAT" in sql
        assert "@RAW.CUSTOMER_STAGE" in sql
        assert "MATCH_BY_COLUMN_NAME" in sql

    def test_parquet_copy_sql(self):
        sql = self._build_copy_sql(
            make_config(
                table_name="ORDERS",
                stage_name="@RAW.ORDERS_STAGE",
                file_format="PARQUET_FORMAT",
                file_pattern=".*\\.parquet",
            )
        )
        assert "PARQUET_FORMAT" in sql
        assert "ORDERS" in sql

    def test_truncate_mode_adds_truncate(self):
        config = make_config(load_mode="TRUNCATE_LOAD")
        # Verify that TRUNCATE_LOAD triggers a truncate (logic check)
        assert config["load_mode"] == "TRUNCATE_LOAD"


# ---------------------------------------------------------------------------
# Tests: COPY result parsing
# ---------------------------------------------------------------------------
class TestCopyResultParsing:
    def _parse_results(self, copy_results):
        total_rows  = 0
        files_loaded = 0
        for row in copy_results:
            rows_loaded = row[3] if len(row) > 3 else 0
            row_status  = row[1] if len(row) > 1 else ""
            total_rows  += int(rows_loaded or 0)
            files_loaded += 1 if row_status == "LOADED" else 0
        return total_rows, files_loaded

    def test_single_file_loaded(self):
        results = [("file1.csv", "LOADED", 1000, 1000, 0, 0, None, None, None, None)]
        rows, files = self._parse_results(results)
        assert rows == 1000
        assert files == 1

    def test_multiple_files(self):
        results = [
            ("file1.csv", "LOADED", 500, 500, 0, 0, None, None, None, None),
            ("file2.csv", "LOADED", 300, 300, 0, 0, None, None, None, None),
            ("file3.csv", "LOAD_FAILED", 200, 0, 0, 5, "bad col", 10, 3, "ID"),
        ]
        rows, files = self._parse_results(results)
        assert rows == 800
        assert files == 2

    def test_empty_results(self):
        rows, files = self._parse_results([])
        assert rows == 0
        assert files == 0
