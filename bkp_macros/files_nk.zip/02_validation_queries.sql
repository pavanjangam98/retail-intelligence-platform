-- =============================================================
-- Script: 02_validation_queries.sql
-- Purpose: Pre/post load validation and health checks
-- =============================================================

USE DATABASE RAMU;
USE SCHEMA PUBLIC;

-- ---------------------------------------------------------------
-- PRE-LOAD: Check stage file counts
-- ---------------------------------------------------------------
-- LIST @RAW.CUSTOMER_STAGE;
-- LIST @RAW.ORDERS_STAGE;
-- LIST @RAW.PRODUCT_STAGE;

-- ---------------------------------------------------------------
-- PRE-LOAD: Validate file format works against stage (dry run)
-- ---------------------------------------------------------------
-- COPY INTO CUSTOMER
-- FROM @RAW.CUSTOMER_STAGE
-- FILE_FORMAT = (FORMAT_NAME = CSV_FORMAT)
-- VALIDATION_MODE = RETURN_ERRORS;

-- ---------------------------------------------------------------
-- OPERATIONAL: Latest run status per table
-- ---------------------------------------------------------------
SELECT
    TABLE_NAME,
    MAX(START_TIME)                          AS LAST_RUN_TIME,
    MAX_BY(STATUS, START_TIME)               AS LAST_STATUS,
    MAX_BY(ROWS_LOADED, START_TIME)          AS LAST_ROWS_LOADED,
    MAX_BY(DURATION_SECS, START_TIME)        AS LAST_DURATION_SECS,
    COUNT(*)                                 AS TOTAL_RUNS,
    SUM(CASE WHEN STATUS='SUCCESS' THEN 1 ELSE 0 END) AS SUCCESS_RUNS,
    SUM(CASE WHEN STATUS='FAILED'  THEN 1 ELSE 0 END) AS FAILED_RUNS
FROM ETL_AUDIT
GROUP BY TABLE_NAME
ORDER BY LAST_RUN_TIME DESC;

-- ---------------------------------------------------------------
-- OPERATIONAL: Runs in the last 24 hours
-- ---------------------------------------------------------------
SELECT
    RUN_ID,
    TABLE_NAME,
    STATUS,
    START_TIME,
    END_TIME,
    DURATION_SECS,
    ROWS_LOADED,
    ERROR_MESSAGE
FROM ETL_AUDIT
WHERE START_TIME >= DATEADD('hour', -24, CURRENT_TIMESTAMP())
ORDER BY START_TIME DESC;

-- ---------------------------------------------------------------
-- OPERATIONAL: All unresolved errors
-- ---------------------------------------------------------------
SELECT
    e.ERROR_ID,
    e.RUN_ID,
    e.TABLE_NAME,
    e.ERROR_TIME,
    e.ERROR_TYPE,
    e.ERROR_MESSAGE,
    a.AIRFLOW_RUN_ID
FROM ETL_ERROR_LOG e
JOIN ETL_AUDIT     a ON e.RUN_ID = a.RUN_ID
WHERE e.IS_RESOLVED = FALSE
ORDER BY e.ERROR_TIME DESC;

-- ---------------------------------------------------------------
-- OPERATIONAL: Mark errors as resolved (update run_id)
-- ---------------------------------------------------------------
-- UPDATE ETL_ERROR_LOG
-- SET IS_RESOLVED = TRUE, RESOLVED_AT = CURRENT_TIMESTAMP(), RESOLVED_BY = 'ANALYST'
-- WHERE RUN_ID = '<run_id>';

-- ---------------------------------------------------------------
-- PERFORMANCE: Average load time per table (last 30 days)
-- ---------------------------------------------------------------
SELECT
    TABLE_NAME,
    COUNT(*)                       AS RUNS,
    ROUND(AVG(DURATION_SECS), 2)   AS AVG_DURATION_SECS,
    MAX(DURATION_SECS)             AS MAX_DURATION_SECS,
    ROUND(AVG(ROWS_LOADED))        AS AVG_ROWS_LOADED,
    SUM(ROWS_LOADED)               AS TOTAL_ROWS_LOADED
FROM ETL_AUDIT
WHERE STATUS = 'SUCCESS'
  AND START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY TABLE_NAME
ORDER BY AVG_DURATION_SECS DESC;

-- ---------------------------------------------------------------
-- COPY RESULTS: Files loaded per run
-- ---------------------------------------------------------------
SELECT
    RUN_ID,
    TABLE_NAME,
    FILE_NAME,
    STATUS,
    ROWS_PARSED,
    ROWS_LOADED,
    ERRORS_SEEN,
    FIRST_ERROR
FROM ETL_COPY_RESULTS
ORDER BY CREATED_AT DESC
LIMIT 200;

-- ---------------------------------------------------------------
-- DAILY SUMMARY VIEW
-- ---------------------------------------------------------------
SELECT * FROM V_ETL_AUDIT_SUMMARY LIMIT 30;

-- ---------------------------------------------------------------
-- RECENT FAILED RUNS WITH ERRORS
-- ---------------------------------------------------------------
SELECT * FROM V_FAILED_RUNS LIMIT 50;

-- ---------------------------------------------------------------
-- CONFIG: Active ingestion configs
-- ---------------------------------------------------------------
SELECT
    CONFIG_ID,
    TABLE_NAME,
    STAGE_NAME,
    FILE_FORMAT,
    LOAD_MODE,
    IS_ACTIVE,
    PRIORITY,
    NOTES
FROM INGEST_CONFIG
WHERE IS_ACTIVE = TRUE
ORDER BY PRIORITY;
