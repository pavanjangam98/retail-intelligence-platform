#!/usr/bin/env bash
# =============================================================
# Script : setup_airflow_connection.sh
# Purpose: Register the Snowflake connection and Airflow
#          variables via Airflow CLI (run on the Airflow host)
# =============================================================
set -euo pipefail

# ── Edit these values before running ──────────────────────────
ACCOUNT="<your_account>"          # e.g. xy12345.us-east-1
USER="<your_user>"
PASSWORD="<your_password>"
WAREHOUSE="COMPUTE_WH"
DATABASE="RAMU"
SCHEMA="PUBLIC"
ROLE="ACCOUNTADMIN"
ALERT_EMAIL="data-engineering@yourcompany.com"
# ──────────────────────────────────────────────────────────────

echo "==> Removing existing connection (if any) …"
airflow connections delete snowflake_default 2>/dev/null || true

echo "==> Creating Snowflake connection …"
airflow connections add snowflake_default \
  --conn-type    snowflake \
  --conn-host    "${ACCOUNT}.snowflakecomputing.com" \
  --conn-login   "${USER}" \
  --conn-password "${PASSWORD}" \
  --conn-schema  "${SCHEMA}" \
  --conn-extra   "{
    \"account\":   \"${ACCOUNT}\",
    \"warehouse\": \"${WAREHOUSE}\",
    \"database\":  \"${DATABASE}\",
    \"role\":      \"${ROLE}\",
    \"insecure_mode\": false
  }"

echo "==> Setting Airflow Variables …"
airflow variables set SNOWFLAKE_CONN_ID   "snowflake_default"
airflow variables set ALERT_EMAIL         "${ALERT_EMAIL}"
airflow variables set ENABLE_VALIDATION   "true"
airflow variables set MAX_ERRORS_ALLOWED  "0"

echo "==> Unpausing DAG …"
airflow dags unpause snowflake_bulk_ingestion

echo ""
echo "✅  Setup complete."
echo "    Test a manual run with:"
echo "    airflow dags trigger snowflake_bulk_ingestion"
