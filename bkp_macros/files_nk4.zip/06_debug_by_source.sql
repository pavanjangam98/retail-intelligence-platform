-- =================================================================
-- 06_debug_queries.sql
-- Use in Snowsight. Entry point is now the SOURCE system since
-- that's the DAG boundary — start here, then drill into target tables.
-- =================================================================

USE DATABASE RAMU;
USE SCHEMA PUBLIC;


-- ═══════════════════════════════════════════════════════════════
-- STEP 0: Which source-DAGs exist and what's their schedule?
-- ═══════════════════════════════════════════════════════════════
SELECT SOURCE_SCHEMA, SCHEDULE_CRON, OWNER, ALERT_EMAIL,
       MAX_ACTIVE_TASKS, IS_ACTIVE
FROM SOURCE_REGISTRY
ORDER BY SOURCE_SCHEMA;


-- ═══════════════════════════════════════════════════════════════
-- STEP 0b: Fan-out map — which source feeds which target schema(s)?
-- Useful before changing a source's schedule: "if I slow down
-- SAP_ERP's DAG, which target schemas are affected?"
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_SOURCE_TARGET_MAP ORDER BY SOURCE_SCHEMA, TARGET_SCHEMA;


-- ═══════════════════════════════════════════════════════════════
-- STEP 1: Which source had failures in the last 24 hours?
-- ═══════════════════════════════════════════════════════════════
SELECT
    SOURCE_SCHEMA, TARGET_SCHEMA, TABLE_NAME, LOAD_MODE, STATUS,
    START_TIME, DURATION_SECS, ERROR_MESSAGE
FROM ETL_AUDIT
WHERE STATUS     = 'FAILED'
  AND START_TIME >= DATEADD('hour', -24, CURRENT_TIMESTAMP())
ORDER BY SOURCE_SCHEMA, START_TIME DESC;


-- ═══════════════════════════════════════════════════════════════
-- STEP 2: Drill into one source's batches (may span several targets)
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_BATCH_SUMMARY
WHERE SOURCE_SCHEMA = '<SOURCE_NAME>'   -- e.g. 'SAP_ERP'
ORDER BY BATCH_START DESC LIMIT 20;


-- ═══════════════════════════════════════════════════════════════
-- STEP 3: Which FILE caused it?
-- ═══════════════════════════════════════════════════════════════
SELECT FILE_NAME, STATUS, ROWS_PARSED, ROWS_LOADED, ERRORS_SEEN,
       FIRST_ERROR, FIRST_ERROR_LINE, ERROR_COLUMN_NAME
FROM ETL_COPY_RESULTS
WHERE RUN_ID = '<paste RUN_ID here>'
ORDER BY STATUS DESC;


-- ═══════════════════════════════════════════════════════════════
-- OPERATIONAL: Per-source daily rollup (all sources, one query)
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_SOURCE_SUMMARY
WHERE RUN_DATE >= DATEADD('day', -7, CURRENT_TIMESTAMP())
ORDER BY RUN_DATE DESC, SOURCE_SCHEMA;


-- ═══════════════════════════════════════════════════════════════
-- OPERATIONAL: A target schema's tables, regardless of which
-- source(s) feed it — e.g. "show me everything landing in FINANCE"
-- ═══════════════════════════════════════════════════════════════
SELECT TABLE_NAME, SOURCE_SCHEMA, LOAD_MODE, STAGE_NAME
FROM INGEST_CONFIG
WHERE TARGET_SCHEMA = 'FINANCE' AND IS_ACTIVE = TRUE
ORDER BY SOURCE_SCHEMA, TABLE_NAME;


-- ═══════════════════════════════════════════════════════════════
-- OPERATIONAL: Open errors across ALL sources
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_OPEN_ERRORS ORDER BY ERROR_TIME DESC;


-- ═══════════════════════════════════════════════════════════════
-- OPERATIONAL: Re-run batch assignment after adding/removing tables
-- ═══════════════════════════════════════════════════════════════
-- CALL sp_assign_batches(25);
-- CALL sp_provision_cdc_staging();


-- ═══════════════════════════════════════════════════════════════
-- ONBOARDING: Add a brand-new source system (creates a new DAG)
-- ═══════════════════════════════════════════════════════════════
-- INSERT INTO SOURCE_REGISTRY
--     (SOURCE_SCHEMA, SCHEDULE_CRON, OWNER, ALERT_EMAIL, MAX_ACTIVE_TASKS, NOTES)
-- VALUES
--     ('WORKDAY_HR', '@daily', 'hr-data-eng', 'hr-data-eng@company.com', 5, 'New HRIS source');
--
-- No DAG file to write. dag_factory.py picks this up on its next
-- scheduler parse and "ingest_workday_hr" appears in the Airflow UI.


-- ═══════════════════════════════════════════════════════════════
-- SAFETY CHECK: Confirm no target table is claimed by two sources
-- (should always return zero rows — the UNIQUE constraint already
-- prevents this, this query is just a sanity check / audit trail)
-- ═══════════════════════════════════════════════════════════════
SELECT TARGET_SCHEMA, TABLE_NAME, COUNT(DISTINCT SOURCE_SCHEMA) AS SOURCE_COUNT
FROM INGEST_CONFIG
WHERE IS_ACTIVE = TRUE
GROUP BY TARGET_SCHEMA, TABLE_NAME
HAVING COUNT(DISTINCT SOURCE_SCHEMA) > 1;


-- ═══════════════════════════════════════════════════════════════
-- COST: Credit usage per warehouse, last 30 days
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_WAREHOUSE_COST
WHERE USAGE_DATE >= DATEADD('day', -30, CURRENT_TIMESTAMP())
ORDER BY USAGE_DATE DESC;
