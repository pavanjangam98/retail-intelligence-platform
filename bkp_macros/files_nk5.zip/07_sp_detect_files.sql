-- =================================================================
-- 07_sp_detect_files.sql
-- File-arrival detection.
--
-- Called by the Airflow file-sensor task BEFORE get_batches runs.
-- For every distinct STAGE_NAME belonging to one SOURCE_SCHEMA, it
-- runs LIST @stage and compares the newest file's LAST_MODIFIED
-- timestamp against what was recorded on the previous poll.
--
-- Returns a VARIANT summary the sensor task uses to decide whether
-- to proceed (new files found) or keep waiting (nothing new yet).
-- =================================================================

CREATE OR REPLACE PROCEDURE sp_detect_new_files(source_schema STRING)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'detect_files'
AS $$
import logging
log = logging.getLogger(__name__)

def _e(v):
    return str(v or '').replace("'", "''")

def detect_files(session, source_schema):
    """
    Polls every distinct stage used by this source's active tables.
    Updates ETL_STAGE_DETECTION on every call (even when nothing new
    is found) so LAST_POLLED_AT always reflects reality.

    Returns:
      {
        "any_new_files": bool,        # True if ANY stage advanced
        "stages_checked": int,
        "stages_with_new_files": [list of stage names],
        "details": [per-stage dicts]
      }
    """
    stage_rows = session.sql(f"""
        SELECT DISTINCT STAGE_NAME
        FROM INGEST_CONFIG
        WHERE SOURCE_SCHEMA = '{source_schema}'
          AND IS_ACTIVE     = TRUE
    """).collect()

    if not stage_rows:
        return {"any_new_files": False, "stages_checked": 0,
                "stages_with_new_files": [], "details": [],
                "reason": "No active stages configured for this source"}

    any_new = False
    stages_with_new = []
    details = []

    for row in stage_rows:
        stage_name = row['STAGE_NAME']

        try:
            files = session.sql(f"LIST {stage_name}").collect()
        except Exception as exc:
            log.error(f"[sp_detect_new_files] LIST failed for {stage_name}: {exc}")
            details.append({"stage_name": stage_name, "error": str(exc)[:500]})
            continue

        files_found = len(files)
        newest_file = None
        newest_ts   = None

        for f in files:
            fd = f.as_dict()
            # LIST returns columns: name, size, md5, last_modified
            ts = fd.get('last_modified')
            if ts is not None and (newest_ts is None or ts > newest_ts):
                newest_ts   = ts
                newest_file = fd.get('name')

        # Read what we saw last time
        prior = session.sql(f"""
            SELECT LAST_FILE_SEEN_TS
            FROM ETL_STAGE_DETECTION
            WHERE STAGE_NAME = '{_e(stage_name)}'
        """).collect()
        prior_ts = prior[0]['LAST_FILE_SEEN_TS'] if prior else None

        is_new = (
            files_found > 0 and
            newest_ts is not None and
            (prior_ts is None or newest_ts > prior_ts)
        )

        if is_new:
            any_new = True
            stages_with_new.append(stage_name)

        # Upsert detection state — always, regardless of is_new
        session.sql(f"""
            MERGE INTO ETL_STAGE_DETECTION tgt
            USING (SELECT
                       '{_e(stage_name)}'    AS STAGE_NAME,
                       '{_e(source_schema)}' AS SOURCE_SCHEMA,
                       CURRENT_TIMESTAMP()   AS LAST_POLLED_AT,
                       '{_e(newest_file)}'   AS LAST_FILE_SEEN,
                       {files_found}         AS FILES_FOUND,
                       {str(is_new).upper()} AS IS_NEW
                  ) src
            ON tgt.STAGE_NAME = src.STAGE_NAME
            WHEN MATCHED THEN UPDATE SET
                LAST_POLLED_AT         = src.LAST_POLLED_AT,
                LAST_FILE_SEEN         = src.LAST_FILE_SEEN,
                LAST_FILE_SEEN_TS      = CASE WHEN src.IS_NEW THEN src.LAST_POLLED_AT
                                               ELSE tgt.LAST_FILE_SEEN_TS END,
                FILES_FOUND_LAST_POLL  = src.FILES_FOUND,
                NEW_FILES_DETECTED     = src.IS_NEW,
                POLL_COUNT             = tgt.POLL_COUNT + 1,
                UPDATED_AT             = CURRENT_TIMESTAMP()
            WHEN NOT MATCHED THEN INSERT
                (STAGE_NAME, SOURCE_SCHEMA, LAST_POLLED_AT, LAST_FILE_SEEN,
                 LAST_FILE_SEEN_TS, FILES_FOUND_LAST_POLL, NEW_FILES_DETECTED, POLL_COUNT)
            VALUES
                (src.STAGE_NAME, src.SOURCE_SCHEMA, src.LAST_POLLED_AT, src.LAST_FILE_SEEN,
                 CASE WHEN src.IS_NEW THEN src.LAST_POLLED_AT ELSE NULL END,
                 src.FILES_FOUND, src.IS_NEW, 1)
        """).collect()

        details.append({
            "stage_name": stage_name,
            "files_found": files_found,
            "newest_file": newest_file,
            "is_new": is_new,
        })

        log.info(f"[sp_detect_new_files] stage={stage_name} files={files_found} "
                 f"newest={newest_file} is_new={is_new}")

    return {
        "any_new_files": any_new,
        "stages_checked": len(stage_rows),
        "stages_with_new_files": stages_with_new,
        "details": details,
    }
$$;
