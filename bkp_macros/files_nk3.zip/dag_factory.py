"""
dag_factory.py — Generates one DAG per TARGET_SCHEMA
========================================================
HOW THIS WORKS

This file is parsed once by the Airflow scheduler, just like any
other DAG file. But instead of defining ONE dag object, it:

  1. Queries SCHEMA_REGISTRY in Snowflake at parse time
  2. Loops over every active schema row
  3. Calls _build_schema_dag() to construct a complete DAG for that
     schema, with its own schedule, owner, email, and concurrency cap
  4. Registers each generated DAG into globals() so Airflow's
     DagBag picks all of them up from this single file

Adding a new schema to ingest = INSERT one row into SCHEMA_REGISTRY.
No new Python file. No code review for a new DAG. The new DAG appears
automatically on the next scheduler parse (typically within ~30s -
5 min depending on your min_file_process_interval).

WHY ONE FACTORY FILE INSTEAD OF N DAG FILES

- Single place to fix a bug in the task logic — fixes every schema's
  DAG at once instead of N files needing the same patch.
- New schemas are zero-code (a SQL insert), not a deploy.
- Still gets fully independent DAGs in the Airflow UI — independent
  schedules, independent run history, independent pause/resume.

EACH GENERATED DAG IS COMPLETELY INDEPENDENT AT RUNTIME

dag_SALES, dag_FINANCE, dag_MARKETING etc. each:
  - have their own schedule (from SCHEMA_REGISTRY.SCHEDULE_CRON)
  - have their own max_active_tasks (concurrency cap)
  - retry and alert independently
  - only ever call sp_load_batch with their own TARGET_SCHEMA, so
    two schema DAGs running at the same time never touch the same
    INGEST_CONFIG rows or the same batch_id
"""

import logging
from datetime import datetime, timedelta

from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
from airflow.utils.email import send_email

log = logging.getLogger(__name__)

SNOWFLAKE_CONN_ID = Variable.get("SNOWFLAKE_CONN_ID", default_var="snowflake_default")


def hook() -> SnowflakeHook:
    return SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)


# ──────────────────────────────────────────────────────────────────
# STEP 1: Read the schema registry at PARSE TIME
# This runs once when the Airflow scheduler parses this file —
# not once per DAG run. If Snowflake is briefly unreachable during
# a parse cycle, the previous set of generated DAGs simply persists
# in the DagBag until the next successful parse.
# ──────────────────────────────────────────────────────────────────
def _get_active_schemas() -> list[dict]:
    try:
        records = hook().get_records("""
            SELECT
                TARGET_SCHEMA, SCHEDULE_CRON, OWNER,
                ALERT_EMAIL, MAX_ACTIVE_TASKS
            FROM SCHEMA_REGISTRY
            WHERE IS_ACTIVE = TRUE
            ORDER BY TARGET_SCHEMA
        """)
    except Exception as exc:
        log.error("[dag_factory] Could not read SCHEMA_REGISTRY: %s", exc)
        return []

    return [
        {
            "target_schema"   : r[0],
            "schedule_cron"   : r[1] or "@daily",
            "owner"           : r[2] or "data-engineering",
            "alert_email"     : r[3] or "",
            "max_active_tasks": r[4] or 5,
        }
        for r in records
    ]


# ──────────────────────────────────────────────────────────────────
# STEP 2: Build one DAG for a single schema
# This is the same task structure as the single-DAG scaled design —
# get_batches -> load_batch -> send_summary_email — just scoped to
# one TARGET_SCHEMA and parameterized per-schema for schedule/owner.
# ──────────────────────────────────────────────────────────────────
def _build_schema_dag(schema_config: dict):
    target_schema    = schema_config["target_schema"]
    schedule_cron    = schema_config["schedule_cron"]
    owner            = schema_config["owner"]
    alert_email      = schema_config["alert_email"]
    max_active_tasks = schema_config["max_active_tasks"]

    default_args = {
        "owner"                    : owner,
        "depends_on_past"          : False,
        "email_on_failure"         : bool(alert_email),
        "email"                    : [alert_email] if alert_email else [],
        "retries"                  : 2,
        "retry_delay"              : timedelta(minutes=5),
        "retry_exponential_backoff": True,
    }

    @dag(
        dag_id           = f"ingest_{target_schema.lower()}",
        description      = f"Batched ingestion for schema: {target_schema}",
        schedule          = schedule_cron,
        start_date        = datetime(2025, 1, 1),
        catchup           = False,
        default_args      = default_args,
        max_active_runs   = 1,
        max_active_tasks  = max_active_tasks,
        tags              = ["snowflake", "ingestion", "scaled", target_schema.lower()],
    )
    def schema_dag():

        # ── TASK 1: get_batches (scoped to this schema only) ────────
        @task
        def get_batches(**context) -> list[dict]:
            records = hook().get_records(f"""
                SELECT DISTINCT
                    BATCH_GROUP,
                    LOAD_MODE,
                    COUNT(*) OVER (PARTITION BY BATCH_GROUP, LOAD_MODE) AS TABLE_COUNT
                FROM INGEST_CONFIG
                WHERE IS_ACTIVE     = TRUE
                  AND TARGET_SCHEMA = '{target_schema}'
                  AND BATCH_GROUP IS NOT NULL
                ORDER BY LOAD_MODE, BATCH_GROUP
            """)

            if not records:
                log.warning(
                    "[%s.get_batches] No batches found for schema=%s. "
                    "Run CALL sp_assign_batches(25); in Snowflake first.",
                    target_schema, target_schema
                )
                return []

            batches = [
                {
                    "target_schema" : target_schema,
                    "batch_group"   : r[0],
                    "load_mode"     : r[1],
                    "table_count"   : r[2],
                    "airflow_run_id": context["run_id"],
                    "dag_id"        : context["dag"].dag_id,
                }
                for r in records
            ]
            log.info("[%s.get_batches] %d batch(es) covering %d table-runs",
                     target_schema, len(batches), sum(b["table_count"] for b in batches))
            return batches

        # ── TASK 2: load_batch (scoped to this schema only) ─────────
        @task
        def load_batch(batch: dict) -> dict:
            log.info("[%s.load_batch] CALL sp_load_batch batch_group=%s mode=%s tables=%d",
                     target_schema, batch["batch_group"], batch["load_mode"], batch["table_count"])

            try:
                result = hook().get_first(f"""
                    CALL sp_load_batch(
                        '{batch["target_schema"]}',
                        {batch["batch_group"]},
                        '{batch["load_mode"]}',
                        '{batch["airflow_run_id"]}',
                        '{batch["dag_id"]}'
                    )
                """)
            except Exception as exc:
                log.error("[%s.load_batch] SP call FAILED batch_group=%s error=%s",
                          target_schema, batch["batch_group"], str(exc)[:300])
                raise

            summary = result[0] if result and result[0] else {}
            log.info("[%s.load_batch] DONE batch_id=%s status=%s success=%s/%s",
                     target_schema, summary.get("batch_id"), summary.get("status"),
                     summary.get("tables_success"), summary.get("tables_total"))

            if summary.get("tables_failed", 0) > 0:
                log.warning("[%s.load_batch] %d table(s) failed in batch_group=%s — check V_OPEN_ERRORS",
                           target_schema, summary.get("tables_failed"), batch["batch_group"])
            return summary

        # ── TASK 3: send_summary_email (scoped to this schema) ──────
        @task(trigger_rule="all_done")
        def send_summary_email(**context) -> None:
            if not alert_email:
                return

            rows = hook().get_records(f"""
                SELECT WAREHOUSE_NAME, LOAD_MODE, TABLE_COUNT,
                       SUCCESS_COUNT, FAILED_COUNT, TOTAL_ROWS
                FROM V_BATCH_SUMMARY
                WHERE TARGET_SCHEMA = '{target_schema}'
                  AND BATCH_START >= DATEADD('hour', -6, CURRENT_TIMESTAMP())
                ORDER BY LOAD_MODE
            """)

            table_rows, total_tables, total_failed = "", 0, 0
            for r in rows:
                wh, mode, count, success, failed, total_rows = r
                total_tables += count
                total_failed += failed
                color = "#2e7d32" if failed == 0 else "#c62828"
                table_rows += (
                    f"<tr><td>{mode}</td><td>{wh}</td><td>{count}</td>"
                    f"<td style='color:{color}'>{success} ok / {failed} failed</td>"
                    f"<td>{(total_rows or 0):,}</td></tr>"
                )

            run_date = context["logical_date"].strftime("%Y-%m-%d")
            html = f"""
            <h2 style='font-family:sans-serif'>{target_schema} Ingestion — {run_date}</h2>
            <p style='font-family:sans-serif;color:#555'>
                {total_tables} tables processed, {total_failed} failed — schema: {target_schema}
            </p>
            <table border='1' cellpadding='7' cellspacing='0'
                   style='border-collapse:collapse;font-family:sans-serif;font-size:13px'>
              <thead style='background:#f5f5f5'>
                <tr><th>Mode</th><th>Warehouse</th><th>Tables</th><th>Result</th><th>Rows</th></tr>
              </thead>
              <tbody>{table_rows}</tbody>
            </table>
            <p style='font-family:sans-serif;font-size:11px;color:#888;margin-top:12px'>
              SELECT * FROM V_LATEST_STATUS WHERE TABLE_NAME IN
              (SELECT TABLE_NAME FROM INGEST_CONFIG WHERE TARGET_SCHEMA = '{target_schema}');
            </p>
            """
            send_email(
                to      = alert_email,
                subject = f"[{target_schema} Ingestion] {run_date} — {total_tables} tables, {total_failed} failed",
                html_content = html,
            )

        # ── Wire up this schema's pipeline ───────────────────────────
        batches = get_batches()
        results = load_batch.expand(batch=batches)
        results >> send_summary_email()

    return schema_dag()


# ──────────────────────────────────────────────────────────────────
# STEP 3: Generate a DAG object per active schema and register
# each one into globals() so Airflow's DagBag discovers them all
# from this single file.
# ──────────────────────────────────────────────────────────────────
for _schema_config in _get_active_schemas():
    _dag_id = f"ingest_{_schema_config['target_schema'].lower()}"
    globals()[_dag_id] = _build_schema_dag(_schema_config)
    log.info("[dag_factory] Registered DAG: %s (schedule=%s, owner=%s)",
             _dag_id, _schema_config["schedule_cron"], _schema_config["owner"])
