-- =================================================================
-- 06_debug_queries.sql
-- Use in Snowsight. Same drill-down workflow as before, now with
-- a schema-level entry point since you have N DAGs instead of 1.
-- =================================================================

USE DATABASE RAMU;
USE SCHEMA PUBLIC;


-- ═══════════════════════════════════════════════════════════════
-- STEP 0: Which schema-DAGs exist and what's their schedule?
-- ═══════════════════════════════════════════════════════════════
SELECT TARGET_SCHEMA, SCHEDULE_CRON, OWNER, ALERT_EMAIL,
       MAX_ACTIVE_TASKS, IS_ACTIVE
FROM SCHEMA_REGISTRY
ORDER BY TARGET_SCHEMA;


-- ═══════════════════════════════════════════════════════════════
-- STEP 1: Which schema had failures in the last 24 hours?
-- ═══════════════════════════════════════════════════════════════
SELECT
    TARGET_SCHEMA, TABLE_NAME, LOAD_MODE, STATUS,
    START_TIME, DURATION_SECS, ERROR_MESSAGE
FROM ETL_AUDIT
WHERE STATUS     = 'FAILED'
  AND START_TIME >= DATEADD('hour', -24, CURRENT_TIMESTAMP())
ORDER BY TARGET_SCHEMA, START_TIME DESC;


-- ═══════════════════════════════════════════════════════════════
-- STEP 2: Drill into one schema's batches
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_BATCH_SUMMARY
WHERE TARGET_SCHEMA = '<SCHEMA_NAME>'
ORDER BY BATCH_START DESC LIMIT 20;


-- ═══════════════════════════════════════════════════════════════
-- STEP 3: Which FILE caused it? (same as before, RUN_ID-scoped)
-- ═══════════════════════════════════════════════════════════════
SELECT FILE_NAME, STATUS, ROWS_PARSED, ROWS_LOADED, ERRORS_SEEN,
       FIRST_ERROR, FIRST_ERROR_LINE, ERROR_COLUMN_NAME
FROM ETL_COPY_RESULTS
WHERE RUN_ID = '<paste RUN_ID here>'
ORDER BY STATUS DESC;


-- ═══════════════════════════════════════════════════════════════
-- OPERATIONAL: Per-schema daily rollup (all schemas, one query)
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_SCHEMA_SUMMARY
WHERE RUN_DATE >= DATEADD('day', -7, CURRENT_TIMESTAMP())
ORDER BY RUN_DATE DESC, TARGET_SCHEMA;


-- ═══════════════════════════════════════════════════════════════
-- OPERATIONAL: Open errors across ALL schemas
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_OPEN_ERRORS ORDER BY ERROR_TIME DESC;


-- ═══════════════════════════════════════════════════════════════
-- OPERATIONAL: Re-run batch assignment after adding/removing tables
-- ═══════════════════════════════════════════════════════════════
-- CALL sp_assign_batches(25);     -- 25 tables per batch, tune as needed
-- CALL sp_provision_cdc_staging();  -- creates staging tables for new CDC entries


-- ═══════════════════════════════════════════════════════════════
-- ONBOARDING: Add a brand-new schema (creates a new DAG automatically)
-- ═══════════════════════════════════════════════════════════════
-- INSERT INTO SCHEMA_REGISTRY
--     (TARGET_SCHEMA, SCHEDULE_CRON, OWNER, ALERT_EMAIL, MAX_ACTIVE_TASKS, NOTES)
-- VALUES
--     ('HR', '@daily', 'hr-data-eng', 'hr-data-eng@company.com', 5, 'New HR domain tables');
--
-- No DAG file to write. The dag_factory.py picks this up on its next
-- scheduler parse and a new "ingest_hr" DAG appears in the Airflow UI.


-- ═══════════════════════════════════════════════════════════════
-- COST: Credit usage per warehouse, last 30 days
-- ═══════════════════════════════════════════════════════════════
SELECT * FROM V_WAREHOUSE_COST
WHERE USAGE_DATE >= DATEADD('day', -30, CURRENT_TIMESTAMP())
ORDER BY USAGE_DATE DESC;
