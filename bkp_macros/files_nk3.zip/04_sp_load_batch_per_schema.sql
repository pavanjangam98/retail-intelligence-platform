-- =================================================================
-- 04_sp_load_batch.sql
-- THE key scaling change.
--
-- Instead of Airflow calling sp_load_table() once per table
-- (1000 separate CALL round-trips), Airflow calls sp_load_batch()
-- once per BATCH_GROUP (e.g. 40 calls for 1000 tables at 25/batch).
--
-- The loop over tables happens INSIDE this single stored procedure,
-- using the SAME warehouse session for all 25 tables — no per-table
-- session spin-up cost, and audit writes are batched into one insert
-- at the end instead of one insert per table.
-- =================================================================

CREATE OR REPLACE PROCEDURE sp_load_batch(
    target_schema   STRING,
    batch_group     NUMBER,
    load_mode       STRING,
    airflow_run_id  STRING,
    dag_id          STRING
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
EXECUTE AS CALLER
HANDLER = 'load_batch'
AS $$
import uuid, traceback, logging
log = logging.getLogger(__name__)

def load_batch(session, target_schema, batch_group, load_mode, airflow_run_id, dag_id):
    """
    Processes every table in (target_schema, batch_group, load_mode)
    using ONE Snowflake session. Accumulates audit/error/copy-result
    rows in memory and writes them in three bulk inserts at the end —
    not one insert per table.

    target_schema scopes this call to a single schema-DAG's tables —
    each per-schema DAG only ever touches its own rows, so two schema
    DAGs running concurrently never contend for the same batch_group.
    """
    batch_id = f"batch-{target_schema}-{batch_group}-{load_mode}-{uuid.uuid4().hex[:8]}"

    configs = session.sql(f"""
        SELECT
            TABLE_NAME, TARGET_SCHEMA, STAGE_NAME, FILE_FORMAT,
            COALESCE(FILE_PATTERN, '.*') AS FILE_PATTERN,
            LOAD_MODE, MERGE_KEYS, CDC_OP_COLUMN, STAGING_TABLE,
            WAREHOUSE_NAME
        FROM INGEST_CONFIG
        WHERE TARGET_SCHEMA = '{target_schema}'
          AND BATCH_GROUP   = {batch_group}
          AND LOAD_MODE     = '{load_mode}'
          AND IS_ACTIVE     = TRUE
        ORDER BY PRIORITY, TABLE_NAME
    """).collect()

    if not configs:
        return {"status": "SKIPPED", "reason": "No tables in this batch", "batch_id": batch_id}

    log.info(f"[sp_load_batch] batch_id={batch_id} mode={load_mode} tables={len(configs)}")

    audit_rows = []
    error_rows = []
    copy_rows  = []
    batch_success = 0
    batch_failed  = 0

    for c in configs:
        table_name    = c['TABLE_NAME']
        target_schema = c['TARGET_SCHEMA']
        stage_name    = c['STAGE_NAME']
        file_format   = c['FILE_FORMAT']
        file_pattern  = c['FILE_PATTERN']
        merge_keys    = c.get('MERGE_KEYS', '') or ''
        cdc_op_column = c.get('CDC_OP_COLUMN', '') or ''
        staging_table = c.get('STAGING_TABLE', '') or ''
        warehouse     = c.get('WAREHOUSE_NAME', '') or ''
        run_id        = str(uuid.uuid4())

        try:
            if load_mode == 'INCREMENTAL':
                result = _incremental(session, table_name, target_schema,
                                      stage_name, file_format, file_pattern, run_id)

            elif load_mode == 'FULL_LOAD':
                result = _full_load(session, table_name, target_schema,
                                    stage_name, file_format, file_pattern)

            elif load_mode == 'CDC_MERGE':
                if not merge_keys or not cdc_op_column or not staging_table:
                    raise ValueError(
                        f"CDC_MERGE table {table_name} missing MERGE_KEYS, "
                        f"CDC_OP_COLUMN, or STAGING_TABLE. Run sp_provision_cdc_staging() first."
                    )
                result = _cdc_merge(session, table_name, target_schema,
                                    stage_name, file_format, file_pattern,
                                    merge_keys, cdc_op_column, staging_table)
            else:
                raise ValueError(f"Unknown load_mode={load_mode}")

            audit_rows.append({
                "run_id": run_id, "table_name": table_name,
                "target_schema": target_schema, "stage_name": stage_name,
                "load_mode": load_mode, "warehouse_name": warehouse,
                "status": "SUCCESS",
                "rows_loaded": result.get('rows_loaded', 0),
                "rows_updated": result.get('rows_updated', 0),
                "rows_deleted": result.get('rows_deleted', 0),
                "files_loaded": result.get('files_loaded', 0),
                "airflow_run_id": airflow_run_id, "dag_id": dag_id,
            })
                copy_rows.append({
                    "run_id": run_id, "table_name": table_name,
                    "file_name": fr.get('file', ''), "status": fr.get('status', ''),
                    "rows_parsed": fr.get('rows_parsed', 0),
                    "rows_loaded": fr.get('rows_loaded', 0),
                    "errors_seen": fr.get('errors_seen', 0),
                    "first_error": fr.get('first_error', ''),
                    "first_error_line": fr.get('first_error_line'),
                    "error_column": fr.get('first_error_column_name', ''),
                })
            batch_success += 1

        except Exception as exc:
            tb = traceback.format_exc()
            audit_rows.append({
                "run_id": run_id, "table_name": table_name,
                "target_schema": target_schema, "stage_name": stage_name,
                "load_mode": load_mode, "warehouse_name": warehouse,
                "status": "FAILED", "error_message": str(exc)[:4990],
                "airflow_run_id": airflow_run_id, "dag_id": dag_id,
            })
            error_rows.append({
                "run_id": run_id, "table_name": table_name, "load_mode": load_mode,
                "error_type": type(exc).__name__,
                "error_message": str(exc)[:4990], "stack_trace": tb[:9990],
            })
            batch_failed += 1
            log.error(f"[sp_load_batch] table={table_name} FAILED: {str(exc)[:200]}")
            # Continue to next table — one bad table doesn't stop the batch

    # ── Bulk-write everything accumulated during this batch ──────
    if audit_rows:
        session.call('sp_audit_write_batch', batch_id, audit_rows)
    if error_rows:
        session.call('sp_error_write_batch', batch_id, error_rows)
    if copy_rows:
        session.call('sp_copy_results_write_batch', batch_id, copy_rows)

    log.info(f"[sp_load_batch] batch_id={batch_id} DONE success={batch_success} failed={batch_failed}")

    return {
        "status": "SUCCESS" if batch_failed == 0 else "PARTIAL_FAILURE",
        "batch_id": batch_id,
        "batch_group": batch_group,
        "load_mode": load_mode,
        "tables_total": len(configs),
        "tables_success": batch_success,
        "tables_failed": batch_failed,
    }


# ── Per-table load functions (called inside the batch loop) ──────

def _incremental(session, table_name, target_schema, stage_name,
                 file_format, file_pattern, run_id):
    full_table = f"{target_schema}.{table_name}"
    pattern_sql = f"PATTERN = '{file_pattern}'" if file_pattern and file_pattern != '.*' else ""

    raw = session.sql(f"""
        COPY INTO {full_table}
        FROM {stage_name}
        FILE_FORMAT = (FORMAT_NAME = {file_format})
        {pattern_sql}
        MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
        ON_ERROR = CONTINUE
        FORCE = FALSE
    """).collect()

    rows_loaded, files_ok, last_file, file_results = 0, 0, None, []
    for r in raw:
        rd = r.as_dict()
        rows_loaded += int(rd.get('rows_loaded', 0) or 0)
        if rd.get('status') == 'LOADED':
            files_ok += 1
            last_file = rd.get('file')
        file_results.append(rd)

    if last_file:
        session.call('sp_watermark_set', table_name, last_file, run_id)

    return {"rows_loaded": rows_loaded, "files_loaded": files_ok, "file_results": file_results}


def _full_load(session, table_name, target_schema, stage_name,
               file_format, file_pattern):
    full_table = f"{target_schema}.{table_name}"
    pattern_sql = f"PATTERN = '{file_pattern}'" if file_pattern and file_pattern != '.*' else ""

    session.sql(f"TRUNCATE TABLE {full_table}").collect()
    raw = session.sql(f"""
        COPY INTO {full_table}
        FROM {stage_name}
        FILE_FORMAT = (FORMAT_NAME = {file_format})
        {pattern_sql}
        MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
        ON_ERROR = CONTINUE
        FORCE = TRUE
    """).collect()

    rows_loaded, files_ok, file_results = 0, 0, []
    for r in raw:
        rd = r.as_dict()
        rows_loaded += int(rd.get('rows_loaded', 0) or 0)
        files_ok += 1 if rd.get('status') == 'LOADED' else 0
        file_results.append(rd)

    return {"rows_loaded": rows_loaded, "files_loaded": files_ok, "file_results": file_results}


def _cdc_merge(session, table_name, target_schema, stage_name,
              file_format, file_pattern, merge_keys, cdc_op_column, staging_table):
    """
    Uses a PERSISTENT staging table (pre-created by sp_provision_cdc_staging).
    TRUNCATE + COPY + MERGE + DELETE — no CREATE/DROP per run.
    This is the change that removes per-table DDL overhead at scale.
    """
    full_table  = f"{target_schema}.{table_name}"
    pattern_sql = f"PATTERN = '{file_pattern}'" if file_pattern and file_pattern != '.*' else ""
    key_list    = [k.strip() for k in merge_keys.split(',')]
    merge_cond  = ' AND '.join(f'tgt.{k} = src.{k}' for k in key_list)

    # Reuse the persistent staging table — just empty it first
    session.sql(f"TRUNCATE TABLE {staging_table}").collect()

    raw = session.sql(f"""
        COPY INTO {staging_table}
        FROM {stage_name}
        FILE_FORMAT = (FORMAT_NAME = {file_format})
        {pattern_sql}
        MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
        ON_ERROR = CONTINUE
        FORCE = FALSE
    """).collect()

    files_ok, file_results = 0, []
    for r in raw:
        rd = r.as_dict()
        files_ok += 1 if rd.get('status') == 'LOADED' else 0
        file_results.append(rd)

    col_rows = session.sql(f"""
        SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = '{target_schema.upper()}' AND TABLE_NAME = '{table_name.upper()}'
        ORDER BY ORDINAL_POSITION
    """).collect()
    all_columns = [r['COLUMN_NAME'] for r in col_rows]
    skip_cols   = set(key_list + [cdc_op_column])
    update_set  = ', '.join(f'tgt.{c} = src.{c}' for c in all_columns if c not in skip_cols)
    insert_cols = ', '.join(c for c in all_columns if c != cdc_op_column)
    insert_vals = ', '.join(f'src.{c}' for c in all_columns if c != cdc_op_column)

    merge_result = session.sql(f"""
        MERGE INTO {full_table} tgt
        USING (SELECT * FROM {staging_table} WHERE UPPER({cdc_op_column}) NOT IN ('D','DELETE')) src
        ON {merge_cond}
        WHEN MATCHED AND UPPER(src.{cdc_op_column}) IN ('U','UPDATE') THEN UPDATE SET {update_set}
        WHEN NOT MATCHED AND UPPER(src.{cdc_op_column}) IN ('I','INSERT') THEN
            INSERT ({insert_cols}) VALUES ({insert_vals})
    """).collect()

    rows_inserted = rows_updated = 0
    if merge_result:
        mr = merge_result[0].as_dict()
        rows_inserted = int(mr.get('number of rows inserted', 0) or 0)
        rows_updated  = int(mr.get('number of rows updated', 0) or 0)

    del_result = session.sql(f"""
        DELETE FROM {full_table} tgt
        WHERE EXISTS (
            SELECT 1 FROM {staging_table} src
            WHERE {merge_cond} AND UPPER(src.{cdc_op_column}) IN ('D','DELETE')
        )
    """).collect()
    rows_deleted = int(del_result[0].as_dict().get('number of rows deleted', 0) or 0) if del_result else 0

    return {
        "rows_loaded": rows_inserted, "rows_updated": rows_updated,
        "rows_deleted": rows_deleted, "files_loaded": files_ok,
        "file_results": file_results
    }
$$;
