-- =================================================================
-- 01_setup_scaled.sql
-- Run ONCE. Adds: dedicated warehouses, resource monitor,
-- batch-aware INGEST_CONFIG, persistent CDC staging registry.
-- =================================================================

USE ROLE ACCOUNTADMIN;
CREATE DATABASE IF NOT EXISTS RAMU;
USE DATABASE RAMU;
CREATE SCHEMA IF NOT EXISTS PUBLIC;
CREATE SCHEMA IF NOT EXISTS RAW;
CREATE SCHEMA IF NOT EXISTS STAGING;   -- persistent CDC staging tables live here
USE SCHEMA PUBLIC;

-- ── Resource monitor — hard credit cap ───────────────────────
-- This is your safety net. If something runs away (bad regex,
-- infinite retry loop, runaway CDC job), the warehouse suspends
-- itself instead of burning credits unattended.
CREATE OR REPLACE RESOURCE MONITOR rm_ingestion_guard
    WITH
        CREDIT_QUOTA = 500                      -- adjust to your monthly budget
        FREQUENCY    = MONTHLY
        START_TIMESTAMP = IMMEDIATELY
        TRIGGERS
            ON 75  PERCENT DO NOTIFY
            ON 90  PERCENT DO NOTIFY
            ON 100 PERCENT DO SUSPEND            -- finishes running queries, blocks new ones
            ON 110 PERCENT DO SUSPEND_IMMEDIATE; -- kills everything, last resort

-- ── Two warehouses — isolate CDC from simple loads ───────────
-- INCREMENTAL/FULL_LOAD are cheap COPY operations — small warehouse,
-- scales out wide (more concurrent batches).
CREATE WAREHOUSE IF NOT EXISTS WH_INCREMENTAL
    WAREHOUSE_SIZE          = 'SMALL'
    MIN_CLUSTER_COUNT       = 1
    MAX_CLUSTER_COUNT       = 4        -- scales OUT for concurrency, not UP for size
    SCALING_POLICY          = 'STANDARD'
    AUTO_SUSPEND             = 60
    AUTO_RESUME              = TRUE
    RESOURCE_MONITOR         = rm_ingestion_guard
    COMMENT                  = 'Incremental + full-load batches';

-- CDC does staging + MERGE + DELETE — heavier per-table, but fewer
-- tables are usually CDC. Bigger warehouse, less concurrency needed.
CREATE WAREHOUSE IF NOT EXISTS WH_CDC
    WAREHOUSE_SIZE          = 'MEDIUM'
    MIN_CLUSTER_COUNT       = 1
    MAX_CLUSTER_COUNT       = 2
    SCALING_POLICY          = 'STANDARD'
    AUTO_SUSPEND             = 60
    AUTO_RESUME              = TRUE
    RESOURCE_MONITOR         = rm_ingestion_guard
    COMMENT                  = 'CDC merge batches — isolated from incremental load';

-- ── File formats (unchanged) ──────────────────────────────────
CREATE OR REPLACE FILE FORMAT CSV_FORMAT
    TYPE = CSV SKIP_HEADER = 1
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    NULL_IF = ('NULL','null','') EMPTY_FIELD_AS_NULL = TRUE;
CREATE OR REPLACE FILE FORMAT PARQUET_FORMAT TYPE = PARQUET;
CREATE OR REPLACE FILE FORMAT JSON_FORMAT TYPE = JSON STRIP_OUTER_ARRAY = TRUE;

-- ── INGEST_CONFIG — now batch-aware ───────────────────────────
-- BATCH_GROUP: tables sharing the same batch run together in one
--              stored procedure CALL (loop happens inside Snowflake).
-- WAREHOUSE_NAME: which warehouse runs this table's batch.
-- Both are computed automatically by sp_assign_batches if left NULL —
-- see 03_sp_batch_assignment.sql.
CREATE OR REPLACE TABLE INGEST_CONFIG (
    CONFIG_ID        NUMBER        AUTOINCREMENT PRIMARY KEY,
    TABLE_NAME       VARCHAR(255)  NOT NULL,
    TARGET_SCHEMA    VARCHAR(100)  DEFAULT 'PUBLIC',
    STAGE_NAME       VARCHAR(500)  NOT NULL,
    FILE_FORMAT      VARCHAR(100)  NOT NULL,
    FILE_PATTERN     VARCHAR(500)  DEFAULT '.*',
    LOAD_MODE        VARCHAR(20)   NOT NULL
                     CHECK (LOAD_MODE IN ('INCREMENTAL','FULL_LOAD','CDC_MERGE')),
    MERGE_KEYS       VARCHAR(500),
    CDC_OP_COLUMN    VARCHAR(100),
    WATERMARK_COLUMN VARCHAR(100),
    IS_ACTIVE        BOOLEAN       DEFAULT TRUE,
    PRIORITY         NUMBER        DEFAULT 100,
    -- Batching — auto-assigned, or set manually for fine control
    BATCH_GROUP       NUMBER,
    WAREHOUSE_NAME    VARCHAR(100),
    -- Persistent CDC staging table name (created once, reused forever)
    STAGING_TABLE     VARCHAR(255),
    NOTES             VARCHAR(1000),
    CREATED_AT        TIMESTAMP     DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_AT        TIMESTAMP     DEFAULT CURRENT_TIMESTAMP()
);

-- ── SCHEMA_REGISTRY — one row per target schema, drives DAG factory ──
-- The dag_factory.py reads this table at parse time to know which
-- DAGs to generate and what schedule/owner/email each one gets.
-- Add a row here whenever onboarding a brand-new schema.
CREATE OR REPLACE TABLE SCHEMA_REGISTRY (
    TARGET_SCHEMA   VARCHAR(100)  PRIMARY KEY,
    SCHEDULE_CRON   VARCHAR(100)  DEFAULT '@daily',  -- Airflow cron/preset per schema
    OWNER           VARCHAR(100)  DEFAULT 'data-engineering',
    ALERT_EMAIL     VARCHAR(255),
    MAX_ACTIVE_TASKS NUMBER       DEFAULT 5,          -- concurrency cap for this schema's DAG
    IS_ACTIVE       BOOLEAN       DEFAULT TRUE,
    NOTES           VARCHAR(1000),
    CREATED_AT      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP()
);

-- Sample rows — one per business domain
INSERT INTO SCHEMA_REGISTRY (TARGET_SCHEMA, SCHEDULE_CRON, OWNER, ALERT_EMAIL, MAX_ACTIVE_TASKS, NOTES)
VALUES
    ('SALES',     '@daily',           'sales-data-eng',     'sales-data-eng@company.com',     8,  'Sales fact + dim tables'),
    ('FINANCE',   '0 */4 * * *',      'finance-data-eng',   'finance-data-eng@company.com',   5,  'Runs every 4 hours — close cycle'),
    ('MARKETING', '@daily',           'marketing-data-eng', 'marketing-data-eng@company.com', 10, 'Campaign + attribution tables');

-- ── ETL_AUDIT — same shape, but now BATCH_ID groups many tables ──
CREATE OR REPLACE TABLE ETL_AUDIT (
    AUDIT_ID         NUMBER        AUTOINCREMENT PRIMARY KEY,
    RUN_ID           VARCHAR(64)   NOT NULL,
    BATCH_ID         VARCHAR(64),             -- groups all tables loaded in one SP call
    TARGET_SCHEMA    VARCHAR(100),            -- which schema-DAG produced this row
    AIRFLOW_RUN_ID   VARCHAR(500),
    DAG_ID           VARCHAR(255),
    TABLE_NAME       VARCHAR(255)  NOT NULL,
    TARGET_SCHEMA    VARCHAR(100),
    STAGE_NAME       VARCHAR(500),
    LOAD_MODE        VARCHAR(20),
    WAREHOUSE_NAME   VARCHAR(100),
    START_TIME       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP(),
    END_TIME         TIMESTAMP,
    DURATION_SECS    NUMBER GENERATED ALWAYS AS (DATEDIFF('second', START_TIME, END_TIME)) VIRTUAL,
    STATUS           VARCHAR(20)   CHECK (STATUS IN ('STARTED','SUCCESS','FAILED','SKIPPED')),
    ROWS_LOADED      NUMBER DEFAULT 0,
    ROWS_UPDATED     NUMBER DEFAULT 0,
    ROWS_DELETED     NUMBER DEFAULT 0,
    FILES_LOADED     NUMBER DEFAULT 0,
    ERROR_MESSAGE    VARCHAR(5000),
    CREATED_AT       TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE ETL_ERROR_LOG (
    ERROR_ID       NUMBER AUTOINCREMENT PRIMARY KEY,
    RUN_ID         VARCHAR(64),
    BATCH_ID       VARCHAR(64),
    TABLE_NAME     VARCHAR(255),
    LOAD_MODE      VARCHAR(20),
    ERROR_TIME     TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
    ERROR_TYPE     VARCHAR(100),
    ERROR_MESSAGE  VARCHAR(5000),
    STACK_TRACE    VARCHAR(10000),
    IS_RESOLVED    BOOLEAN DEFAULT FALSE,
    RESOLVED_AT    TIMESTAMP,
    RESOLVED_BY    VARCHAR(100)
);

CREATE OR REPLACE TABLE ETL_COPY_RESULTS (
    RESULT_ID             NUMBER AUTOINCREMENT PRIMARY KEY,
    RUN_ID                VARCHAR(64),
    BATCH_ID               VARCHAR(64),
    TABLE_NAME             VARCHAR(255),
    FILE_NAME              VARCHAR(1000),
    STATUS                 VARCHAR(50),
    ROWS_PARSED             NUMBER,
    ROWS_LOADED             NUMBER,
    ERRORS_SEEN             NUMBER,
    FIRST_ERROR             VARCHAR(2000),
    FIRST_ERROR_LINE        NUMBER,
    ERROR_COLUMN_NAME       VARCHAR(255),
    CREATED_AT              TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE ETL_WATERMARK (
    WATERMARK_ID     NUMBER AUTOINCREMENT PRIMARY KEY,
    TABLE_NAME       VARCHAR(255) NOT NULL UNIQUE,
    LAST_LOADED_FILE VARCHAR(1000),
    LAST_LOADED_TS   TIMESTAMP,
    LAST_RUN_ID      VARCHAR(64),
    UPDATED_AT       TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- ── Batch run summary view — for monitoring 1000 tables at a glance ──
CREATE OR REPLACE VIEW V_BATCH_SUMMARY AS
SELECT
    BATCH_ID,
    TARGET_SCHEMA,
    WAREHOUSE_NAME,
    LOAD_MODE,
    MIN(START_TIME)                                    AS BATCH_START,
    MAX(END_TIME)                                       AS BATCH_END,
    COUNT(*)                                            AS TABLE_COUNT,
    SUM(CASE WHEN STATUS='SUCCESS' THEN 1 ELSE 0 END)  AS SUCCESS_COUNT,
    SUM(CASE WHEN STATUS='FAILED'  THEN 1 ELSE 0 END)  AS FAILED_COUNT,
    SUM(ROWS_LOADED)                                    AS TOTAL_ROWS
FROM ETL_AUDIT
GROUP BY BATCH_ID, TARGET_SCHEMA, WAREHOUSE_NAME, LOAD_MODE
ORDER BY BATCH_START DESC;

-- Per-schema rollup — what each schema-DAG's last run looked like
CREATE OR REPLACE VIEW V_SCHEMA_SUMMARY AS
SELECT
    TARGET_SCHEMA,
    DATE_TRUNC('day', START_TIME)                       AS RUN_DATE,
    COUNT(DISTINCT TABLE_NAME)                           AS TABLE_COUNT,
    SUM(CASE WHEN STATUS='SUCCESS' THEN 1 ELSE 0 END)  AS SUCCESS_COUNT,
    SUM(CASE WHEN STATUS='FAILED'  THEN 1 ELSE 0 END)  AS FAILED_COUNT,
    SUM(ROWS_LOADED)                                    AS TOTAL_ROWS,
    ROUND(AVG(DURATION_SECS), 1)                         AS AVG_DURATION_SECS
FROM ETL_AUDIT
GROUP BY TARGET_SCHEMA, 2
ORDER BY 2 DESC, 1;

CREATE OR REPLACE VIEW V_LATEST_STATUS AS
SELECT
    TABLE_NAME,
    MAX_BY(LOAD_MODE,     START_TIME) AS LOAD_MODE,
    MAX_BY(STATUS,        START_TIME) AS LAST_STATUS,
    MAX(START_TIME)                   AS LAST_RUN_AT,
    MAX_BY(ROWS_LOADED,   START_TIME) AS LAST_ROWS_LOADED,
    MAX_BY(DURATION_SECS, START_TIME) AS LAST_DURATION_SECS
FROM ETL_AUDIT
GROUP BY TABLE_NAME;

CREATE OR REPLACE VIEW V_OPEN_ERRORS AS
SELECT e.ERROR_ID, e.TABLE_NAME, e.LOAD_MODE, e.ERROR_TIME,
       e.ERROR_TYPE, e.ERROR_MESSAGE, a.BATCH_ID
FROM ETL_ERROR_LOG e JOIN ETL_AUDIT a ON e.RUN_ID = a.RUN_ID
WHERE e.IS_RESOLVED = FALSE ORDER BY e.ERROR_TIME DESC;

-- ── Warehouse credit usage — watch this weekly ────────────────
CREATE OR REPLACE VIEW V_WAREHOUSE_COST AS
SELECT
    WAREHOUSE_NAME,
    DATE_TRUNC('day', START_TIME) AS USAGE_DATE,
    SUM(CREDITS_USED)             AS CREDITS_USED
FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
WHERE WAREHOUSE_NAME IN ('WH_INCREMENTAL', 'WH_CDC')
GROUP BY 1, 2
ORDER BY 2 DESC, 1;
