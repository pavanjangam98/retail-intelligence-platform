{% docs foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference %}
(AI‑Generated) This foundation data product contains the mapping of New Zealand meshblocks to meshblock to territorial authority local board classifications, sourced from the Stats NZ Aria site Concordances file Meshblock YYYY to Urban Rural YYYY, renamed to MESHBLOCK_TO_TERRITORIAL_AUTHORITY_LOCAL_BOARD for ingestion. Each record indicates whether a meshblock is considered urban, rural, or a related settlement type.
{% enddocs %}
{% docs foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference___meshblock_code %}
A meshblock is the smallest geographic unit for which statistical data is reported by Stats NZ. A meshblock is a defined geographic area, which can vary in size from part of a city block to a large 
area of rural land. Meshblocks are added together to form larger geographic areas, such as SA1, SA2, SA3, and urban rural areas. They are also used to define electoral districts, territorial authorities, and regional councils.  
Meshblocks are not named and have seven-digit codes. When meshblocks are split, each new meshblock is given a new code. The original meshblock codes no longer exist within that version and future versions of the meshblock classification. Meshblock codes do not change when a meshblock boundary is nudged. Meshblocks that existed prior to 2015 and have not changed are numbered from 0000100 to 3210003. Meshblocks created from 2015 onwards are numbered from 4000000.
{% enddocs %}
{% docs foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference___meshblock_desc %}
Meshblock Label
{% enddocs %}
{% docs foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference___meshblock_text %}
Meshblock Label..ASCII-translated version of the original value with maori macron characters translated.
{% enddocs %}
{% docs foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference___territorial_authority_local_board_code %}
Territorial Authority Local Board (TALB) is a derived classification. TALB is derived from the definitive version of the local boards for Auckland and territorial authorities for the rest of New Zealand as at 1 January 2026, as defined by the territorial authorities and/or Local Government Commission and maintained by Stats NZ. 
Local boards share governance with a council’s governing body and each has complementary responsibilities, guaranteed by legislation. Local boards can propose bylaws and they gather community views on local and regional matters. Legislation enacted in 2012 allows for the establishment of local boards in areas of new unitary authorities that are predominantly urban and have a population of more than 400,000. The boundaries of local boards cannot be abolished or changed except through a reorganisation process. If new local boards are created they will be incorporated into this classification.
Local boards are defined at meshblock level. Local boards do not coincide with statistical geographies.
TALB is a flat classification. Each category has a unique five-digit code. The first three digits represent the territorial authority code, ranging from 001 to 076 (with 999 being Area Outside Territorial Authority). The last two digits indicate if the territorial authority is further defined at local board level: 00 indicates the territorial authority is “not further defined”. Auckland retains sequential codes from the community board classification.
{% enddocs %}
{% docs foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference___territorial_authority_local_board_desc %}
The names for the classification are retained from the territorial authority and community board classifications.
{% enddocs %}
{% docs foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference___territorial_authority_local_board_text %}
The names for the classification are retained from the territorial authority and community board classifications...ASCII-translated version of the original value with maori macron characters translated.
{% enddocs %}
