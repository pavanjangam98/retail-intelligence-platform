{{ config(
    materialized='incremental'
) }}

/*
There are 4 methods that can be used to run the file based datasets.

Full Run - dbt build -s +foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference+ --vars '{"run_type": "full_run"}'
This method will process all data available in the S3 bucket. Should only be used for Once off Historical Load,
and will encounter issues if there is data available from before the current dataset loaded.

Incremental - dbt build -s +foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference+ --vars '{"run_type": "incremental"}'
This method should be used as the on-going load method, this checks the target table and only tries to load data from after the latest processed dataset.

Load From Date - dbt build -s +foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference+ --vars '{"run_type": "load_from", "start_date": "2025-06-17"}'
This should be used to reprocess historical data that has been modified or inserted late. The variable start_date used should be on or before the date to reprocess.

--Don't use these for BAU
Specific Date - dbt build -s +foundation___fdp__reference___fdp__stats_nz_meshblock_to_territorial_authority_local_board_reference+ --vars '{"run_type": "specific_date", "start_date": "2025-06-17"}'
Used to process a specific date. Shouldn't be used natively, but useful for testing the behaviour of the incremental process

If the correct parameters aren't used for the last two run types this process will fail.

Please Note:
It is not recommended to process data earlier than the latest loaded data.
If data needs to be reprocessed, raw should be removed back until the affected date and reprocessed.
*/

--If no parameters are set default depending on the status of the target table
{% if is_incremental() %}
    {% set run_type = var('run_type', 'incremental') %}
{% else %}
    {% set run_type = var('run_type', 'full_run') %}
{% endif %}
{% do log("Value of run_type is: " ~ run_type, info=True) %}
--Set date variables to null so that the job fails when variables are incorrectly entered
{% set start_date = var('start_date', null) %}
{% set end_date = var('end_date', null) %}

SELECT
TRIM(S.MESHBLOCK_CODE)::VARCHAR AS MESHBLOCK_CODE,
TRIM(S.MESHBLOCK_LABEL)::VARCHAR AS MESHBLOCK_DESC,
TRIM(S.MESHBLOCK_LABEL)::VARCHAR AS MESHBLOCK_TEXT,
TRIM(S.TERRITORIAL_AUTHORITY_LOCAL_BOARD_CODE)::VARCHAR AS TERRITORIAL_AUTHORITY_LOCAL_BOARD_CODE,
TRIM(S.TERRITORIAL_AUTHORITY_LOCAL_BOARD_LABEL)::VARCHAR AS TERRITORIAL_AUTHORITY_LOCAL_BOARD_DESC,
TRIM(S.TERRITORIAL_AUTHORITY_LOCAL_BOARD_LABEL)::VARCHAR AS TERRITORIAL_AUTHORITY_LOCAL_BOARD_TEXT,
S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EXTRACTION_TSTAMP)::TIMESTAMP_LTZ AS DWH_EXTRACTION_TSTAMP,
S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
'{{ invocation_id }}' || '.' || '{{ model.unique_id }}'::VARCHAR AS DWH_PROCESS_INSERT_ID,
LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___properties_file___meshblock_to_territorial_authority_local_board') }} AS S
/* Since we are executing the jobs in different modes, we had to include this if clause with
respect to run_type. However, the functionality of this model is to just pull the latest data from
raw table to foundation, the logic will remain the same except when executing the job in full mode
(initial run), where the target table itself is not available.
*/
{% if is_incremental() and run_type in ['incremental', 'from_date', 'full_run', 'specific_date'] %}
    LEFT JOIN {{ this }} AS T
    ON TRIM(S.MESHBLOCK_CODE) = T.MESHBLOCK_CODE
    AND CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EXTRACTION_TSTAMP)::TIMESTAMP_LTZ = T.DWH_EXTRACTION_TSTAMP
    WHERE S.DWH_PROCESS_TSTAMP > (SELECT MAX(DWH_PROCESS_TSTAMP) FROM {{ this }}) AND T.MESHBLOCK_CODE IS NULL
{% endif %}
