with warehouse_events_history as (
    select *
    from {{ source('audit__snowflake', 'warehouse_events_history') }}
    --where database_name like 'CUSTOMER_%'
)

select *
from warehouse_events_history
