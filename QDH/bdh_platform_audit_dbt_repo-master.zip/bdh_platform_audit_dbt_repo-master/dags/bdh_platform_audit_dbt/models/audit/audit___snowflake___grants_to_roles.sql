with grants_to_roles as (
    select *
    from {{ source('audit__snowflake', 'grants_to_roles') }}

)

select *
from grants_to_roles
