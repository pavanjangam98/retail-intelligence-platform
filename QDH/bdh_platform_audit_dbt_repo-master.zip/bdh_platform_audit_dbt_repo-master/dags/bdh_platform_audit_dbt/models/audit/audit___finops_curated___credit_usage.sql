{{
    config(
        materialized='incremental',
        incremental_strategy='append',
        unique_key='query_id',
        on_schema_change='fail'
    )
}}

with query_cost_ratio as (
    select *
    from {{ ref('audit___finops_curated___query_cost_ratio') }}
    {% if is_incremental() %}
        -- Only process new queries since last run
        where query_start_time > (select  coalesce( max(query_start_time),'1900-01-01' ) from {{ this }})
    {% endif %}

),

final as (
    select
        query_id,
        warehouse_name as warehouse,
        user_name as user,
        query_text,
        query_start_time,
        query_runtime_seconds,
        case
            when lower(user_name) like 'bdh_sf_%' then 'Service User'
            when lower(user_name) like 'tst_%' then 'Test User'
            else 'Named User'
        end as user_category,
        credits_used_cloud_services + query_credits_used as query_cost_credits,
         case
            when split_part(warehouse_name, '_', 1) = 'WH' then 'OTHER'
            else split_part(warehouse_name, '_', 1)
        end as zone,
        '{{ invocation_id }}' || '.' || '{{ model.unique_id }}'::VARCHAR as dwh_process_insert_id,
        convert_timezone('Pacific/Auckland', 'Pacific/Auckland', current_timestamp())::TIMESTAMP_LTZ as dwh_process_tstamp
    from query_cost_ratio
)

select * from final
