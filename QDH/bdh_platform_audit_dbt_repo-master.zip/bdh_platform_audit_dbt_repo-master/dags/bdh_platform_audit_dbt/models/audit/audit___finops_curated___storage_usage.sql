{{
    config(
        materialized='incremental',
        incremental_strategy='append',
        unique_key='database_usage_date',
        on_schema_change='fail'
    )
}}
with databases as (
    select
        database_name,
        case
            when contains(database_name, 'PREPROD') then 'PREPROD'
            when contains(database_name, 'DEV') then 'DEV'
            when contains(database_name, 'PROD') then 'PROD'
            when contains(database_name, 'SYST') then 'SYST'
            when contains(database_name, 'PPTE') then 'PPTE'           
            else 'OTHER'
        end as environment,
        case
            when contains(database_name, 'FOUNDATION') then 'FOUNDATION'
            when contains(database_name, 'CURATED') then 'CURATED'
            when contains(database_name, 'LANDING') then 'LANDING'
            when contains(database_name, 'RAW') then 'RAW'
            when contains(database_name, 'TRANSFORM') then 'TRANSFORM'
            when contains(database_name, 'LOGGING') then 'LOGGING'
            when contains(database_name, 'GOVERNANCE') then 'GOVERNANCE'
            when contains(database_name, 'PLATFORM__AUDIT__PREPROD') then 'PLATFORM__AUDIT'
            when contains(database_name, 'PLATFORM__AUDIT__PROD') then 'PLATFORM__AUDIT'
            else 'OTHER'
        end as layer
    from {{ ref('audit___snowflake___databases') }}
),

storage_usage as (
    select
        database_name,
        usage_date,
        sum(average_database_bytes) as average_database_bytes,
        sum(average_failsafe_bytes) as average_failsafe_bytes,
        sum(average_hybrid_table_storage_bytes) as average_hybrid_table_storage_bytes
    from {{ ref('audit___snowflake___database_storage_usage_history') }}
	 {% if is_incremental() %}
        -- Only process new data since last run
        where usage_date > (select coalesce(max(usage_date),'1900-01-01' ) from {{ this }})
    {% endif %}
    group by
        database_name,
        usage_date
),

final as (
    select
        concat(db_usage.database_name, '_', db_usage.usage_date) as database_usage_date,
        db_usage.database_name as database,
        db_usage.usage_date,
        db.environment,
        db.layer,
        db_usage.average_database_bytes as active_bytes,
        db_usage.average_failsafe_bytes as archive_bytes,
        split_part(db_usage.database_name, '__', 1) as zone,
        '{{ invocation_id }}' || '.' || '{{ model.unique_id }}'::VARCHAR as dwh_process_insert_id,
        convert_timezone('Pacific/Auckland', 'Pacific/Auckland', current_timestamp())::TIMESTAMP_LTZ as dwh_process_tstamp

    from storage_usage as db_usage
    left join databases as db
        on db_usage.database_name = db.database_name
)

select * from final
