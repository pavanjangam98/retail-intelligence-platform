with databases as (
    select *
    from {{ source('audit__snowflake', 'databases') }}

)

select *
from databases
