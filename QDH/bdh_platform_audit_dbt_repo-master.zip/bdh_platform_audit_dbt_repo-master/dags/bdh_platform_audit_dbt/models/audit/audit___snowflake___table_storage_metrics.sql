with table_storage_metrics as (
    select *
    from {{ source('audit__snowflake', 'table_storage_metrics') }}
)

select *
from table_storage_metrics
