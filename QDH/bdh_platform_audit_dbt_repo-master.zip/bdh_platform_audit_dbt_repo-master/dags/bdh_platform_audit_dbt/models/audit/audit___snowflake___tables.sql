with tables as (
    select *
    from {{ source('audit__snowflake', 'tables') }}
)

select *
from tables
