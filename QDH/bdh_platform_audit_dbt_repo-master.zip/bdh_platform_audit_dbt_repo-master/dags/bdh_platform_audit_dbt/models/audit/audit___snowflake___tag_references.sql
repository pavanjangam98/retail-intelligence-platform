with tag_references as (
    select *
    from {{ source('audit__snowflake', 'tag_references') }}
)

select *
from tag_references
