{{
    config(
        materialized='view'
    )
}}
with vw_user_roles as (
    select distinct
    g.name as table_name,
    g.table_schema,
    g.privilege,
    g.granted_on,
    g.grantee_name as role_name,
    rg.role as user_role,
    rg.grantee_name as username,
    g.table_catalog as database_name,
    case
            when wg.name is null then 'OTHER'
            when split_part(wg.name, '_', 1) = 'WH' then 'OTHER'
            else split_part(wg.name, '_', 1)
    end as zone
from {{ ref('audit___snowflake___grants_to_roles') }} as g
inner join {{ ref('audit___snowflake___grants_to_users') }} as rg
on g.grantee_name = rg.role
left join {{ ref('audit___snowflake___grants_to_roles') }} as wg
on g.grantee_name = wg.grantee_name  -- Match on the same role
    and wg.granted_on = 'WAREHOUSE'
    and wg.privilege in ('USAGE', 'OPERATE', 'OWNERSHIP')
    and wg.deleted_on is null
where g.granted_on in ('TABLE', 'VIEW')
    and g.deleted_on is null
order by g.name,
    g.privilege
)

select * from vw_user_roles
