{{
    config(
        materialized='view'
    )
}}
WITH vw_warehouse_rightsizing AS (

   SELECT
    warehouse_name,
    warehouse_size,
    finops_curated.credits_per_hour(warehouse_size) AS current_credits_per_hour,
    COUNT(*) AS query_count,
    COUNT(DISTINCT user_name) AS unique_users,
    finops_curated.mseconds_to_time(MEDIAN(total_elapsed_time)) AS median_elapsed_time,
    finops_curated.mseconds_to_time(MEDIAN(queued_overload_time)) AS median_queue_time,
    SUM(CASE WHEN queued_overload_time > 0 THEN 1 ELSE 0 END) AS queries_with_queue,
    AVG(bytes_spilled_to_remote_storage) AS avg_remote_spill_raw,
    -- Financial metrics
    ROUND(SUM(total_elapsed_time) / 3600000 * finops_curated.credits_per_hour(warehouse_size), 2) AS total_credits_consumed,

    -- Sizing status (for cost efficiency) - based only on total_elapsed_time using AVG   
     CASE
        WHEN PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY total_elapsed_time)
             > (MEDIAN(total_elapsed_time) * 5) -- P90 is 5x avg
        THEN 'ADAPTIVE_WORKLOAD'
        WHEN MEDIAN(total_elapsed_time) < 120000
             AND finops_curated.credits_per_hour(warehouse_size) >= 16
        THEN 'OVERSIZED'
        WHEN MEDIAN(total_elapsed_time) > 3600000
             AND finops_curated.credits_per_hour(warehouse_size) < 64
        THEN 'UNDERSIZED'
        ELSE 'WELL_SIZED'
     END AS sizing_status,

    -- Enhanced recommendations for mixed workloads
     CASE
        WHEN MEDIAN(total_elapsed_time) < 120000
             AND finops_curated.credits_per_hour(warehouse_size) >= 16
             AND AVG(bytes_spilled_to_remote_storage) = 0
        THEN 'DOWNSIZE to MEDIUM (4 credits/hr) - queries complete in <2 min'
        WHEN AVG(bytes_spilled_to_remote_storage) > 10737418240 -- >10GB
        THEN 'UPSIZE by 2-3 sizes - excessive remote spillage detected'
        WHEN AVG(bytes_spilled_to_remote_storage) > 1073741824 -- >1GB
        THEN 'UPSIZE by 1-2 sizes - remote spillage impacting performance'
        WHEN MEDIAN(total_elapsed_time) > 3600000
             AND finops_curated.credits_per_hour(warehouse_size) < 64
        THEN 'UPSIZE by 1 size - average runtime >1 hour'
        WHEN MEDIAN(queued_overload_time) > 30000
        THEN 'Enable multi-cluster OR separate workloads - queuing issues'
        WHEN PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY total_elapsed_time)
             > (MEDIAN(total_elapsed_time) * 5)
        THEN 'ADAPTIVE_WORKLOAD_DETECTED - Monitor query patterns; separate long-running queries to larger warehouse'
        ELSE 'No action needed - warehouse appropriately sized'
     END AS recommendation,

     CASE
        WHEN MEDIAN(total_elapsed_time) < 120000
             AND finops_curated.credits_per_hour(warehouse_size) >= 128
        THEN 'MEDIUM'
        WHEN MEDIAN(total_elapsed_time) < 120000
             AND finops_curated.credits_per_hour(warehouse_size) >= 32
        THEN 'SMALL'
        WHEN MEDIAN(total_elapsed_time) < 120000
             AND finops_curated.credits_per_hour(warehouse_size) >= 16
        THEN 'MEDIUM'
        ELSE warehouse_size
     END AS suggested_size,
    -- Potential savings calculation (for oversized only)
    CASE
        WHEN MEDIAN(total_elapsed_time) < 120000
             AND finops_curated.credits_per_hour(warehouse_size) >= 16
        THEN ROUND((finops_curated.credits_per_hour(warehouse_size) - 4)
                   * SUM(total_elapsed_time) / 3600000, 2)
        ELSE 0
    END AS potential_credit_savings,
    -- Monthly projection
    CASE
        WHEN MEDIAN(total_elapsed_time) < 120000
             AND finops_curated.credits_per_hour(warehouse_size) >= 16
        THEN ROUND((finops_curated.credits_per_hour(warehouse_size) - 4)
                   * SUM(total_elapsed_time) / 3600000 * 30, 2)
        ELSE 0
    END AS monthly_credit_savings_projection,

    DATEDIFF('day', MIN(start_time), MAX(start_time)) AS total_days_analyzed
FROM {{ ref('audit___snowflake___query_history') }}
WHERE warehouse_size IS NOT NULL
GROUP BY warehouse_name, warehouse_size
HAVING COUNT(*) >= 10
ORDER BY potential_credit_savings DESC, total_credits_consumed DESC
)

SELECT *
FROM vw_warehouse_rightsizing
