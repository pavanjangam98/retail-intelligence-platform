with grants_to_users as (
    select *
    from {{ source('audit__snowflake', 'grants_to_users') }}

)

select *
from grants_to_users
