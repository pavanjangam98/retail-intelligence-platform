{{
    config(
        materialized='view'
    )
}}
with cte_query_history as (
    select *
    from 
    {{ ref('audit___snowflake___query_history') }}   
    where warehouse_id is not null
        and warehouse_size is not null
),

cte_warehouse_metering_history as (
    select *
     from {{ ref('audit___snowflake___warehouse_metering_history') }}       
),

cte_join_qryh_and_wmh as (
    select
        qry.query_id,
        qry.start_time as query_start_time,
        qry.end_time as query_end_time,
        qry.database_name,
        qry.query_text,
        qry.user_name,
        qry.warehouse_name,
        qry.warehouse_size,
        qry.total_elapsed_time as query_runtime_milliseconds,
        qry.credits_used_cloud_services,
        wmh.warehouse_id,
        wmh.start_time as warehouse_start_time,
        wmh.end_time as warehouse_end_time,
        wmh.credits_used as warehouse_credits_used,
        qry.total_elapsed_time / 1000 as query_runtime_seconds
    from cte_query_history as qry
    left join cte_warehouse_metering_history as wmh
        on qry.start_time >= wmh.start_time
        and qry.end_time <= wmh.end_time
        and qry.warehouse_id = wmh.warehouse_id
),

cte_aggregate_wmh_records as (
    select
        warehouse_id,
        warehouse_start_time,
        warehouse_end_time,
        count(distinct query_id) as query_total_count,
        sum(query_runtime_milliseconds) as total_runtime_milliseconds
    from cte_join_qryh_and_wmh
    group by
        warehouse_id,
        warehouse_start_time,
        warehouse_end_time
),

cte_final as (
    select
        qry.query_id,
        qry.query_start_time,
        qry.query_end_time,
        qry.database_name,
        qry.query_text,
        qry.user_name,
        qry.warehouse_name,
        qry.warehouse_size,
        qry.query_runtime_milliseconds,
        qry.query_runtime_seconds,
        qry.credits_used_cloud_services,
        qry.warehouse_id,
        qry.warehouse_start_time,
        qry.warehouse_end_time,
        qry.warehouse_credits_used,
        agg.query_total_count,
        agg.total_runtime_milliseconds,
        qry.query_runtime_milliseconds / agg.total_runtime_milliseconds as query_cost_ratio,
        query_cost_ratio * qry.warehouse_credits_used as query_credits_used
    from cte_join_qryh_and_wmh as qry
    left join cte_aggregate_wmh_records as agg
        on qry.warehouse_start_time = agg.warehouse_start_time
        and qry.warehouse_end_time = agg.warehouse_end_time
        and qry.warehouse_id = agg.warehouse_id

)

select *
from cte_final
