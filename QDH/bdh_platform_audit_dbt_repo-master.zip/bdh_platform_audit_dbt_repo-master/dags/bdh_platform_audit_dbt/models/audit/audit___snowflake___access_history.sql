with access_history as (
    select *
    from {{ source('audit__snowflake', 'access_history') }}
    
)

select *
from access_history
