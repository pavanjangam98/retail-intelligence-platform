with users as (
    select *
    from {{ source('audit__snowflake', 'users') }}

)

select *
from users
