with warehouse_metering_history as (
    select *
    from {{ source('audit__snowflake', 'warehouse_metering_history') }}
)

select *
from warehouse_metering_history
