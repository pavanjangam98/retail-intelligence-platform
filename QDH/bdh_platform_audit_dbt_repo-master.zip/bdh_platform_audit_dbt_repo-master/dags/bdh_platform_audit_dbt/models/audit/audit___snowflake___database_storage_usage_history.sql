with storage_usage_history as (
    select *
    from {{ source('audit__snowflake', 'database_storage_usage_history') }}
)

select *
from storage_usage_history
