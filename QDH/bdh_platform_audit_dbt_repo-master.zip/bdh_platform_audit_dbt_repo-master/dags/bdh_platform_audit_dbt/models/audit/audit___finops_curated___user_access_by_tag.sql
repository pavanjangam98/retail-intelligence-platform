{{
    config(
        materialized='view'
    )
}}
with user_tag_access_detailed as (

    select distinct
    t.object_database as database_name,
    t.object_schema as schema_name,
    t.object_name as table_name,
    t.column_name,
    t.tag_name,
    t.tag_value,
    gu.grantee_name as username,
    gr.privilege as privilege_type,
    gr.granted_on,
    gr.created_on,
    case
            when wg.name is null then 'OTHER'
            when split_part(wg.name, '_', 1) = 'WH' then 'OTHER'
            else split_part(wg.name, '_', 1)
    end as zone

from {{ ref('audit___snowflake___tag_references') }} as t

inner join {{ ref('audit___snowflake___columns') }} as c
    on t.object_database = c.table_catalog
    and t.object_schema = c.table_schema
    and t.object_name = c.table_name
    and t.column_name = c.column_name

inner join {{ ref('audit___snowflake___grants_to_roles') }} as gr
    on c.table_catalog = gr.table_catalog
    and c.table_schema = gr.table_schema
    and c.table_name = gr.name
    and gr.granted_on = 'TABLE'

inner join {{ ref('audit___snowflake___grants_to_users') }} as gu
    on gr.grantee_name = gu.role

left join {{ ref('audit___snowflake___grants_to_roles') }} as wg
on gr.grantee_name = wg.grantee_name  -- Match on the same role
    and wg.granted_on = 'WAREHOUSE'
    and wg.privilege in ('USAGE', 'OPERATE', 'OWNERSHIP')
    and wg.deleted_on is null

where t.domain = 'COLUMN'
  and t.object_deleted is null      -- Only active tag references
  and gr.deleted_on is null     -- Only active grants
  and gu.deleted_on is null     -- Only active user grants
order by t.object_database, t.object_schema, t.object_name, t.column_name
)

select * from user_tag_access_detailed
