with columns as (
    select *
    from {{ source('audit__snowflake', 'columns') }}
   
)

select *
from columns
