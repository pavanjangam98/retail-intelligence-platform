{{
    config(
        materialized='view'
    )
}}
with vw_batch_job_optimization as (
select
    query_tag as job_id,
     warehouse_name,
    warehouse_size,
    case
            when split_part(warehouse_name, '_', 1) = 'WH' then 'OTHER'
            else split_part(warehouse_name, '_', 1)
     end as zone,
    finops_curated.credits_per_hour(warehouse_size) as credits_per_hour,

    -- Execution and usage metrics
    count(*) as total_executions,
    count(distinct date(start_time)) as last_active_days,

    -- Key performance metrics
    finops_curated.mseconds_to_time(median(total_elapsed_time)) as median_total_elapsed_time,

    -- Spillage insights
    finops_curated.format_bytes(avg(bytes_spilled_to_remote_storage)) as avg_spill_remote,
    round(sum(case when bytes_spilled_to_remote_storage > 0 then 1 else 0 end) * 100.0 / count(*), 1) as pct_with_spill,

    -- Credit and cost usage
    round(sum(total_elapsed_time) / 3600000 * finops_curated.credits_per_hour(warehouse_size), 2) as total_credits_consumed,
    round(avg(total_elapsed_time) / 3600000 * finops_curated.credits_per_hour(warehouse_size), 2) as avg_credits_per_execution,

     -- Optimization recommendations
    case
        when median(total_elapsed_time) < 120000
             and finops_curated.credits_per_hour(warehouse_size) > 16
        then 'OVERSIZED'
        when avg(bytes_spilled_to_remote_storage) > 10737418240 -- >10GB
        then 'UNDERSIZED_CRITICAL'
        when avg(bytes_spilled_to_remote_storage) > 1073741824 -- >1GB
        then 'UNDERSIZED_HIGH'
        when percentile_cont(0.90) within group (order by total_elapsed_time) > 28800000
             and finops_curated.credits_per_hour(warehouse_size) < 32
        then 'UNDERSIZED_LONG_RUNTIME'
        when percentile_cont(0.90) within group (order by total_elapsed_time)
             > (median(total_elapsed_time) * 10)
        then 'ADAPTIVE_WORKLOAD'
        else 'WELL_SIZED'
    end as sizing_status,

    case
        when median(total_elapsed_time) < 120000
             and finops_curated.credits_per_hour(warehouse_size) > 16
        then 'DOWNSIZE to MEDIUM - jobs complete quickly, wasting credits'
        when avg(bytes_spilled_to_remote_storage) > 10737418240
        then 'UPSIZE by 2-3 sizes URGENTLY - >10GB remote spillage'
        when avg(bytes_spilled_to_remote_storage) > 1073741824
        then 'UPSIZE by 1-2 sizes - significant remote spillage'
        when percentile_cont(0.90) within group (order by total_elapsed_time) > 28800000
             and finops_curated.credits_per_hour(warehouse_size) < 32
        then 'UPSIZE to reduce runtime - jobs taking >8 hours'
        when percentile_cont(0.90) within group (order by total_elapsed_time)
             > (median(total_elapsed_time) * 10)
        then 'ADAPTIVE_WORKLOAD_DETECTED - Monitor query patterns; separate long-running queries to larger warehouse'
        else 'No action needed - job appropriately sized'
    end as recommendation,

    case
        when avg(total_elapsed_time) < 120000
             and finops_curated.credits_per_hour(warehouse_size) > 16
        then round((finops_curated.credits_per_hour(warehouse_size) - 4)
                   * sum(total_elapsed_time) / 3600000, 2)
        when avg(bytes_spilled_to_remote_storage) > 1073741824
        then round((finops_curated.credits_per_hour(warehouse_size) * 2 - finops_curated.credits_per_hour(warehouse_size))
                   * sum(total_elapsed_time) / 3600000 * 0.5, 2) * -1
        else 0
    end as estimated_credit_impact,

    -- Execution window
    min(start_time) as first_execution,
    max(start_time) as last_execution

from {{ ref('audit___snowflake___query_history') }}
where warehouse_size is not NULL
  and query_tag is not NULL
group by query_tag, warehouse_name, warehouse_size
having count(*) >= 3
order by total_credits_consumed desc, avg_spill_remote desc
)

select * from vw_batch_job_optimization
