{{
    config(
        materialized='view'
    )
}}

select
    wr.warehouse_name,
    wr.warehouse_size,
    ROUND(wr.total_credits_consumed / wr.total_days_analyzed, 2) as avg_daily_credits,
    ROUND(wr.total_credits_consumed / wr.total_days_analyzed * 30, 2) as projected_monthly_credits

from {{ ref('audit___finops_curated___warehouse_recommender') }} as wr
where wr.total_days_analyzed > 0
