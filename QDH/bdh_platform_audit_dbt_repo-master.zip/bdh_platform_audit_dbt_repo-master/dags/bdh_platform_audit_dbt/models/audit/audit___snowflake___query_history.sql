with queries as (
    select *
    from {{ source('audit__snowflake', 'query_history') }}

)

select * from queries
