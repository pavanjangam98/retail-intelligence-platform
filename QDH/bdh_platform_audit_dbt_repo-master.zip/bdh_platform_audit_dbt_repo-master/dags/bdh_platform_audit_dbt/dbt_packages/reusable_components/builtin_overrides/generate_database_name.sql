{% macro generate_database_name(custom_database_name=none, node=none) %}
 
    {# Split the node name into database, schema, and object name components #}
    {# assign the zone dbtvariable  #}
    -- It pulls the DBT_BDH_ZONE  dbt variable 
    {% set bdh_zone = var('DBT_BDH_ZONE') %}
    {# assign the is_airflow environment variable and assign default value as false #}
    -- It pulls the IS_AIRFLOW  environment variable
    {% set bdh_isairflow = env_var('IS_AIRFLOW') %}
    -- Assign the current target environment ,the node name, and splits the node name to identify parts like database ,schema ,object
    {% set environment = target.name.lower() %}
    {% set node_name = node.name %}
    {% set split_name = node_name.split('___', 2) %}
    {% set node_type = node.unique_id.split('.', 1)[0] %}
    {% set bdh_package = 'bdh' in node.unique_id.split('.', 2)[1] %}
    {% set database_name = split_name[0] %}
    -- Error handling for invalid naming or configurations:
    -- If the node type is one of model, snapshot, or seed, but the node name doesn’t follow the expected database__schema__object format, it raises an error.
    {# Validate the split resulted in three parts, otherwise raise an error #}
    {% if bdh_package and node_type in ['model', 'snapshot', 'seed'] and split_name | length != 3 %}
        {{ exceptions.raise_compiler_error('Invalid naming syntax (should be <database>___<schema>___<object>): ' ~ node_name) }}
    {% endif %}
 
    {# Validate the environment #}
    -- It also checks if the environment is valid (dev, tst, or prd), and raises an error if not.
    {% if environment not in ['dev', 'syst', 'ppte','prod','preprod'] %}
        {{ exceptions.raise_compiler_error('Unsupported target defined (should be dev, tst, or prod): ' ~ environment) }}
    {% endif %}
    --It ensures that the target.database is defined before proceeding.
    {% if target.database is none %}
        {{ exceptions.raise_compiler_error('Invalid node ID for generating database name in database generation: ' ~ node.unique_id) }}
    {% endif %}
    {# Generate the final database name based on environment conditions #}
    {# Checking for is excution mode is an airflow #}
    -- Check isairflow environment
	{%- if bdh_isairflow == "false" -%}
        -- If the environment is dev or the node type is operation, it directly returns the target.database.
		{% if environment == 'dev' or node_type == 'operation' %}
			{{ return(target.database.lower()) }}
	    {% elif not bdh_package %}
			{{ return((bdh_zone ~ '__Transform'  ~ environment) if custom_database_name is none else custom_database_name) }}
		{% else %}
			{% if database_name is none %}
				{{ exceptions.raise_compiler_error('Invalid node ID for generating database name in database generation: ' ~ node.unique_id) }}
			{% endif %}	
			-- generating database names dynamically, ensuring that naming conventions and environments are properly handled.	
			{{ return((bdh_zone ~ '__' ~ database_name ~ '__' ~ environment) if custom_database_name is none else custom_database_name) }}
		{% endif %}

	{%- else -%}
        
        {% if database_name is none %}
			{{ exceptions.raise_compiler_error('Invalid node ID for generating database name in database generation: ' ~ node.unique_id) }}
		{% endif %}
        -- generating database names dynamically, ensuring that naming conventions and environments are properly handled.
		{{ return((bdh_zone ~ '__' ~ database_name ~ '__' ~ environment) if custom_database_name is none else custom_database_name) }}	
	{%- endif -%}       
{% endmacro %}
