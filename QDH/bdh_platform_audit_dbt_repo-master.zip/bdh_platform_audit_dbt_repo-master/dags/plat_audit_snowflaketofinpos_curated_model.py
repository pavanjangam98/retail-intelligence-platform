import os
from datetime import datetime
from cosmos import DbtDag, ProjectConfig, ProfileConfig, ExecutionConfig, RenderConfig
from cosmos.profiles import SnowflakePrivateKeyPemProfileMapping

# Environment setup
target_name = os.getenv("TARGET_NAME", "preprod").lower()
schema_name = os.getenv("SCHEMA_NAME", "snowflake").lower()

# DAG definition
model_build_dag = DbtDag(
    
    project_config=ProjectConfig("/usr/local/airflow/dags/repo/dags/bdh_platform_audit_dbt/"),
    
    profile_config=ProfileConfig(
        profile_name="default",
        target_name=target_name,
        profile_mapping=SnowflakePrivateKeyPemProfileMapping(
            conn_id="sfconnect",
            profile_args={"schema": schema_name},
        )
    ),
    
    execution_config=ExecutionConfig(
        dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt"
    ),
    
    render_config=RenderConfig(
        select=["path:models/audit"],
    ),
    schedule_interval="0 0 * * *",
    start_date=datetime(2025, 12, 1),
    catchup=False,
    dag_id="plat_audit_snowflaketofinpos_curated_model",
    tags=["daily", "snowflake", "finops_curated"],
)


