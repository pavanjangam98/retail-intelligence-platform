// Disable unit testing in your pipeline
ENABLE_UNIT_TEST = false
// Disable integration testing in your pipeline
ENABLE_INTEGRATION_TEST = false
// Disables PMD in your pipeline. Currently only applies to gradle projects.
ENABLE_LOCAL_QUALITY_SCAN = false
// Disable SonarQube analysis
ENABLE_CODE_QUALITY_SCAN = false
// Disable Checkmarx analysis
ENABLE_STATIC_SECURITY_SCAN = false
// Disable container scan (wizcli) scanning. Only applies when you are building a Docker image in your pipeline.
ENABLE_CONTAINER_SECURITY_SCAN = false
// Disable Nexus IQ scanning
ENABLE_DEPENDENCY_SECURITY_SCAN = false
 
jte {
  pipeline_template = "astronomer_gitsync"
}
 
 
libraries {
  astronomer 
{
    build_template {
            version = '3.11'
   }
   ADGroup = "A_BDH_mj_fg_plat_astro_deployer"  
   Astro_Sync_Gitrepo = "bdh_platform_audit_dbt_gitsync_repo"
  }

sonarqube {
    enabled = false
  }
 
  
  sonatype {
        application_id = 'snowflake_uplift'
        organisation = 'Data and Analytics'
  }
  checkmarx {
        project_path = 'CxServer/BNZ Technology/Bank of New Zealand/Digital'
    }
}
