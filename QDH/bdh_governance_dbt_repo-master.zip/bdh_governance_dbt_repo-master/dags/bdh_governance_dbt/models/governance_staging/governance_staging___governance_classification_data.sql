WITH temp_table AS (

    SELECT 
        am_base.object_id,
        am_base.object_type,
        am_base.catalog_set_ids,
        cm.catalog_set_property_id      AS cm_set_id,
        cm.catalog_set_title,
        rc.column_id,
        upper(rc.name)                         AS column_name,
        rc.title                        AS column_title,
        rc.table_id,
        upper(rt.name)                         AS table_name,
        rc.schema_id,
        upper(split_part(rs.name, '.', 2))    AS schema_name,
        upper(REGEXP_REPLACE(rs.db_catalog_name, '__[^_]+$', '')) AS db_name,
        upper(COALESCE(rc.is_primary_key, FALSE) ) AS primary_key_flag,
        rc.data_type,
        rc.deleted AS src_deleted,
        upper(COALESCE(REGEXP_REPLACE(cm.business_key, '[\\{\\}''"]', ''), FALSE)) AS business_key_flag,
        upper(cm.security_classification) AS security_classification,
        array_to_string(cm.classification_tag, ',') AS classification_tag_str,
        cm.ts_updated,
        upper(split_part(rs.db_catalog_name, '__',1)) as zone_name,
        upper(REGEXP_SUBSTR(rs.db_catalog_name, '[^_]+$')) as environment


    FROM  {{ source('snowflake_share','alation_set_member') }}  am_base
    -- {{ ref( 'stg_alation___alation___alation_set_member') }} am_base

    CROSS JOIN LATERAL FLATTEN(input => am_base.catalog_set_ids) f

    JOIN 
      {{ source('snowflake_share','catalog_set_membership') }} cm
    --{{ ref( 'stg_alation___alation___catalog_set_membership') }} cm
        ON f.value::string = cm.catalog_set_property_id

    JOIN 
    --{{ ref( 'stg_alation___alation___rdbms_columns') }} rc
      {{ source('snowflake_share','rdbms_columns') }} rc
        ON am_base.object_id = rc.column_id

    JOIN 
      {{ source('snowflake_share','rdbms_tables') }} rt
    --{{ ref( 'stg_alation___alation___rdbms_tables') }} rt
        ON rc.table_id = rt.table_id

    JOIN 
        {{ source('snowflake_share','rdbms_datasources') }} rd
       -- {{ ref( 'stg_alation___alation___rdbms_datasources') }} rd
        ON rt.ds_id = rd.ds_id

    JOIN 
        {{ source('snowflake_share','rdbms_schemas') }} rs
        -- {{ ref( 'stg_alation___alation___rdbms_schemas') }} rs
        ON rt.schema_id = rs.schema_id

    WHERE UPPER(am_base.object_type) = 'ATTRIBUTE'
      AND upper(cm.deleted) = upper(FALSE)

),

/* STEP 1: Sensitivity Ranking */
cleaned AS (

    SELECT
        object_id,
        db_name,
        schema_name,
        table_name,
        column_name,

        COALESCE(
            REGEXP_REPLACE(security_classification, '[\\{\\}''"]', ''),
            'Unclassified'
        ) AS security_classification_code,
        'ALATION' AS SOURCE_SYSTEM,
        classification_tag_str,
        CASE 
            WHEN business_key_flag = 'TRUE' THEN 'Y' 
            ELSE 'N' 
        END AS business_key_flag,
        CASE 
            WHEN primary_key_flag = 'TRUE' THEN 'Y' 
            ELSE 'N' 
        END AS primary_key_flag,
        data_type,
        CASE 
            WHEN src_deleted = 'TRUE' THEN 'Y' 
            ELSE 'N' 
        END AS is_src_deleted,
        catalog_set_title,
        ts_updated,
        security_classification,
        zone_name,
        case 
            when environment in ('DEV','SYST') THEN 'PREPROD'
            when environment in ('PPTE','PROD') THEN 'PROD'
            else null 
        end as env_name,       
		environment
    FROM temp_table
),

filtered_data AS (

   SELECT *  , CASE 
            WHEN security_classification IN ('HIGHLY CONFIDENTIAL','UNCLASSIFIED') THEN 1
            WHEN security_classification = 'CONFIDENTIAL' THEN 2
            WHEN security_classification = 'PRIVATE' THEN 3
            WHEN security_classification = 'PUBLIC' THEN 4
            ELSE 5
        END AS sensitivity_rank   FROM cleaned  where env_name = '{{ target.name }}' and environment in('DEV','PPTE')
),

/* STEP 2: Detect Upgrade/Downgrade */
classified AS (

    SELECT *,
        LAG(sensitivity_rank) OVER (
            PARTITION BY db_name, schema_name, table_name, column_name
            ORDER BY ts_updated
        ) AS prev_rank
    FROM filtered_data
),

/* STEP 3: Smart Ranking */
ranked AS (

    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY db_name, schema_name, table_name, column_name
            ORDER BY 

                /* Upgrade → prefer more sensitive */
                CASE 
                    WHEN prev_rank IS NOT NULL 
                         AND sensitivity_rank < prev_rank
                    THEN sensitivity_rank
                END ASC,

                /* Downgrade → prefer latest */
                CASE 
                    WHEN prev_rank IS NOT NULL 
                         AND sensitivity_rank > prev_rank
                    THEN ts_updated
                END DESC,

                /* Fallback → latest always wins */
                ts_updated DESC

        ) AS rn
    FROM classified
)

SELECT
    object_id,
    db_name,
    schema_name,
    table_name,
    column_name,
    security_classification_code,
    SOURCE_SYSTEM,
    zone_name,
    env_name,
    business_key_flag,
    primary_key_flag,
    data_type,
    is_src_deleted,
    ts_updated AS SOURCE_DS_UPDATE,
    CURRENT_TIMESTAMP AS record_created_at,
    CURRENT_TIMESTAMP AS record_updated_at
FROM ranked
WHERE rn = 1
 
