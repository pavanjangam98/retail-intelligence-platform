{{ config(
    materialized='incremental',
    unique_key='dbt_scd_id',
    incremental_strategy='merge',
    schema='governance_classification',
    on_schema_change='fail'
) }}


with source_rows_base as (
    select
        object_id                   as classification_id,
        db_name,
        schema_name,
        table_name,
        column_name,
        initcap(security_classification_code) as security_classification_code,
        source_system,
        zone_name,
        env_name,
        business_key_flag,
        primary_key_flag,
        is_src_deleted,
        source_ds_update,
        record_created_at
    from 
    {{ ref('governance_staging___governance_classification_data') }}
    where object_id is not null
),

source_rows_validated as (
    select *
    from source_rows_base
    where classification_id  is not null
      and source_ds_update is not null
    qualify row_number() over (
        partition by classification_id , source_ds_update
        order by source_ds_update
    ) = 1
),

source_rows_value_change as (
    select *,
        md5(
            coalesce(cast(classification_id  as string),              '') || '-' ||
            coalesce(cast(source_ds_update as string), '') || '-' ||
            coalesce(cast(db_name as string),         '') || '-' ||
            coalesce(cast(column_name as string),     '')
        ) as dbt_scd_id,

        -- attribute hash: change in ANY of these columns triggers SCD2
        md5(
            coalesce(cast(security_classification_code as string), '') || '-' ||
            coalesce(cast(business_key_flag        as string), '') || '-' ||
            coalesce(cast(primary_key_flag        as string), '') || '-' ||
            coalesce(cast(is_src_deleted            as string), '')
        ) as dwh_attribute_hash,

        case
            when row_number() over (
                partition by classification_id order by source_ds_update
            ) = 1
                then 'NEW'
            when md5(
                    coalesce(cast(security_classification_code as string), '') || '-' ||
                    coalesce(cast(business_key_flag       as string), '') || '-' ||
                    coalesce(cast(primary_key_flag        as string), '') || '-' ||
                    coalesce(cast(is_src_deleted            as string), '')
                 ) <>
                 lag(md5(
                    coalesce(cast(security_classification_code as string), '') || '-' ||
                    coalesce(cast(business_key_flag        as string), '') || '-' ||
                    coalesce(cast(primary_key_flag         as string), '') || '-' ||
                    coalesce(cast(is_src_deleted           as string), '')
                 )) over (partition by classification_id order by source_ds_update)
                then 'CHANGED'
            else 'UNCHANGED'
        end as dwh_change_type,

        source_ds_update                    as dwh_effective_from_tstamp,
        TO_TIMESTAMP_NTZ('9999-12-31')      as dwh_effective_to_tstamp,
        'Y'                                 as is_active,
        current_timestamp()                 as dwh_process_tstamp,
        concat(
            conditional_change_event(
                md5(
                    coalesce(cast(security_classification_code as string), '') || '-' ||
                    coalesce(cast(business_key_flag        as string), '') || '-' ||
                    coalesce(cast(primary_key_flag         as string), '') || '-' ||
                    coalesce(cast(is_src_deleted           as string), '')
                )
            ) over (partition by classification_id order by source_ds_update asc),
            '_',
            to_char(source_ds_update, 'YYYY-MM-DD HH24:MI:SS.FF3')
        ) as value_change

    from source_rows_validated
),

source_rows_first_value_change as (
    select *
    from source_rows_value_change
    qualify row_number() over (
        partition by classification_id, value_change
        order by source_ds_update asc
    ) = 1
),

source_rows as (
    select *
    from source_rows_first_value_change
    {% if is_incremental() %}
    -- 3-day lookback window to catch late-arriving records
    where record_created_at > (
        select coalesce(dateadd(day, -1, max(dwh_process_tstamp)), '1900-01-01')
        from {{ this }}
    )
    {% endif %}
),

-- ─────────────────────────────────────────────
-- DESTINATION: empty  on first run,reads only open rows on incremental
-- ─────────────────────────────────────────────

destination_rows as (
    {% if is_incremental() %}
        select * from {{ this }}
        where dwh_effective_to_tstamp = TO_TIMESTAMP_NTZ('9999-12-31')
    {% else %}
        select
            cast(null as NUMBER(38,0))        as classification_id,
            cast(null as string)        as db_name,
            cast(null as string)        as schema_name,
            cast(null as string)        as table_name,
            cast(null as string)        as column_name,
            cast(null as string)        as security_classification_code,
            cast(null as string)        as business_key_flag,
            cast(null as string)        as primary_key_flag,
            cast(null as string)        as is_src_deleted,
            cast(null as TIMESTAMP_TZ(9))     as source_ds_update,
            cast(null as TIMESTAMP_TZ(9))     as dwh_effective_from_tstamp,
            cast(null as TIMESTAMP_TZ(9))     as dwh_effective_to_tstamp,
            cast(null as string)        as dbt_scd_id,
            cast(null as string)        as dwh_change_type,
            cast(null as string)        as is_active,
            cast(null as string)        as dwh_attribute_hash,
            cast(null as TIMESTAMP_TZ(9))     as dwh_process_tstamp
        where 1 = 0
    {% endif %}
),

-- ─────────────────────────────────────────────
-- COMPARE SOURCE VS DESTINATION
-- ─────────────────────────────────────────────

source_data_by_id as (
    select
        s.classification_id, s.db_name, s.schema_name, s.table_name, s.column_name,
        s.security_classification_code, s.business_key_flag, s.primary_key_flag,
        s.is_src_deleted,
        s.source_ds_update,
        s.dbt_scd_id,
        s.dwh_change_type,
        s.is_active,
        s.dwh_attribute_hash                        as src_attribute_hash,
        s.dwh_process_tstamp,
        d.dwh_attribute_hash                        as dest_attribute_hash,
        d.dbt_scd_id                                as dest_dbt_scd_id,
        d.source_ds_update                          as dest_source_ds_update,
        case
            when d.classification_id is null                                then 'NEW'
            when s.dwh_attribute_hash = d.dwh_attribute_hash then 'UNCHANGED'
            else                                                  'CHANGED'
        end as derived_dml_type_code
    from source_rows s
    left join destination_rows d
        on  s.classification_id = d.classification_id
        and d.dwh_effective_to_tstamp = TO_TIMESTAMP_NTZ('9999-12-31')
),

-- ─────────────────────────────────────────────
-- EXPIRE OLD ROWS
-- ─────────────────────────────────────────────

new_valid_to as (
    select
        dest_dbt_scd_id                             as dbt_scd_id,
        classification_id,
        dateadd(day, -1, source_ds_update)  as dwh_effective_to_tstamp,
        'N'                                         as new_is_active
    from source_data_by_id
    where derived_dml_type_code = 'CHANGED'
),

records_to_update as (
    select
        d.*,
        n.dwh_effective_to_tstamp                   as new_effective_to_tstamp,
        n.new_is_active
    from destination_rows d
    inner join new_valid_to n
        on  d.classification_id         = n.classification_id
        and d.dbt_scd_id = n.dbt_scd_id
),

-- Same dbt_scd_id → merge UPDATEs the existing row (closes it)
updated_records as (
    select
        classification_id, db_name, schema_name, table_name, column_name,
        security_classification_code, business_key_flag, primary_key_flag,
        is_src_deleted,
        source_ds_update,
        dwh_effective_from_tstamp,
        new_effective_to_tstamp                     as dwh_effective_to_tstamp,
        dbt_scd_id,
        dwh_change_type,        --  'new' or 'changed' from original insert
        new_is_active           as is_active,
        dwh_attribute_hash,
        dwh_process_tstamp
    from records_to_update
),
-- ─────────────────────────────────────────────
-- PASS-THROUGH UNCHANGED DESTINATION ROWS
-- ─────────────────────────────────────────────
unchanged_records as (
    select
        d.classification_id, d.db_name, d.schema_name, d.table_name, d.column_name,
        d.security_classification_code, d.business_key_flag, d.primary_key_flag,
        d.is_src_deleted,
        d.source_ds_update,
        d.dwh_effective_from_tstamp,
        d.dwh_effective_to_tstamp,
        d.dbt_scd_id,
        case
            when s.derived_dml_type_code = 'UNCHANGED'
             and d.dwh_effective_to_tstamp = TO_TIMESTAMP_NTZ('9999-12-31')
                then 'UNCHANGED'
            else d.dwh_change_type  --  'new' or 'changed' from original insert
        end                                         as dwh_change_type,
        d.is_active,
        d.dwh_attribute_hash,
        d.dwh_process_tstamp
    from destination_rows d
    left join new_valid_to n
        on  d.classification_id         = n.classification_id
        and d.dbt_scd_id = n.dbt_scd_id
    -- only join unchanged source rows to prevent fan-out
    left join source_data_by_id s
        on  d.classification_id                    = s.classification_id
        and s.derived_dml_type_code = 'UNCHANGED'
    where n.dbt_scd_id is null      -- exclude rows already being closed
),
-- ─────────────────────────────────────────────
-- INSERT NEW SCD2 ROWS
-- ─────────────────────────────────────────────

new_source_records as (
    select
        classification_id, db_name, schema_name, table_name, column_name,
        security_classification_code, business_key_flag, primary_key_flag,
        is_src_deleted,
        source_ds_update,
        source_ds_update                            as dwh_effective_from_tstamp,
        TO_TIMESTAMP_NTZ('9999-12-31')              as dwh_effective_to_tstamp,
        dbt_scd_id,
        derived_dml_type_code                       as dwh_change_type,  -- 'new' or 'changed'
        is_active,
        src_attribute_hash                          as dwh_attribute_hash,
        dwh_process_tstamp
    from source_data_by_id
    where derived_dml_type_code != 'UNCHANGED'
),

-- ─────────────────────────────────────────────
-- COMBINE ALL
-- ─────────────────────────────────────────────

all_records as (
    select * from updated_records
    union all
    select * from unchanged_records
    union all
    select * from new_source_records
)

select
    classification_id, 
    db_name, 
    schema_name, 
    table_name, 
    column_name,
    security_classification_code, 
    business_key_flag, 
    primary_key_flag,
    is_src_deleted,
    source_ds_update,
    dwh_effective_from_tstamp,
    dwh_effective_to_tstamp,
    dbt_scd_id,
    dwh_change_type,
    is_active,
    dwh_attribute_hash,
    dwh_process_tstamp
from all_records
qualify row_number() over (
    partition by classification_id, dwh_effective_from_tstamp
    order by
        dwh_effective_from_tstamp asc,
        case
            when dwh_change_type = 'NEW'     then 1
            when dwh_change_type = 'CHANGED' then 2
            else                                  3
        end,
        dwh_effective_to_tstamp asc  -- expired row always wins over open row
) = 1
