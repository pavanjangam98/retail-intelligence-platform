
{{ config(
    materialized='view',
    schema='governance_classification',
) }}

select *
from 
{{ ref('governance_classification___governance_classification_data_history') }}
where  is_active = 'Y'  and upper(is_src_deleted) = 'N'     
   
