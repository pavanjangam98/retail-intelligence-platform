{{ config(
    materialized='incremental',
    incremental_strategy='merge',
    unique_key='table_id',
    on_schema_change='sync_all_columns'
) }}

WITH source_data AS (
    SELECT
        *,
        CURRENT_TIMESTAMP AS LOADED_AT
    FROM {{ source('alation_share', 'rdbms_tables') }}
    WHERE DS_ID IN (19,27)
),

incremental_filter AS (
    SELECT *
    FROM source_data
    {% if is_incremental() %}
        WHERE DIM_TS_CREATED >=
        (
            SELECT coalesce(dateadd(day, -1, max(LOADED_AT)), '1900-01-01')
        from {{ this }}
        )
    {% endif %}
)
SELECT *
FROM incremental_filter