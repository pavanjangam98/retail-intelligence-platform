{% macro apply_tags_and_masking() %}

{% set this_db = this.database | upper %}
{% set this_schema = this.schema | upper %}
{% set this_table = this.identifier | upper %}

{% set classification_table = source('classification','STG_GOVERNANCE_CLASSIFICATION_DATA') %}
{% set tagging_schema = source('tags','TAGS').database ~ '.' ~ source('tags','TAGS').schema %}
{% set masking_schema = 'GOVERNANCE__PREPROD.GOVERNANCE_MASKING' %}

{% set info_columns = this_db ~ '.information_schema.columns' %}

{% set query %}
SELECT
    upper(trim(C.column_name)) column_name,
    C.security_classification_code,
    I.data_type
FROM {{ classification_table }} C
JOIN {{ info_columns }} I
ON upper(trim(C.column_name)) = upper(I.column_name)
WHERE upper(trim(C.table_name)) = '{{ this_table }}'
AND upper(trim(C.schema_name)) = '{{ this_schema }}'
AND upper(trim(C.db_name)) = '{{ this_db }}'
{% endset %}

{% set results = run_query(query) %}

{% if execute %}
    {% set rows = results.rows %}
    {% set cols = results.column_names %}
    {% set statements = [] %}

    {% for r in rows %}

        {% set column_name = r[0] %}
        {% set classification = r[1] %}
        {% set data_type = r[2] %}

        {# Determine masking policy #}

        {% if data_type in ['NUMBER','INT','INTEGER','DECIMAL'] %}
            {% set mask_policy = masking_schema ~ '.SENSITIVE_DATA_MASK_NUMBER' %}
        {% elif data_type in ['VARCHAR','STRING','TEXT'] %}
            {% set mask_policy = masking_schema ~ '.SENSITIVE_DATA_MASK_STRING' %}
        {% elif data_type == 'BOOLEAN' %}
            {% set mask_policy = masking_schema ~ '.SENSITIVE_DATA_MASK_BOOLEAN' %}
        {% elif data_type in ['DATE'] %}
            {% set mask_policy = masking_schema ~ '.SENSITIVE_DATA_MASK_DATE' %}
        {% elif 'TIMESTAMP' in data_type %}
            {% set mask_policy = masking_schema ~ '.SENSITIVE_DATA_MASK_TIMESTAMP' %}
        {% else %}
            {% set mask_policy = masking_schema ~ '.SENSITIVE_DATA_HASH_SHA256' %}
        {% endif %}

        {% set stmt %}
ALTER TABLE {{ this }}
MODIFY COLUMN {{ column_name }}
SET TAG {{ tagging_schema }}.SECURITY_CLASSIFICATION_CODE = '{{ classification }}',
SET MASKING POLICY {{ mask_policy }}
        {% endset %}

        {% do statements.append(stmt) %}

    {% endfor %}

{% endif %}

{{ statements | join(';\n') }}

{% endmacro %}