{% macro get_database(mapping_key) %}
    {% if mapping_key == 'primary' %}
        {% if target.name == 'DEV' %}
            GOVERNANCE__STG_ALATION__PREPROD
        {% elif target.name == 'PPTE' %}
            GOVERNANCE__STG_ALATION__PPTE
        {% else %}
            GOVERNANCE__STG_ALATION__PROD
        {% endif %}
    {% elif mapping_key == 'secondary' %}
        {% if target.name == 'DEV' %}
            GOVERNANCE__PREPROD
        {% elif target.name == 'PREPROD' %}
            GOVERNANCE__PREPROD
        {% else %}
            GOVERNANCE__PROD
        {% endif %}
    {% endif %}
{% endmacro %}