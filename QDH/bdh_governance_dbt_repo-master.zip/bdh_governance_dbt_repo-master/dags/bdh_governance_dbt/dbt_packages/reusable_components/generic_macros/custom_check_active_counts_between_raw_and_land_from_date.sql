{% macro custom_check_active_counts_between_raw_and_land_from_date(
    model,
    model_key_columns,
    source_name,
    table_name,
    compare_key_columns,
    ingestion_type="non_kafka",
    load_type="non_append",
    look_back=1,
    raise_error=True,
	afterState="afterState",
	beforeState="beforeState"
) %}

-- Raw model time column based on raw table type
{% if load_type == "append" %}
    {% set model_time_col = "DWH_EXTRACTION_TSTAMP" %}
{% elif load_type == "non_append" %}
    {% set model_time_col = "DWH_EFFECTIVE_FROM_TSTAMP" %}
{% else %}
    {{ exceptions.raise_compiler_error("Unsupported load_type: " ~ load_type) }}    
{% endif %}

-- Set the landing/compare table
{% set compare_model = source(source_name, table_name) %}

-- Determine compare time column based on ingestion type
{% if ingestion_type == "kafka" %}
    {% set compare_time_col = "convert_timezone('Pacific/Auckland','Pacific/Auckland', parse_json(record_content):metadata:time::TIMESTAMP_NTZ)" %}
{% elif ingestion_type == "non_kafka" %}
    {% set compare_time_col = "LOAD_DATE::DATE" %} 
{% else %}
    {{ exceptions.raise_compiler_error("Unsupported ingestion_type: " ~ ingestion_type) }}
{% endif %}

--------------------------------------------------------------------------------
-- Defining current timestamp
--------------------------------------------------------------------------------
{% set current_ts_query %}
    SELECT current_timestamp AS current_ts
{% endset %}
{% set current_ts_result = run_query(current_ts_query) %}
{% set current_ts = current_ts_result.columns[0].values()[0] %}
{{ log("Current timestamp used in macro: " ~ current_ts, info=True) }}

--------------------------------------------------------------------------------
-- Step 1: Raw model distinct count query
--------------------------------------------------------------------------------
{% set model_count_query %}
    select count(*) as model_count
    from (
        select distinct
            {% for col in model_key_columns %}
                r.{{ col }}{% if not loop.last %}, {% endif %}
            {% endfor %}
        from {{ ref(model) }} as r
        {% if ingestion_type == "kafka" and load_type == "non_append" %}
        where r.{{ model_time_col }} >= dateadd(day, -{{ look_back }}, '{{ current_ts }}'::timestamp)
          and r.{{ model_time_col }} <= dateadd(minute, -120, '{{ current_ts }}'::timestamp)
          -- and r.DWH_EFFECTIVE_TO_TSTAMP = '9999-12-31 00:00:00.000'
          and r.DWH_IS_DELETED_FLAG = 'N'
        {% elif ingestion_type == "non_kafka" and load_type == "non_append" %}
          where r.DWH_EFFECTIVE_TO_TSTAMP = '9999-12-31 00:00:00.000'
          and r.DWH_IS_DELETED_FLAG = 'N'
        {% elif ingestion_type == "non_kafka" and load_type == "append" %}  
          where r.DWH_EXTRACTION_TSTAMP = (Select max(DWH_EXTRACTION_TSTAMP) from {{ ref(model) }} )
        {% elif ingestion_type == "kafka" and load_type == "append" %}   
          where 1=1
          {# Placeholder for this scenario where ingestion type is : kafka and history of raw table is append #}
        {% endif %}
    )
{% endset %}

--------------------------------------------------------------------------------
-- Step 2: Compare/landing distinct count query
--------------------------------------------------------------------------------
{% if ingestion_type == "kafka" and load_type == "non_append" %}
    {% set after_coalesced_cols = [] %}
    {% set afterstate_not_null_conditions = [] %}
    {% for col in compare_key_columns %}
        {% set coalesced_expr = "coalesce(parse_json(record_content):" ~ afterState ~ ":" ~ col ~ ", parse_json(record_content):" ~ beforeState ~ ":" ~ col ~ ")" %}
        {% do after_coalesced_cols.append(coalesced_expr ~ " as " ~ (( col | replace('.', '_') ))) %}
        {% do afterstate_not_null_conditions.append("parse_json(record_content):" ~ afterState ~ ":" ~ col ~ " is not null") %}
    {% endfor %}

    {% set compare_count_query %}
        select count(*) as compare_count
        from (
           select distinct 
                {% for col in compare_key_columns %}
                     {{ col | replace('.', '_') }} {% if not loop.last %}, {% endif %}
                {% endfor %}
                from (
                select
                    {{ after_coalesced_cols | join(',\n                    ') }},
                    {{ compare_time_col }} as record_time,
                    record_content,
                    row_number() over (
                        partition by
                            {% for col in compare_key_columns %}
                                coalesce(parse_json(record_content):{{afterState}}:{{ col }}, parse_json(record_content):{{beforeState}}:{{ col }}){% if not loop.last %}, {% endif %}
                            {% endfor %}
                        order by {{ compare_time_col }} desc
                    ) as rn
                from ( select *  from {{ compare_model }} where
				 {{ compare_time_col }} >= dateadd(day, -{{ look_back }}, '{{ current_ts }}'::timestamp) 
            and {{ compare_time_col }} <= dateadd(minute, -120, '{{ current_ts }}'::timestamp)
            and not
	    is_null_value(parse_json(record_content):{{afterState}})))
            where rn = 1 
        )
    {% endset %}

{% elif ingestion_type == "non_kafka" and (load_type == "append" or load_type == "non_append") %}
    {% set compare_count_query %}
        select count(*) as compare_count
        from (
            select distinct
                {% for col in compare_key_columns %}
                    {{ col }}{% if not loop.last %}, {% endif %}
                {% endfor %}
            from {{ compare_model }}
            where {{ compare_time_col }} = (select max({{ compare_time_col }}) from {{ compare_model }})
        )
    {% endset %}

{% endif %}

--------------------------------------------------------------------------------
-- Step 3: Execute queries and compare results
--------------------------------------------------------------------------------
{% if execute %}
    {{ log("[Count Check] Raw Count Query: " ~ model_count_query, info=True) }}
    {{ log("[Count Check] Compare Count Query: " ~ compare_count_query, info=True) }}

    {% set model_count_result = run_query(model_count_query) %}
    {% set compare_count_result = run_query(compare_count_query) %}

    {% if model_count_result and compare_count_result %}
        {% set model_count_val = model_count_result.columns[0].values()[0] %}
        {% set compare_count_val = compare_count_result.columns[0].values()[0] %}

        {{ log("[Count Check] Raw Layer Count: " ~ model_count_val ~ ", Compare Layer Count: " ~ compare_count_val, info=True) }}

        {% if model_count_val != compare_count_val %}
            {% if raise_error %}
                {% do exceptions.raise_compiler_error(" Count mismatch! Raw: " ~ model_count_val ~ ", Compare: " ~ compare_count_val) %}
            {% else %}
                {{ log(" Warning: Count mismatch detected but continuing.", info=True) }}
            {% endif %}
        {% else %}
            {{ log(" Count matches between raw and compare layers!", info=True) }}
        {% endif %}
    {% else %}
        {{ log(" One or both count queries returned no results.", info=True) }}
    {% endif %}
{% endif %}

{% endmacro %}