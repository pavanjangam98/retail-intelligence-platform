# Set environment variables

# $env:PYTHONPATH = "$PWD;$PWD\dags"
$env:AIRFLOW_HOME = "/usr/local/airflow"
$env:IS_AIRFLOW = "true"
$env:TARGET_NAME = "DEV"
$env:SCHEMA_NAME = "TEST"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Running Tests with Coverage..." -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Run tests with coverage

pytest tests/ --cov=dags --cov-report=xml:coverage.xml --cov-report=html:htmlcov --cov-branch -v
 
# Check if tests passed

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "Tests Passed Successfully!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Detailed Coverage Report (All Files):" -ForegroundColor Yellow
    Write-Host ""

    # Show detailed coverage for ALL files

    coverage report -m
    Write-Host ""
    Write-Host "Coverage files generated:" -ForegroundColor Yellow
    Write-Host "  - coverage.xml (for SonarQube)" -ForegroundColor White
    Write-Host "  - htmlcov/index.html (HTML report)" -ForegroundColor White

    if (Test-Path "coverage.xml") {
        Write-Host ""
        Write-Host "coverage.xml generated successfully" -ForegroundColor Green

    }
    Write-Host ""
    Write-Host "Opening HTML coverage report..." -ForegroundColor Cyan
    Start-Process "htmlcov\index.html"
}

else {

    Write-Host ""
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "Tests Failed!" -ForegroundColor Red
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "Please fix the failing tests before generating coverage report." -ForegroundColor Yellow
    exit 1

}
 