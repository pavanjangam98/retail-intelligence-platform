## 🚀 Summary

Provide a concise description of the changes in this PR.

- What was the problem?
- What changes were made?
- Any relevant context?

---

## 🧠 Changes Introduced

- [ ] New or updated DAG(s) (Astronomer)
- [ ] New or updated dbt model(s)
- [ ] New or updated dbt tests / sources / snapshots
- [ ] Changes to schedules / parameters
- [ ] Other (specify): __________________________

---

## ✅ Author Checklist

### General
- [ ] Code tested locally or in a dev environment
- [ ] Documentation updated where relevant
- [ ] Code formatted and linted
- [ ] PR title follows naming convention (`feature/`, `bugfix/`, `hotfix/`, `chore/`)

### dbt-specific
- [ ] New models include tests (`tests/` or `schema.yml`)
- [ ] Descriptions added for models/fields
- [ ] `dbt build` completes successfully
- [ ] No unresolved warnings or errors
- [ ] Emptied `packages.yml` and removed `package-lock.yml` 

### Airflow/Astronomer-specific
- [ ] DAG IDs, schedules, and default args follow conventions
- [ ] Retry logic, alerts, and owners are defined
- [ ] DAG runs successfully via `astro dev run` or in a local Airflow environment

---

## 📸 Screenshots / Logs (if applicable)

Include logs or screenshots that support this change (e.g., dbt run results, DAG tree view, etc.).

- [ ] Confluence page for logs/screenshots: __________________________

---

## 🔗 Related Issues / Tickets

Closes(Jira Link) #___  
Related to(Jira Link) #___

- [ ] Github Pull Request link added to reviewer Jira task

---

## 🙋 Reviewer Notes

Any context for the reviewer? Known issues or limitations?

---

## 👀 Reviewer Checklist

### General
- [ ] The PR description clearly explains the changes.
- [ ] Changes are scoped, clear, and aligned with the ticket.
- [ ] No unexpected files or debug code present.
- [ ] Code follows team conventions and naming patterns.

### dbt-specific
- [ ] Models follow directory and naming conventions.
- [ ] Jinja macros are used where appropriate (avoid duplication).
- [ ] Tests are meaningful and not overly permissive.
- [ ] Dependencies between models are valid and logical.

### Astronomer-specific
- [ ] DAG structure is clear and modular.
- [ ] DAG has proper retries, owner.
- [ ] No hardcoded paths, credentials, or temporary logic.
- [ ] DAG passes linting/static checks (e.g., `flake8`, `black`).

---