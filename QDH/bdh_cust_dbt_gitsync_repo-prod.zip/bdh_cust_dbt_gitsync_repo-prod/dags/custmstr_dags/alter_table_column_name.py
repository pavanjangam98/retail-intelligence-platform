import os
import json
from datetime import datetime
from airflow.decorators import dag, task
from airflow.operators.empty import EmptyOperator
from cosmos import DbtTaskGroup, DbtDag, ProjectConfig, ProfileConfig, ExecutionConfig, RenderConfig
from cosmos.profiles import SnowflakePrivateKeyPemProfileMapping
from cosmos.operators import DbtRunOperationOperator
 
# Get the environment details
is_airflow = os.getenv("IS_AIRFLOW", "true").lower()
target_name = os.getenv("TARGET_NAME", "DEV").lower()
schema_name = os.getenv("SCHEMA_NAME", "Anubhav").lower()
project_path = "/usr/local/airflow/dags/repo/dags/bdh_cust_dbt/"
 

# Set up profile config
profile_config = ProfileConfig(
    profile_name="default",
    target_name=target_name,
    profile_mapping=SnowflakePrivateKeyPemProfileMapping(
        conn_id="sfconnect",
        profile_args={"schema": schema_name},
    )
)
# Debug print for DBT executable path

dbt_executable_path = f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt"
print(f"DBT Executable Path: {dbt_executable_path}") 
# DAG definition
@dag(
    start_date=datetime(2025, 9, 25),
    schedule=None,
    catchup=False,
)
def alter_table_column_name_dag():
    alter_table_column_name = DbtRunOperationOperator(
        task_id="alter_table_column_name",
        macro_name="rename_column",
        project_dir=project_path,
        profile_config=profile_config,
        args={
            "database_name": "CUST__FOUNDATION__PPTE",
            "schema_name": "FDP__CUSTMSTR",
            "table_name":"FDP__PARTY_CORE",
            "old_column_name":"INTERNAL_REVENUE_DEPARTMENT_ID",
            "new_column_name":"INLAND_REVENUE_DEPARTMENT_ID"
            },
        dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt",
    )

    ##execute_task
    alter_table_column_name
alter_table_column_name_dag()