import os
import json
from datetime import datetime
from airflow.decorators import dag
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.timetables.base import DagRunInfo, DataInterval, TimeRestriction, Timetable
from cosmos import DbtTaskGroup, DbtDag, ProjectConfig, ProfileConfig, ExecutionConfig, RenderConfig
from cosmos.operators import DbtRunOperationOperator
from cosmos.profiles import SnowflakePrivateKeyPemProfileMapping
import holidays
import pendulum

target_name = os.getenv("TARGET_NAME", "DEV").lower()
schema_name = os.getenv("SCHEMA_NAME", "DEFAULT").lower()
project_path = "/usr/local/airflow/dags/repo/dags/bdh_cust_dbt/"
config_path = "/usr/local/airflow/dags/repo/dags/config/customer_models_loadtype_config.json"

with open(config_path, "r") as f:
    model_config = json.load(f)

model_name = "raw___banker_segment_onprem_file___banker_segment"
load_type = model_config.get(model_name, {}).get("load_type", "default")
start_date = model_config.get(model_name, {}).get("start_date", 0)
end_date = model_config.get(model_name, {}).get("end_date", 0)
tool_name = model_config.get(model_name, {}).get("tool_name", "airflow")
look_back = model_config.get(model_name, {}).get("look_back", 30)
 
if load_type.lower() == "full_data_load":
    look_back = 30   # fixed for full
else:
    look_back = look_back

    
profile_config = ProfileConfig(
    profile_name="default",
    target_name=target_name,
    profile_mapping=SnowflakePrivateKeyPemProfileMapping(
        conn_id="sfconnect",
        profile_args={"schema": schema_name},
    )
)

dbt_executable_path = f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt"
NZ_TIMEZONE = "Pacific/Auckland"


class SixthBusinessDayTimetable(Timetable):
    description = "Run at 00:00 NZ time on the sixth NZ working day of each month"

    @property
    def summary(self) -> str:
        return "0 0 NZ time on 6th NZ business day"

    def infer_manual_data_interval(self, *, run_after):
        return DataInterval.exact(run_after)

    def next_dagrun_info(self, *, last_automated_data_interval, restriction):
        if restriction.earliest is None:
            return None

        if last_automated_data_interval is None:
            start_point = restriction.earliest.in_timezone(NZ_TIMEZONE)
            if not restriction.catchup:
                start_point = max(start_point, pendulum.now(NZ_TIMEZONE))
            next_run = self._first_sixth_business_day_on_or_after(start_point)
        else:
            next_month = last_automated_data_interval.start.in_timezone(NZ_TIMEZONE).start_of("month").add(months=1)
            next_run = self._sixth_business_day(next_month.year, next_month.month)

        if restriction.latest is not None and next_run > restriction.latest:
            return None

        return DagRunInfo.exact(next_run)

    def serialize(self):
        return {}

    @classmethod
    def deserialize(cls, data):
        return cls()

    @staticmethod
    def _first_sixth_business_day_on_or_after(start_point):
        month_cursor = start_point.start_of("month")
        candidate = SixthBusinessDayTimetable._sixth_business_day(month_cursor.year, month_cursor.month)

        if candidate < start_point:
            month_cursor = month_cursor.add(months=1)
            candidate = SixthBusinessDayTimetable._sixth_business_day(month_cursor.year, month_cursor.month)

        return candidate

    @staticmethod
    def _sixth_business_day(year, month):
        day = pendulum.datetime(year, month, 1, tz=NZ_TIMEZONE)
        business_day_count = 0
        nz_holidays = holidays.country_holidays("NZ", years=year)

        while day.month == month:
            if day.day_of_week < pendulum.SATURDAY and day.date() not in nz_holidays:
                business_day_count += 1
                if business_day_count == 6:
                    return day.start_of("day")
            day = day.add(days=1)

        raise ValueError(f"Could not determine sixth business day for {year}-{month:02d}")


@dag(
    start_date=pendulum.datetime(2025, 11, 5, tz=NZ_TIMEZONE),
    schedule=SixthBusinessDayTimetable(),
    catchup=False,
    tags=["Monthly", "raw"],
    max_active_runs=1
)
def cust_lndgtofndn_custmstr_bankerpositionsegment():
    raw_dag = DbtTaskGroup(
        project_config=ProjectConfig(project_path),
        operator_args={
            "install_deps": False,
            "vars": {"run_type": load_type, "tool_name": tool_name, "start_date": start_date, "end_date": end_date},
        },
        profile_config=profile_config,
        execution_config=ExecutionConfig(dbt_executable_path=dbt_executable_path),
        group_id="raw_dag",
        render_config=RenderConfig(
            select=["raw___banker_segment_onprem_file___banker_segment"],  # raw models
            dbt_deps=False,
        ),
        default_args={"retries": 0},
    )
    refresh_external_table = DbtRunOperationOperator(
        task_id="refresh_external_table",
        macro_name="refresh_external_table",
        project_dir=project_path,
        profile_config=profile_config,
        args={
            "database_name": f"LANDING__{target_name.upper()}",
            "schema_name": "BANKER_SEGMENT_ONPREM_FILE",
            "table_name":"BANKER_SEGMENT"
            },
        dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt",
    )    

    freshness_check = DbtRunOperationOperator(
       task_id="check_source_freshness",
       macro_name="source_freshness_check",
       project_dir=project_path,
       profile_config=profile_config,
       args={
           "database": f"LANDING__{target_name.upper()}",
           "schema": "BANKER_SEGMENT_ONPREM_FILE",
           "table":"BANKER_SEGMENT",
           "error_count_non_prd": 4320,
           "error_period_non_prd": "hour",
           "error_count_prd": 768,
           "error_period_prd": "hour",
           "ingestion_type": "non_kafka"
       },
       dbt_executable_path=dbt_executable_path,
    )

    historical_variance_check = DbtRunOperationOperator(
       task_id="check_historical_variance_for_file",
       macro_name="historical_variance_in_file_record_count",
       project_dir=project_path,
       profile_config=profile_config,
       args={
           "model": "raw___banker_segment_onprem_file___banker_segment",
           "source_name": "landing__banker_segment_onprem_file",
           "table_name": "BANKER_SEGMENT",
           "date_column": "load_date",
           "variance_pct": 10 ,
           "is_append": False
       },
       dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt",
    )

    count_check_between_raw_land = DbtRunOperationOperator(
       task_id="run_recon_check_active_records_land_to_raw",
       macro_name="custom_check_active_counts_between_raw_and_land_from_date_all_files",
       project_dir=project_path,
       profile_config=profile_config,
       args={
           "model": "raw___banker_segment_onprem_file___banker_segment",
           "model_key_columns": ["POSITION_NUMBER"],
           "source_name": "landing__banker_segment_onprem_file",
           "table_name": "BANKER_SEGMENT",
           "compare_key_columns": ["POSITION_NUMBER"],
           "ingestion_type": "file",
           "load_type": "type2",
           "raise_error": "True" 
       },
       dbt_executable_path=dbt_executable_path,
    )

    foundation_dag = DbtTaskGroup(
        project_config=ProjectConfig(project_path),
        operator_args={
            "install_deps": False,
            "vars": {"run_type": load_type, "tool_name": tool_name, "start_date": start_date, "end_date": end_date},
        },
        profile_config=profile_config,
        execution_config=ExecutionConfig(dbt_executable_path=dbt_executable_path),
        group_id="foundation_dag",
        render_config=RenderConfig(
            select=["foundation___fdp__custmstr___fdp__banker_position_segmentation"],  # your foundation models
            dbt_deps=False,
        ),
        default_args={"retries": 0},
    )

    active_count_recon_foundation_to_raw = DbtRunOperationOperator(
        task_id="run_recon_check_active_records",
        macro_name="fdp_custom_check_active_counts_between_models_from_date",
        project_dir=project_path,
        profile_config=profile_config,
        args={
            "model": "foundation___fdp__custmstr___fdp__banker_position_segmentation",
            "compare_model": "raw___banker_segment_onprem_file___banker_segment",
            "model_time_col": "DWH_EFFECTIVE_FROM_TSTAMP",
            "compare_time_col": "DWH_EFFECTIVE_FROM_TSTAMP",
            "look_back": 90
        },
        dbt_executable_path=dbt_executable_path,
    )
    
    delete_count_recon_foundation_to_raw = DbtRunOperationOperator(
        task_id="run_recon_check_deleted_records",
        macro_name="fdp_custom_check_deleted_counts_between_models_from_date",
        project_dir=project_path,
        profile_config=profile_config,
        args={
            "model": "foundation___fdp__custmstr___fdp__banker_position_segmentation",
            "compare_model": "raw___banker_segment_onprem_file___banker_segment",
            "model_time_col": "DWH_EFFECTIVE_FROM_TSTAMP",
            "compare_time_col": "DWH_EFFECTIVE_FROM_TSTAMP",
            "look_back": 90
        },
        dbt_executable_path=dbt_executable_path,
    )
    
    distinct_count_recon_foundation_to_raw = DbtRunOperationOperator(
        task_id="run_recon_check_distinct_records",
        macro_name="fdp_custom_check_distinct_counts_between_models_from_date",
        project_dir=project_path,
        profile_config=profile_config,
        args={
            "model": "foundation___fdp__custmstr___fdp__banker_position_segmentation",
            "compare_model": "raw___banker_segment_onprem_file___banker_segment",
            "model_columns": ["POSITION_ID"],
            "compare_columns": ["POSITION_NUMBER"],
            "compare_time_col": "DWH_EFFECTIVE_FROM_TSTAMP",
            "look_back": 90
        },
        dbt_executable_path=dbt_executable_path,
    )

    # Chain freshness -> raw models -> raw-land count -> trigger foundation
    refresh_external_table >> freshness_check >> historical_variance_check >> raw_dag >> count_check_between_raw_land >> foundation_dag >> [active_count_recon_foundation_to_raw, delete_count_recon_foundation_to_raw, distinct_count_recon_foundation_to_raw]
cust_lndgtofndn_custmstr_bankerpositionsegment()
