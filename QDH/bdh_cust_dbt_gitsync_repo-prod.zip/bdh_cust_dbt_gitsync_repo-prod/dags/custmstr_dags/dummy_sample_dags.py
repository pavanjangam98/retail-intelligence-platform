import os
from datetime import datetime
from cosmos import DbtDag, ProjectConfig, ProfileConfig, ExecutionConfig, RenderConfig
from cosmos.profiles import SnowflakePrivateKeyPemProfileMapping
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator
 
is_airflow = os.getenv("IS_AIRFLOW", "False")  # Convert to boolean
 
# Set up the profile configuration
profile_config = ProfileConfig(
   profile_name="default",
   target_name="DEV",
   profile_mapping=SnowflakePrivateKeyPemProfileMapping(
       conn_id="sfconnect",
       profile_args={"database": "CUSTOMER__TRANSFORM__DEV", "schema": "Anubhav",},
   )
)
 
# DAG 1 configuration
dbt_ncino_model_dag_1 = DbtDag(
    project_config=ProjectConfig("/usr/local/airflow/dags/bdh_cust_dbt/"),
    profile_config=profile_config,
    execution_config=ExecutionConfig(dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt"),
    schedule_interval="@daily",  #"*/10 * * * *",
    start_date=datetime(2025, 3, 31),
    catchup=False,
    dag_id="dbt_ncino_model_dag_1",
    render_config=RenderConfig(select=["@raw___ncino___customer"]),
    default_args={"retries": 0},
)
 
# Task in DAG 1
task_1 = DummyOperator(task_id="task_1", dag=dbt_ncino_model_dag_1)
task_2 = DummyOperator(task_id="task_2", dag=dbt_ncino_model_dag_1)

# Trigger DAG 2 after task_2
trigger_dag_2 = TriggerDagRunOperator(
    task_id="trigger_dag_2",
    trigger_dag_id="dbt_first_model_dag",  # This is the DAG you want to trigger
    #conf={},  # Optional: Pass any configuration to the triggered DAG
    dag=dbt_ncino_model_dag_1
)
 
# Set task dependencies in DAG 1
task_1 >> task_2 >> trigger_dag_2 
# Set task dependency in DAG 1
task_1 >> task_2