import os
import json
from datetime import datetime
from airflow.decorators import dag, task
from airflow.operators.empty import EmptyOperator
from cosmos import DbtTaskGroup, DbtDag, ProjectConfig, ProfileConfig, ExecutionConfig, RenderConfig
from cosmos.profiles import SnowflakePrivateKeyPemProfileMapping
from cosmos.operators import DbtRunOperationOperator
 
# Get the environment details
is_airflow = os.getenv("IS_AIRFLOW", "true").lower()
target_name = os.getenv("TARGET_NAME", "DEV").lower()
schema_name = os.getenv("SCHEMA_NAME", "DEFAULT").lower()
project_path = "/usr/local/airflow/dags/repo/dags/bdh_cust_dbt/" 
# Load model config from JSON

config_path = "/usr/local/airflow/dags/repo/dags/config/customer_models_loadtype_config.json"
with open(config_path, "r") as f:
    model_config = json.load(f)
 
model_name = "raw___customer_profile_score_service___customer_profile_score_gap"

load_type = model_config.get(model_name, {}).get("load_type", "default")
end_date = model_config.get(model_name, {}).get("end_date", "9999-12-31")
# look_back = model_config.get(model_name, {}).get("look_back", 0)  # default to 0 if not set
look_back = model_config.get(model_name, {}).get("look_back", 30)
if look_back in [None, "","default"]:
	look_back = 30
else:
	look_back = int(look_back)
tool_name = model_config.get(model_name, {}).get("tool_name", "airflow")
# look_back = 30 if (not days_back or str(days_back).strip().lower() == "default") else int(days_back)

# Print values for debugging
print(f"Load Type: {load_type}")
# print(f"Days Back: {days_back}")
print(f"look back: {look_back}")
print(f"End Date: {end_date}")

# Set up profile config
profile_config = ProfileConfig(
    profile_name="default",
    target_name=target_name,
    profile_mapping=SnowflakePrivateKeyPemProfileMapping(
        conn_id="sfconnect",
        profile_args={"schema": schema_name},
    )
)
# Debug print for DBT executable path

dbt_executable_path = f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt"
print(f"DBT Executable Path: {dbt_executable_path}") 
# DAG definition

@dag(
    start_date=datetime(2025, 9, 25),
    schedule="@hourly",
    catchup=False,
    tags=["hourly"],
    max_active_runs=1
)
def cust_lndgtofndn_custmstr_partyprofilescoregap():
    @task.branch(task_id="branch_raw_view_execution")
    def branch_raw_view_execution():
        if load_type.lower() == "full_data_load":
            return "raw_view_dag"
        return "skip_raw_view_dag"
    skip_raw_view_dag = EmptyOperator(
        task_id="skip_raw_view_dag"
    )
    freshness_check = DbtRunOperationOperator(
       task_id="check_source_freshness",
       macro_name="source_freshness_check",
       project_dir=project_path,
       profile_config=profile_config,
       args={
           "database": f"LANDING__{target_name.upper()}",
           "schema": "CUSTOMER_PROFILE_SCORE_SERVICE",
           "table":"CUSTOMER_PROFILE_SCORE",
           "error_count_non_prd": 5000,
           "error_period_non_prd": "hour",
           "error_count_prd": 25,
           "error_period_prd": "hour",
           "ingestion_type": "kafka"
       },
       dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt",
    )
    # --------------------------------------------------------------
    # RAW VIEW (Full load only)
    # --------------------------------------------------------------
    raw_view_dag = DbtTaskGroup(
        group_id="raw_view_dag",
        project_config=ProjectConfig(project_path),
        profile_config=profile_config,
        execution_config=ExecutionConfig(dbt_executable_path=dbt_executable_path),
        operator_args={
            "install_deps": False,
            "vars": {
                "run_type": load_type,
                "days_back": look_back,
                "tool_name": tool_name,
            },
        },
        render_config=RenderConfig(
            select=["raw___customer_profile_score_service___customer_profile_score_gap_full_view"],
            dbt_deps=False,
        ),
        default_args={"retries": 0},
    )
    join_after_raw_view = EmptyOperator(
        task_id="join_after_raw_view",
        trigger_rule="none_failed_min_one_success"
    )
    # --------------------------------------------------------------
    # RAW DAG (always runs)
    # --------------------------------------------------------------
    raw_dag = DbtTaskGroup(
        project_config=ProjectConfig("/usr/local/airflow/dags/repo/dags/bdh_cust_dbt/"),
        operator_args={
            "install_deps": False,
            "vars": {"run_type": load_type, "days_back": look_back, "tool_name": tool_name, "end_date": end_date}
        },
        profile_config=profile_config,
        execution_config=ExecutionConfig(dbt_executable_path=dbt_executable_path),
        group_id="raw_dag",
        render_config=RenderConfig(
            select=["raw___customer_profile_score_service___customer_profile_score_gap"],
            dbt_deps=False,
        ),
        default_args={"retries": 0},
    )
    check_active_and_overlapped_records = DbtRunOperationOperator(
        task_id="check_active_and_overlapped_records_land_to_raw",
        macro_name="check_active_and_overlap",
        project_dir=project_path,
        profile_config=profile_config,
        args={
             "model_name": "raw___customer_profile_score_service___customer_profile_score_gap",
             "pk_columns": ["CUSTOMERNUMBER", "SCORETYPE", "GAPTYPE"],
             "effective_from_column": "DWH_EFFECTIVE_FROM_TSTAMP",
             "effective_to_column": "DWH_EFFECTIVE_TO_TSTAMP"
        },
        dbt_executable_path=dbt_executable_path,
    )    

    foundation_dag = DbtTaskGroup(
        project_config=ProjectConfig("/usr/local/airflow/dags/repo/dags/bdh_cust_dbt/"),
        operator_args={
            "install_deps": False,
            "vars": {"run_type": load_type, "days_back": look_back, "tool_name": tool_name, "end_date": end_date},
        },
        profile_config=profile_config,
    	execution_config=ExecutionConfig(dbt_executable_path=dbt_executable_path),
        group_id="foundation_dag",
        render_config=RenderConfig(
            select=["foundation___fdp__custmstr___fdp__party_profile_score_gap"],  # your foundation models
            dbt_deps=False,
        ),
        default_args={"retries": 0},
    )

    active_count_recon_foundation_to_raw = DbtRunOperationOperator(
        task_id="run_recon_check_active_records",
        macro_name="fdp_custom_check_active_counts_between_models_from_date",
        project_dir=project_path,
        profile_config=profile_config,
    	args={
    		"model": "foundation___fdp__custmstr___fdp__party_profile_score_gap",
    		"compare_model": "raw___customer_profile_score_service___customer_profile_score_gap",
    		"model_time_col": "DWH_EFFECTIVE_FROM_TSTAMP",
    		"compare_time_col": "DWH_EFFECTIVE_FROM_TSTAMP",
    		"look_back": look_back
        },
        dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt",
    )
    delete_count_recon_foundation_to_raw = DbtRunOperationOperator(
        task_id="run_recon_check_deleted_records",
        macro_name="fdp_custom_check_deleted_counts_between_models_from_date",
        project_dir=project_path,
        profile_config=profile_config,
    	args={
    		"model": "foundation___fdp__custmstr___fdp__party_profile_score_gap",
    		"compare_model": "raw___customer_profile_score_service___customer_profile_score_gap",
    		"model_time_col": "DWH_EFFECTIVE_FROM_TSTAMP",
    		"compare_time_col": "DWH_EFFECTIVE_FROM_TSTAMP",
    		"look_back": look_back
        },
        dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt",
    )
    distinct_count_recon_foundation_to_raw = DbtRunOperationOperator(
        task_id="run_recon_check_distinct_records",
        macro_name="fdp_custom_check_distinct_counts_between_models_from_date",
        project_dir=project_path,
        profile_config=profile_config,
    	args={
    		"model": "foundation___fdp__custmstr___fdp__party_profile_score_gap",
    		"compare_model": "raw___customer_profile_score_service___customer_profile_score_gap",
    		"model_columns": ["CUSTOMER_ID", "SCORE_TYPE_CODE", "GAP_TYPE_CODE"],
    		"compare_columns": ["CUSTOMERNUMBER", "SCORETYPE", "GAPTYPE"],
    		"compare_time_col": "DWH_EFFECTIVE_FROM_TSTAMP",
    		"look_back": look_back
        },
        dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt",
    )
# Chain freshness -> raw models -> raw-land count -> trigger foundation
    branch_task = branch_raw_view_execution()
    freshness_check >> branch_task
    branch_task >> raw_view_dag >> join_after_raw_view
    branch_task >> skip_raw_view_dag >> join_after_raw_view
    join_after_raw_view >> raw_dag >> check_active_and_overlapped_records >> foundation_dag
    foundation_dag >> [active_count_recon_foundation_to_raw, delete_count_recon_foundation_to_raw, distinct_count_recon_foundation_to_raw]

cust_lndgtofndn_custmstr_partyprofilescoregap()
