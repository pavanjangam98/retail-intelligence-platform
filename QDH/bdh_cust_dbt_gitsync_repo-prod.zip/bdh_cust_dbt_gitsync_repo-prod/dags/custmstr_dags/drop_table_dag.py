import os
import json
from datetime import datetime
from airflow.decorators import dag, task
from airflow.operators.empty import EmptyOperator
from cosmos import DbtTaskGroup, DbtDag, ProjectConfig, ProfileConfig, ExecutionConfig, RenderConfig
from cosmos.profiles import SnowflakePrivateKeyPemProfileMapping
from cosmos.operators import DbtRunOperationOperator
 
# Get the environment details
is_airflow = os.getenv("IS_AIRFLOW", "true").lower()
target_name = os.getenv("TARGET_NAME", "DEV").lower()
schema_name = os.getenv("SCHEMA_NAME", "Anubhav").lower()
project_path = "/usr/local/airflow/dags/repo/dags/bdh_cust_dbt/"
 

# Set up profile config
profile_config = ProfileConfig(
    profile_name="default",
    target_name=target_name,
    profile_mapping=SnowflakePrivateKeyPemProfileMapping(
        conn_id="sfconnect",
        profile_args={"schema": schema_name},
    )
)
# Debug print for DBT executable path

dbt_executable_path = f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt"
print(f"DBT Executable Path: {dbt_executable_path}") 
# DAG definition
@dag(
    start_date=datetime(2025, 9, 25),
    schedule=None,
    catchup=False,
)
def drop_table_dag():
    
    drop_table_1 = DbtRunOperationOperator(
        task_id="drop_table_1",
        macro_name="drop_table",
        project_dir=project_path,
        profile_config=profile_config,
        args={
            "database_name": "CUST__RAW__PPTE",
            "schema_name": "EMAX",
            "table_name":"EIT_CUST_ACS"
            },
        dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt",
    )

    drop_table_2 = DbtRunOperationOperator(
        task_id="drop_table_2",
        macro_name="drop_table",
        project_dir=project_path,
        profile_config=profile_config,
        args={
            "database_name": "CUST__RAW__PPTE",
            "schema_name": "EMAX",
            "table_name":"EIT_ACS_LST"
            },
        dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt",
    )
 
    
    drop_table_1 >> drop_table_2
drop_table_dag()
