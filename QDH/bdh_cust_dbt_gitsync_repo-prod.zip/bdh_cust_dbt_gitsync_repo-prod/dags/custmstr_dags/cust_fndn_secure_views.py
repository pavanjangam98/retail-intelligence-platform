import os
import json
from datetime import datetime
from cosmos import DbtDag, ProjectConfig, ProfileConfig, ExecutionConfig, RenderConfig
from cosmos.profiles import SnowflakePrivateKeyPemProfileMapping
 
# Get the environment details
is_airflow = os.getenv("IS_AIRFLOW", "true").lower()
target_name = os.getenv("TARGET_NAME", "DEV").lower()
schema_name = os.getenv("SCHEMA_NAME", "QDH_PILOT").lower()

# Set up profile config
profile_config = ProfileConfig(
    profile_name="default",
    target_name=target_name,
    profile_mapping=SnowflakePrivateKeyPemProfileMapping(
        conn_id="sfconnect",
        profile_args={"schema": schema_name},
    )
)
# Debug print for DBT executable path

dbt_executable_path = f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt"
print(f"DBT Executable Path: {dbt_executable_path}") 
# DAG definition

model_build_dag = DbtDag(
    project_config=ProjectConfig("/usr/local/airflow/dags/repo/dags/bdh_cust_dbt/"),
    operator_args={
        "install_deps": False
    },
    profile_config=profile_config,
    execution_config=ExecutionConfig(
        dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt"
    ),
    schedule_interval= None,
    start_date=datetime(2026, 5, 29),
    catchup=False,
    dag_id="cust_fndn_secure_views",
    tags=["on demand"],
    render_config=RenderConfig(
        select=[
           "foundation___fdp__custmstr___fdp__bis_country_reference_view",
           "foundation___fdp__custmstr___fdp__party_address_view",
           "foundation___fdp__custmstr___fdp__party_communication_view",
           "foundation___fdp__custmstr___fdp__party_core_view",
           "foundation___fdp__custmstr___fdp__party_demographics_industry_reference_view",
           "foundation___fdp__custmstr___fdp__party_entity_type_reference_view",
           "foundation___fdp__custmstr___fdp__party_entity_view",
           "foundation___fdp__custmstr___fdp__party_individual_view",
           "foundation___fdp__custmstr___fdp__party_occupation_reference_view",
           "foundation___fdp__custmstr___fdp__party_rating_view",
           "foundation___fdp__custmstr___fdp__party_relationship_type_reference_view",
           "foundation___fdp__custmstr___fdp__party_relationship_view",
           "foundation___fdp__custmstr___fdp__party_warning_link_view"
       ],
        dbt_deps=False
    ),
    default_args={"retries": 0},
)