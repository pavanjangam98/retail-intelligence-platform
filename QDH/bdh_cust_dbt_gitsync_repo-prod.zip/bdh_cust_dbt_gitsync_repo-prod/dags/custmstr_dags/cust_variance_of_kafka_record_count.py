from airflow import DAG
import os
from datetime import datetime
from cosmos.operators import DbtRunOperationOperator
from cosmos import ProfileConfig
from cosmos.profiles import SnowflakePrivateKeyPemProfileMapping
import logging

# Configurable Parameters
project_path = "/usr/local/airflow/dags/repo/dags/bdh_cust_dbt/"
conn_id = "sfconnect"
schema_name = os.getenv("SCHEMA_NAME", "anubhav").lower()
target_name = os.getenv("TARGET_NAME", "DEV").lower()

# List of models/macros to run in parallel

models_to_run = [
    {
        "task_id": "run_kafka_variance_of_bst_cust_com",
        "args": {
		"model": "raw___bis___bst_cust_com",
		"source_name": "landing__bis",
		"table_name": "BST_CUST_COM",
		"primary_key": ["CUSTOMER_NO", "EMSG_TYPE_CODE", "EMSG_SERV_NO"],
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_cust_reln",
        "args": {
		"model": "raw___bis___bst_cust_reln",
		"source_name": "landing__bis",
		"table_name": "BST_CUST_RELN",
		"primary_key": ["CUSTOMER1_NO", "RELATIONSHIP_TYPE", "RELATIONSHIP_CODE", "CUSTOMER2_NO"],
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_customer",
        "args": {
		"model": "raw___bis___bst_customer",
		"source_name": "landing__bis",
		"table_name": "BST_CUSTOMER",
		"primary_key": "CUSTOMER_NO",
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_indiv_citizen",
        "args": {
		"model": "raw___bis___bst_indiv_citizen",
		"source_name": "landing__bis",
		"table_name": "BST_INDIV_CITIZEN",
		"primary_key": ["COUNTRY_CODE", "CUSTOMER_NO"],
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_indiv_cust",
        "args": {
		"model": "raw___bis___bst_indiv_cust",
		"source_name": "landing__bis",
		"table_name": "BST_INDIV_CUST",
		"primary_key": "CUSTOMER_NO",
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_joint_cust",
        "args": {
		"model": "raw___bis___bst_joint_cust",
		"source_name": "landing__bis",
		"table_name": "BST_JOINT_CUST",
		"primary_key": "CUSTOMER_NO",
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_np_customer",
        "args": {
		"model": "raw___bis___bst_np_customer",
		"source_name": "landing__bis",
		"table_name": "BST_NP_CUSTOMER",
		"primary_key": "CUSTOMER_NO",
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_mcust_grp_memb",
        "args": {
		"model": "raw___bis___bst_mcust_grp_memb",
		"source_name": "landing__bis",
		"table_name": "BST_MCUST_GRP_MEMB",
		"primary_key": ["MANAGED_GROUP_NO", "CUSTOMER_NO"],
        "variance_pct": 10
        }
    },
	{
        "task_id": "run_kafka_variance_of_bst_np_cust_type",
        "args": {
		"model": "raw___bis___bst_np_cust_type",
		"source_name": "landing__bis",
		"table_name": "BST_NP_CUST_TYPE",
		"primary_key": ["NP_CUST_TYPE"],
        "variance_pct": 10
        }
    },
	{
        "task_id": "run_kafka_variance_of_bst_non_nz_tax_res",
        "args": {
		"model": "raw___bis___bst_non_nz_tax_res",
		"source_name": "landing__bis",
		"table_name": "BST_NON_NZ_TAX_RES",
		"primary_key": ["CUSTOMER_NO", "COUNTRY_CODE"],
        "variance_pct": 10
        }
    },
	{
        "task_id": "run_kafka_variance_of_bst_cust_wkplce",
        "args": {
		"model": "raw___bis___bst_cust_wkplce",
		"source_name": "landing__bis",
		"table_name": "BST_CUST_WKPLCE",
		"primary_key": ["CUSTOMER_NO"],
        "variance_pct": 10
        }
    },
	{
        "task_id": "run_kafka_variance_of_bst_mcust_group",
        "args": {
		"model": "raw___bis___bst_mcust_group",
		"source_name": "landing__bis",
		"table_name": "BST_MCUST_GROUP",
		"primary_key": ["MANAGED_GROUP_NO"],
        "variance_pct": 10
        }
    },
	{
        "task_id": "run_kafka_variance_of_bst_workplace",
        "args": {
		"model": "raw___bis___bst_workplace",
		"source_name": "landing__bis",
		"table_name": "BST_WORKPLACE",
		"primary_key": ["WORKPLACE_CODE"],
        "variance_pct": 10
        }
    },
	{
        "task_id": "run_kafka_variance_of_bst_mcust_grp_reln",
        "args": {
		"model": "raw___bis___bst_mcust_grp_reln",
		"source_name": "landing__bis",
		"table_name": "BST_MCUST_GRP_RELN",
		"primary_key": ["POSITION_NO", "MANAGED_GROUP_NO", "RELATIONSHIP_TYPE"],
        "variance_pct": 10
        }
    },
	{
        "task_id": "run_kafka_variance_of_bst_warning_type",
        "args": {
		"model": "raw___bis___bst_warning_type",
		"source_name": "landing__bis",
		"table_name": "BST_WARNING_TYPE",
		"primary_key": ["WARNING_CODE"],
        "variance_pct": 10
        }
    },
	{
        "task_id": "run_kafka_variance_of_bst_warning",
        "args": {
		"model": "raw___bis___bst_warning",
		"source_name": "landing__bis",
		"table_name": "BST_WARNING",
		"primary_key": ["CUSTOMER_NO", "WARNING_DATE", "WARNING_CODE"],
        "variance_pct": 10
        }
    },
	{
        "task_id": "run_kafka_variance_of_pot_cust_rtng",
        "args": {
		"model": "raw___bis___pot_cust_rtng",
		"source_name": "landing__bis",
		"table_name": "POT_CUST_RTNG",
		"primary_key": ["CNSMR_ID"],
        "variance_pct": 10
        }
    },
	{
        "task_id": "run_kafka_variance_of_bst_occupation",
        "args": {
		"model": "raw___bis___bst_occupation",
		"source_name": "landing__bis",
		"table_name": "BST_OCCUPATION",
		"primary_key": ["OCCUPATION_CODE"],
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_reln_type",
        "args": {
        "model": "raw___bis___bst_reln_type",
        "source_name": "landing__bis",
        "table_name": "BST_RELN_TYPE",
        "primary_key": ["RELATIONSHIP_TYPE","RELATIONSHIP_CODE"],
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_customer_partydemographics_industry_reference_data",
        "args": {
        "model": "raw___party_demographics_service___customer_partydemographics_industry_reference_data",
        "source_name": "landing__party_demographics_service",
        "table_name": "CUSTOMER_PARTYDEMOGRAPHICS_INDUSTRY_REFERENCE_DATA",
        "primary_key": ["industryReference.NABSICCODE"],
        "variance_pct": 10,
        "afterState": "data.stateAfter",
        "beforeState": "data.stateBefore"
        }
    },
    {
        "task_id": "run_kafka_variance_of_customer_authority",
        "args": {
        "model": "raw___customer_authority_service___customer_authority",
        "source_name": "landing__customer_authority_service",
        "table_name": "CUSTOMER_AUTHORITY",
        "primary_key": ["GOVERNEDCUSTOMERNUMBER","AUTHORISEDCUSTOMERNUMBER"],
        "variance_pct": 10,
        "afterState": "data.stateAfter",
        "beforeState": "data.stateBefore"
        }
    },
	{
        "task_id": "run_kafka_variance_of_customer_partydemographics_industry",
        "args": {
        "model": "raw___party_demographics_service___customer_partydemographics_industry",
        "source_name": "landing__party_demographics_service",
        "table_name": "CUSTOMER_PARTYDEMOGRAPHICS_INDUSTRY",
        "primary_key": ["industry.customerNumber"],
        "variance_pct": 10,
        "afterState": "data.stateAfter",
        "beforeState": "data.stateBefore"
        }
    },
    {
        "task_id": "run_kafka_variance_of_customer_profile_score",
        "args": {
        "model": "raw___customer_profile_score_service___customer_profile_score",
        "source_name": "landing__customer_profile_score_service",
        "table_name": "CUSTOMER_PROFILE_SCORE",
        "primary_key": ["CUSTOMERNUMBER","SCORETYPE"],
        "variance_pct": 10,
        }
    },
    {
        "task_id": "run_kafka_variance_of_customer_profile_score_gap",
        "args": {
        "model": "raw___customer_profile_score_service___customer_profile_score_gap",
        "source_name": "landing__customer_profile_score_service",
        "table_name": "CUSTOMER_PROFILE_SCORE",
        "primary_key": ["CUSTOMERNUMBER","SCORETYPE"],
        "variance_pct": 10,
        }
    },
    {
        "task_id": "run_kafka_variance_of_customer_party_address",
        "args": {
        "model": "raw___customer_party_address_service___customer_party_address",
        "source_name": "landing__customer_party_address_service",
        "table_name": "CUSTOMER_PARTY_ADDRESS",
        "primary_key": ["ADDRESSID"],
        "variance_pct": 10,
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_country",
        "args": {
		"model": "raw___bis___bst_country",
		"source_name": "landing__bis",
		"table_name": "BST_COUNTRY",
		"primary_key": ["COUNTRY_CODE"],
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_crs_self_crt",
        "args": {
		"model": "raw___bis___bst_crs_self_cert",
		"source_name": "landing__bis",
		"table_name": "BST_CRS_SELF_CERT",
		"primary_key": ["CUSTOMER_NO"],
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_bst_mcust_relntype",
        "args": {
		"model": "raw___bis___bst_mcust_relntype",
		"source_name": "landing__bis",
		"table_name": "BST_MCUST_RELNTYPE",
		"primary_key": ["RELATIONSHIP_TYPE"],
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_eit_acs_lst",
        "args": {
		"model": "raw___emax___eit_acs_lst",
		"source_name": "landing__emax",
		"table_name": "EIT_ACS_LST",
		"primary_key": ["ACCESS_LIST_NO"],
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_eit_acs_status",
        "args": {
		"model": "raw___emax___eit_acs_status",
		"source_name": "landing__emax",
		"table_name": "EIT_ACS_STATUS",
		"primary_key": ["ACCESS_STATUS","CHAID_TYPE"],
        "variance_pct": 10
        }
    },
    {
        "task_id": "run_kafka_variance_of_eit_cust_acs",
        "args": {
		"model": "raw___emax___eit_cust_acs",
		"source_name": "landing__emax",
		"table_name": "EIT_CUST_ACS",
		"primary_key": ["EMAX_NO"],
        "variance_pct": 10
        }
    }
]

# Cosmos dbt Profile Config
profile_config = ProfileConfig(
    profile_name="default",
    target_name=target_name,
    profile_mapping=SnowflakePrivateKeyPemProfileMapping(
        conn_id=conn_id,
        profile_args={"schema": schema_name}
    ),
)
 
# DAG Definition

with DAG(
    dag_id="cust_historical_variance_of_kafka_record_count",
    start_date=datetime(2025, 9, 29),
    schedule_interval="@daily",
    catchup=False,
    tags=["dbt", "macro"],
    default_args={"retries": 0},
    max_active_runs=1
) as dag:
    for model in models_to_run:
        DbtRunOperationOperator(
            task_id=model["task_id"],
            macro_name="historical_variance_of_kafka_record_count",
            project_dir=project_path,
            profile_config=profile_config,
            args=model["args"],
            dbt_executable_path=f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt",
        )
