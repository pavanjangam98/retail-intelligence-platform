{% macro select_bst_cust_indiv_citizen_fields(state) %}
    {{ state }}_COUNTRY_CODE::VARCHAR AS COUNTRY_CODE,
    {{ state }}_PRIMARY_IND::CHAR(1) AS PRIMARY_IND,
    {{ state }}_CUSTOMER_NO::VARCHAR AS CUSTOMER_NO 
{% endmacro %}