{% macro select_bst_mcust_grp_reln_fields(state) %}
    {{ state }}_POSITION_NO::VARCHAR AS POSITION_NO,
    {{ state }}_MANAGED_GROUP_NO::VARCHAR AS MANAGED_GROUP_NO,
    {{ state }}_RELATIONSHIP_TYPE::VARCHAR AS RELATIONSHIP_TYPE,
    {{ state }}_RELN_CREATE_DATE::DATE AS RELN_CREATE_DATE,
    {{ state }}_MANAGEMENT_IND::VARCHAR AS MANAGEMENT_IND
{% endmacro %}