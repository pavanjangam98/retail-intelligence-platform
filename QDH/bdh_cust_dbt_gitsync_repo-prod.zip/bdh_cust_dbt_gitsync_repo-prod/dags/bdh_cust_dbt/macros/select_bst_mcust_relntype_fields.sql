{% macro select_bst_mcust_relntype_fields(state) %}
    {{ state }}_RELATIONSHIP_TYPE::VARCHAR AS RELATIONSHIP_TYPE,
    {{ state }}_RELATIONSHIP_DESC::VARCHAR AS RELATIONSHIP_DESC,
    {{ state }}_RELN_SHORT_DESC::VARCHAR AS RELN_SHORT_DESC,
    {{ state }}_MANAGEMENT_IND::VARCHAR AS MANAGEMENT_IND
{% endmacro %}