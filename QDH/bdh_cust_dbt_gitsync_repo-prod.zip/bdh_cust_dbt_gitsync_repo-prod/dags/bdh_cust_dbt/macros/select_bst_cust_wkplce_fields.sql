{% macro select_bst_cust_wkplce_fields(state) %}
    {{ state }}_CUSTOMER_NO::VARCHAR AS CUSTOMER_NO,
    {{ state }}_WORKPLACE_CODE::SMALLINT AS WORKPLACE_CODE,
    {{ state }}_LAST_UPDT_USERID::VARCHAR AS LAST_UPDT_USERID,
    {{ state }}_LAST_UPDT_TSTAMP::TIMESTAMP AS LAST_UPDT_TSTAMP
{% endmacro %}