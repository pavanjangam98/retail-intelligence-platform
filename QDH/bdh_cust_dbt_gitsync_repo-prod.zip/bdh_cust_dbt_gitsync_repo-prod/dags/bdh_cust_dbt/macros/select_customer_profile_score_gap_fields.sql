{% macro select_customer_profile_score_gap_fields(state) %}
    {{ state }}_CUSTOMERNUMBER::VARCHAR AS CUSTOMERNUMBER,
	{{ state }}_SCORETYPE::VARCHAR AS SCORETYPE,
	{{ state }}_GAPSTATUS::VARCHAR AS GAPSTATUS,
	{{ state }}_GAPTYPE::VARCHAR AS GAPTYPE
{% endmacro %}