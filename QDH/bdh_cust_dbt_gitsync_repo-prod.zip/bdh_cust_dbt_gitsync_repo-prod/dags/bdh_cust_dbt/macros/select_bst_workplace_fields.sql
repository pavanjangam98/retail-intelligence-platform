{% macro select_bst_workplace_fields(state) %}
    {{ state }}_WORKPLACE_CODE::VARCHAR AS WORKPLACE_CODE,
    {{ state }}_WORKPLACE_DESC::VARCHAR AS WORKPLACE_DESC,
    {{ state }}_END_DATE::DATE AS END_DATE
{% endmacro %}