{% macro select_party_demographics_service_customer_partydemographics_industry_reference_data_fields(state) %}

{{ state }}_amlRating::VARCHAR AS AMLRATING,
{{ state }}_briberyAndCorruptionRating::VARCHAR AS BRIBERYANDCORRUPTIONRATING,
{{ state }}_esgRating::VARCHAR AS ESGRATING,
{{ state }}_keywordPhraseTxt::VARCHAR AS KEYWORDPHRASETXT, 
{{ state }}_legacyCode::NUMBER AS LEGACYCODE,
{{ state }}_level1Code::VARCHAR AS LEVEL1CODE,
{{ state }}_level1Description::VARCHAR AS LEVEL1DESCRIPTION,
{{ state }}_level2Code::NUMBER AS LEVEL2CODE,
{{ state }}_level2Description::VARCHAR AS LEVEL2DESCRIPTION,
{{ state }}_level3Code::NUMBER AS LEVEL3CODE,
{{ state }}_level3Description::VARCHAR AS LEVEL3DESCRIPTION,
{{ state }}_level4Code::NUMBER AS LEVEL4CODE,
{{ state }}_level4Description::VARCHAR AS LEVEL4DESCRIPTION,
{{ state }}_nabSicCode::VARCHAR AS NABSICCODE,
{{ state }}_nabSicDescription::VARCHAR AS NABSICDESCRIPTION,
{{ state }}_sanctionsRating::VARCHAR AS SANCTIONSRATING,
{{ state }}_terrorismFinancingRating::VARCHAR AS TERRORISMFINANCINGRATING


{% endmacro %}




