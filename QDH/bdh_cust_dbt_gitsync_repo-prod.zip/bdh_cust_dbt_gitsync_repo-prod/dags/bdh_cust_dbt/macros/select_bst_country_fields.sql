
{% macro select_bst_country_fields(state) %}
    {{ state }}_COUNTRY_CODE::VARCHAR(2) AS COUNTRY_CODE,
    {{ state }}_COUNTRY_DESC::VARCHAR(20) AS COUNTRY_DESC,
    {{ state }}_NRWT_RATE_PCNT::NUMBER(4,2) AS NRWT_RATE_PCNT,
    {{ state }}_TAX_CODE::VARCHAR(1) AS TAX_CODE
{% endmacro %}