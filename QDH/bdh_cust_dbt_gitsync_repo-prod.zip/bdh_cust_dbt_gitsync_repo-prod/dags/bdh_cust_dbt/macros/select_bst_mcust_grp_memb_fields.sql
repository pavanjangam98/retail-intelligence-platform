{% macro select_bst_mcust_grp_memb_fields(state) %}
    {{ state }}_MANAGED_GROUP_NO::VARCHAR AS MANAGED_GROUP_NO,
    {{ state }}_CUSTOMER_NO::VARCHAR AS CUSTOMER_NO,
    {{ state }}_FORMAL_NAME::VARCHAR AS FORMAL_NAME,
    {{ state }}_POSITION_NO::VARCHAR(6) AS POSITION_NO,
    {{ state }}_TRANSFER_IND::VARCHAR(1) AS TRANSFER_IND,
    {{ state }}_PRIMARY_IND::VARCHAR(1) AS PRIMARY_IND
{% endmacro %}