{% macro select_party_demographics_service_customer_partydemographics_industry_fields(state) %}
    data_{{ state }}_industry_customerNumber::VARCHAR AS CUSTOMERNUMBER,
    data_{{ state }}_industry_primaryCode_code::VARCHAR AS CODE,
    data_{{ state }}_industry_primaryCode_legacyCode::VARCHAR AS LEGACYCODE
{% endmacro %}
