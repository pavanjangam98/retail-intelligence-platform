{% macro select_bst_np_cust_type_fields(state) %}
    {{ state }}_NP_CUST_TYPE::VARCHAR AS NP_CUST_TYPE,
    {{ state }}_NP_CUST_DESC::VARCHAR AS NP_CUST_DESC
{% endmacro %}