{% macro select_bst_warning_type_fields(state) %}
    {{ state }}_WARNING_CODE::VARCHAR AS WARNING_CODE,
    {{ state }}_WARN_PRIORITY_NO::SMALLINT AS WARN_PRIORITY_NO,
    {{ state }}_WARNING_TEXT::VARCHAR AS WARNING_TEXT,
    {{ state }}_PRTF_PRIORITY_NO::SMALLINT AS PRTF_PRIORITY_NO,
    {{ state }}_DELAY_ARCH_TIME::SMALLINT AS DELAY_ARCH_TIME
{% endmacro %}