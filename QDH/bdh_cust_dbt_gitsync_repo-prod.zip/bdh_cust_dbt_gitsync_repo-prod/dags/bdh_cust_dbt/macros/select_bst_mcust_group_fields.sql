{% macro select_bst_mcust_group_fields(state) %}
    {{ state }}_MANAGED_GROUP_NO::VARCHAR AS MANAGED_GROUP_NO,
    {{ state }}_MANAGED_GROUP_NAME::VARCHAR AS MANAGED_GROUP_NAME, 
    {{ state }}_GROUP_TYPE::VARCHAR AS GROUP_TYPE,
    {{ state }}_POSITION_NO::VARCHAR AS POSITION_NO,
    {{ state }}_TRANSFER_IND::VARCHAR AS TRANSFER_IND,
    {{ state }}_GRP_POTN_CODE::VARCHAR AS GRP_POTN_CODE,
    {{ state }}_LAST_UPDT_TSTAMP::TIMESTAMP AS LAST_UPDT_TSTAMP
{% endmacro %}