{% macro select_eit_cust_acs_fields(state) %}
    {{ state }}_EMAX_NO::VARCHAR AS EMAX_NO,
    {{ state }}_CUSTOMER_NO::NUMBER AS CUSTOMER_NO,
    {{ state }}_D_CHAN_ACS_ID::VARCHAR(19) AS D_CHAN_ACS_ID,
    {{ state }}_LAST_UPDT_TSTAMP::TIMESTAMP_NTZ AS LAST_UPDT_TSTAMP,
    {{ state }}_USER_ID::VARCHAR(8) AS USER_ID
{% endmacro %}