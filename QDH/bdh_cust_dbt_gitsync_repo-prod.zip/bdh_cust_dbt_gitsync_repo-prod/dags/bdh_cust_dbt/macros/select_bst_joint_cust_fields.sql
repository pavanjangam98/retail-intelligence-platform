{% macro select_bst_joint_cust_fields(state) %}
    {{ state }}_CUSTOMER_NO::VARCHAR AS CUSTOMER_NO,
    {{ state }}_RELN_NATURE_DESC::VARCHAR(20) AS RELN_NATURE_DESC,
    {{ state }}_OCCUPATION_CODE::INT AS OCCUPATION_CODE,
    {{ state }}_JNT_CUST_TYPE::VARCHAR(3) AS JNT_CUST_TYPE
{% endmacro %}