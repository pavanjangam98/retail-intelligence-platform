{% macro select_bst_non_nz_tax_res_fields(state) %}
    {{ state }}_COUNTRY_CODE::VARCHAR AS COUNTRY_CODE,
    {{ state }}_TAX_ID_NO::VARCHAR AS TAX_ID_NO,
    {{ state }}_CUSTOMER_NO::VARCHAR AS CUSTOMER_NO 
{% endmacro %}