{% macro select_eit_acs_status_fields(state) %}
    {{ state }}_ACCESS_STATUS::VARCHAR(2) AS ACCESS_STATUS,
    {{ state }}_CHAID_TYPE::VARCHAR(1) AS CHAID_TYPE,
    {{ state }}_STATUS_DESC::VARCHAR AS STATUS_DESC,
    {{ state }}_LAST_UPDT_TSTAMP::TIMESTAMP_NTZ AS LAST_UPDT_TSTAMP,
    {{ state }}_USER_ID::VARCHAR(8) AS USER_ID,
    {{ state }}_DISPLAY_IND::VARCHAR(1) AS DISPLAY_IND
{% endmacro %}