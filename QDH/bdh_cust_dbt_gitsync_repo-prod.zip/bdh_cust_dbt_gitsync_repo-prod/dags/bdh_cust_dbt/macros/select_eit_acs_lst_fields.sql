{% macro select_eit_acs_lst_fields(state) %}
    {{ state }}_ACCESS_LIST_NO::VARCHAR AS ACCESS_LIST_NO,
    {{ state }}_EMAX_NO::VARCHAR AS EMAX_NO,
    {{ state }}_ACCESS_LIST_DESC::VARCHAR(20) AS ACCESS_LIST_DESC,
    {{ state }}_ACCESS_LIST_TYPE::VARCHAR(1) AS ACCESS_LIST_TYPE,
    {{ state }}_LAST_UPDT_TSTAMP::TIMESTAMP_NTZ AS LAST_UPDT_TSTAMP,
    {{ state }}_USER_ID::VARCHAR(8) AS USER_ID,
    {{ state }}_CONVERTED_IND::VARCHAR(1) AS CONVERTED_IND
{% endmacro %}