{% macro select_bst_warning_fields(state) %}
    {{ state }}_CUSTOMER_NO::VARCHAR AS CUSTOMER_NO,
	{{ state }}_WARNING_DATE::DATE AS WARNING_DATE,
	{{ state }}_WARNING_CODE::VARCHAR AS WARNING_CODE,
	{{ state }}_CREATED_USERID::VARCHAR AS CREATED_USERID
{% endmacro %}