{% macro select_bst_occupation_fields(state) %}
    {{ state }}_OCCUPATION_CODE::VARCHAR AS OCCUPATION_CODE,
	{{ state }}_OCCUPATION_DESC::VARCHAR AS OCCUPATION_DESC
{% endmacro %}