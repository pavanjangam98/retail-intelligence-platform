{% macro generate_schema_name(custom_schema_name=none, node=none) %}
    {# Split the node name into components #}
    {# -- Assign the target environment #}
    {% set environment = target.name.lower() %}
    {# Assgin the is_airflow environment variable and assign default value as false #}
    {# -- It pulls the IS_AIRFLOW environment variable #}
    {% set bdh_isairflow = env_var('IS_AIRFLOW') %}
    {# -- Assign the current target environment ,the node name, and splits the node name to identify parts like database ,schema ,object #}
    {% set node_name = node.name %}
    {% set split_name = node_name.split('___', 2) %}
    {% set node_type = node.unique_id.split('.', 1)[0] %}
    {% set bdh_package = 'bdh' in node.unique_id.split('.', 2)[1] %}

    {# -- NEW: Detect whether the node name is 2-part (database___object) or 3-part (database___schema___object) #}
    {% set is_three_part = split_name | length == 3 %}
    {% set is_two_part   = split_name | length == 2 %}

    {# -- NEW: schema_name resolves to split_name[1] for 3-part, or none for 2-part (no schema encoded in name) #}
    {% set schema_name = split_name[1] if is_three_part else none %}

    {# Error handling for invalid naming or configurations #}
    {# -- If the node type is one of model, snapshot, or seed, but the node name doesn't follow the expected format, it raises an error. #}
    {# Validate the split resulted in two or three parts, otherwise raise an error #}
    {# -- CHANGED: relaxed from != 3 to < 2 to allow both 2-part and 3-part naming conventions #}
    {% if bdh_package and node_type in ['model', 'snapshot', 'seed'] and split_name | length < 2 %}
        {{ exceptions.raise_compiler_error('Invalid naming syntax (should be <database>___<schema>___<object> or <database>___<object>): ' ~ node_name) }}
    {% endif %}

    {# Validate the environment #}
    {# -- It also checks if the environment is valid (dev, syst, ppte, or prod), and raises an error if not. #}
    {% if environment not in ['dev', 'syst', 'ppte', 'prod','preprod'] %}
        {{ exceptions.raise_compiler_error('Unsupported target defined (should be dev, tst, or prd): ' ~ environment) }}
    {% endif %}
    {# -- It ensures that the target.schema is defined before proceeding. #}
    {% if target.schema is none %}
        {{ exceptions.raise_compiler_error('Invalid node ID for generating schema name in schema generation: ' ~ node.unique_id) }}
    {% endif %}
    {# -- It also checks that the target.schema is defined, raising an error if it is not. #}
    {# Generate schema name depending on if the node is a part of an external package #}
    {% set schema_name = target.schema.lower() if custom_schema_name is none else custom_schema_name %}

    {# -- Node Type and Package Handling #}
    {% if bdh_package %}
        {# -- CHANGED: for 3-part use split_name[1] as schema; for 2-part fall back to target.schema (no schema in name) #}
        {% if is_three_part %}
            {% set schema_name = split_name[1] if custom_schema_name is none else custom_schema_name %}
        {% elif is_two_part %}
            {% set schema_name = target.schema.lower() if custom_schema_name is none else custom_schema_name %}
        {% endif %}
    {% endif %}

    {# -- Final Schema Name Generation #}
    {# Generate the final schema name based on environment conditions #}
    {# Checking for is execution mode is an airflow #}
    {% if bdh_isairflow == "false" %}
        {# -- Check isairflow environment #}
        {# -- If the environment is dev or node type is operation, it returns the schema as defined by target.schema. #}
        {% if environment == 'dev' or node_type == 'operation' %}
            {{ return(target.schema.lower()) }}
        {% elif environment == 'syst' %}
            {% if schema_name is none %}
                {{ exceptions.raise_compiler_error('Invalid node ID for generating schema name in schema generation: ' ~ node.unique_id) }}
            {% endif %}
            {{ return(schema_name | trim) }}
        {% else %}
            {% if schema_name is none %}
                {{ exceptions.raise_compiler_error('Invalid node ID for generating schema name in schema generation: ' ~ node.unique_id) }}
            {% endif %}
            {{ return(schema_name | trim) }}
        {% endif %}
    {% else %}
        {% if schema_name is none %}
            {{ exceptions.raise_compiler_error('Invalid node ID for generating schema name in schema generation: ' ~ node.unique_id) }}
        {% endif %}
        {# -- In tst,prd, it returns the schema name without modification. #}
        {{ return(schema_name | trim) }}
    {% endif %}
{% endmacro %}
