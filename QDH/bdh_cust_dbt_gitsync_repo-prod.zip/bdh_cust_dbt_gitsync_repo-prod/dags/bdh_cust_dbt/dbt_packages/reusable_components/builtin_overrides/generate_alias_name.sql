{% macro generate_alias_name(custom_alias_name=none, node=none) %}
    {# Split the node name into components #}
    {# -- Assign the target environment #}
    {% set environment = target.name.lower() %}
    {# assign the zone dbt variable #}
    {# -- It pulls the IS_AIRFLOW environment variable #}
    {% set bdh_isairflow = env_var('IS_AIRFLOW') %}
    {# -- The macro takes the node.name and splits it into parts based on the delimiter ___ (expecting a two or three-part structure: database, schema, and object). #}
    {% set node_name = node.name %}
    {% set split_name = node_name.split('___', 2) %}
    {% set node_type = node.unique_id.split('.', 1)[0] %}
    {% set bdh_package = 'bdh' in node.unique_id.split('.', 2)[1] %}

    {# -- NEW: Detect whether the node name is 2-part (database___object) or 3-part (database___schema___object) #}
    {% set is_three_part = split_name | length == 3 %}
    {% set is_two_part   = split_name | length == 2 %}

    {# -- CHANGED: object_name now resolves based on split length #}
    {# -- 3-part (database___schema___object): object = split_name[2] #}
    {# -- 2-part (database___object):          object = split_name[1] #}
    {% if is_three_part %}
        {% set object_name = split_name[2] %}
    {% elif is_two_part %}
        {% set object_name = split_name[1] %}
    {% else %}
        {% set object_name = none %}
    {% endif %}

    {# -- Error Handling for Invalid Naming or Configurations #}
    {# -- The macro checks that the node name has two or three parts when the node is of type model, snapshot, or seed and is part of the bdh package. #}
    {# Validate the split resulted in two or three parts, otherwise raise an error #}
    {# -- CHANGED: relaxed from != 3 to < 2 to allow both 2-part and 3-part naming conventions #}
    {% if bdh_package and node_type in ['model', 'snapshot', 'seed'] and split_name | length < 2 %}
        {{ exceptions.raise_compiler_error('Invalid naming syntax (should be <database>___<schema>___<object> or <database>___<object>): ' ~ node_name) }}
    {% endif %}

    {# Validate the environment #}
    {# -- It ensures the environment is valid (dev, syst, ppte, or prod). #}
    {% if environment not in ['dev', 'syst', 'ppte', 'prod','preprod'] %}
        {{ exceptions.raise_compiler_error('Unsupported target defined (should be dev, tst, or prd): ' ~ environment) }}
    {% endif %}

    {# -- Generate Alias Name Based on Node Version and Environment #}
    {# Generate the final alias name based on node version and environment #}
    {# Checking for is execution mode is an airflow #}
    {# -- If the environment is dev and isairflow or the node type is operation, it generates the alias name based on the full node name #}
    {% if environment == 'dev' and bdh_isairflow == "false" or node_type == 'operation' or not bdh_package %}

        {% if node_name is none %}
            {{ exceptions.raise_compiler_error('Invalid node ID for generating node name in alias generation: ' ~ node.unique_id) }}
        {% endif %}
        {# -- If the node has a version (via node.version), the version is appended to the node name, with dots replaced by underscores (_vX_X format). #}
        {% if node.version %}
            {# Append a version suffix if the node has a version #}
            {{ return(node_name ~ '_v' ~ node.version | replace('.', '_')) }}
        {% else %}
            {# Use full name if in the developer schema #}
            {# -- If no version exists, the full node name is used as the alias. #}
            {{ return(node_name) }}
        {% endif %}

    {% else %}

        {% if object_name is none %}
            {{ exceptions.raise_compiler_error('Invalid node ID for generating object name in alias generation: ' ~ node.unique_id) }}
        {% endif %}

        {% if node.version %}
            {# Append a version suffix if the node has a version #}
            {{ log("generate_alias_name:version: {0}".format(object_name ~ '_v' ~ node.version | replace('.', '_'))) }}
            {{ return(object_name ~ '_v' ~ node.version | replace('.', '_')) }}
        {% else %}
            {# Use the short alias if in production or testing #}
            {# -- In production or testing environments, the alias name is based on the object name extracted from the node. #}
            {{ return(object_name) }}
        {% endif %}

    {% endif %}
{% endmacro %}
