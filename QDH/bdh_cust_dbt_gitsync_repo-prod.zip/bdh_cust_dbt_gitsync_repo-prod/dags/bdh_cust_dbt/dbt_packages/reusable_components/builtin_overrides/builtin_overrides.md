{% docs generate_database_name___desc %}

This DBT macro is designed to generate a Database name dynamically based on several conditions, parameters and environment variable.

It uses some default params, whose values are pulled from the dbt_project.yml & Profile.yml file.
from dbt_project.yml file - use value specified in bdh_zone variable.
from profile.yml file - use value specified in environment variable.
Is_Airflow from terminal - true Or false (For higher envs, it will be always true.)
 
{% enddocs %}

{% docs generate_database_name___custom_database_name %}

This is 'custom_database_name' argument. It acts as first argument to this macro.

This is custom database name that can be configured at different places in dbt. 

For our use case, its value is set to none.

{% enddocs %}

{% docs generate_database_name___node %}

This is 'node' argument. This act as second argument to this macro.

This is the model name which we are executing. for e.g. 'raw___bis___bst_customer'

{% enddocs %}

{% docs generate_schema_name___desc %}

This DBT macro is designed to generate a Schema name dynamically based on several conditions, parameters and environment variable.

It uses some default params, whose values are pulled from the dbt_project.yml & Profile.yml file.
from project.yml file -  use value specified in bdh_zone variable.
from profile.yml file -  use value specified in bdh_zone variable.
Is_Airflow from terminal - true Or false (For higher envs, it will be always true.)
 
{% enddocs %}

{% docs generate_schema_name___custom_schema_name %}

This is 'custom_schema_name' argument. It acts as first argument to this macro.

This is the custom schema name that can be configured in different places in dbt.

For our use case, its value is set to none.

{% enddocs %}

{% docs generate_schema_name___node %}

This is 'node' argument. This act as second argument to this macro.

This is the model name which we are executing. for e.g. 'raw___bis___bst_customer'

{% enddocs %}

{% docs generate_alias_name___desc %}

This DBT macro is designed to generate a Alias name dynamically based on several conditions, parameters and environment variable.

It uses some default params, whose values are pulled from the dbt_project.yml & Profile.yml file.
from project.yml file -  use value specified in bdh_zone variable.
from profile.yml file -  use value specified in bdh_zone variable.
Is_Airflow from terminal - true Or false.(For higher envs, it will be always true.)
 
{% enddocs %}

{% docs generate_alias_name___custom_alias_name %}

This is 'custom_alias_name' argument. It acts as first argument to this macro.

This is the custom_alias_name that can be configured in different places in dbt. 

For our use case, its value is set to none.

{% enddocs %}

{% docs generate_alias_name___node %}

This is 'node' argument. This act as second argument to this macro.

This is the model name which we are executing. for e.g. 'raw___bis___bst_customer'

{% enddocs %}