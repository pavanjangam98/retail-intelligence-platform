{% macro apply_tags() %}
    {% set out_str = 'ALTER TABLE ' ~ this ~ ' MODIFY\n' %}
    {% set this_db_name = this.database | upper %}
    {% set this_schema_name = this.schema | upper %}
    {% set this_table_name = this.identifier | upper %}
    {% set src_classification_table = source('classification','CLASSIFICATION_DATA_LV') | upper %}
    {% set src_tagging_schema = source('tags','TAGS').database ~ "." ~ source('tags','TAGS').schema | upper %}
    {% set bdh_isairflow = env_var('IS_AIRFLOW') %}
    {% set bdh_zone = var('DBT_BDH_ZONE') %}
    {% set info_columns = this_db_name + '.information_schema.columns' %}

    {# get the classification table details to get the tags from if applying to transform db #}
    {% if bdh_isairflow.lower() == "false" and this_db_name|length > 0 and this_table_name.split('___')|length > 2%}
        {% set tgt_db_name = bdh_zone + '__' + this_table_name.split('___')[0] %}
        {% set tgt_schema_name = this_table_name.split('___')[1] %}
        {% set tgt_table_name = this_table_name.split('___')[2] %}
    {% elif this_db_name|length > 0 and this_db_name.split('__')|length > 1%}
        {% set tgt_db_name = bdh_zone + '__' + this_db_name.split('__')[1] %}
        {% set tgt_schema_name = this_schema_name %}
        {% set tgt_table_name = this_table_name %}
    {% endif %}

    {# query the governance table for tags to apply #}
    {% set query %}
        SELECT 
            UPPER(trim(C.column_name)) as column_name
            ,security_classification_code
            ,privacy_identifier_flag
            ,pci_dss_compliance_identifier_flag
            ,government_identifier_flag
            ,sensitive_personal_identifier_flag
            ,health_identifier_flag
            ,credit_identifier_flag
            ,credentials_identifier_flag
        FROM 
            {{ src_classification_table }} C
        LEFT JOIN
            {{ info_columns }} I
        ON UPPER(trim(C.column_name)) = UPPER(I.column_name)
            AND UPPER('{{ this_table_name }}') = UPPER(I.table_name)
            AND UPPER('{{ this_schema_name }}') = UPPER(I.table_schema)
        WHERE
            UPPER(trim(C.table_name)) = UPPER('{{ tgt_table_name }}')
            AND UPPER(trim(C.schema_name)) = UPPER('{{ tgt_schema_name }}')
            AND UPPER(trim(C.db_name)) = UPPER('{{ tgt_db_name }}')
            AND I.column_name IS NOT NULL
    {% endset %}

    {% set src_classification = run_query(query) %}

    {% if src_classification|length == 0 %}
        {{ '' }}
    {% else %}
        {% if execute %}
            {% set classification_list = src_classification.rows %}
            {% set column_list = src_classification.column_names %}
            {% set mod_strs = [] %}

            {# generate modify statement for each target table column that exists in classification source table#}

            {% for classification in classification_list %}
                {% set col_str = [] %}
                {% set tag_strs = [] %}

                {# generate column set tag statement and list of tags to add #}

                {% for i in range(column_list|length) %}
                    {% if column_list[i] == "COLUMN_NAME" %}
                        {% do col_str.append(' COLUMN ' ~ classification[i] ~ ' SET TAG ') %}
                    {% else %}
                        {% do tag_strs.append(' ' ~ src_tagging_schema + '.' ~ column_list[i] ~ ' = "' ~ classification[i] ~ '"') %}
                    {% endif %}
                {% endfor %}
                {# build modify statement per column #}
                {% do mod_strs.append(col_str | join(', ') + tag_strs | join(', ')) %}
            {% endfor %}
        {% endif %}
        {# build and output alter table statement #}
        {{ out_str + mod_strs | join('\n ,') }}
    {% endif %}
    
{% endmacro %}