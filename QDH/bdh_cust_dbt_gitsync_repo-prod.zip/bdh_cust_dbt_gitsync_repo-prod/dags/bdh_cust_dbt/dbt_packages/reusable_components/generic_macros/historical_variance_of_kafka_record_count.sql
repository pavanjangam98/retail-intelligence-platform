{% macro historical_variance_of_kafka_record_count(model, source_name, table_name, primary_key, date_column='RECORD_CONTENT:metadata.time', variance_pct=10, afterState="afterState", beforeState="beforeState") %}
    
    {% set src_tble = source(source_name, table_name) %}

    {% set max_date_query %}
        SELECT MAX({{ date_column }})::DATE AS max_date FROM {{ src_tble }}
    {% endset %}
    
    {{ log("max_date_query: " ~ max_date_query, info=True) }}
    
    {% set max_date_result = run_query(max_date_query) %}
    
    {% if max_date_result is none %}
    {{ exceptions.raise_compiler_error(" Query compilation error: No max date issue found in source table.") }}
    {% endif %}
    
    {% set max_date = max_date_result.columns[0].values()[0] %}
    {{ log("Max available date in source (MAX): " ~ max_date, info=True) }}
    
    {% set latest_date_query %}
    SELECT (DATE '{{ max_date }}' - INTERVAL '1 day')::DATE AS load_date
    {% endset %}
    
    {{ log("latest_date_query: " ~ latest_date_query, info=True) }}
    
    {% set latest_date_result = run_query(latest_date_query) %}
    
    {% if latest_date_result is none %}
    {{ exceptions.raise_compiler_error("Query compilation error: Failed to subtract 1 day from max date.") }}
    {% endif %}
    
    {% set latest_date = latest_date_result.columns[0].values()[0] %}
    {{ log("Latest available load_date (MAX - 1 day): " ~ latest_date, info=True) }}
    
    {% if latest_date is none %}
        {{ log("No data in source table to evaluate.", info=True) }}
        {{ exceptions.raise_compiler_error("Query compilation error:No data in source table to evaluate.") }}
    {% else %}

 --handling PK's

    {% if primary_key is iterable and primary_key is not string %}
        {% set transformed_keys = [] %}
        {% for col in primary_key %}
        {% set expr = "COALESCE(RECORD_CONTENT:" ~ afterState ~ "." ~ col ~ ", RECORD_CONTENT:" ~ beforeState ~ "." ~ col ~ ")" %}
        {% do transformed_keys.append(expr) %}
    {% endfor %}
        {% set primary_key_expr = transformed_keys | join(', ') %}
    {% else %}
        {% set primary_key_expr = "COALESCE(RECORD_CONTENT:" ~ afterState ~ "." ~ primary_key ~ ", RECORD_CONTENT:" ~ beforeState ~ "." ~ primary_key ~ ")" %}
    {% endif %}

    {{ log("Primary key being used: " ~ primary_key_expr, info=True) }}

    -- Today's (load_date) record count after deduplication

    {% set today_count_query %}
        SELECT COUNT(*) as record_count
        FROM (
            SELECT *
            FROM (
                SELECT *,
                       ROW_NUMBER() OVER (PARTITION BY {{ primary_key_expr }}, {{ date_column }} ORDER BY {{ date_column }} DESC) AS row_num
                FROM {{ src_tble }}
                WHERE DATE({{ date_column }}) = DATE('{{ latest_date }}')
            ) ranked
            WHERE row_num = 1
        ) deduped
    {% endset %}

    {{ log("today_count_query: " ~ today_count_query, info=True) }}  

    {% set today_count_result = run_query(today_count_query) %}
    {% if today_count_result is none %}
        {{ log("run_query() returned None for today's deduped count", info=True) }}
        {{ exceptions.raise_compiler_error("Query compilation error: Null returned for count from source table for the latest date.") }}
    {% else %}

        {% set today_count = today_count_result.columns[0].values()[0] | int %}
        {{ log("Today's deduped record count: " ~ today_count, info=True) }}

        {% if today_count == 0 %}
            {{ log("WARNING: No data in source table to evaluate for the latest date.", info=True) }}
        {% else %}

        -- Historical Deduplicated Record Count (Last 30 Days)

        {% set history_query %}
            SELECT COUNT(*) as record_count
            FROM (
                SELECT *
                FROM (
                    SELECT *,
                           ROW_NUMBER() OVER (PARTITION BY {{ primary_key_expr }}, {{ date_column }} ORDER BY {{ date_column }} DESC) as rn
                    FROM {{ src_tble }}
                    WHERE DATE({{ date_column }}) >= DATE('{{ latest_date }}') - INTERVAL '30 day'
                      AND DATE({{ date_column }}) < DATE('{{ latest_date }}')
                ) deduped
                WHERE rn = 1
            ) final
        {% endset %}

            -- Get Number of Distinct Days with Data

            {% set days_query %}
                SELECT COUNT(DISTINCT DATE({{ date_column }})) AS day_count
                FROM {{ src_tble }}
                WHERE DATE({{ date_column }}) >= DATE('{{ latest_date }}') - INTERVAL '30 day'
                  AND DATE({{ date_column }}) < DATE('{{ latest_date }}')
            {% endset %}

            -- Run both queries

            {% set history_result = run_query(history_query) %}
            {% set days_result = run_query(days_query) %}
            {% if history_result is none or days_result is none %}
                {{ log("Failed to retrieve historical data or day count.", info=True) }}
                {{ exceptions.raise_compiler_error("Query compilation error: Null or Zero record returned for history data count from source table.") }}
            {% else %}

                {% set total_records = history_result.columns[0].values()[0] | int %}
                {% set total_days = days_result.columns[0].values()[0] | int %}
                {{ log("Total historical days with data: " ~ total_days, info=True) }}
                {{ log("Total historical deduplicated records: " ~ total_records, info=True) }}
                {% if total_days == 0 or total_records is none %}
                    {{ log("Insufficient historical data to calculate variance.", info=True) }}
                    {{ log("WARNING: total_days is 0 or total_records is null. Variance calculation skipped.", info=True) }}
                {% else %}

                    -- Calculate Average and Variance Bounds

                    {% set average_count = (total_records / total_days) | round(2) %}
                    {% set variance_row_count = (average_count * (variance_pct / 100.0)) | round(2) %}
                    {% set lower_bound = (average_count - variance_row_count) | round(2) %}
                    {% set upper_bound = (average_count + variance_row_count) | round(2) %}
                    {% set variance_allowed_percentage = (((variance_row_count) / average_count) * 100) | round(2) %}
                    {% set variance_observed_pct = (((today_count - average_count) / average_count) * 100) | round(2) %}

                    -- Log All Variance Metrics (before final comparison)

                    {{ log("Average historical count: " ~ average_count, info=True) }}
                    {{ log("Variance percent: " ~ variance_pct, info=True) }}
                    {{ log("Variance amount: " ~ variance_row_count, info=True) }}
                    {{ log("Lower bound: " ~ lower_bound, info=True) }}
                    {{ log("Upper bound: " ~ upper_bound, info=True) }}
                    {{ log("Variance allowed percentage: ±" ~ variance_pct ~ "%", info=True) }}
                    {{ log("Today's count: " ~ today_count ~ ", Allowed range: [" ~ lower_bound ~ ", " ~ upper_bound ~ "]", info=True) }}
                    {{ log("Variance observed percentage: " ~ variance_observed_pct ~ "%", info=True) }}

                    -- Compare Yesterday's Count to Expected Range

                    {% if today_count < lower_bound or today_count > upper_bound %}
                        {{ log("Latest date count is outside the acceptable variance range.", info=True) }}
                        SELECT 1 AS test_result -- fail
                        {{ log(" WARNING: Today's count is OUTSIDE the acceptable variance range.", info=True) }}
                        {% do log("WARNING: " ~ 'Latest day count is outside the acceptable variance range. Variance allowed percentage: ±' ~ variance_allowed_percentage ~'%, Variance observed percentage: ' ~ variance_observed_pct ~ '%', info=True) %}
                    {% else %}
                        {{ log(" INFO: Today's count is within acceptable variance.", info=True) }}
                        SELECT 0 AS test_result WHERE 1=2 -- soft-pass
                    {% endif %}
                {% endif %}
            {% endif %}
        {% endif %}
    {% endif %}
{% endif %}  
{% endmacro %}