{% macro fdp_custom_check_deleted_counts_between_models_from_date(model, compare_model, model_time_col, compare_time_col, look_back) %}



{% set query %}
    select current_timestamp as current_tstamp
{% endset %}

{% set result = run_query(query) %}
{% set current_tstamp = result.columns[0].values()[0] %}
 
{% set model_count_sql %}
    select count(*) as model_count
    from {{ ref(model) }}
    where {{ model_time_col }} >= dateadd(day, -{{ look_back }}, to_timestamp('{{ current_tstamp }}'))
      and dwh_latest_dml_type_code = 'D'
{% endset %}
 
{% set compare_model_count_sql %}
    select count(*) as compare_count
    from {{ ref(compare_model) }}
    where {{ compare_time_col }} >= dateadd(day, -{{ look_back }}, to_timestamp('{{ current_tstamp }}'))
      and dwh_latest_dml_type_code = 'D'
{% endset %}
 
{{ log("model_count_sql: " ~ model_count_sql, info=True) }}
{{ log("compare_model_count_sql: " ~ compare_model_count_sql, info=True) }}
 
{% set model_count_result = run_query(model_count_sql) %}
{% set compare_count_result = run_query(compare_model_count_sql) %}
 
{{ log("model_count_result: " ~ model_count_result, info=True) }}
{{ log("compare_count_result: " ~ compare_count_result, info=True) }}
 
{% set model_count_val = model_count_result.columns[0].values()[0] %}
{% set compare_count_val = compare_count_result.columns[0].values()[0] %}
 
{{ log("model_count_val: " ~ model_count_val, info=True) }}
{{ log("compare_count_val: " ~ compare_count_val, info=True) }}
 
{% if model_count_val != compare_count_val %}
    {{ log("Deleted count not matching: model count = " ~ model_count_val ~ ", compare model count = " ~ compare_count_val, info=True) }}
    {{ exceptions.raise_compiler_error("Deleted count mismatch detected: model count (" ~ model_count_val|string ~ ") does not equal compare model count (" ~ compare_count_val|string ~ ").") }}
{% else %}
    {{ log("Deleted count matching: model count = " ~ model_count_val ~ ", compare model count = " ~ compare_count_val, info=True) }}
{% endif %}
 
 
{% endmacro %}