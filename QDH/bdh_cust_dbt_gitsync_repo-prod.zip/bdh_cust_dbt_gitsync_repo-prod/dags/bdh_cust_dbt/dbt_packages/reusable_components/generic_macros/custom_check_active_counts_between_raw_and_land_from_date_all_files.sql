{% macro custom_check_active_counts_between_raw_and_land_from_date_all_files(
    model,
    model_key_columns,
    source_name,
    table_name,
    compare_key_columns,
    ingestion_type="file",
    load_type="type2",
    look_back=1,
    parent_key='APPLICATIONNUMBER',
    raise_error=True
) %}

-- Raw model time column based on raw table type
{% if load_type == "append" %}
    {% set model_time_col = "DWH_EXTRACTION_TSTAMP" %}
{% elif load_type == "type2" %}
    {% set model_time_col = "DWH_EFFECTIVE_FROM_TSTAMP" %}
{% elif load_type == "xml" %}
    {% set model_time_col = "DWH_EFFECTIVE_FROM_TSTAMP" %}
{% elif load_type == "delta" %}
    {% set model_time_col = "DWH_EFFECTIVE_FROM_TSTAMP" %}
{% else %}
    {{ exceptions.raise_compiler_error("Unsupported load_type: " ~ load_type) }}    
{% endif %}

-- Ensure only file is used
{% if ingestion_type != "file" %}
    {{ exceptions.raise_compiler_error("This macro supports only file ingestion_type") }}
{% endif %}

-- Set the landing/compare table
{% set compare_model = source(source_name, table_name) %}

-- Determine compare time column
{% if load_type in ["append", "type2", "delta"] %}
    {% set compare_time_col = "LOAD_DATE::DATE" %}
{% elif load_type == "xml" %}
    {% set compare_time_col = "LOAD_TSTAMP" %}
{% endif %}

--------------------------------------------------------------------------------
-- Defining current timestamp
--------------------------------------------------------------------------------
{% set current_ts_query %}
    SELECT current_timestamp AS current_ts
{% endset %}
{% set current_ts_result = run_query(current_ts_query) %}
{% set current_ts = current_ts_result.columns[0].values()[0] %}
{{ log("Current timestamp used in macro: " ~ current_ts, info=True) }}

--------------------------------------------------------------------------------
-- Step 1: Raw model distinct count query
--------------------------------------------------------------------------------
{% set model_count_query %}
    select count(*) as model_count
    from (
        select distinct
            {% for col in model_key_columns %}
                r.{{ col }}{% if not loop.last %}, {% endif %}
            {% endfor %}
        from {{ ref(model) }} as r

        {% if load_type == "type2" %}
            where r.DWH_EFFECTIVE_TO_TSTAMP = '9999-12-31 00:00:00.000'
              and r.DWH_IS_DELETED_FLAG = 'N'

        {% elif load_type == "delta" %}
            where r.{{ model_time_col }}::DATE >= (
                select min(d.load_date)
                from (
                    select distinct {{ compare_time_col }} as load_date
                    from {{ compare_model }}
                    order by load_date desc
                    limit {{ look_back }}
                ) d
            )
              and r.DWH_IS_DELETED_FLAG = 'N'

        {% elif load_type == "xml" %}
            where dwh_latest_dml_type_code not in ('D')
              and DWH_EFFECTIVE_TO_TSTAMP::DATE = '9999-12-31'
              and exists (
                    select 1
                    from {{ compare_model }} v
                    where v.{{ compare_time_col }} = (select max({{ compare_time_col }}) from {{ compare_model }})
                      and r.{{ parent_key }} = v.{{ parent_key }}
              )

        {% elif load_type == "append" %}
            where r.DWH_EXTRACTION_TSTAMP = (
                select max(DWH_EXTRACTION_TSTAMP)
                from {{ ref(model) }}
            )
        {% endif %}
    )
{% endset %}

--------------------------------------------------------------------------------
-- Step 2: Compare/landing distinct count query
--------------------------------------------------------------------------------
{% if load_type in ["append", "type2"] %}

    {% set compare_count_query %}
        select count(*) as compare_count
        from (
            select distinct
                {% for col in compare_key_columns %}
                    {{ col }}{% if not loop.last %}, {% endif %}
                {% endfor %}
            from {{ compare_model }}
            where {{ compare_time_col }} = (
                select max({{ compare_time_col }})
                from {{ compare_model }}
            )
        )
    {% endset %}

{% elif load_type == "delta" %}

    {% set compare_count_query %}
        select count(*) as compare_count
        from (
            select distinct
                {% for col in compare_key_columns %}
                    {{ col }}{% if not loop.last %}, {% endif %}
                {% endfor %}
            from {{ compare_model }}
            where {{ compare_time_col }} >= (
                select min(d.load_date)
                from (
                    select distinct {{ compare_time_col }} as load_date
                    from {{ compare_model }}
                    order by load_date desc
                    limit {{ look_back }}
                ) d
            )
        )
    {% endset %}

{% elif load_type == "xml" %}

    {% set compare_count_query %}
        select count(*) as compare_count
        from (
            select distinct
                {% for col in compare_key_columns %}
                    {{ col }}{% if not loop.last %}, {% endif %}
                {% endfor %}
            from {{ compare_model }}
            where {{ compare_time_col }} = (
                select max({{ compare_time_col }})
                from {{ compare_model }}
            )
        )
    {% endset %}

{% endif %}

--------------------------------------------------------------------------------
-- Step 3: Execute queries and compare results
--------------------------------------------------------------------------------
{% if execute %}
    {{ log("[Count Check] Raw Count Query: " ~ model_count_query, info=True) }}
    {{ log("[Count Check] Compare Count Query: " ~ compare_count_query, info=True) }}

    {% set model_count_result = run_query(model_count_query) %}
    {% set compare_count_result = run_query(compare_count_query) %}

    {% if model_count_result and compare_count_result %}
        {% set model_count_val = model_count_result.columns[0].values()[0] %}
        {% set compare_count_val = compare_count_result.columns[0].values()[0] %}

        {{ log("[Count Check] Raw Layer Count: " ~ model_count_val ~ ", Compare Layer Count: " ~ compare_count_val, info=True) }}

        {% if model_count_val != compare_count_val %}
            {% if raise_error %}
                {% do exceptions.raise_compiler_error("Count mismatch! Raw: " ~ model_count_val ~ ", Compare: " ~ compare_count_val) %}
            {% else %}
                {{ log("Warning: Count mismatch detected but continuing.", info=True) }}
            {% endif %}
        {% else %}
            {{ log("Count matches between raw and compare layers!", info=True) }}
        {% endif %}
    {% else %}
        {{ log("One or both count queries returned no results.", info=True) }}
    {% endif %}
{% endif %}

{% endmacro %}