{% macro set_query_tag() %}
  {% if execute %}
    -- Get tool name dynamically (defaults to 'dbt')
    {% set tool_name = var('tool_name', 'dbt') %}
    -- Determine current dbt node (model or test)
    {% set node = model if model is defined else (test if test is defined else none) %}
    {% if node is not none %}
      {% if node.resource_type == 'model' %}
        -- Build query tag for a model
      {% set new_query_tag = ("tool_name = " ~ tool_name ~ ", database_name = " ~ node.database ~ ", schema_name = " ~ node.schema ~ ", table_name = " ~ node.alias ~ "") %}
      {% elif node.resource_type == 'test' %}
        -- Build query tag for a test
        {% set new_query_tag = "tool_name = " ~ tool_name ~ ", test_name = " ~ node.name ~ "" %}
      {% else %}
        -- Fallback for unknown node type
        {% set new_query_tag = tool_name ~ '__unknown__' %}
      {% endif %}
      -- Set the query tag at session level
      {% do run_query("alter session set query_tag = '" ~ new_query_tag ~ "'") %}
      {{ log("Query tag set to: " ~ new_query_tag, info=True) }}
    {% else %}
      {{ log("Query tag not set: No model or test context found.", info=True) }}
    {% endif %}
  {% endif %}
{% endmacro %}

 