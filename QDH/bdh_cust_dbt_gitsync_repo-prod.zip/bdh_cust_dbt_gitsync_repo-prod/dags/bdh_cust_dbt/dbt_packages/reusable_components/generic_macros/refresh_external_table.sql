{% macro refresh_external_table(database_name, schema_name, table_name) %}

    {{ log("Refreshing: " ~ database_name ~ "." ~ schema_name ~ "." ~ table_name, info=True) }}

    {% set refresh_query %}
        CALL {{database_name}}.{{schema_name}}.refresh_external_table_proc(
            '{{ database_name }}', 
            '{{ schema_name }}',    
            '{{ table_name }}'
        );
    {% endset %}

    {% set result = run_query(refresh_query) %}

    {% if execute and result %}
        {{ log("Result: " ~ result.columns[0].values()[0], info=True) }}
    {% endif %}

{% endmacro %}