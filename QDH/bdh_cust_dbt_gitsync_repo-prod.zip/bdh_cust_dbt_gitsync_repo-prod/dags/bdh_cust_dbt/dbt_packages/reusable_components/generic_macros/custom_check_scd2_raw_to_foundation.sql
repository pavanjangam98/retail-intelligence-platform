{% macro custom_check_scd2_raw_to_foundation(
    source_model,
    target_model,
    key_columns,
    source_key_columns,
    target_key_columns,
    source_trim_columns,
    source_from_column,
    source_to_column,
    source_deleted_flag_column,
    source_dml_type_column,
    target_from_column,
    target_to_column,
    target_deleted_flag_column,
    target_dml_type_column,
    look_back=5,
    lag_minutes=60,
    raise_error=False,
    validate_columns=['RELN_ACCESS_IND','START_DATE','KEY_CONTACT_IND','OTHER_FREE_TEXT'],
    validate_source_columns=['RELN_ACCESS_IND','START_DATE','KEY_CONTACT_IND','OTHER_FREE_TEXT'],
    validate_target_columns=['RELATION_ACCESS_FLAG','START_DATE','KEY_CONTACT_FLAG','OTHER_FREE_TEXT']

) %}

{# =================================================================
   Macro : custom_check_scd2_raw_to_foundation
   Validates SCD Type-2 pipeline from RAW to FOUNDATION layer.
   Single file — no helper macros needed.
   Supports : INSERT / UPDATE / DELETE / LATE ARRIVAL / COLUMN CHECK.
================================================================= #}

{# ── Resolve relations from model name strings ── #}
{% set source_relation = (source_model) %}
{% set target_relation = (target_model) %}

-- {% set source_relation = source_model %}
-- {% set target_relation = target_model %}

{{ log("=== SCD2 Raw→Foundation Validation Macro Started ===",        info=True) }}
{{ log("Source Model               : " ~ source_model,                info=True) }}
{{ log("Target Model               : " ~ target_model,                info=True) }}
{{ log("Resolved Source Relation   : " ~ source_relation,             info=True) }}
{{ log("Resolved Target Relation   : " ~ target_relation,             info=True) }}
{{ log("Key Columns (alias)        : " ~ key_columns,                 info=True) }}
{{ log("Source Key Columns         : " ~ source_key_columns,          info=True) }}
{{ log("Target Key Columns         : " ~ target_key_columns,          info=True) }}
{{ log("Source Trim Columns        : " ~ source_trim_columns,         info=True) }}
{{ log("Source From Column         : " ~ source_from_column,          info=True) }}
{{ log("Source To Column           : " ~ source_to_column,            info=True) }}
{{ log("Source Deleted Flag Column : " ~ source_deleted_flag_column,  info=True) }}
{{ log("Source DML Type Column     : " ~ source_dml_type_column,      info=True) }}
{{ log("Target From Column         : " ~ target_from_column,          info=True) }}
{{ log("Target To Column           : " ~ target_to_column,            info=True) }}
{{ log("Target Deleted Flag Column : " ~ target_deleted_flag_column,  info=True) }}
{{ log("Target DML Type Column     : " ~ target_dml_type_column,      info=True) }}
{{ log("Look Back (days)           : " ~ look_back,                   info=True) }}
{{ log("Lag Minutes                : " ~ lag_minutes,                 info=True) }}
{{ log("Validate Column (alias)    : " ~ validate_columns,             info=True) }}
{{ log("Validate Source Column     : " ~ validate_source_columns,      info=True) }}
{{ log("Validate Target Column     : " ~ validate_target_columns,      info=True) }}
{{ log("Source relation            : " ~ source_relation,             info=True) }}
{{ log("Target relation            : " ~ target_relation,             info=True) }}
{{ log("Hash Columns               : " ~ hash_columns,                info=True) }}

{# ── Validate list lengths ── #}
{% if key_columns | length != source_key_columns | length %}
    {{ exceptions.raise_compiler_error(
        "key_columns and source_key_columns must be the same length. Got "
        ~ key_columns | length ~ " key_columns and "
        ~ source_key_columns | length ~ " source_key_columns."
    ) }}
{% endif %}

{% if key_columns | length != target_key_columns | length %}
    {{ exceptions.raise_compiler_error(
        "key_columns and target_key_columns must be the same length. Got "
        ~ key_columns | length ~ " key_columns and "
        ~ target_key_columns | length ~ " target_key_columns."
    ) }}
{% endif %}

{# ── Validate column check params are consistent ── #}
{% if validate_columns is not none and validate_source_columns is none %}
    {{ exceptions.raise_compiler_error(
        "validate_source_column is required when validate_column is provided."
    ) }}
{% endif %}
{% if validate_columns is not none and validate_target_columns is none %}
    {{ exceptions.raise_compiler_error(
        "validate_target_column is required when validate_column is provided."
    ) }}
{% endif %}

{# ── Capture current timestamp once for consistent time windows ── #}
{% set current_ts = None %}
{% if execute %}
    {% set current_ts_query %}
        SELECT CURRENT_TIMESTAMP AS current_ts
    {% endset %}
    {% set current_ts_result = run_query(current_ts_query) %}
    {% set current_ts = current_ts_result.columns[0].values()[0] %}
    {{ log("Current Timestamp : " ~ current_ts, info=True) }}
{% endif %}

{% set generated_sql %}

WITH source_data AS (
    SELECT
        {# ── Source key columns — apply TRIM() if listed in source_trim_columns ── #}
        {% for i in range(source_key_columns | length) %}
            {% if source_key_columns[i] in source_trim_columns %}
        TRIM({{ source_key_columns[i] }})                                AS {{ key_columns[i] }},
            {% else %}
        {{ source_key_columns[i] }}                                      AS {{ key_columns[i] }},
            {% endif %}
        {% endfor %}

        {# ── Validate columns from source — TRIM if in source_trim_columns ── #}
        {% if validate_columns is not none %}
            {% for i in range(validate_columns | length) %}
                {% if validate_source_columns[i] in source_trim_columns %}
        TRIM({{ validate_source_columns[i] }})                           AS {{ validate_columns[i] }}_src,
                {% else %}
        {{ validate_source_columns[i] }}                                 AS {{ validate_columns[i] }}_src,
                {% endif %}
            {% endfor %}
        {% endif %}

        {{ source_from_column }}                                         AS src_effective_from,
        {{ source_to_column }}                                           AS src_effective_to,
        {{ source_dml_type_column }}                                     AS src_dml_type_code,
        {{ source_deleted_flag_column }}                                 AS src_is_deleted_flag,
        
        {% if validate_source_columns is not none %}
        MD5(
            CONCAT_WS('|',
                {% for col in validate_source_columns %}
                    COALESCE(TRIM({{ col }}), '∅'){% if not loop.last %}, {% endif %}
                {% endfor %}
            )
        ) AS src_hash,
        {% endif %}
        -- Row number per key ordered by effective_from ASC
        ROW_NUMBER() OVER (
            PARTITION BY {{ key_columns | join(', ') }}
            ORDER BY {{ source_from_column }} ASC
        )                                                                AS record_order,

        CASE
            WHEN {{ source_dml_type_column }} = 'D'
             AND {{ source_deleted_flag_column }} = 'Y' THEN 'DELETE'
            WHEN ROW_NUMBER() OVER (
                     PARTITION BY {{ key_columns | join(', ') }}
                     ORDER BY {{ source_from_column }} ASC
                 ) = 1                                  THEN 'INSERT'
            ELSE 'UPDATE'
        END                                                              AS scenario,

        -- Late arrival: effective_from is earlier than a row
        -- that was already processed for the same key group
        CASE
            WHEN {{ source_from_column }} < MAX({{ source_from_column }}) OVER (
                     PARTITION BY {{ key_columns | join(', ') }}
                     ORDER BY {{ source_from_column }} ASC
                     ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
                 )
            THEN TRUE
            ELSE FALSE
        END                                                              AS is_late_arrival

    FROM {{ source_relation }}
    WHERE {{ source_from_column }} <= DATEADD(MINUTE, -{{ lag_minutes }}, '{{ current_ts }}'::TIMESTAMP_TZ)
      AND {{ source_from_column }} >= DATEADD(DAY,    -{{ look_back }},   '{{ current_ts }}'::TIMESTAMP_TZ)

     
),


target_data AS (
    SELECT
        {# ── Target key columns aliased to match key_columns for clean JOINs ── #}
        {% for i in range(target_key_columns | length) %}
        {{ target_key_columns[i] }}                                      AS {{ key_columns[i] }},
        {% endfor %}

        {# ── Validate columns from target — TRIM if in source_trim_columns (for consistency) ── #}
        {% if validate_columns is not none %}
            {% for i in range(validate_columns | length) %}
                {% if validate_target_columns[i] in source_trim_columns %}
        TRIM({{ validate_target_columns[i] }})                           AS {{ validate_columns[i] }}_tgt,
                {% else %}
        {{ validate_target_columns[i] }}                                 AS {{ validate_columns[i] }}_tgt,
                {% endif %}
            {% endfor %}
        {% endif %}

        TO_TIMESTAMP_NTZ({{ target_from_column }})                       AS tgt_effective_from,
        TO_TIMESTAMP_NTZ({{ target_to_column }})                         AS tgt_effective_to,
        {{ target_dml_type_column }}                                     AS tgt_dml_type_code,
        {{ target_deleted_flag_column }}                                 AS tgt_is_deleted_flag,

        {% if validate_target_columns is not none %}
        MD5(
            CONCAT_WS('|',
                {% for col in validate_target_columns %}
                    COALESCE(TRIM({{ col }}), '∅'){% if not loop.last %}, {% endif %}
                {% endfor %}
            )
        ) AS tgt_hash,
        {% endif %}


        ROW_NUMBER() OVER (
            PARTITION BY
                {# Partition by original target key columns —
                   aliases not resolvable in window functions in Snowflake #}
                {% for col in target_key_columns %}
                {{ col }}{% if not loop.last %}, {% endif %}
                {% endfor %}
            ORDER BY {{ target_from_column }} ASC
        )                                                                AS record_order

    FROM {{ target_relation }}
    WHERE {{ target_from_column }} <= DATEADD(MINUTE, -{{ lag_minutes }}, '{{ current_ts }}'::TIMESTAMP_TZ)
      AND {{ target_from_column }} >= DATEADD(DAY,    -{{ look_back }},   '{{ current_ts }}'::TIMESTAMP_TZ)
),


-- ============================================================
-- CHECK 1 : INSERT and UPDATE (including late arrivals)
-- Validates effective_from, effective_to and optional column.
-- ============================================================
insert_update_check AS (

    SELECT
        {% for col in key_columns %}s.{{ col }}, {% endfor %}
        s.record_order,

        -- Label late arrivals distinctly
        CASE
            WHEN s.is_late_arrival = TRUE THEN s.scenario || '_LATE'
            ELSE s.scenario
        END                                                              AS scenario,

        s.src_effective_from,
        s.src_effective_to,
        t.tgt_effective_from,
        t.tgt_effective_to,

        {# ── Expose SHA2 hashes for debugging when column validation enabled ── #}
        {% if validate_columns is not none %}
        s.src_hash,
        t.tgt_hash,
        {% endif %}

        CASE
            WHEN t.{{ key_columns[0] }} IS NULL
                THEN 'FAIL - Row missing in foundation for record_order '
                     || s.record_order::VARCHAR
            WHEN s.src_effective_from <> t.tgt_effective_from
                THEN 'FAIL - effective_from mismatch (src: '
                     || s.src_effective_from::VARCHAR
                     || ', tgt: ' || t.tgt_effective_from::VARCHAR || ')'
            WHEN s.src_effective_to <> t.tgt_effective_to
                THEN 'FAIL - effective_to mismatch (src: '
                     || s.src_effective_to::VARCHAR
                     || ', tgt: ' || t.tgt_effective_to::VARCHAR || ')'

            {# ── SHA2 hash comparison across all validate columns ── #}
            {% if validate_columns is not none %}
            WHEN s.src_hash IS DISTINCT FROM t.tgt_hash
                THEN 'FAIL - validate_columns SHA2 mismatch (src_sha2: '
                     || COALESCE(s.src_hash, 'NULL')
                     || ', tgt_sha2: '
                     || COALESCE(t.tgt_hash, 'NULL') || ')'
            {% endif %}

            ELSE 'PASS'
        END                                                              AS row_result

    FROM source_data s
    LEFT JOIN target_data t
        ON  {% for col in key_columns %}
            s.{{ col }} = t.{{ col }}{% if not loop.last %} AND {% endif %}
            {% endfor %}
        AND s.record_order = t.record_order
    WHERE s.scenario IN ('INSERT', 'UPDATE')

    
),

-- ============================================================
-- CHECK 2 : DELETE scenario
-- Validates flags, effective_from, effective_to and optional column.
-- ============================================================
delete_check AS (
    SELECT
        {% for col in key_columns %}s.{{ col }}, {% endfor %}
        s.record_order,
        s.scenario,
        s.src_effective_from,
        s.src_effective_to,
        t.tgt_effective_from,
        t.tgt_effective_to,

        {% if validate_columns is not none %}
        s.src_hash,
        t.tgt_hash,
        {% endif %}

        CASE
            WHEN t.{{ key_columns[0] }} IS NULL
                THEN 'FAIL - Row missing in foundation for record_order '
                     || s.record_order::VARCHAR
            WHEN t.tgt_is_deleted_flag IS DISTINCT FROM 'Y'
                THEN 'FAIL - tgt_is_deleted_flag is not Y (actual: '
                     || COALESCE(t.tgt_is_deleted_flag, 'NULL') || ')'
            WHEN t.tgt_dml_type_code IS DISTINCT FROM 'D'
                THEN 'FAIL - tgt_dml_type_code is not D (actual: '
                     || COALESCE(t.tgt_dml_type_code, 'NULL') || ')'
            WHEN s.src_effective_from <> t.tgt_effective_from
                THEN 'FAIL - effective_from mismatch (src: '
                     || s.src_effective_from::VARCHAR
                     || ', tgt: ' || t.tgt_effective_from::VARCHAR || ')'
            WHEN s.src_effective_to <> t.tgt_effective_to
                THEN 'FAIL - effective_to mismatch (src: '
                     || s.src_effective_to::VARCHAR
                     || ', tgt: ' || t.tgt_effective_to::VARCHAR || ')'

            {% if validate_columns is not none %}
            WHEN s.src_hash IS DISTINCT FROM t.tgt_hash
                THEN 'FAIL - validate_columns SHA2 mismatch (src_sha2: '
                     || COALESCE(s.src_hash, 'NULL')
                     || ', tgt_sha2: '
                     || COALESCE(t.tgt_hash, 'NULL') || ')'
            {% endif %}

            ELSE 'PASS'
        END                                                              AS row_result

    FROM source_data s
    LEFT JOIN target_data t
        ON  {% for col in key_columns %}
            s.{{ col }} = t.{{ col }}{% if not loop.last %} AND {% endif %}
            {% endfor %}
        AND s.record_order = t.record_order
    WHERE s.scenario = 'DELETE'
),

-- ============================================================
-- CHECK 3 : Late arrival — prior row back-dating
-- When a late-arriving raw row lands between two existing
-- foundation rows, the PRIOR foundation row's effective_to
-- must be back-dated to (late_src_effective_from − 1 µs).
-- Without this check, prior row stays open at 9999-12-31
-- causing an overlap in SCD Type-2 history.
-- Joins on (record_order − 1) to fetch the prior target row.
-- (column check not applicable here — prior row back-dating only)
-- ============================================================
missing_late_check AS (
    SELECT
        {% for col in key_columns %}s.{{ col }}, {% endfor %}
        s.record_order,
        'LATE_PRIOR_ROW_BACKDATE'                                        AS scenario,
        s.src_effective_from,
        s.src_effective_to,
        prev_t.tgt_effective_from,
        prev_t.tgt_effective_to,

        {# ── NULL placeholders to keep UNION ALL column count consistent ── #}
        {% if validate_columns is not none %}
        NULL::VARCHAR                                                     AS src_hash,
        NULL::VARCHAR                                                     AS tgt_hash,
        {% endif %}

        CASE
            WHEN prev_t.{{ key_columns[0] }} IS NULL
                THEN 'FAIL - Prior foundation row not found for record_order '
                     || (s.record_order - 1)::VARCHAR
            WHEN prev_t.tgt_effective_to IS DISTINCT FROM
                 TIMESTAMPADD(MICROSECOND, -1, s.src_effective_from)
                THEN 'FAIL - Prior row not back-dated (exp: '
                     || TIMESTAMPADD(MICROSECOND, -1, s.src_effective_from)::VARCHAR
                     || ', act: ' || prev_t.tgt_effective_to::VARCHAR || ')'
            ELSE 'PASS'
        END                                                              AS row_result

    FROM source_data s
    LEFT JOIN target_data prev_t
        ON  {% for col in key_columns %}
            s.{{ col }} = prev_t.{{ col }}{% if not loop.last %} AND {% endif %}
            {% endfor %}
        AND prev_t.record_order = s.record_order - 1
    WHERE s.is_late_arrival = TRUE
      AND s.scenario <> 'DELETE'
)

-- Return ONLY failing rows so dbt marks test as PASS when 0 rows returned
SELECT * FROM (
    SELECT * FROM insert_update_check
    UNION ALL
    SELECT * FROM delete_check
    UNION ALL
    SELECT * FROM missing_late_check
) all_checks
WHERE row_result <> 'PASS'

ORDER BY
    {% for col in key_columns %}{{ col }}, {% endfor %}
    record_order, scenario

{% endset %}

{{ log("=== Generated SCD2 Raw→Foundation Validation SQL ===", info=True) }}
{{ log(generated_sql,                                          info=True) }}
{{ log("=== End of Generated SQL ===",                         info=True) }}

{% if execute %}
    {% set results    = run_query(generated_sql) %}
    {% set fail_count = results.rows | length %}

    {{ log("[SCD2 Raw→Fnd] Total failing rows : " ~ fail_count, info=True) }}

    {% if fail_count > 0 %}
        {{ log("Connect with data team for refresh", info=True) }}
        {% if raise_error %}
            {{ exceptions.raise_compiler_error(
                "SCD2 Raw→Foundation validation FAILED for "
                ~ target_relation ~ " — "
                ~ fail_count ~ " failing row(s) found in the last "
                ~ look_back ~ " day(s). Check dbt.log for details."
            ) }}
        {% else %}
            {{ log("Warning: validation failed but continuing (raise_error=False).", info=True) }}
        {% endif %}
    {% else %}
        {{ log("SCD2 Raw→Foundation validation PASSED for "
               ~ target_relation
               ~ " (last " ~ look_back ~ " day(s))", info=True) }}
    {% endif %}
{% endif %}

{{ return(generated_sql) }}

{% endmacro %}
