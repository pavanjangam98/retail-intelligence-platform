{% macro generate_json_flatten_uptoarray(model_name, json_column) %}

/*
This macro flattens nested JSON data from a column and dynamically infers
column paths and types, limited to: STRING, NUMBER, and VARIANT.

NULL values are assigned to the dominant non-null type. If only nulls exist,
default to STRING.
*/

{% set get_json_path %}
-- Step 1: Flatten JSON and infer types (excluding nulls from type mapping)
with json_flatten as (
  select
    j.path as json_path,
    j.key as json_key,
    j.value as json_value,

    -- Infer type, ignoring nulls directly
    case
      when typeof(j.value) IN ('ARRAY') then 'VARIANT'
      when typeof(j.value) IN ('INTEGER', 'FLOAT', 'NUMBER') then 'NUMBER'
      when typeof(j.value) IN ('VARCHAR', 'BOOLEAN') then 'STRING'
      else NULL
    end as json_datatype

  from {{ model_name }},
       lateral flatten(input => {{ json_column }}, recursive => true) j

  where typeof(j.value) in (
    'VARCHAR', 'BOOLEAN', 'INTEGER', 'FLOAT', 'NUMBER', 'ARRAY', 'OBJECT', 'NULL_VALUE'
  )
)

-- Step 2: For each path, assign ONE dominant type
select
  json_path,
  concat(json_path, '::',
    coalesce(
      max_by(json_datatype,
        case
          when json_datatype = 'VARIANT' then 3
          when json_datatype = 'STRING' then 2
          when json_datatype = 'NUMBER' then 1
          else 0
        end
      ),
      'STRING'  -- fallback if only nulls
    )
  ) as path_type
from json_flatten
where not contains(json_path, '[')
  --and json_datatype IS NOT NULL
group by json_path
{% endset %}

-- Step 3: Run the query to get path and inferred type
{% set res = run_query(get_json_path) %}
{% if execute %}
    {% set res_list_path = res.columns[0].values() %}  -- json_path
    {% set res_list = res.columns[1].values() %}       -- json_path::inferred_type
{% else %}
    {% set res_list = [] %}
    {% set res_list_path = [] %}
{% endif %}

-- Step 4: Flatten the JSON using inferred paths and types
select
  {{ json_column }},
  {% for json_path_type, json_path in zip(res_list, res_list_path) %}
    {{ json_column }}:{{ json_path_type }} as {{ json_path
      | replace(".", "_")
      | replace("[", "_")
      | replace("]", "")
      | replace("'", "")
    }}{% if not loop.last %},{% endif %}
  {% endfor %}
from {{ model_name }}

{% endmacro %} 