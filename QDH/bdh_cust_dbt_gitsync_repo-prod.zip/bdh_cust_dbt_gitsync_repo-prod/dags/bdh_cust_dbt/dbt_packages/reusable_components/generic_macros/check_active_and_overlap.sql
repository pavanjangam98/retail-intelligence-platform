{% macro check_active_and_overlap(
    model_name,
    pk_columns,
    effective_from_column,
    effective_to_column
) %}

{% set base_sql %}
with base as (
    select
        {{ pk_columns | join(',') }},
        {{ effective_from_column }} as effective_from,
        {{ effective_to_column }} as effective_to
    from {{ ref(model_name) }}
)
{% endset %}


{% set multiple_active_sql %}
select
    {{ pk_columns | join(',') }}
from base
where effective_to = '9999-12-31 00:00:00'
group by {{ pk_columns | join(',') }}
having count(*) > 1
{% endset %}


{% set overlap_sql %}
select
    {{ pk_columns | join(',') }}
from (
    select
        {{ pk_columns | join(',') }},
        effective_from,
        effective_to,

        lag(effective_from)
            over (
                partition by {{ pk_columns | join(',') }}
                order by effective_from
            ) as prev_from,

        lag(effective_to)
            over (
                partition by {{ pk_columns | join(',') }}
                order by effective_from
            ) as prev_to,

        lag(effective_from, 2)
            over (
                partition by {{ pk_columns | join(',') }}
                order by effective_from
            ) as prev2_from,

        lag(effective_to, 2)
            over (
                partition by {{ pk_columns | join(',') }}
                order by effective_from
            ) as prev2_to

    from base
) t
where
    (
        effective_from between prev_from and prev_to
    )
    or
    (
        effective_from between prev2_from and prev2_to
    )
{% endset %}


{# 🔹 Print Base SQL Only Once #}
{% do print("========= BASE SQL =========") %}
{% do print(base_sql) %}

{% do print("========= MULTIPLE ACTIVE SQL =========") %}
{% do print(multiple_active_sql) %}

{% do print("========= OVERLAP SQL =========") %}
{% do print(overlap_sql) %}


{# 🔹 Execute Queries #}
{% set active_results = run_query(base_sql ~ multiple_active_sql) %}
{% set overlap_results = run_query(base_sql ~ overlap_sql) %}

{% set active_count = active_results.rows | length %}
{% set overlap_count = overlap_results.rows | length %}

{% do print("========= RESULTS =========") %}
{% do print("Multiple Active Failures: " ~ active_count) %}
{% do print("Overlap Failures: " ~ overlap_count) %}

{% if active_count > 0 %}
    {% do print("---- Multiple Active Rows ----") %}
    {% for row in active_results.rows %}
        {% do print(row) %}
    {% endfor %}
{% endif %}

{% if overlap_count > 0 %}
    {% do print("---- Overlap Rows ----") %}
    {% for row in overlap_results.rows %}
        {% do print(row) %}
    {% endfor %}
{% endif %}

{% if active_count == 0 and overlap_count == 0 %}
    {% do print(" No issues found. All good!") %}
{% endif %}

{% endmacro %}
