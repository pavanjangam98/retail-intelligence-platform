{% macro source_freshness_check(database, schema, table, error_count_non_prd, error_count_prd, error_period_prd, error_period_non_prd, ingestion_type) %}
   {% set env = target.name | lower %}
   -- Define schema groups here (easy to extend later)
   --{% set kafka_group = ['bis'] %}
   --{% set file_group = ['ibis', 'cg', 'cif'] %}
   -- Schema-based loaded_at_field
   {% if ingestion_type == "kafka" %}
       {% set loaded_at_field = "convert_timezone('Pacific/Auckland','UTC', parse_json(record_content):metadata:time::TIMESTAMP_NTZ)" %}
   {% elif ingestion_type == "non_kafka" %}
       {% set loaded_at_field = "LOAD_DATE::DATE" %}
   {% else %}
       {{ exceptions.raise_compiler_error("Unsupported schema: " ~ schema) }}
   {% endif %}

   -- Soft exit for syst/dev
   {% if env in ['syst', 'dev'] %}
       {% set sql %}
       select case
           when max({{ loaded_at_field }}) >= dateadd({{ error_period_non_prd }}, -{{ error_count_non_prd }}, current_timestamp)
               then 'PASS'
           else 'FAIL'
       end as freshness_status
       from {{ database }}.{{ schema }}.{{ table }}
       {% endset %}
       {% set results = run_query(sql) %}
       {% if execute %}
           {% set status = results.columns[0].values()[0] %}
           {% if status == 'FAIL' %}
               {{ log("Source freshness FAILED - time period " ~ error_count_non_prd ~ " " ~ error_period_non_prd, info=True) }}
           {% else %}
               {{ log("Source freshness check PASS - time period " ~ error_count_non_prd ~ " " ~ error_period_non_prd, info=True) }}
           {% endif %}
       {% endif %}
   -- Hard exit for ppte/prd
   {% elif env in ['ppte','prod'] %}
       {% set sql %}
       select case
           when max({{ loaded_at_field }}) >= dateadd({{ error_period_prd }}, -{{ error_count_prd }}, current_timestamp)
               then 'PASS'
           else 'FAIL'
       end as freshness_status
       from {{ database }}.{{ schema }}.{{ table }}
       {% endset %}
       {% set results = run_query(sql) %}
       {% if execute %}
           {% set status = results.columns[0].values()[0] %}
           {% if status == 'FAIL' %}
               {{ log("Connect with data team for refresh", info=True) }}
               {{ exceptions.raise_compiler_error("Source freshness failed for " ~ database ~ "." ~ schema ~ "." ~ table) }}
           {% else %}
               {{ log("Source freshness PASSED in " ~ env ~ " - time period " ~ error_count_prd ~ " " ~ error_period_prd, info=True) }}
           {% endif %}
       {% endif %}
   {% endif %}
{% endmacro %}
