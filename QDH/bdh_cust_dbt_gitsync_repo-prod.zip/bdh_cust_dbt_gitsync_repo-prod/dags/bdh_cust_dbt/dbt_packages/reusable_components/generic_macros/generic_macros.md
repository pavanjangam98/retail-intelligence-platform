{% docs create_sequence_macro___desc %}

These macros help with automatic surrogate key generation in SCD tables, ensuring that every row inserted gets a unique value without the need to manually handle the sequence. 

{% enddocs %}

{% docs create_sequence_macro___target_tbl %}

This macro uses the target_tbl parameter to dynamically create a sequence name. target_tbl is passed as an argument when calling the macro, which is expected to be the name of the table for which you're creating the sequence.


{% enddocs %}

{% docs apply_tags___desc %}

This Macro is designed to be applied as a posthook at the model or project level to read from the Governance Database and apply the classification tags to the relevant tables. If this does not run correctly Grants need to be checked for the development or service user to have read access to the Governance Database.
This creates 1 Alter Statement per table modifying every column that has a classification record. This will apply every run in case the tags are changed.

{% enddocs %}

{% docs generate_json_flatten_uptoarray___desc %}

This macro can  be useful for dynamically extracting paths to nested JSON elements in a table and flattening them into a simpler structure.
It helps us understand the structure of complex JSON data and could be used in data transformation processes  need to deal with varying or deeply nested JSON data.

{% enddocs %}

{% docs generate_json_flatten_uptoarray___model_name %}

The first argument is the name of the model we are working with.

{% enddocs %}

{% docs generate_json_flatten_uptoarray___json_column %}

The second argument is the name of the column containing JSON data that we want to flatten.

{% enddocs %}

{% docs insert_into_execution_status_log_table___desc %}

This macro is the capture the log related to models, seeds, snapshot execution etc. into 'execution status log' table. in Logging Database.

{% enddocs %}

{% docs insert_into_execution_status_log_table___No_input_args_required %}

Requires no input arguments.

{% enddocs %}


{% docs increment_sequence_macro___desc %}

This macro provide the next val for the records.

{% enddocs %}

{% docs increment_sequence_macro___No_input_args_required %}

Requires no input arguments.

{% enddocs %}


{% docs set_query_tag %}

This macro is designed to dynamically generate and apply a query tag to the current session in your data warehouse (e.g., Snowflake) using dbt. This tag helps with query observability, lineage tracking, debugging, and audit logging by embedding metadata into the query history.

{% enddocs %}

{% docs set_query_tag___No_input_args_required %}

Requires no input arguments.

{% enddocs %}

{% docs custom_check_active_counts_between_raw_and_land_from_date___desc %}

This macro compares active record counts between the raw and land datasets from a specified start date onward. It is used to validate data consistency and completeness during ingestion or ETL processing by checking for discrepancies in active row counts over time.

{% enddocs %}

{% docs custom_check_active_counts_between_raw_and_land_from_date___model %}

The name of the raw dbt model being validated.

{% enddocs %}

{% docs custom_check_active_counts_between_raw_and_land_from_date___model_key_columns %}

The primary key column used to identify distinct records in raw model table. 

{% enddocs %}

{% docs custom_check_active_counts_between_raw_and_land_from_date___source_name %}

Used to reference the schema of landing layer source table.

{% enddocs %}

{% docs custom_check_active_counts_between_raw_and_land_from_date___table_name %}

The name of the source table in landing layer.

{% enddocs %}


{% docs custom_check_active_counts_between_raw_and_land_from_date___compare_key_columns %}

Primary key columns of source table of landing layer.

{% enddocs %}

{% docs custom_check_active_counts_between_raw_and_land_from_date___ingestion_type %}

Specifies the ingestion type, such as 'kafka' and 'non-kafka'.

{% enddocs %}

{% docs custom_check_active_counts_between_raw_and_land_from_date___load_type %}

Defines the load type strategy ('append', 'non-append') used during data ingestion. This affects expectations for record differences. 

{% enddocs %}

{% docs custom_check_active_counts_between_raw_and_land_from_date___look_back %}

The number of days to look back from the current date when comparing records. Helps in narrowing the time window for validation. 

{% enddocs %}

{% docs custom_check_active_counts_between_raw_and_land_from_date___raise_error %}

The macro will raise an error when a mismatch or any discrepency is detected. 

{% enddocs %}

{% docs fdp_custom_check_active_counts_between_models_from_date___desc %}

This macro compares active (non-deleted) record counts between two dbt models from a given start date onward. It's used to validate data consistency across layers or stages by ensuring active row counts align within a defined date range.

{% enddocs %}

{% docs fdp_custom_check_active_counts_between_models_from_date___model %}

The name of the foundation dbt model being validated.

{% enddocs %}

{% docs fdp_custom_check_active_counts_between_models_from_date___compare_model %}

The dbt model from the raw layer used as the baseline for the active count comparison.

{% enddocs %}

{% docs fdp_custom_check_active_counts_between_models_from_date___model_time_col %}

The timestamp column in the foundation model used to filter records for the lookback window.

{% enddocs %}

{% docs fdp_custom_check_active_counts_between_models_from_date___compare_time_col %}

The timestamp column in the raw model used to filter records for the same lookback period.

{% enddocs %}

{% docs fdp_custom_check_active_counts_between_models_from_date___look_back %}

The number of days to look back from the current timestamp for filtering records before comparing counts.

{% enddocs %}

{% docs fdp_custom_check_deleted_counts_between_models_from_date___desc %}

This macro compares deleted record counts between two dbt models — typically from the foundation and raw layers.

{% enddocs %}

{% docs fdp_custom_check_deleted_counts_between_models_from_date___model %}

The dbt model from the foundation layer to validate for deleted record counts.

{% enddocs %}

{% docs fdp_custom_check_deleted_counts_between_models_from_date___compare_model %}

The dbt model from the raw layer used as the baseline for deleted record comparison.

{% enddocs %}

{% docs fdp_custom_check_deleted_counts_between_models_from_date___model_time_col %}

The timestamp column in the foundation model used to filter deleted records within the lookback period.

{% enddocs %}

{% docs fdp_custom_check_deleted_counts_between_models_from_date___compare_time_col %}

The timestamp column in the raw model used to filter deleted records for comparison.

{% enddocs %}

{% docs fdp_custom_check_deleted_counts_between_models_from_date___look_back %}

The number of days to look back from the current timestamp to define the window for deleted record comparison.

{% enddocs %}

{% docs fdp_custom_check_distinct_counts_between_models_from_date___desc %}

This macro compares the count of distinct values for a specified column between two dbt models — usually from the foundation and raw layers — over a defined lookback window. 
It helps identify issues like unexpected duplicates or missing values between layers and raises a compiler error if the distinct counts don't match.

{% enddocs %}

{% docs fdp_custom_check_distinct_counts_between_models_from_date___model %}

The dbt model from the foundation layer to validate for distinct values.

{% enddocs %}

{% docs fdp_custom_check_distinct_counts_between_models_from_date___model_columns %}

Foundation table column Primary keys

{% enddocs %}

{% docs fdp_custom_check_distinct_counts_between_models_from_date___compare_model %}

The dbt model from the raw layer used as the baseline for distinct value comparison.

{% enddocs %}

{% docs fdp_custom_check_distinct_counts_between_models_from_date___compare_columns %}

Raw models primary keys

{% enddocs %}

{% docs fdp_custom_check_distinct_counts_between_models_from_date___compare_time_col %}

DWH Efffective from TS.

{% enddocs %}

{% docs fdp_custom_check_distinct_counts_between_models_from_date___look_back %}

The number of days to look back from the current timestamp when filtering records for distinct value comparison.

{% enddocs %}

{% docs source_freshness_check___desc %}

This macro checks the freshness of a source table by evaluating the maximum ingestion timestamp (loaded_at) against a defined threshold.
It supports both kafka and non_kafka ingestion types, and dynamically adjusts the validation window based on the dbt environment:
- In dev and syst environments, it logs failures without failing the job.
- In ppte and prd, it raises a compiler error on failure.

{% enddocs %}

{% docs source_freshness_check___database %}

The name of the database containing the source table to be checked for freshness.

{% enddocs %}

{% docs source_freshness_check___schema %}

The schema within the database that holds the source table.

{% enddocs %}

{% docs source_freshness_check___table %}

The name of the source table to validate for data freshness.

{% enddocs %}

{% docs source_freshness_check___error_count_non_prd %}

The number of time units (e.g., days or hours) to define the freshness threshold in non-production environments (dev, syst).

{% enddocs %}

{% docs source_freshness_check___error_count_prd %}

The number of time units (e.g., days or hours) to define the freshness threshold in production environments (ppte, prd).

{% enddocs %}

{% docs source_freshness_check___error_period_prd %}

The time unit (e.g., days, hours) used in conjunction with 'error_count_prd' to calculate the freshness window in production environments.

{% enddocs %}

{% docs source_freshness_check___error_period_non_prd %}

The time unit (e.g., days, hours) used in conjunction with 'error_count_non_prd' to calculate the freshness window in non-production environments.

{% enddocs %}

{% docs source_freshness_check___ingestion_type %}

Specifies the ingestion type for the source system. 
Supported values:
- "kafka": Uses metadata timestamp parsed from JSON.
- "non_kafka": Uses the LOAD_DATE column.

{% enddocs %}

{% docs historical_variance_in_file_record_count___desc %}

This macro validates the stability of record counts in a source file by comparing the latest day's record count with the average count over the past 30 days.
It detects unexpected spikes or drops in file volume by checking whether the latest count falls within an allowed variance percentage of the historical average.
Useful for both append-only and replace-style ingestion pipelines.

{% enddocs %}

{% docs historical_variance_in_file_record_count___model %}

The dbt model being analyzed. Typically used for dependency tracking or display.

{% enddocs %}

{% docs historical_variance_in_file_record_count___source_name %}

The name of the source will be pass in Argument.

{% enddocs %}

{% docs historical_variance_in_file_record_count___table_name %}

The name of the table to evaluate.

{% enddocs %}

{% docs historical_variance_in_file_record_count___date_column %}

The column representing the ingestion or load date of the records.
Defaults to 'load_date'. This field is used to calculate the latest file and build the 30-day historical window.

{% enddocs %}

{% docs historical_variance_in_file_record_count___variance_pct %}

The allowed percentage variance (±) between the latest day's record count and the historical average over the past 30 days.
Defaults to 10, meaning ±10% deviation is acceptable.

{% enddocs %}

{% docs historical_variance_in_file_record_count___is_append %}

Boolean flag indicating whether the source data follows an append-only ingestion pattern.
- If True: the macro excludes the earliest file from variance checks (to reduce skew from small files).
- If False: uses all available files within the 30-day range.
Defaults to 'false'.

{% enddocs %}

{% docs historical_variance_of_kafka_record_count___desc %}

This macro checks for variance in Kafka-sourced data volumes over the past 30 days by comparing the latest day's deduplicated record count (based on primary keys) against the historical daily average.

{% enddocs %}

{% docs historical_variance_of_kafka_record_count___model %}

The dbt model invoking this macro. Primarily used for dependency tracking or reference in logs.

{% enddocs %}

{% docs historical_variance_of_kafka_record_count___source_name %}

The source name will be pass in argument (used with the source() Jinja function) pointing to the Kafka stream or raw table.

{% enddocs %}

{% docs historical_variance_of_kafka_record_count___table_name %}

The name of the table containing the raw streaming records.

{% enddocs %}

{% docs historical_variance_of_kafka_record_count___primary_key %}

The primary key used to deduplicate Kafka records.  
 
{% enddocs %}

{% docs historical_variance_of_kafka_record_count___date_column %}

The timestamp column used to determine the load date of each Kafka record.

{% enddocs %}

{% docs historical_variance_of_kafka_record_count___variance_pct %}

The allowed variance percentage (±) between the latest day's deduplicated record count and the 30-day historical average.
Defaults to '10', allowing up to ±10% deviation before triggering a warning.

{% enddocs %}

{% docs refresh_external_table___desc %}

This macro is used to refresh the external tables

{% enddocs %}

{% docs refresh_external_table___schema_name %}

Schema of the external table.

{% enddocs %}

{% docs refresh_external_table___table_name %}

table name of the external table.

{% enddocs %}

{% docs refresh_external_table___database_name %}

Database name of the external table.

{% enddocs %}
