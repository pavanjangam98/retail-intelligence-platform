{% macro scm_apply_tags(db_name=none, schema_name=none, table_name=none, since_date=none) %}
    {% if db_name is none %}
        {% set this_db_name     = this.database   | upper %}
        {% set this_schema_name = this.schema     | upper %}
        {% set this_table_name  = this.identifier | upper %}
    {% else %}
        {% set this_db_name     = db_name     | upper %}
        {% set this_schema_name = schema_name | upper %}
        {% set this_table_name  = table_name  | upper %}
    {% endif %}

    {% set src_classification_view = source('scmclassification','CLASSIFICATION_ACTIVE') | upper %}
    {% set _tags_db           = source('scmtags','TAGS').database | upper | trim %}
    {% set _tags_sch          = source('scmtags','TAGS').schema   | upper | trim %}
    {% set src_tagging_schema = _tags_db ~ '.' ~ _tags_sch %}

    {% set bdh_isairflow = env_var('IS_AIRFLOW') %}
    {% set bdh_zone      = var('DBT_BDH_ZONE') | upper | trim %}
    {% set environment   = target.name | upper %}
    
    {# STEP 0: resolve target db / schema / table names  #}
   
    {% if bdh_isairflow.lower() == "false"
          and this_db_name | length > 0
          and this_table_name.split('___') | length > 2 %}
        {% set tgt_db_name     = bdh_zone ~ '__' ~ this_table_name.split('___')[0] %}
        {% set tgt_schema_name = this_table_name.split('___')[1] %}
        {% set tgt_table_name  = this_table_name.split('___')[2] %}
    {% elif this_db_name | length > 0 and this_db_name.split('__') | length > 1 %}
        {% set tgt_db_name     =  bdh_zone ~ '__' ~ this_db_name.split('__')[1] %}
        {% set tgt_schema_name = this_schema_name %}
        {% set tgt_table_name  = this_table_name %}
    {% else %}
        {% set tgt_db_name     = this_db_name %}
        {% set tgt_schema_name = this_schema_name %}
        {% set tgt_table_name  = this_table_name %}
    {% endif %}

   
    {% set targetdb_name = tgt_db_name ~ '__' ~ environment %}    
    
    {% if 'TRANSFORM' in this_db_name | upper %}
        {% if execute %}
            {{ log("apply_tags: target DB is a TRANSFORM layer (" ~ targetdb_name ~ ") - tags not applicable, skipping.", info=true) }}
        {% endif %}
    {% else %}  
    {% set info_columns = targetdb_name ~ '.information_schema.columns' %}
    {% set info_tables  = targetdb_name ~ '.information_schema.tables'  %}
    {% set out_str  = 'ALTER TABLE ' ~ targetdb_name ~ '.' ~ tgt_schema_name ~ '.' ~ tgt_table_name ~ ' MODIFY ' %}
    {% set mod_strs = [] %}
   
    {# STEP 1: confirm the table exists in the TARGET database    #}
   
    {% set table_exists_query %}
        SELECT 1
        FROM   {{ info_tables }}
        WHERE  UPPER(table_catalog) = UPPER('{{ targetdb_name }}')
          AND  UPPER(table_schema)  = UPPER('{{ tgt_schema_name }}')
          AND  UPPER(table_name)    = UPPER('{{ tgt_table_name }}')
    {% endset %}
    {% set table_meta = run_query(table_exists_query) %}

    {% if table_meta | length == 0 %}
        {% if execute %}
            {{ log("apply_tags [" ~ targetdb_name ~ "." ~ tgt_schema_name ~ "." ~ tgt_table_name ~ "]: not found in INFORMATION_SCHEMA — skipping.", info=true) }}
        {% endif %}

    {% else %}
        {% if execute %}
            {{ log("apply_tags: table confirmed — " ~ targetdb_name ~ "." ~ tgt_schema_name ~ "." ~ tgt_table_name, info=true) }}
        {% endif %}
     
        {# STEP 2: query CLASSIFICATION_ACTIVE                                #}
        {# Join to information_schema ensures column physically exists        #}
     
        {% set query %}
            SELECT
                 UPPER(trim(C.column_name))     AS column_name
                ,C.security_classification_code
                ,C.business_key_flag
                ,C.primary_key_flag
                ,C.dwh_change_type
                ,C.dwh_effective_from_tstamp
                ,C.dwh_process_tstamp
            FROM {{ src_classification_view }} C
            LEFT JOIN {{ info_columns }} I
                ON  UPPER(trim(C.column_name))      = UPPER(I.column_name)
                AND UPPER('{{ tgt_table_name }}')   = UPPER(I.table_name)
                AND UPPER('{{ tgt_schema_name }}')  = UPPER(I.table_schema)
            WHERE
                UPPER(trim(C.table_name))  = UPPER('{{ tgt_table_name }}')
                AND UPPER(trim(C.schema_name)) = UPPER('{{ tgt_schema_name }}')
                AND UPPER(trim(C.db_name))     = UPPER('{{ tgt_db_name }}')
                AND I.column_name IS NOT NULL
                {% if since_date is not none %}
                AND C.dwh_process_tstamp >= '{{ since_date }}'::timestamp
                {% endif %}
        {% endset %}
        {% set src_classification = run_query(query) %}

        {% if src_classification | length == 0 %}
            {% if execute %}
                {{ log("apply_tags: no classifications found for " ~ tgt_table_name ~ " — skipping.", info=true) }}
            {% endif %}
        {% else %}
            {% if execute %}
                {% set classification_list = src_classification.rows %}
                {% set column_list         = src_classification.column_names %}
              
                {# STEP 3: fetch existing tag values already applied in        #}
                {#         Snowflake so we only ALTER what actually changed    #}               
                {# Run 1 → tag not in Snowflake           -> SET TAG (fresh apply)     #}
                {# Run 2 → tag matches classification     -> SKIP   (no change)        #}
                {# Run N → tag differs from classification -> SET TAG (value changed)  #} 
                
                {% set existing_tags_query %}
                    SELECT
                         UPPER(COLUMN_NAME) AS column_name
                        ,TAG_NAME
                        ,TAG_VALUE
                        ,TAG_DATABASE
                        ,TAG_SCHEMA
                    FROM TABLE(
                        {{ targetdb_name }}.information_schema.TAG_REFERENCES_ALL_COLUMNS(
                            '{{ targetdb_name }}.{{ tgt_schema_name }}.{{ tgt_table_name }}',
                            'table'
                        )
                    )
                    WHERE TAG_NAME IN ('BUSINESS_KEY_FLAG','PRIMARY_KEY_FLAG','SECURITY_CLASSIFICATION_CODE')
                {% endset %}
                {% set existing_tags_result = run_query(existing_tags_query) %}
                {% set existing_tags = {} %}

                {% if existing_tags_result | length > 0 %}
                    {% for row in existing_tags_result.rows %}
                        {% set col      = row[0] | upper | trim %}
                        {% set tag_name = row[1] | upper | trim %}
                        {% set tag_db   = row[3] | upper | trim %}
                        {% set tag_sch  = row[4] | upper | trim %}
                        {% set tag_full = tag_db ~ '.' ~ tag_sch ~ '.' ~ tag_name %}
                        {% if col not in existing_tags %}
                            {% do existing_tags.update({ col: {} }) %}
                        {% endif %}
                        {% do existing_tags[col].update({ tag_full: row[2] }) %}
                    {% endfor %}
                    {{ log("apply_tags: loaded existing tags for " ~ (existing_tags.keys() | list | length) ~ " column(s).", info=true) }}
                {% else %}
                    {{ log("apply_tags: no existing tags in Snowflake — all tags will be applied fresh.", info=true) }}
                {% endif %}

                
                {# STEP 4: compare classification vs Snowflake,               #}
                {#         build ALTER clauses only for changed values         #}
                
                {% for classification in classification_list %}
                    {% set tag_strs = [] %}
                    {% set ns = namespace(col_name='') %}

                    {% for i in range(column_list | length) %}
                        {% if column_list[i] == 'COLUMN_NAME' %}
                            {% set ns.col_name = classification[i] | upper %}
                        {% endif %}
                    {% endfor %}

                    {% for i in range(column_list | length) %}
                        {% if column_list[i] not in (
                            'COLUMN_NAME', 'DWH_CHANGE_TYPE',
                            'DWH_EFFECTIVE_FROM_TSTAMP', 'DWH_PROCESS_TSTAMP'
                        ) %}
                            {% set tag_full_name = (_tags_db ~ '.' ~ _tags_sch ~ '.' ~ column_list[i]) | upper | trim %}
                            {% set new_val       = classification[i] | string %}
                            {% set current_val   = '' %}

                            {% if ns.col_name in existing_tags and tag_full_name in existing_tags[ns.col_name] %}
                                {% set current_val = existing_tags[ns.col_name][tag_full_name] | string %}
                            {% endif %}

                            {% if current_val != new_val %}
                                {{ log("apply_tags: CHANGED   - " ~ tgt_table_name ~ "." ~ ns.col_name ~ "." ~ column_list[i] ~ " [" ~ current_val ~ "] -> [" ~ new_val ~ "]", info=true) }}
                                {% do tag_strs.append(
                                    ' ' ~ src_tagging_schema ~ '.' ~ column_list[i] ~ ' = "' ~ new_val ~ '"'
                                ) %}
                            {% else %}
                                {{ log("apply_tags: UNCHANGED - " ~ tgt_table_name ~ "." ~ ns.col_name ~ "." ~ column_list[i] ~ " = [" ~ current_val ~ "] - skipping.", info=true) }}
                            {% endif %}
                        {% endif %}
                    {% endfor %}

                    {% if tag_strs | length > 0 %}
                        {% do mod_strs.append(
                            'COLUMN ' ~ ns.col_name ~ ' SET TAG ' ~ tag_strs | join(', ')
                        ) %}
                    {% endif %}
                {% endfor %}

            {% endif %} {# end execute #}

            
            {# STEP 5: execute ALTER only if at least one tag value changed     #}
            {# run-operation mode (db_name passed) -> execute directly          #}
            {# post-hook mode    (db_name is none) -> return SQL for dbt        #}
           
            {% if mod_strs | length > 0 %}
                {% set alter_sql = out_str ~ mod_strs | join(', ') %}
                {% if db_name is not none %}
                    {% do run_query(alter_sql) %}
                    {{ log("apply_tags: ALTER executed (run-operation) for " ~ tgt_table_name ~ ".", info=true) }}
                {% else %}
                    {{ alter_sql }}
                    {{ log("apply_tags: ALTER returned (post-hook) for " ~ tgt_table_name ~ ".", info=true) }}
                {% endif %}
            {% else %}
                {{ log("apply_tags: all tags match Snowflake - no ALTER needed for " ~ tgt_table_name ~ ".", info=true) }}
            {% endif %}

        {% endif %} {# end classification check #}
    {% endif %} {# end table exists check #}
    {% endif %} {# end TRANSFORM layer check #}
{% endmacro %}
 
