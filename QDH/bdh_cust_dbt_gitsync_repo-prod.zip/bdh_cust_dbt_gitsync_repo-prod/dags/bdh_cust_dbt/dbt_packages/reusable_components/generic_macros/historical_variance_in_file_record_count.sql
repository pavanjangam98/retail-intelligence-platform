{% macro historical_variance_in_file_record_count(model,source_name,table_name,date_column='load_date',variance_pct=10,is_append=false) %}
    
    {% set src_tble = source(source_name, table_name) %}

    {% set max_date_query %}
        SELECT MAX({{ date_column }}) AS max_date FROM {{ src_tble }}
    {% endset %}

    {{ log("max_date_query: " ~ max_date_query, info=True) }}

    {% set max_date_result = run_query(max_date_query) %}
    {% set latest_date = max_date_result.columns[0].values()[0] %}
    {{ log("Latest available load_date: " ~ latest_date, info=True) }}

    {% if latest_date is none %}
        {{ log("No data in source table Or No file to evaluate.", info=True) }}
        {{ exceptions.raise_compiler_error("No data in source table Or No file to evaluate.") }}
    {% else %}
        -- Count distinct load dates in last 30 days
        {% set load_date_count_query %}
            SELECT case when max(load_date)=min(load_date) then null else min(load_date) end as hist_load_date
            FROM {{ src_tble }}
            WHERE {{ date_column }} > (DATE('{{ latest_date }}') - INTERVAL '30 days')
        {% endset %}
  {{ log("load_date_count_query" ~ load_date_count_query, info=True) }}
        {% set load_date_count_result = run_query(load_date_count_query) %}
  {% set hist_load_date = load_date_count_result.columns[0].values()[0] %}
        {{ log("Distinct load_dates in past 30 days: " ~ load_date_count, info=True) }}
  {{ log("hist_load_date: " ~ hist_load_date, info=True) }}

        {% if hist_load_date is none %}
              {{ log("Only one load_date present in the past 30 days. Skipping variance check.", info=True) }}
            SELECT 0 AS test_result WHERE 1=2 -- soft-pass
        {% else %}
            -- Get today's (latest) record count
            {% set latest_date_count_query %}
                SELECT COUNT(*) as record_count 
                FROM {{ src_tble }} 
                WHERE {{ date_column }} = DATE('{{ latest_date }}')
            {% endset %}
            {{ log("Latest Date count query: " ~ latest_date_count_query, info=True) }}
            {% if execute %}
                {% set latest_date_count_result = run_query(latest_date_count_query) %}
            {% else %}
                {% set latest_date_count_result = none %}
            {% endif %}

            {% if latest_date_count_result is none %}
                {{ log("run_query() returned None for latest_date_count_query", info=True) }}
    {{ exceptions.raise_compiler_error("Null returned for count from source table for the latest date.") }}
            {% else %}
                {% set latest_date_count = latest_date_count_result.columns[0].values()[0] | int %}
                {{ log("Latest date record count: " ~ latest_date_count, info=True) }}

                {% if latest_date_count == 0 %}
                    {{ log("No file received for latest date (record count = 0).", info=True) }}
     {{ exceptions.raise_compiler_error("No data in source table to evaluate for the latest date.") }}
                {% else %}
                    -- Get last 30 days of historical data (excluding latest date)
                    {% set earliest_date_query %}
                        SELECT MIN({{ date_column }}) AS earliest_date
                        FROM {{ src_tble }}
                        WHERE {{ date_column }} < DATE('{{ latest_date }}')
                          AND {{ date_column }} >= DATE('{{ latest_date }}') - INTERVAL '30 days'
                    {% endset %}
                    {% set earliest_date_result = run_query(earliest_date_query) %}
                    {% set earliest_date = earliest_date_result.columns[0].values()[0] %}
                    {{ log("Earliest load_date in past 30 days: " ~ earliest_date, info=True) }}
 
                    -- Build history query based on append mode
                    {% if is_append %}
                        {{ log("Table is in append mode. Removing earliest file from variance check.", info=True) }}
                        {% set history_query %}
                            SELECT COUNT(*) AS record_count, {{ date_column }}
                            FROM {{ src_tble }}
                            WHERE {{ date_column }} < DATE('{{ latest_date }}')
                              AND {{ date_column }} > DATE('{{ earliest_date }}') -- skip earliest file
                            GROUP BY {{ date_column }}
                        {% endset %}
                    {% else %}
                        {% set history_query %}
                            SELECT COUNT(*) AS record_count, {{ date_column }}
                            FROM {{ src_tble }}
                            WHERE {{ date_column }} < DATE('{{ latest_date }}')
                              AND {{ date_column }} >= DATE('{{ latest_date }}') - INTERVAL '30 days'
                            GROUP BY {{ date_column }}
                        {% endset %}
                    {% endif %}
                    {{ log("History query: " ~ history_query, info=True) }}
                    {% set history_result = run_query(history_query) %}
                    {% if history_result is none %}
                        {{ log("run_query() returned None for history_query", info=True) }}
      {{ exceptions.raise_compiler_error("Null returned for history data count from source table.") }}
                    {% else %}
                        {% set total_days = history_result.rows | length %}
                        {% set total_records = history_result.columns[0].values() | sum %}
                        {{ log("Total historical days with data: " ~ total_days, info=True) }}
                        {{ log("Total historical record count: " ~ total_records, info=True) }}

                        {% if total_days == 0 %}
                            {{ log("No historical data available to calculate average.", info=True) }}
       {{ exceptions.raise_compiler_error("No History data available in  source table.") }}
                        {% else %}
                            {% set average_count = (total_records / total_days) %}
                            {% set variance_row_count = (average_count * (variance_pct / 100.0))| round(2) %}
                            {% set lower_bound_row_count = (average_count - variance_row_count) %}
                            {% set upper_bound_row_count = (average_count + variance_row_count) %}
                            {% set variance_allowed_percentage = (((variance_row_count)/average_count) * 100) | round(2) %}
                            {% set variance_observed_percentage = (((latest_date_count - average_count)/average_count) * 100) | round(0, 'ceil') %}

                            {{ log("Average historical count: " ~ average_count, info=True) }}
                            {{ log("Variance percent: ±" ~ variance_pct ~ "%", info=True) }}
                            {{ log("Variance row count: " ~ variance_row_count, info=True) }}
                            {{ log("Lower bound: " ~ lower_bound_row_count, info=True) }}
                            {{ log("Upper bound: " ~ upper_bound_row_count, info=True) }}
                            {{ log("Variance allowed percentage: ±" ~ variance_allowed_percentage ~ "%", info=True) }}
                            {{ log("Variance observed percentage: " ~ variance_observed_percentage ~ "%", info=True) }}

                            {% if latest_date_count < lower_bound_row_count or latest_date_count > upper_bound_row_count %}
                                {{ log("Latest date count is outside the acceptable variance range.", info=True) }}
                                SELECT 1 AS test_result -- Fail
        {{ log("Warning:Latest day count is outside the acceptable variance range..",info=True) }}
        {% do log("Warning:" ~ 'Latest day count is outside the acceptable variance range. Variance allowed percentage: ±' ~ variance_allowed_percentage ~'%,Variance observed percentage: ' ~ variance_observed_percentage ~ '%', info=True) %}
                            {% else %}
                                {{ log("Latest Date count is within acceptable variance range.", info=True) }}
                                SELECT 0 AS test_result WHERE 1=2 -- Success
                            {% endif %}
                        {% endif %}
                    {% endif %}
                {% endif %}
            {% endif %}
        {% endif %}
    {% endif %}
{% endmacro %} 