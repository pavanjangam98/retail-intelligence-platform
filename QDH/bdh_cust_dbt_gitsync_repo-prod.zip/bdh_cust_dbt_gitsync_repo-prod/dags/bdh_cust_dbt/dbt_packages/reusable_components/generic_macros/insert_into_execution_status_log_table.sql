{% macro insert_into_execution_status_log_table() %}
{%- set bdh_isairflow = env_var('IS_AIRFLOW') | lower -%}
{%- if bdh_isairflow =="false" -%}
    {# Fetch the database, environment, and schema from the target (i.e., .profile.yml or connection config) #}
    {% set database_name = target.database.lower() %}
    {% set environment =  target.name.lower() %}
    {% set schema_name = target.schema.lower() %}
    {% set db_value = database_name ~ '.' ~ schema_name %}
{%- else -%}
    {# Fetch the database, environment, and schema from dbt variables defined in dbt_project.yml #}
    {% set database_name = var('DBT_DATABASE').lower() %}
    {% set environment =  target.name.lower() %}
    {% set schema_name =  var('DBT_SCHEMA').lower() %}
    {# Concatenate the three variables into a single string #}
    {% set db_value = database_name ~ '__' ~ environment ~ '.' ~ schema_name %}
{%- endif -%}

{% if execute %}
{# Get the records that need to be updated this is full table,view count #}
{% set get_tables_query %}
WITH tablecte AS( 
    select
        command_invocation_id,
        node_id,
        (iff({{ env_var('IS_AIRFLOW') }} = 'false', '{{ database_name }}', '{{ var("DBT_BDH_ZONE") }}__' || SPLIT_PART(name, '___', 1) || '__' || lower('{{ target.name }}')) || '.' ||
        iff({{ bdh_isairflow }} = 'false', lower(schema), lower(split_part(node_id,'___',2))) || '.' ||
        case when {{ bdh_isairflow }} = 'false' then name else
            case when node_id like 'model.%' then split_part(node_id,'___',3) end
        end) as full_table_name,
        rows_affected,
        materialization,
        name,
        schema
    FROM {{ ref('dbt_artifacts', 'model_executions') }} 
    WHERE materialization in('table','view') 
    AND status = 'success' 
    AND rows_affected = 1
    AND command_invocation_id = '{{ invocation_id }}'
)
SELECT 
    command_invocation_id,
    node_id,
    full_table_name,
    materialization
FROM tablecte
{% endset %}

{# Execute the query to get the table information #}
{% set results = run_query(get_tables_query) %}

{# Loop through each result and execute individual updates #}
{% if results %}
    {% for row in results %}
        {% set cmd_invocation_id = row[0] %}
        {% set node_id = row[1] %}
        {% set full_table_name = row[2] %}
        {% set materialization = row[3] %}
        {# Get the count from the target table #}        
        {% if materialization == 'view' %}
            {% set count_query %}
                SELECT COUNT(*) as row_count 
                FROM {{ full_table_name }}                
            {% endset %}
        {% else %}
            {% set count_query %}
                SELECT COUNT(*) as row_count 
                FROM {{ full_table_name }} 
                --WHERE DWH_PROCESS_INSERT_ID = '{{ invocation_id }}' || '.' || '{{ node_id }}'
            {% endset %}
        {% endif %}

        {% set count_result = run_query(count_query) %}
        {% if count_result %}
            {% set actual_count = count_result[0][0] %}

            {# Now execute the update with the actual full record count only ..No delta #}
            {% set update_query %}
                UPDATE {{ ref('dbt_artifacts', 'model_executions') }} 
                SET rows_affected = {{ actual_count }}
                WHERE command_invocation_id = '{{ cmd_invocation_id }}' 
                AND materialization in('table','view') 
                AND node_id = '{{ node_id }}'
            {% endset %}

            {# Execute the update #}
            {% do run_query(update_query) %}
            {{ log("Updated rows_affected to " ~ actual_count ~ " for node_id: " ~ node_id, info=true) }}
        {% endif %}
    {% endfor %}
{% endif %}
{% endif %}

{# Use the concatenated value in your SQL query #}
merge into {{ db_value }}.EXECUTION_STATUS_LOG as target
using (
    with model_runs as (
        select * from {{ ref('dbt_artifacts', 'model_executions') }}
    ),
    snapshot_runs as (
        select * from {{ ref('dbt_artifacts', 'snapshot_executions') }}
    ),
    seed_runs as (
        select * from {{ ref('dbt_artifacts', 'seed_executions') }}
    ),
    test_runs as (
         select * from {{ ref('dbt_artifacts', 'test_executions')}}
    ),
    tests as (
         select * from {{ ref('dbt_artifacts', 'tests')}}
    ),
test_excn as (select A.*,
--SPLIT_PART(A.node_id, '.', 3)  AS Test_name,
all_results:schema as schema_nm, SPLIT_PART(all_results:attached_node,'.',3) AS table_nm, SPLIT_PART(all_results:attached_node,'___',3) as table_nm_flag_true
from test_runs A
inner join tests B
on a.COMMAND_INVOCATION_ID = b.command_invocation_id
and SPLIT_PART(A.node_id, '.', 3)  =b.name)
,
    node_runs as (
    SELECT COMMAND_INVOCATION_ID, NODE_ID, RUN_STARTED_AT, WAS_FULL_REFRESH, THREAD_ID, STATUS, COMPILE_STARTED_AT, query_completed_at, TOTAL_NODE_RUNTIME, ROWS_AFFECTED, MATERIALIZATION, SCHEMA, NAME, ALIAS, NULL AS FAILURES, MESSAGE, ADAPTER_RESPONSE, NULL AS table_nm_flag_true
    FROM model_runs
    UNION
    SELECT COMMAND_INVOCATION_ID, NODE_ID, RUN_STARTED_AT, WAS_FULL_REFRESH, THREAD_ID, STATUS, COMPILE_STARTED_AT, query_completed_at, TOTAL_NODE_RUNTIME, ROWS_AFFECTED, MATERIALIZATION, SCHEMA, NAME, ALIAS, NULL AS FAILURES, MESSAGE, ADAPTER_RESPONSE, NULL AS table_nm_flag_true
    FROM snapshot_runs
    UNION
    SELECT COMMAND_INVOCATION_ID, NODE_ID, RUN_STARTED_AT, WAS_FULL_REFRESH, THREAD_ID, STATUS, COMPILE_STARTED_AT, query_completed_at, TOTAL_NODE_RUNTIME, ROWS_AFFECTED, MATERIALIZATION, SCHEMA, NAME, ALIAS, NULL AS FAILURES, MESSAGE, ADAPTER_RESPONSE, NULL AS table_nm_flag_true
    FROM seed_runs
    UNION
    SELECT COMMAND_INVOCATION_ID, NODE_ID, RUN_STARTED_AT, WAS_FULL_REFRESH, THREAD_ID, STATUS, COMPILE_STARTED_AT, query_completed_at, TOTAL_NODE_RUNTIME, ROWS_AFFECTED, NULL AS MATERIALIZATION, schema_nm AS SCHEMA, table_nm AS NAME, NULL AS ALIAS, FAILURES, MESSAGE, ADAPTER_RESPONSE, table_nm_flag_true
    FROM test_excn
    )
    select
        nr.command_invocation_id as invocation_id,
        nr.node_id,
        '{{ var('DBT_BDH_ZONE') }}' as zone,
        iff({{env_var('IS_AIRFLOW') }}= 'false', '{{ database_name }}', '{{ var("DBT_BDH_ZONE") }}__' || SPLIT_PART(nr.NAME, '___', 1) || '__' || lower('{{ target.name }}')) as database_name,
        iff({{bdh_isairflow}}= 'false', lower(nr.schema), lower(split_part(node_id,'___',2))) as schema_name,
        case when {{bdh_isairflow}} ='false' then nr.name else
    (case when node_id like 'model.%' then split_part(node_id,'___',3)
            when node_id like 'test.%' then table_nm_flag_true
            when  node_id like 'snapshot.%' then split_part(node_id,'___',3) end) end as table_name,
        CASE SPLIT_PART(nr.node_id, '.', 1)
        WHEN 'model' THEN NR.NAME
        WHEN 'test' THEN SPLIT_PART(nr.node_id, '.', 3)
        WHEN 'snapshot' THEN NR.NODE_ID
        WHEN 'seed' THEN NR.NODE_ID
        ELSE 'Unknown Job Name' END as JOB_NAME,
        CASE SPLIT_PART(nr.node_id, '.', 1)
        WHEN 'model' THEN 'Model'
        WHEN 'test' THEN 'Test'
        WHEN 'snapshot' THEN 'Snapshot'
        WHEN 'seed' THEN 'Seed'
        ELSE 'Unknown Job Type'
        END AS JOB_TYPE,
        nr.run_started_at,
        nr.status,
        nr.compile_started_at,
        nr.query_completed_at as run_end_at,
        round(nr.total_node_runtime, 2) as refresh_runtime_seconds,
        nr.was_full_refresh,
        decode(nr.materialization, 'snapshot', 'table', 'incremental', 'table', nr.materialization) as object_type,
        --iff(object_type = 'view', null, nr.rows_affected) as refresh_rows_affected, 
        nr.rows_affected as refresh_rows_affected,  
        CASE
            WHEN lower(nr.message) LIKE '%success%' OR lower(nr.message) = 'none' THEN 'Succeeded'
            ELSE nr.message
            END AS message,
        '{{ target.user }}' as executed_by,
        current_timestamp as bdh_record_insert_timestamp
    from node_runs as nr
) as source
on target.invocation_id = source.invocation_id
and target.job_name = source.job_name
when not matched then
insert (
    invocation_id, zone, database_name, schema_name, table_name, job_name, Job_type, run_started_at, status, compile_started_at, run_end_at,
    refresh_runtime_seconds, was_full_refresh,
    message,refresh_rows_affected, executed_by, bdh_record_insert_timestamp
)
values (
    source.invocation_id, source.zone, source.database_name, source.schema_name, source.table_name, source.job_name, source.Job_type, source.run_started_at, source.status,
    source.compile_started_at, source.run_end_at, source.refresh_runtime_seconds, source.was_full_refresh,
    source.message,source.refresh_rows_affected, source.executed_by, source.bdh_record_insert_timestamp
);
{% endmacro %}
