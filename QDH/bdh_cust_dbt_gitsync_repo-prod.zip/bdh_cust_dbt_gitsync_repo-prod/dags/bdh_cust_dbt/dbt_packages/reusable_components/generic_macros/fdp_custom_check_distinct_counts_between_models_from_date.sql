{% macro fdp_custom_check_distinct_counts_between_models_from_date(
    model,
    model_columns,
    compare_model,
    compare_columns,
    compare_time_col,
    look_back
) %}

-- force dbt to register the dependency on compare_model
-- depends_on: {{ ref(compare_model) }}

{% set query %}
    select current_timestamp as current_tstamp
{% endset %}

{% set result = run_query(query) %}
{% set current_tstamp = result.columns[0].values()[0] %}

{% set compare_relation = ref(compare_model) %}

{% set model_count_sql %}
    select count(*) as model_count from (
        select {% for col in model_columns %}
            {{ col }}{% if not loop.last %}, {% endif %}
        {% endfor %}, count(*) as cnt
        from {{ ref(model) }}
        where {{ compare_time_col }} >= dateadd(day, -{{ look_back }}, to_timestamp('{{ current_tstamp }}'
 ))
        group by {% for col in model_columns %}
            {{ col }}{% if not loop.last %}, {% endif %}
        {% endfor %}
    )
{% endset %}

{% set compare_model_count_sql %}
    select count(*) as compare_count from (
        select {% for col in compare_columns %}
            {{ col }}{% if not loop.last %}, {% endif %}
        {% endfor %}, count(*) as cnt
        from {{ compare_relation }}
        where {{ compare_time_col }} >= dateadd(day, -{{ look_back }}, to_timestamp('{{ current_tstamp }}'
 ))
        group by {% for col in compare_columns %}
            {{ col }}{% if not loop.last %}, {% endif %}
        {% endfor %}
    )
{% endset %}

{{ log("model_count_sql: " ~ model_count_sql, info=True) }}
{{ log("compare_model_count_sql: " ~ compare_model_count_sql, info=True) }}

{% set model_count_result = run_query(model_count_sql) %}
{% set compare_count_result = run_query(compare_model_count_sql) %}

{{ log("model_count_result: " ~ model_count_result, info=True) }}
{{ log("compare_count_result: " ~ compare_count_result, info=True) }}

{% set model_count_val = model_count_result.columns[0].values()[0] %}
{% set compare_count_val = compare_count_result.columns[0].values()[0] %}

{{ log("model_count_val: " ~ model_count_val, info=True) }}
{{ log("compare_count_val: " ~ compare_count_val, info=True) }}

{% if model_count_val != compare_count_val %}
    {{ log("Distinct count not matching: model count = " ~ model_count_val ~ ", compare model count = " ~ compare_count_val, info=True) }}
    {{ exceptions.raise_compiler_error("Distinct count mismatch detected: model count (" ~ model_count_val|string ~ ") does not equal compare model count (" ~ compare_count_val|string ~ ").") }}
{% else %}
    {{ log("Distinct count matching: model count = " ~ model_count_val ~ ", compare model count = " ~ compare_count_val, info=True) }}
{% endif %}

{% endmacro %}
