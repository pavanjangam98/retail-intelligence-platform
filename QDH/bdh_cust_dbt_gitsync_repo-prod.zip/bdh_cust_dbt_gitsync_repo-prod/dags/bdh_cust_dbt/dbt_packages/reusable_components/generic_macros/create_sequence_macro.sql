/*
  Creates a surrogative key for SCD Tables
 
  Usage: create_sequence_macro
        : increment_sequence  
*/

/* 
These macros help with automatic surrogate key generation in SCD tables, ensuring that every row inserted gets a unique value without the need to manually handle the sequence.

*/ 
{%- macro create_sequence_macro(target_tbl) -%}

 /* 
 This macro creates a sequence in the database if it doesn't already exist. It uses the target_tbl parameter to dynamically create a sequence name.
  target_tbl is passed as an argument when calling the macro, which is expected to be the name of the table for which you're creating the sequence.
 */
create sequence if not exists {{ target_tbl }}_SEQ;
 
{%- endmacro -%}

/* 
This macro is used to get the next value from a sequence, typically for generating new surrogate keys or IDs for a table.
The {{ this }}_SEQ.nextval expression fetches the next value from a sequence dynamically.
*/

{%- macro increment_sequence_macro() -%}
 
  {{ this }}_SEQ.nextval
 
{%- endmacro -%}