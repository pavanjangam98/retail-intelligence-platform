{% macro rename_column(database_name, schema_name, table_name, old_column_name, new_column_name) %}
 
    {% if execute %}
        {% set relation = adapter.get_relation(
            database=database_name,
            schema=schema_name,
            identifier=table_name
        ) %}
 
        {% if relation is not none %}
            {% do log(
                "Renaming column "
                ~ old_column_name ~ " to " ~ new_column_name
                ~ " in table: "
                ~ database_name ~ "." ~ schema_name ~ "." ~ table_name,
                info=True
            ) %}
 
            {% do run_query(
                "alter table "
                ~ database_name ~ "." ~ schema_name ~ "." ~ table_name
                ~ " rename column "
                ~ old_column_name
                ~ " to "
                ~ new_column_name
            ) %}
        {% else %}
            {% do log(
                "Table does not exist: "
                ~ database_name ~ "." ~ schema_name ~ "." ~ table_name,
                info=True
            ) %}
        {% endif %}
    {% endif %}
 
{% endmacro %}
 
 