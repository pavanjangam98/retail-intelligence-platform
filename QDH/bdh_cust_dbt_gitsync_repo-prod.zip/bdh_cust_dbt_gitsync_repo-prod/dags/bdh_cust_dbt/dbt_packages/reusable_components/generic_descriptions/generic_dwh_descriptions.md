{% docs dwh_source_system_code %} 

Identifies the source system that originated the record. This will be the source system abbreviation that has been defined.

{% enddocs %}

{% docs dwh_latest_dml_type_code %} 

Identifies the type of source system operation that resulted in the insertion of the record into the database. This includes: I – Insert, U – Update, and D – Deleted. It may also include X – Reinsertion of a deleted record (not always implemented).

{% enddocs %}

{% docs dwh_extraction_tstamp %} 

This column stores the date and time from which the record represents a true value. This should be included as part of the Primary Key on the Raw layer.

{% enddocs %}

{% docs dwh_effective_from_tstamp %} 

This column stores the date and time from which the record represents a true value. We can use the processing time from the source system when applicable; otherwise, the batch processing time will be used. This should be included as part of the Primary Key on the Raw layer.

{% enddocs %}

{% docs dwh_effective_to_tstamp %} 

This column stores the date and time after which the record no longer represents a true value. The dwh_effective_to_tstamp of the previous row MUST equal the dwh_effective_from_tstamp of the next row minus one time unit. For active records, dwh_effective_to_tstamp should be 9999‑12‑31.

{% enddocs %}

{% docs dwh_is_deleted_flag %} 

This Boolean indicates the deletion status of the record in the source system. A value of Y indicates the record is deleted from the source system and logically deleted from the source‑aligned layer. A value of N indicates that the record is present in the source system. When a delete is detected, the dwh_effective_to_tstamp is updated to current timestamp, a new record is inserted, and the current record is changed — for example, setting dwh_effective_to_tstamp to 9999‑12‑31 and dwh_is_deleted_flag = 'Y'. 

{% enddocs %}

{% docs dwh_extraction_id %} 

Populate with the ID from the process that extracted the data (e.g., the Kafka process ID). For file-based ingestion, this will be the filename where the record, in its current state, was first seen (stored in S3).

{% enddocs %}

{% docs dwh_process_insert_id %} 

This column is the unique identifier for the specific process used to create or insert this data row. Both dwh_process_insert_id and dwh_process_update_id are required to enable easy rollback of incorrectly loaded data.

{% enddocs %}

{% docs dwh_process_update_id %} 

This column is the unique identifier for the specific process used to update this row. Both dwh_process_insert_id and dwh_process_update_id are required to enable easy rollback of incorrectly loaded data.

{% enddocs %}

{% docs dwh_process_tstamp %} 

This column stores the date and time when the specific process was used to insert, update, or delete the data row.

{% enddocs %}

{% docs dwh_hash_key %} 

For S3 landing acquisitions, this column contains the unique hash of the record’s attributes. It is used to determine whether a change has occurred for Type 2 tables.

{% enddocs %}