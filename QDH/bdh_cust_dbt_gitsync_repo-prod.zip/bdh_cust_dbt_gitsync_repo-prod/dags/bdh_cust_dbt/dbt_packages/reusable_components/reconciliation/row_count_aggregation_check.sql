{%- macro row_count_aggregation_check(
    test_name, 
    test_type, 
    source_table, 
    target_table, 
    source_where_clause=none, 
    target_where_clause=none, 
    source_select_fields=none, 
    target_select_fields=none, 
    source_aggregate_fields=none, 
    target_aggregate_fields=none, 
    aggregate_functions=none, 
    source_sql=none, 
    target_sql=none, 
    iscustomsql=none, 
    threshold_value=none, 
    data_date_variable=none,
    comparison_type=none, 
    incremental_comparison_interval=none, 
    source_date_field=none, 
    target_date_field=none
) -%}

    {%- if (source_table is none and source_sql is none) or (target_table is none and target_sql is none) -%}
        {%- set error_msg = "Must provide either source_table/target_table OR source_sql/target_sql parameters" -%}
        select 
            'PARAMETER_ERROR' as test_type,
            null as source_result,
            null as target_result,
            '' as description,
            'FAIL' as test_passed,
            null as threshold_status,
            '{{ error_msg }}' as validation_message,
            null as variance_difference,
            null as variance_percentage, 
            DATE('1900-01-01') as last_file_processed_date,
            DATE('1900-01-01') as data_date
    {%- else -%}

    {# Determine test mode based on test_name parameter #}
    {%- set is_row_count_test = (test_name == 'ROW_COUNT_CHECK') -%}
    {%- set is_aggregation_test = (test_name == 'AGGREGATION_CHECK') -%}

    {# Set default threshold if not provided - handle None, null, and empty values #}
    {%- if threshold_value is none or threshold_value == 'None' or threshold_value == '' or threshold_value == 'null' -%}
        {%- set threshold_value_clean = 1.0 -%}
    {%- else -%}
        {%- set threshold_value_clean = threshold_value | float -%}
    {%- endif -%}
    {%- set row_count_threshold_percentage = threshold_value_clean -%}
    {%- set tolerance_percentage = threshold_value_clean -%}
    {%- set threshold_display = threshold_value_clean | string -%}
    {# Set default comparison_type if not provided - handle None, null, and empty values #}
    {%- if comparison_type is none or comparison_type == 'None' or comparison_type == '' or comparison_type == 'null' -%}
        {%- set comparison_type_display = 'full' -%}
    {%- else -%}
        {%- set comparison_type_display = comparison_type -%}
    {%- endif -%}

    {# Setup data date variable handling #}
    {%- if data_date_variable is not none -%}
        {%- set data_date_value = var(data_date_variable) -%}
        {%- set data_date_sql = "TO_DATE('" + data_date_value|string + "')" -%}
    {%- else -%}
        {%- set data_date_sql = 'CURRENT_DATE()' -%}
    {%- endif -%}

    {# Set default date columns if not provided #}
    {%- set source_date_field = source_date_field -%}
    {%- set target_date_field = target_date_field -%}

    {# Build incremental date filter conditions #}
    {%- set incremental_date_filter_start = '' -%}
    {%- set incremental_date_filter_end = '' -%}

    {%- if comparison_type == 'incremental' -%}
        {%- if incremental_comparison_interval == 'daily' -%}
            {%- set incremental_date_filter_start = "DATEADD(day, -1, " + data_date_sql + ")" -%}
            {%- set incremental_date_filter_end = data_date_sql -%}
        {%- elif incremental_comparison_interval == 'weekly' -%}
            {%- set incremental_date_filter_start = "DATEADD(day, -7, " + data_date_sql + ")" -%}
            {%- set incremental_date_filter_end = data_date_sql -%}
        {%- elif incremental_comparison_interval == 'monthly' -%}
            {%- set incremental_date_filter_start = "DATEADD(MONTH, -1, " + data_date_sql + ")" -%}
            {%- set incremental_date_filter_end = data_date_sql -%}
        {%- else -%}
            {%- set incremental_date_filter_start = data_date_sql -%}
            {%- set incremental_date_filter_end = "DATEADD(day, 1, " + data_date_sql + ")" -%}
        {%- endif -%}
    {%- endif -%}

    {# Process where clauses with variable substitution #}
    {%- set processed_source_where = source_where_clause -%}
    {%- set processed_target_where = target_where_clause -%}

    {%- if data_date_variable is not none -%}
        {%- if processed_source_where is not none -%}
            {%- set processed_source_where = processed_source_where.replace('${DATA_DATE}', "'" + data_date_value|string + "'") -%}
            {%- set processed_source_where = processed_source_where.replace('$DATA_DATE', "'" + data_date_value|string + "'") -%}
        {%- endif -%}
        {%- if processed_target_where is not none -%}
            {%- set processed_target_where = processed_target_where.replace('${DATA_DATE}', "'" + data_date_value|string + "'") -%}
            {%- set processed_target_where = processed_target_where.replace('$DATA_DATE', "'" + data_date_value|string + "'") -%}
        {%- endif -%}
    {%- endif -%}

    {# Parse reconcile columns for aggregation tests #}
    {%- if is_aggregation_test -%}
        {%- if source_aggregate_fields is not none -%}
            {%- set source_reconcile_cols_list = source_aggregate_fields.split(',') -%}
            {%- set source_reconcile_cols_clean = [] -%}
            {%- for col in source_reconcile_cols_list -%}
                {%- set _ = source_reconcile_cols_clean.append(col.strip()) -%}
            {%- endfor -%}
        {%- else -%}
            {%- set source_reconcile_cols_clean = [] -%}
        {%- endif -%}

        {%- if target_aggregate_fields is not none -%}
            {%- set target_reconcile_cols_list =target_aggregate_fields.split(',') -%}
            {%- set target_reconcile_cols_clean = [] -%}
            {%- for col in target_reconcile_cols_list -%}
                {%- set _ = target_reconcile_cols_clean.append(col.strip()) -%}
            {%- endfor -%}
        {%- else -%}
            {%- set target_reconcile_cols_clean = [] -%}
        {%- endif -%}

    {# Parse aggregate_functions - can be a single function or comma-separated list #}
    {%- if aggregate_functions is not none -%}
        {%- set agg_funcs_list = aggregate_functions.split(',') -%}
        {%- set agg_funcs_clean = [] -%}
        {%- for func in agg_funcs_list -%}
            {%- set _ = agg_funcs_clean.append(func.strip().lower()) -%}
        {%- endfor -%}
    {%- else -%}
        {# Default aggregate functions if none specified #}
        {%- set agg_funcs_clean = ['sum', 'count', 'avg', 'min', 'max'] -%}
    {%- endif -%}
 {%- endif -%}

    {# Build source and target base CTEs #}
	{# Common CTEs for both row_count_check and aggregation_check #}
    {# Enhanced CTEs that support both table and SQL query sources #}
    with source_base as (
        {%- if source_sql is not none and iscustomsql == 'Y' -%}
        select * from (
            {{ source_sql }}
        ) as source_query_result
        {%- else -%}
        select * from {{ source_table }}
        {%- endif %}
        where 1=1
        {%- if processed_source_where is not none %}
        and ({{ processed_source_where }})
        {%- endif %}
        {%- if comparison_type == 'incremental' and incremental_date_filter_start != '' and source_date_field is not none %}
        and ({{ source_date_field }} >= {{ incremental_date_filter_start }})
        and ({{ source_date_field }} < {{ incremental_date_filter_end }})
        {%- endif %}
    ),
    target_base as (
        {%- if target_sql is not none and iscustomsql == 'Y' -%}
        select * from (
            {{ target_sql }}
        ) as target_query_result
        {%- else -%}
        select * from {{ target_table }}
        {%- endif %}
        where 1=1
        {%- if processed_target_where is not none %}
        and ({{ processed_target_where }})
        {%- endif %}
        {%- if comparison_type == 'incremental' and incremental_date_filter_start != '' and target_date_field is not none %}
        and ({{ target_date_field }} >= {{ incremental_date_filter_start }})
        and ({{ target_date_field }} < {{ incremental_date_filter_end }})
        {%- endif %}
    ),

    {# Conditional aggregation based on test type and group by columns #}
    {%- if source_select_fields is not none -%}
    source_aggregated as (
        select 
            {{ source_select_fields }},
            count(*) as record_count
            {%- if is_aggregation_test and source_reconcile_cols_clean|length > 0 -%}
            {%- for col in source_reconcile_cols_clean -%}
                {%- for func in agg_funcs_clean -%}
                    {%- if func == 'sum' -%}
            , sum({{ col }}) as {{ col }}_sum
                    {%- elif func == 'count' -%}
            , count({{ col }}) as {{ col }}_count
                    {%- elif func == 'avg' -%}
            , avg({{ col }}) as {{ col }}_avg
                    {%- elif func == 'min' -%}
            , min({{ col }}) as {{ col }}_min
                    {%- elif func == 'max' -%}
            , max({{ col }}) as {{ col }}_max
                    {%- endif -%}
                {%- endfor -%}
            {%- endfor -%}
            {%- endif %}
        from source_base
        group by {{ source_select_fields }}
    ),
    {%- else -%}
    source_aggregated as (
        select 
            count(*) as record_count
            {%- if is_aggregation_test and source_reconcile_cols_clean|length > 0 -%}
            {%- for col in source_reconcile_cols_clean -%}
                {%- for func in agg_funcs_clean -%}
                    {%- if func == 'sum' -%}
            , sum({{ col }}) as {{ col }}_sum
                    {%- elif func == 'count' -%}
            , count({{ col }}) as {{ col }}_count
                    {%- elif func == 'avg' -%}
            , avg({{ col }}) as {{ col }}_avg
                    {%- elif func == 'min' -%}
            , min({{ col }}) as {{ col }}_min
                    {%- elif func == 'max' -%}
            , max({{ col }}) as {{ col }}_max
                    {%- endif -%}
                {%- endfor -%}
            {%- endfor -%}
            {%- endif %}
        from source_base
    ),
    {%- endif -%}

    {%- if target_select_fields is not none -%}
    target_aggregated as (
        select 
            {{ target_select_fields }},
            count(*) as record_count
            {%- if is_aggregation_test and target_reconcile_cols_clean|length > 0 -%}
            {%- for col in target_reconcile_cols_clean -%}
                {%- for func in agg_funcs_clean -%}
                    {%- if func == 'sum' -%}
            , sum({{ col }}) as {{ col }}_sum
                    {%- elif func == 'count' -%}
            , count({{ col }}) as {{ col }}_count
                    {%- elif func == 'avg' -%}
            , avg({{ col }}) as {{ col }}_avg
                    {%- elif func == 'min' -%}
            , min({{ col }}) as {{ col }}_min
                    {%- elif func == 'max' -%}
            , max({{ col }}) as {{ col }}_max
                    {%- endif -%}
                {%- endfor -%}
            {%- endfor -%}
            {%- endif %}
        from target_base
        group by {{ target_select_fields }}
    ),
    {%- else -%}
    target_aggregated as (
        select 
            count(*) as record_count
            {%- if is_aggregation_test and target_reconcile_cols_clean|length > 0 -%}
            {%- for col in target_reconcile_cols_clean -%}
                {%- for func in agg_funcs_clean -%}
                    {%- if func == 'sum' -%}
            , sum({{ col }}) as {{ col }}_sum
                    {%- elif func == 'count' -%}
            , count({{ col }}) as {{ col }}_count
                    {%- elif func == 'avg' -%}
            , avg({{ col }}) as {{ col }}_avg
                    {%- elif func == 'min' -%}
            , min({{ col }}) as {{ col }}_min
                    {%- elif func == 'max' -%}
            , max({{ col }}) as {{ col }}_max
                    {%- endif -%}
                {%- endfor -%}
            {%- endfor -%}
            {%- endif %}
        from target_base
    ),
    {%- endif -%}

    {# Summary CTEs for source and target #}
    {%- if source_select_fields is not none -%}
    source_summary as (
        select 
            sum(record_count) as total_records
            {%- if is_aggregation_test and source_reconcile_cols_clean|length > 0 -%}
            {%- for col in source_reconcile_cols_clean -%}
                {%- for func in agg_funcs_clean -%}
                    {%- if func == 'sum' -%}
            , sum({{ col }}_sum) as {{ col }}_total_sum
                    {%- elif func == 'count' -%}
            , sum({{ col }}_count) as {{ col }}_total_count
                    {%- elif func == 'avg' -%}
            , avg({{ col }}_avg) as {{ col }}_overall_avg
                    {%- elif func == 'min' -%}
            , min({{ col }}_min) as {{ col }}_overall_min
                    {%- elif func == 'max' -%}
            , max({{ col }}_max) as {{ col }}_overall_max
                    {%- endif -%}
                {%- endfor -%}
            {%- endfor -%}
            {%- endif %}
        from source_aggregated
    ),
    target_summary as (
        select 
            sum(record_count) as total_records
            {%- if is_aggregation_test and target_reconcile_cols_clean|length > 0 -%}
            {%- for col in target_reconcile_cols_clean -%}
                {%- for func in agg_funcs_clean -%}
                    {%- if func == 'sum' -%}
            , sum({{ col }}_sum) as {{ col }}_total_sum
                    {%- elif func == 'count' -%}
            , sum({{ col }}_count) as {{ col }}_total_count
                    {%- elif func == 'avg' -%}
            , avg({{ col }}_avg) as {{ col }}_overall_avg
                    {%- elif func == 'min' -%}
            , min({{ col }}_min) as {{ col }}_overall_min
                    {%- elif func == 'max' -%}
            , max({{ col }}_max) as {{ col }}_overall_max
                    {%- endif -%}
                {%- endfor -%}
            {%- endfor -%}
            {%- endif %}
        from target_aggregated
    ),
    {%- else -%}
    source_summary as (
        select 
            record_count as total_records
            {%- if is_aggregation_test and source_reconcile_cols_clean|length > 0 -%}
            {%- for col in source_reconcile_cols_clean -%}
                {%- for func in agg_funcs_clean -%}
                    {%- if func == 'sum' -%}
            , {{ col }}_sum as {{ col }}_total_sum
                    {%- elif func == 'count' -%}
            , {{ col }}_count as {{ col }}_total_count
                    {%- elif func == 'avg' -%}
            , {{ col }}_avg as {{ col }}_overall_avg
                    {%- elif func == 'min' -%}
            , {{ col }}_min as {{ col }}_overall_min
                    {%- elif func == 'max' -%}
            , {{ col }}_max as {{ col }}_overall_max
                    {%- endif -%}
                {%- endfor -%}
            {%- endfor -%}
            {%- endif %}
        from source_aggregated
    ),
    target_summary as (
        select
            record_count as total_records
            {%- if is_aggregation_test and target_reconcile_cols_clean|length > 0 -%}
            {%- for col in target_reconcile_cols_clean -%}
                {%- for func in agg_funcs_clean -%}
                    {%- if func == 'sum' -%}
            , {{ col }}_sum as {{ col }}_total_sum
                    {%- elif func == 'count' -%}
            , {{ col }}_count as {{ col }}_total_count
                    {%- elif func == 'avg' -%}
            , {{ col }}_avg as {{ col }}_overall_avg
                    {%- elif func == 'min' -%}
            , {{ col }}_min as {{ col }}_overall_min
                    {%- elif func == 'max' -%}
            , {{ col }}_max as {{ col }}_overall_max
                    {%- endif -%}
                {%- endfor -%}
            {%- endfor -%}
            {%- endif %}
        from target_aggregated
    ),
    {%- endif -%}

    {%- if is_row_count_test -%}
    {# Row count comparison logic #}
    row_count_source_except_target as (
        {%- if source_select_fields is not none -%}
        select 
            {{ source_select_fields }},
            record_count
        from source_aggregated
        except
        select 
            {{ target_select_fields }},
            record_count
        from target_aggregated
        {%- else -%}
        select record_count from source_aggregated
        except
        select record_count from target_aggregated
        {%- endif -%}
    ),
    row_count_target_except_source as (
        {%- if target_select_fields is not none -%}
        select 
            {{ target_select_fields }},
            record_count
        from target_aggregated
        except
        select 
            {{ source_select_fields }},
            record_count
        from source_aggregated
        {%- else -%}
        select record_count from target_aggregated
        except
        select record_count from source_aggregated
        {%- endif -%}
    ),
    row_count_differences as (
        select 
            (select count(*) from row_count_source_except_target) as only_in_source,
            (select count(*) from row_count_target_except_source) as only_in_target
    ),
    final_results as (
        select
            '{{ test_type }}' as test_type,
            s.total_records as source_result,
            t.total_records as target_result,
            concat(
                'Comparison Type: {{ comparison_type_display }}',
                {%- if comparison_type == 'incremental' -%}
                ', Interval: {{ incremental_comparison_interval | default("daily") }}',
                ', Source Date field: {{ source_date_field }}',
                ', Target Date field: {{ target_date_field }}',
                {%- if data_date_variable is not none -%}
                ', Data Date Variable: {{ data_date_variable }}',
                {%- endif -%}
                ', Date Range: ', {{ incremental_date_filter_start }}, ' to ', {{ incremental_date_filter_end }},
                {%- endif -%}
                ', Threshold: {{ threshold_display }}%'
            ) as description,
            case 
                when rd.only_in_source = 0 and rd.only_in_target = 0 
                     and (
                         case 
                             when greatest(s.total_records, t.total_records) = 0 then 0
                             else (abs(s.total_records - t.total_records) * 100.0) / greatest(s.total_records, t.total_records)
                         end <= {{ row_count_threshold_percentage }}
                     )
                then 'PASS'
                else 'FAIL'
            end as test_passed,
            case
                when rd.only_in_source = 0 and rd.only_in_target = 0 
                     and (
                         case 
                             when greatest(s.total_records, t.total_records) = 0 then 0
                             else (abs(s.total_records - t.total_records) * 100.0) / greatest(s.total_records, t.total_records)
                         end <= {{ row_count_threshold_percentage }}
                     )
                then 'WITHIN_THRESHOLD'
                when rd.only_in_source = 0 and rd.only_in_target = 0 
                     and (
                         case 
                             when greatest(s.total_records, t.total_records) = 0 then 0
                             else (abs(s.total_records - t.total_records) * 100.0) / greatest(s.total_records, t.total_records)
                         end > {{ row_count_threshold_percentage }}
                     )
                then 'EXCEEDS_THRESHOLD'
                -- when coalesce(s.total_records, 0) = coalesce(t.total_records, 0) then 'EXACT_MATCH'
                -- when rd.only_in_source <> rd.only_in_target then 'RECORD_MISMATCH'
                else 'EXCEEDS_THRESHOLD'
            end as threshold_status,

            case
                when rd.only_in_source = 0 and rd.only_in_target = 0 then 'ROW_COUNT_MATCHED'
                else 'ROW_COUNT_UNMATCHED'
            end as validation_message,
            abs(s.total_records - t.total_records) as variance_difference,
            round(
                case 
                    when greatest(s.total_records, t.total_records) = 0 then 0
                    else (abs(s.total_records - t.total_records) * 100.0) / greatest(s.total_records, t.total_records)
                end, 2
            ) as variance_percentage,
            DATE('1900-01-01') as last_file_processed_date,
            {%- if data_date_variable is not none -%}
            TO_DATE('{{ data_date_value }}') as data_date
            {%- else -%}
            DATE('1900-01-01') as data_date
            {%- endif -%}
            
        {{ ' ' }}from source_summary s, target_summary t, row_count_differences rd
    )
    {%- else -%}
    {# Aggregation function results #}
    final_results as (
        {%- if source_reconcile_cols_clean|length > 0 -%}
            {%- set source_col = source_reconcile_cols_clean[0] -%}
            {%- if target_reconcile_cols_clean|length > 0 -%}
                {%- set target_col = target_reconcile_cols_clean[0] -%}
            {%- else -%}
                {%- set target_col = source_col -%}
            {%- endif -%}
            {%- for func in agg_funcs_clean -%}
        select
            '{{ test_type }}_{{ func|upper }}' as test_type,
            {%- if func == 'sum' -%}
             round(s.{{ source_col }}_total_sum, 2) as source_result,
             round(t.{{ target_col }}_total_sum, 2) as target_result,
             concat(
                'Comparison Type: {{ comparison_type_display }}',
                {%- if comparison_type == 'incremental' -%}
                ', Interval: {{ incremental_comparison_interval | default("daily") }}',
				', Source Date Field: {{ source_date_field }}',
                ', Target Date Field: {{ target_date_field }}',
                {%- if data_date_variable is not none -%}
                ', Data Date Variable: {{ data_date_variable }}',
                {%- endif -%}

				', Date Range: ', {{ incremental_date_filter_start }}, ' to ', {{ incremental_date_filter_end }},
                {%- endif -%}
                ', Threshold: {{ threshold_display }}%'
                 ) as description,
             case 
                when (
                    case 
                        when greatest(abs(s.{{ source_col }}_total_sum), abs(t.{{ target_col }}_total_sum)) = 0 then 0
                        else (abs(s.{{ source_col }}_total_sum - t.{{ target_col }}_total_sum) * 100.0) / greatest(abs(s.{{ source_col }}_total_sum), abs(t.{{ target_col }}_total_sum))
                    end <= {{ tolerance_percentage }}
                ) then 'PASS'
                else 'FAIL'
             end as test_passed,
             case 
                when (
                    case 
                        when greatest(abs(s.{{ source_col }}_total_sum), abs(t.{{ target_col }}_total_sum)) = 0 then 0
                        else (abs(s.{{ source_col }}_total_sum - t.{{ target_col }}_total_sum) * 100.0) / greatest(abs(s.{{ source_col }}_total_sum), abs(t.{{ target_col }}_total_sum))
                    end <= {{ tolerance_percentage }}
                ) then 'WITHIN_THRESHOLD'
                when s.{{ source_col }}_total_sum = t.{{ target_col }}_total_sum then 'EXACT_MATCH'
                else 'EXCEEDS_THRESHOLD'
             end as threshold_status,
             case 
                when s.{{ source_col }}_total_sum = t.{{ target_col }}_total_sum then 'AGGREGATION_MATCHED'
                else 'AGGREGATION_MISMATCHED'
             end as validation_message,
             abs(s.{{ source_col }}_total_sum - t.{{ target_col }}_total_sum) 
             as variance_difference,
             round(
                case 
                    when greatest(abs(s.{{ source_col }}_total_sum), abs(t.{{ target_col }}_total_sum)) = 0 then 0
                    else (abs(s.{{ source_col }}_total_sum - t.{{ target_col }}_total_sum) * 100.0) / greatest(abs(s.{{ source_col }}_total_sum), abs(t.{{ target_col }}_total_sum))
                end, 2
                ) as variance_percentage,
             DATE('1900-01-01') as last_file_processed_date,
             {%- if data_date_variable is not none -%}
              TO_DATE('{{ data_date_value }}') as data_date
             {%- else -%}
              DATE('1900-01-01') as data_date
             {%- endif -%}               
            {%- elif func == 'count' -%}
                cast(s.{{ source_col }}_total_count as integer) as source_result,
                cast(t.{{ target_col }}_total_count as integer) as target_result,
                concat(
                    'Comparison Type: {{ comparison_type_display }}',
                    {%- if comparison_type == 'incremental' -%}
                    ', Interval: {{ incremental_comparison_interval | default("daily") }}',
                    ', Source Date Column: {{ source_date_field }}',
                    ', Target Date Column: {{ target_date_field }}',
                    {%- if data_date_variable is not none -%}
                    ', Data Date Variable: {{ data_date_variable }}',
                    {%- endif -%}
                    ', Date Range: ', {{ incremental_date_filter_start }}, ' to ', {{ incremental_date_filter_end }},
                    {%- endif -%}
                    ', Threshold: {{ threshold_display }}%'
                ) as description,
                case 
                    when s.{{ source_col }}_total_count = t.{{ target_col }}_total_count then 'PASS'
                    else 'FAIL'
                end as test_passed,
                case 
                    when (
                        case 
                            when greatest(abs(s.{{ source_col }}_total_count), abs(t.{{ target_col }}_total_count)) = 0 then 0
                            else (abs(s.{{ source_col }}_total_count - t.{{ target_col }}_total_count) * 100.0) / greatest(abs(s.{{ source_col }}_total_count), abs(t.{{ target_col }}_total_count))
                        end <= {{ tolerance_percentage }}
                    ) then 'WITHIN_THRESHOLD'
                    when s.{{ source_col }}_total_count = t.{{ target_col }}_total_count then 'EXACT_MATCH'
                    else 'EXCEEDS_THRESHOLD'
                end as threshold_status,
                case 
                    when s.{{ source_col }}_total_count = t.{{ target_col }}_total_count then 'AGGREGATION_MATCHED'
                    else 'AGGREGATION_MISMATCHED'
                end as validation_message,
                abs(cast(s.{{ source_col }}_total_count as integer) - cast(t.{{ target_col }}_total_count as integer)) 
                as variance_difference,
                round(
                    case 
                        when greatest(s.{{ source_col }}_total_count, t.{{ target_col }}_total_count) = 0 then 0
                        else (abs(s.{{ source_col }}_total_count - t.{{ target_col }}_total_count) * 100.0) / greatest(s.{{ source_col }}_total_count, t.{{ target_col }}_total_count)
                    end, 2
                ) as variance_percentage,
                DATE('1900-01-01') as last_file_processed_date,
                {%- if data_date_variable is not none -%}
                TO_DATE('{{ data_date_value }}') as data_date
                {%- else -%}
                DATE('1900-01-01') as data_date
                {%- endif -%}               
            {%- elif func == 'avg' -%}
                round(s.{{ source_col }}_overall_avg, 8) as source_result,
                round(t.{{ target_col }}_overall_avg, 8) as target_result,
                concat(
                    'Comparison Type: {{ comparison_type_display }}',
                    {%- if comparison_type == 'incremental' -%}
                    ', Interval: {{ incremental_comparison_interval | default("daily") }}',
                    ', Source Date Column: {{ source_date_field }}',
                    ', Target Date Column: {{ target_date_field }}',
                    {%- if data_date_variable is not none -%}
                    ', Data Date Variable: {{ data_date_variable }}',
                    {%- endif -%}
                    ', Date Range: ', {{ incremental_date_filter_start }}, ' to ', {{ incremental_date_filter_end }},
                    {%- endif -%}
                    ', Threshold: {{ threshold_display }}%'
                ) as description,
                case 
                    when (
                        case 
                            when greatest(abs(s.{{ source_col }}_overall_avg), abs(t.{{ target_col }}_overall_avg)) = 0 then 0
                            else (abs(s.{{ source_col }}_overall_avg - t.{{ target_col }}_overall_avg) * 100.0) / greatest(abs(s.{{ source_col }}_overall_avg), abs(t.{{ target_col }}_overall_avg))
                        end <= {{ tolerance_percentage }}
                    ) then 'PASS'
                    else 'FAIL'
                end as test_passed,
                case 
                    when (
                        case 
                            when greatest(abs(s.{{ source_col }}_overall_avg), abs(t.{{ target_col }}_overall_avg)) = 0 then 0
                            else (abs(s.{{ source_col }}_overall_avg - t.{{ target_col }}_overall_avg) * 100.0) / greatest(abs(s.{{ source_col }}_overall_avg), abs(t.{{ target_col }}_overall_avg))
                        end <= {{ tolerance_percentage }}
                    ) then 'WITHIN_THRESHOLD'
                    when s.{{ source_col }}_overall_avg = t.{{ target_col }}_overall_avg then 'EXACT_MATCH'
                    else 'EXCEEDS_THRESHOLD'
                end as threshold_status,
                case 
                    when abs(s.{{ source_col }}_overall_avg - t.{{ target_col }}_overall_avg) <= {{ tolerance_percentage }} then 'AGGREGATION_MATCHED'
                    else 'AGGREGATION_MISMATCHED'
                end as validation_message,
                abs(s.{{ source_col }}_overall_avg - t.{{ target_col }}_overall_avg) 
                as variance_difference,
                round(
                    case 
                        when greatest(abs(s.{{ source_col }}_overall_avg), abs(t.{{ target_col }}_overall_avg)) = 0 then 0
                        else (abs(s.{{ source_col }}_overall_avg - t.{{ target_col }}_overall_avg) * 100.0) / greatest(abs(s.{{ source_col }}_overall_avg), abs(t.{{ target_col }}_overall_avg))
                    end, 2
                ) as variance_percentage, 
                DATE('1900-01-01') as last_file_processed_date,
                {%- if data_date_variable is not none -%}
                TO_DATE('{{ data_date_value }}') as data_date
                {%- else -%}
                DATE('1900-01-01') as data_date   
                {%- endif -%}             
            {%- elif func == 'min' -%}
                round(coalesce(s.{{ source_col }}_overall_min, 0), 2) as source_result,
                round(coalesce(t.{{ target_col }}_overall_min, 0), 2) as target_result,
                concat(
                    'Comparison Type: {{ comparison_type_display }}',
                    {%- if comparison_type == 'incremental' -%}
                    ', Interval: {{ incremental_comparison_interval | default("daily") }}',
                    ', Source Date Column: {{ source_date_field }}',
                    ', Target Date Column: {{ target_date_field }}',
                    {%- if data_date_variable is not none -%}
                    ', Data Date Variable: {{ data_date_variable }}',
                    {%- endif -%}
                    ', Date Range: ', {{ incremental_date_filter_start }}, ' to ', {{ incremental_date_filter_end }},
                    {%- endif -%}
                    ', Threshold: {{ threshold_display }}%'
                ) as description,
                case 
                    when coalesce(s.{{ source_col }}_overall_min, 0) = coalesce(t.{{ target_col }}_overall_min, 0) then 'PASS'
                    else 'FAIL'
                end as test_passed,
                case 
                    when (
                        case 
                            when greatest(abs(coalesce(s.{{ source_col }}_overall_min, 0)), abs(coalesce(t.{{ target_col }}_overall_min, 0))) = 0 then 0
                            else (abs(coalesce(s.{{ source_col }}_overall_min, 0) - coalesce(t.{{ target_col }}_overall_min, 0)) * 100.0) / greatest(abs(coalesce(s.{{ source_col }}_overall_min, 0)), abs(coalesce(t.{{ target_col }}_overall_min, 0)))
                        end <= {{ tolerance_percentage }}
                    ) then 'WITHIN_THRESHOLD'
                    when coalesce(s.{{ source_col }}_overall_min, 0) = coalesce(t.{{ target_col }}_overall_min, 0) then 'EXACT_MATCH'
                    else 'EXCEEDS_THRESHOLD'
                end as threshold_status,
                case 
                    when coalesce(s.{{ source_col }}_overall_min, 0) = coalesce(t.{{ target_col }}_overall_min, 0) then 'AGGREGATION_MATCHED'
                    else 'AGGREGATION_MISMATCHED'
                end as validation_message,
                abs(coalesce(s.{{ source_col }}_overall_min, 0) - coalesce(t.{{ target_col }}_overall_min, 0)) 
                as variance_difference,
                round(
                    case 
                        when greatest(abs(coalesce(s.{{ source_col }}_overall_min, 0)), abs(coalesce(t.{{ target_col }}_overall_min, 0))) = 0 then 0
                        else (abs(coalesce(s.{{ source_col }}_overall_min, 0) - coalesce(t.{{ target_col }}_overall_min, 0)) * 100.0) / greatest(abs(coalesce(s.{{ source_col }}_overall_min, 0)), abs(coalesce(t.{{ target_col }}_overall_min, 0)))
                    end, 2
                ) as variance_percentage,   
                DATE('1900-01-01') as last_file_processed_date,             
                {%- if data_date_variable is not none -%}
                TO_DATE('{{ data_date_value }}') as data_date
                {%- else -%}
                DATE('1900-01-01') as data_date   
                {%- endif -%} 
           
            {%- elif func == 'max' -%}
                round(s.{{ source_col }}_overall_max, 2) as source_result,
                round(t.{{ target_col }}_overall_max, 2) as target_result,
                concat(
                    'Comparison Type: {{ comparison_type_display }}',
                    {%- if comparison_type == 'incremental' -%}
                    ', Interval: {{ incremental_comparison_interval | default("daily") }}',
                    ', Source Date Column: {{ source_date_field }}',
                    ', Target Date Column: {{ target_date_field }}',
                    {%- if data_date_variable is not none -%}
                    ', Data Date Variable: {{ data_date_variable }}',
                    {%- endif -%}
                    ', Date Range: ', {{ incremental_date_filter_start }}, ' to ', {{ incremental_date_filter_end }},
                    {%- endif -%}
                    ', Threshold: {{ threshold_display }}%'
                ) as description,
                case 
                    when s.{{ source_col }}_overall_max = t.{{ target_col }}_overall_max then 'PASS'
                    else 'FAIL'
                end as test_passed,
                case 
                    when (
                        case 
                            when greatest(abs(s.{{ source_col }}_overall_max), abs(t.{{ target_col }}_overall_max)) = 0 then 0
                            else (abs(s.{{ source_col }}_overall_max - t.{{ target_col }}_overall_max) * 100.0) / greatest(abs(s.{{ source_col }}_overall_max), abs(t.{{ target_col }}_overall_max))
                        end <= {{ tolerance_percentage }}
                    ) then 'WITHIN_THRESHOLD'
                    when s.{{ source_col }}_overall_max = t.{{ target_col }}_overall_max then 'EXACT_MATCH'
                    else 'EXCEEDS_THRESHOLD'
                end as threshold_status,
                case 
                    when s.{{ source_col }}_overall_max = t.{{ target_col }}_overall_max then 'AGGREGATION_MATCHED'
                    else 'AGGREGATION_MISMATCHED'
                end as validation_message,
                abs(s.{{ source_col }}_overall_max - t.{{ target_col }}_overall_max) 
                as variance_difference,
                round(
                    case 
                        when greatest(abs(s.{{ source_col }}_overall_max), abs(t.{{ target_col }}_overall_max)) = 0 then 0
                        else (abs(s.{{ source_col }}_overall_max - t.{{ target_col }}_overall_max) * 100.0) / greatest(abs(s.{{ source_col }}_overall_max), abs(t.{{ target_col }}_overall_max))
                    end, 2
                ) as variance_percentage,
                DATE('1900-01-01') as last_file_processed_date,             
                {%- if data_date_variable is not none -%}
                TO_DATE('{{ data_date_value }}') as data_date
                {%- else -%}
                DATE('1900-01-01') as data_date   
                {%- endif -%} 
            {%- endif -%}
        {{ '  ' }} from source_summary s, target_summary t
                {%- if not loop.last %}
        union all {{ " "}}
                {%- endif -%}
            {%- endfor -%}
        {%- else -%}
     

        select 
           'CONFIGURATION_ERROR' as test_type,
            null as source_result,
            null as target_result,
            '' as description,
            'FAIL' as test_passed,
            'UNKNOWN' as threshold_status,
            '{{ error_msg }}' as validation_message,
            null as variance_difference,
            null as variance_percentage, 
            DATE('1900-01-01') as last_file_processed_date,
            DATE('1900-01-01') as data_date
        {%- endif %}
    )
    {%- endif -%}

    select * from final_results
    {%- if is_aggregation_test -%}
     {{ ' ' }} order by test_type
    {%- endif -%}
    {%- endif -%}
{% endmacro %}
