{% docs data_freshness_unique_active_check___desc %}
Performs data freshness validation or unique active record checks based on test_name. For Freshness Check: validates data timeliness within threshold hours. For Unique Active Check: identifies duplicate records based on unique key columns.
{% enddocs %}

{% docs data_freshness_unique_active_check___test_name %}
Test name determining execution logic. Must be 'Freshness Check' or 'Unique Active Check'. Example: 'Freshness Check'
{% enddocs %}

{% docs data_freshness_unique_active_check___test_type %}
Test type identifier for reporting. Example: 'DATA_FRESHNESS', 'UNIQUE_VALIDATION'
{% enddocs %}

{% docs data_freshness_unique_active_check___source_table %}
Fully qualified source table name or used with source_sql. Example: ref('source_data')
{% enddocs %}

{% docs data_freshness_unique_active_check___target_table %}
Fully qualified target table name or used with target_sql. Example: ref('target_data')
{% enddocs %}

{% docs data_freshness_unique_active_check___source_where_clause %}
Optional WHERE clause filter for source table. Supports ${DATA_DATE} substitution. Example: "status = 'ACTIVE'"
{% enddocs %}

{% docs data_freshness_unique_active_check___target_where_clause %}
Optional WHERE clause filter for target table. Supports ${DATA_DATE} substitution. Example: "is_deleted = FALSE"
{% enddocs %}

{% docs data_freshness_unique_active_check___source_freshness_column %}
Source timestamp column for freshness validation. Used only for Freshness Check. Example: 'updated_timestamp'
{% enddocs %}

{% docs data_freshness_unique_active_check___target_freshness_column %}
Target timestamp column for freshness validation. Used only for Freshness Check. Example: 'load_timestamp'
{% enddocs %}

{% docs data_freshness_unique_active_check___threshold_value %}
Threshold for validation. For Freshness Check: hours threshold. For Unique Active Check: variance percentage tolerance. Default: 1.0. Example: 24.0 (hours) or 1.0 (percent)
{% enddocs %}

{% docs data_freshness_unique_active_check___source_unique_columns %}
Comma-separated unique key columns for source. Used only for Unique Active Check. Example: 'customer_id,account_id'
{% enddocs %}

{% docs data_freshness_unique_active_check___target_unique_columns %}
Comma-separated unique key columns for target. Used only for Unique Active Check. Example: 'customer_id,account_id'
{% enddocs %}

{% docs data_freshness_unique_active_check___source_sql %}
Optional custom SQL query for source data instead of source_table. Example: 'SELECT * FROM schema.table WHERE condition'
{% enddocs %}

{% docs data_freshness_unique_active_check___target_sql %}
Optional custom SQL query for target data instead of target_table. Example: 'SELECT * FROM schema.table WHERE condition'
{% enddocs %}

{% docs data_freshness_unique_active_check___data_date_variable %}
Name of dbt variable containing business date. Used for ${DATA_DATE} substitution in where clauses. Example: 'run_date'
{% enddocs %}
