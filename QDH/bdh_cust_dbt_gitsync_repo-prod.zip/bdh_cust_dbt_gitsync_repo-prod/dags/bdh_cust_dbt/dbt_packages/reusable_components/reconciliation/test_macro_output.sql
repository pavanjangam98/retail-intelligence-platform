{% macro test_macro_output() %}
    {% set query %}
  {{ row_count_aggregation_check(
        test_name='Aggregation Check',
        test_type='sum count avg max min fin_tran_amt_by_nom_acct_type',
        source_table='landing__dev.IBIS.TLTD_FIN_TRAN',
        target_table='ptp__raw__dev.IBIS.TLTD_FIN_TRAN',
        source_where_clause="affect_loan_ind = 'Y'",
        target_where_clause="affect_loan_ind = 'Y'",
        source_aggregate_fields='fin_tran_amt',
        target_aggregate_fields='fin_tran_amt',
        aggregate_functions='sum,count,avg,min,max'
    ) }}
    {% endset %}

    {{ log("Generated SQL:", info=true) }}
    {{ log(query, info=true) }}

    {% set results = run_query(query) %}

    {{ log("Results:", info=true) }}
    {% if results.rows %}
        {{ log("Number of rows returned: " ~ results.rows | length, info=true) }}
        {% for row in results.rows %}
            {{ log("Row " ~ loop.index ~ ": " ~ row, info=true) }}
        {% endfor %}
    {% else %} {{ log("No results returned", info=true) }}
    {% endif %}
{% endmacro %}
