{% docs execute_art_framework___desc %}
Automated Reconciliation Testing (ART) framework executor. Reads test configurations from metadata tables, executes appropriate test macros based on test_name, and stores results in TEST_RESULTS table. Supports Row Count, Aggregation, Freshness, Unique Active, and Source File Row Count checks.
{% enddocs %}

{% docs execute_art_framework___run_date %}
Business date for test execution run. Used as effective date for data being tested. Example: '2024-10-10'
{% enddocs %}

{% docs execute_art_framework___execution_id %}
Optional unique identifier for test execution batch. Auto-generates format 'ART_YYYYMMDD_HHMMSS' if not provided. Example: 'ART_20241010_143022'
{% enddocs %}
