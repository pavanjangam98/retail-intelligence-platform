{% macro execute_art_framework(run_date,execution_id=none) %}
    {% if execution_id is none %}
        {% set execution_id = 'ART_' ~ modules.datetime.datetime.now().strftime('%Y%m%d_%H%M%S') %}
    {% endif %}
    {% set environment = target.name.lower() %}
    {% set bdh_db = var('DBT_DATABASE') %}
    {% set execute = true %}  {# <-- define this variable #}
    {% set config_query %}
       SELECT
            rt.table_id,
            rt.source_database_name||'__{{environment}}' || '.'|| rt.source_schema || '.' || rt.source_table as source_table,
            rt.target_db_name||'__{{ environment }}'||'.'|| rt.target_schema || '.' || rt.target_table as target_table,
            rts.test_id,
            rts.test_type,
            rts.test_name,
            rts.test_description,
            rts.source_select_fields,
            rts.target_select_fields,
            rts.source_where_clause,
            rts.target_where_clause,
            rts.aggregate_functions,
            rts.source_aggregate_fields,    
            rts.target_aggregate_fields,
            rts.source_unique_fields,
            rts.target_unique_fields,
            rts.source_sql,
            rts.target_sql,
            rts.iscustomsql,
            rts.data_date_variable,
            rts.comparison_type,
            rts.incremental_comparison_interval,
            rts.source_date_field,
            rts.target_date_field,
            rts.threshold_value  
        FROM {{bdh_db}}__{{environment}}.RECON.METADATA_TABLES rt
        JOIN {{bdh_db}}__{{environment}}.RECON.METADATA_TEST_CASES rts ON rt.table_id = rts.table_id
        WHERE rt.enabled = 'Y'
        AND rts.enabled = 'Y'
        ORDER BY  rts.test_id
 
    {% endset %}
    {% if execute %}
        {% set results = run_query(config_query) %}
        {% if results.rows %}
            {% for row in results.rows %}
                {% set table_id = row[0] %}
                {% set source_table = row[1] %}
                {% set target_table = row[2] %}
                {% set test_id = row[3] %}
                {% set test_type = row[4] %}
                {% set test_name = row[5] %}
                {% set test_description = row[6] %}
                {% set source_select_fields = row[7] %}
                {% set target_select_fields = row[8] %}  
                {% set source_where_clause = row[9] %}
                {% set target_where_clause = row[10] %}              
                {% set aggregate_functions = row[11] %}                
                {% set source_aggregate_fields = row[12] %}
                {% set target_aggregate_fields = row[13] %}
                {% set source_unique_fields = row[14] %}
                {% set target_unique_fields = row[15] %}
                {% set source_sql = row[16] %}
                {% set target_sql = row[17] %}
                {% set iscustomsql = row[18] %}
                {% set data_date_variable = row[19] %}
                {% set comparison_type = row[20] %}
                {% set incremental_comparison_interval = row[21] %}
                {% set source_date_field = row[22] %}
                {% set target_date_field = row[23] %}
                {% set threshold_value = row[24] %}
 

                {{ log("Executing test: " ~ test_name ~ " (" ~ test_type ~ ") for table: " ~ target_table, info=true) }}
                {% set test_result_query %}
                    {% if test_name == 'ROW_COUNT_CHECK' %}
                        {{ row_count_aggregation_check(test_name,test_type,source_table, target_table ,source_where_clause, target_where_clause, source_select_fields ,target_select_fields , source_aggregate_fields,target_aggregate_fields,aggregate_functions,source_sql,target_sql,iscustomsql,threshold_value,data_date_variable,comparison_type,incremental_comparison_interval,source_date_field,target_date_field) }}
                    {% elif test_name == 'AGGREGATION_CHECK' %}
                        {{ row_count_aggregation_check(test_name,test_type,source_table, target_table ,source_where_clause, target_where_clause, source_select_fields ,target_select_fields , source_aggregate_fields,target_aggregate_fields,aggregate_functions,source_sql,target_sql,iscustomsql,threshold_value,data_date_variable,comparison_type,incremental_comparison_interval,source_date_field,target_date_field) }}
                    {% elif test_name == 'FRESHNESS_CHECK' %}
                        {{ data_freshness_unique_active_check(test_name,test_type,source_table,target_table,source_where_clause, target_where_clause,source_date_field,target_date_field,threshold_value,source_unique_fields,target_unique_fields,source_sql,target_sql,data_date_variable) }}
                    {% elif test_name == 'UNIQUE_ACTIVE_CHECK' %}
                        {{ data_freshness_unique_active_check(test_name,test_type,source_table,target_table,source_where_clause, target_where_clause,source_date_field,target_date_field,threshold_value,source_unique_fields,target_unique_fields,source_sql,target_sql,data_date_variable) }}
                    {% elif test_name == 'SOURCE_FILE_ROW_COUNT_CHECK' %}
                        {{ source_file_data_recon_check(test_name,test_type,test_id,source_table,target_table,source_where_clause,target_where_clause,target_select_fields,threshold_value,source_date_field,target_date_field,data_date_variable)}}
                    {% else %}
                        {% set test_result_query = "" %}
                    {% endif %}
                {% endset %}
                {% if test_result_query is not none and test_result_query | trim != '' %}
                    {% set test_results = run_query(test_result_query) %}                    
                    {% if test_results.rows and test_results.rows|length > 0 %}
                        {# Loop through all result rows instead of just taking the first one #}
                        {% for result_row in test_results.rows %}
                            {% if result_row and result_row|length > 0 %}
                                {% set test_type_result = result_row[0] %}
                                {% set source_count = result_row[1] %}
                                {% set target_count = result_row[2] %}
                                {% set description = result_row[3] %}
                                {% set test_status = result_row[4] %}
                                {% set threshold_status = result_row[5] %}
                                {% set validation_msg = result_row[6] %}
                                {% set variance_difference = result_row[7] %}                    
                                {% set variance_percentage = result_row[8] %}
                                {% set last_file_processed_date = result_row[9] %}                              
                                {% set data_date = result_row[10] %}
                               
                                {# Format numeric values based on test type #}
                                {% if row[5] == 'Aggregation Check' %}
                                    {# Check if this is a COUNT aggregation test #}
                                    {% if test_type_result and ('_COUNT' in test_type_result.upper()) %}
                                        {# Integer formatting for count operations #}
                                        {% set source_count_formatted = "%d"|format(source_count|int) if source_count != 'null' and source_count is not none else '0' %}
                                        {% set target_count_formatted = "%d"|format(target_count|int) if target_count != 'null' and target_count is not none else '0' %}
                                    {% else %}
                                        {# Float formatting for sum, avg, min, max operations #}
                                        {% set source_count_formatted = "%.2f"|format(source_count|float) if source_count != 'null' and source_count is not none else '0.00' %}
                                        {% set target_count_formatted = "%.2f"|format(target_count|float) if target_count != 'null' and target_count is not none else '0.00' %}
                                    {% endif %}
                                {% elif row[5] == 'Row Count Check' %}
                                    {# Check if this is a COUNT operation or other aggregations #}
                                    {% if test_type_result and ('_SUM' in test_type_result.upper() or '_AVG' in test_type_result.upper() or '_MIN' in test_type_result.upper() or '_MAX' in test_type_result.upper()) %}
                                        {# Integer formatting for count operations #}
                                        {% set source_count_formatted = "%.2f"|format(source_count|float) if source_count != 'null' and source_count is not none else '0.00' %}
                                        {% set target_count_formatted = "%.2f"|format(target_count|float) if target_count != 'null' and target_count is not none else '0.00' %}
                                    {% else %}
                                        {# Default integer formatting for basic row count checks #}
                                        {% set source_count_formatted = "%d"|format(source_count|int) if source_count != 'null' and source_count is not none else '0' %}
                                        {% set target_count_formatted = "%d"|format(target_count|int) if target_count != 'null' and target_count is not none else '0' %}
                                    {% endif %}
                                {% else %}
                                    {# Default to original values for other test types #}
                                    {% set source_count_formatted = source_count %}
                                    {% set target_count_formatted = target_count %}
                                {% endif %}

                                {% set insert_query %}
                                    INSERT INTO {{bdh_db}}__{{environment}}.RECON.TEST_RESULTS (
                                        test_execution_id,
                                        test_id,
                                        table_id,
                                        source_table_name,
                                        target_table_name,
                                        test_type,
                                        source_result,
                                        target_result,
                                        description,
                                        test_passed,
                                        threshold_status,
                                        validation_msg,
                                        value_difference,
                                        variance_percentage,  
                                        result_query,
                                        last_file_processed_date,
                                        data_date,
                                        insert_timestamp
                                       
                                    )
                                    VALUES (
                                        '{{ execution_id }}',
                                        {{ test_id }},
                                        {{ table_id }},                            
                                        '{{ source_table if iscustomsql == 'N' else '<mulitple>' }}',
                                        '{{ target_table }}',
                                        '{{ test_type_result }}',
                                        '{{ source_count_formatted }}',
                                        '{{ target_count_formatted }}',
                                        '{{ description }}',
                                        {{ 'TRUE' if test_status == 'PASS' else 'FALSE' }},
                                        '{{ threshold_status }}',
                                        '{{ validation_msg }}',

                                        {{ 'NULL' if variance_difference == 'None' or variance_difference is none else variance_difference }},
                                        {{ 'NULL' if variance_percentage == 'None' or variance_percentage is none else variance_percentage }},                
                                        $${{ test_result_query }}$$,                                      
                                        '{{ last_file_processed_date }}',
                                        '{{ data_date }}',
                                          CURRENT_TIMESTAMP
                                     
                                    )
                                {% endset %}
                                {% do run_query(insert_query) %}
                                {{ log("Test result inserted: " ~ test_name ~ " - Status: " ~ test_status ~ " - Row " ~ loop.index ~ " of " ~ test_results.rows|length, info=true) }}
                            {% else %}
                                {{ log("Test result skipped: " ~ test_name ~ " - Invalid row " ~ loop.index, info=true) }}
                            {% endif %}
                        {% endfor %}
                        {{ log("Test completed: " ~ test_name ~ " - " ~ test_results.rows|length ~ " result(s) inserted into RECON.TEST_RESULTS", info=true) }}
                    {% else %}
                        {{ log("Test skipped: " ~ test_name ~ " - No rows returned", info=true) }}
                    {% endif %}
                {% else %}
                    {{ log("Test skipped: " ~ test_name ~ " - No macro available to handle this test_name", info=true) }}
                {% endif %}
            {% endfor %}
            {{ log("Row count check framework execution completed. Execution ID: " ~ execution_id, info=true) }}
        {% else %}
            {{ log("No enabled row count tests found in configuration", info=true) }}
        {% endif %}
    {% endif %}
{% endmacro %}