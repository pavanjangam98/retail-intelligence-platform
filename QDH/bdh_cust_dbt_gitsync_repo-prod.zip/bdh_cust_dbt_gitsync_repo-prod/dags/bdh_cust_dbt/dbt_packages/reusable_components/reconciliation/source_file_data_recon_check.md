{% docs source_file_data_recon_check___desc %}
Performs watermark-based file-level data reconciliation between source and target tables. Validates data consistency by comparing record counts and key checksums for files loaded since the last successful reconciliation.
{% enddocs %}

{% docs source_file_data_recon_check___test_name %}
The descriptive name of the reconciliation test. Example: 'Customer Data File Reconciliation'
{% enddocs %}

{% docs source_file_data_recon_check___test_type %}
The type/category of the reconciliation test. Example: 'FILE_RECON', 'DATA_QUALITY'
{% enddocs %}

{% docs source_file_data_recon_check___test_id %}
Unique identifier for this reconciliation test. Used to track watermark in TEST_RESULTS table. Example: 'RECON_CUSTOMER_001'
{% enddocs %}

{% docs source_file_data_recon_check___source_table %}
Fully qualified source table name containing file metadata with columns: extraction_date, file_name, record_count, key_checksum. Example: ref('source_file_metadata')
{% enddocs %}

{% docs source_file_data_recon_check___target_table %}
Fully qualified target table name containing loaded data with metadata$filename and load date field. Example: ref('stg_customer_data')
{% enddocs %}

{% docs source_file_data_recon_check___source_where_clause %}
Optional WHERE clause filter for source table. Supports ${DATA_DATE} variable substitution. Example: "status = 'PROCESSED'"
{% enddocs %}

{% docs source_file_data_recon_check___target_where_clause %}
Optional WHERE clause filter for target table. Supports ${DATA_DATE} variable substitution. Example: "is_deleted = FALSE"
{% enddocs %}

{% docs source_file_data_recon_check___target_select_fields %}
Comma-separated list of key columns for checksum calculation. Example: 'customer_id,transaction_date'
{% enddocs %}

{% docs source_file_data_recon_check___threshold_value %}
Maximum acceptable variance percentage for record counts. Default: 1.0 (1% variance allowed). Example: 0.5, 2.0
{% enddocs %}

{% docs source_file_data_recon_check___source_date_field %}
Name of the date column in source table. Default: 'extraction_date'. Example: 'file_date'
{% enddocs %}

{% docs source_file_data_recon_check___target_date_field %}
Name of the date column in target table. Default: 'load_date'. Example: 'insertion_date'
{% enddocs %}

{% docs source_file_data_recon_check___data_date_variable %}
Name of dbt variable containing business date for data run. Used for date substitution in where clauses. Example: 'run_date'
{% enddocs %}
