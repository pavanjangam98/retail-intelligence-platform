{% docs row_count_aggregation_check___desc %}
Performs row count validation or aggregation checks between source and target tables. Supports full and incremental comparisons with configurable thresholds. For Row Count Check: validates record counts. For Aggregation Check: compares SUM, COUNT, AVG, MIN, MAX values.
{% enddocs %}

{% docs row_count_aggregation_check___test_name %}
Test name determining execution logic. Must be 'Row Count Check' or 'Aggregation Check'. Example: 'Row Count Check'
{% enddocs %}

{% docs row_count_aggregation_check___test_type %}
Test type identifier for reporting and result tracking. Example: 'ROW_COUNT', 'AGGREGATION'
{% enddocs %}

{% docs row_count_aggregation_check___source_table %}
Fully qualified source table name. Used when iscustomsql='N'. Example: ref('source_data')
{% enddocs %}

{% docs row_count_aggregation_check___target_table %}
Fully qualified target table name. Used when iscustomsql='N'. Example: ref('target_data')
{% enddocs %}

{% docs row_count_aggregation_check___source_where_clause %}
Optional WHERE clause filter for source. Supports ${DATA_DATE} or $DATA_DATE substitution. Example: "status = 'ACTIVE'"
{% enddocs %}

{% docs row_count_aggregation_check___target_where_clause %}
Optional WHERE clause filter for target. Supports ${DATA_DATE} or $DATA_DATE substitution. Example: "is_deleted = FALSE"
{% enddocs %}

{% docs row_count_aggregation_check___source_select_fields %}
Optional GROUP BY columns for source. Used for grouped comparisons. Example: 'customer_id, region'
{% enddocs %}

{% docs row_count_aggregation_check___target_select_fields %}
Optional GROUP BY columns for target. Used for grouped comparisons. Example: 'customer_id, region'
{% enddocs %}

{% docs row_count_aggregation_check___source_aggregate_fields %}
Columns to aggregate in source for Aggregation Check. Comma-separated list. Example: 'amount, quantity'
{% enddocs %}

{% docs row_count_aggregation_check___target_aggregate_fields %}
Columns to aggregate in target for Aggregation Check. Comma-separated list. Example: 'amount, quantity'
{% enddocs %}

{% docs row_count_aggregation_check___aggregate_functions %}
Aggregate functions to apply. Comma-separated list. Default: 'sum,count,avg,min,max'. Example: 'sum,count'
{% enddocs %}

{% docs row_count_aggregation_check___source_sql %}
Optional custom SQL query for source data. Used when iscustomsql='Y'. Example: 'SELECT * FROM schema.table WHERE condition'
{% enddocs %}

{% docs row_count_aggregation_check___target_sql %}
Optional custom SQL query for target data. Used when iscustomsql='Y'. Example: 'SELECT * FROM schema.table WHERE condition'
{% enddocs %}

{% docs row_count_aggregation_check___iscustomsql %}
Flag indicating if custom SQL is used. 'Y' for custom SQL, 'N' for table names. Example: 'Y' or 'N'
{% enddocs %}

{% docs row_count_aggregation_check___threshold_value %}
Maximum acceptable variance percentage. Default: 1.0 (1% variance allowed). Example: 0.5, 2.0, 5.0
{% enddocs %}

{% docs row_count_aggregation_check___data_date_variable %}
Name of dbt variable containing business date. Used for ${DATA_DATE} substitution in where clauses and incremental filtering. Example: 'run_date'
{% enddocs %}

{% docs row_count_aggregation_check___comparison_type %}
Comparison mode: 'full' for entire dataset or 'incremental' for date-filtered comparison. Default: 'full'. Example: 'incremental'
{% enddocs %}

{% docs row_count_aggregation_check___incremental_comparison_interval %}
Interval for incremental comparison. Used when comparison_type='incremental'. Options: 'daily', 'weekly', 'monthly'. Example: 'daily'
{% enddocs %}

{% docs row_count_aggregation_check___source_date_field %}
Date column in source for incremental filtering. Required when comparison_type='incremental'. Example: 'created_date'
{% enddocs %}

{% docs row_count_aggregation_check___target_date_field %}
Date column in target for incremental filtering. Required when comparison_type='incremental'. Example: 'load_date'
{% enddocs %}
