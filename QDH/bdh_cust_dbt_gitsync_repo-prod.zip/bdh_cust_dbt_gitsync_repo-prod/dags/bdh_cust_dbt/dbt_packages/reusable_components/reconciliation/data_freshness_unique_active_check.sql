{%- macro data_freshness_unique_active_check(
    test_name,
	test_type,
	source_table,
	target_table,
	source_where_clause=none,
	target_where_clause=none,
	source_freshness_column=none,
	target_freshness_column=none,
	threshold_value=none,
	source_unique_columns=none,
	target_unique_columns=none, 
	source_sql=none, 
	target_sql=none, 
	data_date_variable=none) 
-%}

{# Setup data date variable handling #}
{%- if data_date_variable is not none -%}
    {%- set data_date_value = var(data_date_variable) -%}
    {%- set data_date_sql = "TO_DATE('" + data_date_value|string + "')" -%}
{%- else -%}
    {%- set data_date_sql = 'CURRENT_DATE()' -%}
{%- endif -%}

{# Parse source_unique_columns for unique_active_check #}
{%- if source_unique_columns is not none -%}
    {%- set source_unique_cols_list = source_unique_columns.split(',') -%}
    {%- set source_unique_cols_clean = [] -%}
    {%- for col in source_unique_cols_list -%}
        {%- set _ = source_unique_cols_clean.append(col.strip()) -%}
    {%- endfor -%}
{%- else -%}
    {%- set source_unique_cols_clean = [] -%}
{%- endif -%}

{# Parse target_unique_columns for unique_active_check #}
{%- if target_unique_columns is not none -%}
    {%- set target_unique_cols_list = target_unique_columns.split(',') -%}
    {%- set target_unique_cols_clean = [] -%}
    {%- for col in target_unique_cols_list -%}
        {%- set _ = target_unique_cols_clean.append(col.strip()) -%}
    {%- endfor -%}
{%- else -%}
    {%- set target_unique_cols_clean = [] -%}
{%- endif -%}

{# Process where clauses with variable substitution #}
{%- set processed_source_where = source_where_clause -%}
{%- set processed_target_where = target_where_clause -%}

{%- if data_date_variable is not none -%}
    {%- if processed_source_where is not none -%}
        {%- set processed_source_where = processed_source_where.replace('${DATA_DATE}', "'" + data_date_value|string + "'") -%}
        {%- set processed_source_where = processed_source_where.replace('$DATA_DATE', "'" + data_date_value|string + "'") -%}
    {%- endif -%}
    {%- if processed_target_where is not none -%}
        {%- set processed_target_where = processed_target_where.replace('${DATA_DATE}', "'" + data_date_value|string + "'") -%}
        {%- set processed_target_where = processed_target_where.replace('$DATA_DATE', "'" + data_date_value|string + "'") -%}
    {%- endif -%}
{%- endif -%}


{%- set tolerance_percentage = threshold_value | default('1.0') | float -%}

{# Enhanced CTEs that support both table and SQL query sources #}
with source_base as (
    {%- if source_sql is not none -%}
    select * from (
        {{ source_sql }}
    ) as source_query_result
    {%- else -%}
    select * from {{ source_table }}
    {% endif %}
    where 1=1
    {% if processed_source_where is not none %}
    and ({{ processed_source_where }})
    {% endif %}
),
target_base as (
    {%- if target_sql is not none -%}
    select * from (
        {{ target_sql }}
    ) as target_query_result
    {%- else -%}
    select * from {{ target_table }}
    {% endif %}
    where 1=1
    {% if processed_target_where is not none %}
    and ({{ processed_target_where }})
    {% endif %}
),

{# Test Type Specific Logic #}
{%- if test_name == 'FRESHNESS_CHECK' -%}
    {# Data Freshness Check Logic #}
    source_freshness as (
        select 
            count(*) as total_records,
            max({{ source_freshness_column }}) as latest_timestamp,
            min({{ source_freshness_column }}) as earliest_timestamp,
            count(case when {{ source_freshness_column }} >= dateadd(hour, - {{ threshold_value }}, current_timestamp()) then 1 end) as fresh_records,
            count(case when {{ source_freshness_column }} < dateadd(hour,  - {{ threshold_value }}, current_timestamp()) then 1 end) as stale_records
        from source_base
        where {{ source_freshness_column }} is not null
    ),
    target_freshness as (
        select 
            count(*) as total_records,
            max({{ target_freshness_column }}) as latest_timestamp,
            min({{ target_freshness_column }}) as earliest_timestamp,
            count(case when {{ target_freshness_column }} >= dateadd(hour, - {{ threshold_value }}, current_timestamp()) then 1 end) as fresh_records,
            count(case when {{ target_freshness_column }} < dateadd(hour,  - {{ threshold_value }}, current_timestamp()) then 1 end) as stale_records
        from target_base
        where {{ target_freshness_column }} is not null
    ),
    comparison as (
        select
            '{{ test_type }}' as test_type,
            s.total_records as source_record_count,
            t.total_records as target_record_count,
            s.latest_timestamp as source_latest_timestamp,
            t.latest_timestamp as target_latest_timestamp,
            s.fresh_records as source_fresh_records,
            t.fresh_records as target_fresh_records,
            s.stale_records as source_stale_records,
            t.stale_records as target_stale_records,

            case 
                when s.latest_timestamp >= dateadd(hour, - {{ threshold_value }}, current_timestamp())
                 and t.latest_timestamp >= dateadd(hour, - {{ threshold_value }}, current_timestamp())
                 and abs(s.fresh_records - t.fresh_records) = 0 then 'PASS'
                else 'FAIL'
            end as status,
            case
                when s.latest_timestamp < dateadd(hour, - {{ threshold_value }}, current_timestamp()) then 'SOURCE_DATA_STALE'
                when t.latest_timestamp < dateadd(hour, - {{ threshold_value }}, current_timestamp()) then 'TARGET_DATA_STALE'
                when abs(s.fresh_records - coalesce(t.fresh_records,0)) > 0 then 'DATA_FRESH_ROW_COUNT_MISMATCHED'
                else 'DATA_FRESH_ROW_COUNT_MATCHED'
            end as validation_message,           
            abs(s.fresh_records - t.fresh_records) as fresh_count_difference,
            timestampdiff(hour, least(s.latest_timestamp, t.latest_timestamp), current_timestamp()) as hours_since_latest_data,
            round(
                case 
                    when greatest(s.fresh_records, t.fresh_records) = 0 then 0
                    else (abs(s.fresh_records - t.fresh_records) * 100.0) / greatest(s.fresh_records, t.fresh_records)
                end, 2
            ) as variance_percentage
        from source_freshness s, target_freshness t
    )
    SELECT   
        test_type,
        source_fresh_records as source_result,
        target_fresh_records as target_result,
        concat(
            'Data refreshed since : ', cast(hours_since_latest_data as string), ' hrs',
			 ', Source Date field: {{ source_freshness_column }}',
             ', Target Date field: {{ target_freshness_column }}',
            {%- if data_date_variable is not none -%}
            ', Data Date Variable: {{ data_date_variable }}',
            ', Data Date Value: {{ data_date_value }}',
			{%- endif -%}
			', Threshold: {{ threshold_value }} hrs'
        ) as description,
        status as test_passed,
		 case
            when greatest(source_fresh_records, target_fresh_records) = 0 then 'NO_DATA'
            when hours_since_latest_data <= {{ threshold_value }} then 'WITHIN_THRESHOLD'
            else 'EXCEEDS_THRESHOLD'
        end as threshold_status,
        validation_message,       
        fresh_count_difference as variance_difference,
        variance_percentage,
		DATE('1900-01-01') as last_file_processed_date,		
        {%- if data_date_variable is not none -%}
         TO_DATE('{{ data_date_value }}') as data_date
        {%- else -%}
        DATE('1900-01-01') as data_date
        {% endif %}         
    FROM comparison
 {%- elif test_name == 'UNIQUE_ACTIVE_CHECK' -%}
    {# Unique Active Check Logic with separate source and target unique columns #}
    {%- if source_unique_cols_clean|length == 0 or target_unique_cols_clean|length == 0 -%}
        {# Error handling for missing unique columns #}
        select 
        'CONFIGURATION_ERROR' as test_type,
        null as source_result,
        null as target_result,
        '' as description,
        'FAIL' as test_passed,
        'UNKNOWN' as threshold_status,
        '{{ error_msg }}' as validation_message,
        null as variance_difference,
        null as variance_percentage, 
        DATE('1900-01-01') as last_file_processed_date,
        DATE('1900-01-01') as data_date
    {%- else -%}
		source_grouped as (
		  select 
                {% for col in source_unique_cols_clean %}coalesce({{ col }}, 'NULL'){% if not loop.last %}, {% endif %}{% endfor %},
                count(*) as occurrence_count
            from source_base
            group by {% for col in source_unique_cols_clean %}{{ col }}{% if not loop.last %}, {% endif %}{% endfor %}
		),
        target_grouped as (
            select 
                {% for col in target_unique_cols_clean %}coalesce({{ col }}, 'NULL'){% if not loop.last %}, {% endif %}{% endfor %},
                count(*) as occurrence_count
            from target_base
            group by {% for col in target_unique_cols_clean %}{{ col }}{% if not loop.last %}, {% endif %}{% endfor %}
        ),
        source_unique as (
            select 
                (select count(*) from source_base) as total_records,
                count(*) as unique_combinations,
                coalesce(sum(case when occurrence_count > 1 then occurrence_count - 1 else 0 end), 0) as duplicate_records,
                coalesce(sum(case when occurrence_count > 1 then 1 else 0 end), 0) as duplicate_groups
            from source_grouped
        ),
        target_unique as (
            select 
                (select count(*) from target_base) as total_records,
                count(*) as unique_combinations,
                coalesce(sum(case when occurrence_count > 1 then occurrence_count - 1 else 0 end), 0) as duplicate_records,
                coalesce(sum(case when occurrence_count > 1 then 1 else 0 end), 0) as duplicate_groups
            from target_grouped
        ),
        comparison as (
            select
                '{{ test_type }}' as test_type,
                s.total_records as source_record_count,
                t.total_records as target_record_count,
                s.unique_combinations as source_unique_combinations,
                t.unique_combinations as target_unique_combinations,
                s.duplicate_records as source_duplicate_records,
                t.duplicate_records as target_duplicate_records,
                s.duplicate_groups as source_duplicate_groups,
                t.duplicate_groups as target_duplicate_groups,
                case 
                    when s.duplicate_records = 0 and t.duplicate_records = 0 
                     and s.unique_combinations = t.unique_combinations then 'PASS'
                    else 'FAIL'
                end as status,
                case
                    when s.duplicate_records > 0 and t.duplicate_records > 0 then 'BOTH_HAVE_DUPLICATES'
                    when s.duplicate_records > 0 then 'SOURCE_HAS_DUPLICATES'
                    when t.duplicate_records > 0 then 'TARGET_HAS_DUPLICATES'
                    when s.unique_combinations != t.unique_combinations then 'UNIQUE_COUNT_MISMATCHED'
                    else 'UNIQUE_COUNT_MATCHED'
                end as validation_message,
                case
                    when greatest(s.unique_combinations, t.unique_combinations) = 0 then 'NO_DATA'
                    when round(
                        case 
                            when greatest(s.unique_combinations, t.unique_combinations) = 0 then 0
                            else (abs(s.unique_combinations - t.unique_combinations) * 100.0) / greatest(s.unique_combinations, t.unique_combinations)
                        end, 2
                    ) <= {{ tolerance_percentage }} then 'WITHIN_THRESHOLD'
                    else 'EXCEEDS_THRESHOLD'
                end as threshold_status,
                abs(s.unique_combinations - t.unique_combinations) as unique_combination_difference,
                round(
                    case 
                        when greatest(s.unique_combinations, t.unique_combinations) = 0 then 0
                        else (abs(s.unique_combinations - t.unique_combinations) * 100.0) / greatest(s.unique_combinations, t.unique_combinations)
                    end, 2
                ) as variance_percentage
            from source_unique s, target_unique t
        )
        SELECT   
            test_type,
            source_unique_combinations as source_result,
            target_unique_combinations as target_result,
            concat(
                'Source Unique Columns: {{ source_unique_columns }}',
                ', Target Unique Columns: {{ target_unique_columns }}',
                ', Source Duplicates: ', cast(source_duplicate_records as string),
                ', Target Duplicates: ', cast(target_duplicate_records as string),
                {%- if data_date_variable is not none -%}
                ', Data Date Variable: {{ data_date_variable }}',
                ', Data Date Value: {{ data_date_value }}',
                {%- endif -%}
                ', Threshold: {{ threshold_value }}%'
            ) as description,
            status as test_passed,           
            threshold_status,
            validation_message,
            unique_combination_difference as variance_difference,
            variance_percentage,
            DATE('1900-01-01') as last_file_processed_date,
            {%- if data_date_variable is not none -%}
            TO_DATE('{{ data_date_value }}') as data_date
            {%- else -%}
            DATE('1900-01-01') as data_date
            {% endif %}         
        from comparison
    {%- endif -%}
 
{%- else -%}
    select 
       'CONFIGURATION_ERROR' as test_type,
        null as source_result,
        null as target_result,
        '' as description,
        'FAIL' as test_passed,
        'UNKNOWN' as threshold_status,
        '{{ error_msg }}' as validation_message,
        null as variance_difference,
        null as variance_percentage, 
        DATE('1900-01-01') as last_file_processed_date,
        DATE('1900-01-01') as data_date
{%- endif -%}

{%- endmacro -%}