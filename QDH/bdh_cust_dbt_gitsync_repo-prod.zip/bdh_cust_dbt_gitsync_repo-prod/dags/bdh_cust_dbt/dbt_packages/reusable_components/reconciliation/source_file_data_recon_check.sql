{% macro source_file_data_recon_check(
    test_name,
    test_type,
    test_id,
    source_table,
    target_table, 
    source_where_clause=none,
    target_where_clause=none, 
    target_select_fields=none,
    threshold_value=none, 
    source_date_field=none, 
    target_date_field=none,
    data_date_variable=none
) %}
    {%- set environment = target.name.lower() -%}
    {%- set bdh_db = var('DBT_DATABASE') -%}

    {%- if target_select_fields is not none -%}
        {%- set key_cols_list = target_select_fields.split(',') -%}
        {%- set key_cols_clean = [] -%}
        {%- for col in key_cols_list -%}
            {%- set _ = key_cols_clean.append(col.strip()) -%}
        {%- endfor -%}
    {%- else -%}
        {%- set key_cols_clean = [] -%}
    {%- endif -%}

    {%- if source_date_field is none or source_date_field == 'None' or source_date_field == '' or source_date_field == 'null' -%}
        {%- set source_date_field = 'extraction_date' -%}
    {%- endif -%}

    {%- if target_date_field is none or target_date_field == 'None' or target_date_field == '' or target_date_field == 'null' -%}
        {%- set target_date_field = 'load_date' -%}
    {%- endif -%}  

    {# Set default threshold if not provided - handle None, null, and empty values #}
    {%- if threshold_value is none or threshold_value == 'None' or threshold_value == '' or threshold_value == 'null' -%}
        {%- set threshold_value_clean = 1.0 -%}
    {%- else -%}
        {%- set threshold_value_clean = threshold_value | float -%}
    {%- endif -%}

    {# Setup data date variable handling #}
    {%- if data_date_variable is not none -%}
        {%- set data_date_value = var(data_date_variable) -%}
        {%- set data_date_sql = "TO_DATE('" + data_date_value|string + "')" -%}
    {%- else -%}
        {%- set data_date_sql = 'CURRENT_DATE()' -%}
    {%- endif -%}

    {# Process where clauses with variable substitution #}
    {%- set processed_source_where = source_where_clause -%}
    {%- set processed_target_where = target_where_clause -%}

    {%- if data_date_variable is not none -%}
        {%- if processed_source_where is not none -%}
            {%- set processed_source_where = processed_source_where.replace('${DATA_DATE}', "'" + data_date_value|string + "'") -%}
            {%- set processed_source_where = processed_source_where.replace('$DATA_DATE', "'" + data_date_value|string + "'") -%}
        {%- endif -%}
        {%- if processed_target_where is not none -%}
            {%- set processed_target_where = processed_target_where.replace('${DATA_DATE}', "'" + data_date_value|string + "'") -%}
            {%- set processed_target_where = processed_target_where.replace('$DATA_DATE', "'" + data_date_value|string + "'") -%}
        {%- endif -%}
    {%- endif -%}

    -- Get the last successful reconciliation date from watermark table
    WITH watermark_base AS (
        SELECT DISTINCT
            COALESCE(MAX(last_file_processed_date), DATE('1900-01-01')) as last_recon_date
            FROM {{ bdh_db }}__{{ environment }}.RECON.TEST_RESULTS 
        WHERE TEST_ID = '{{ test_id }}'       
            AND TEST_TYPE = '{{ test_type }}'
          
    ),

    -- Get all extraction dates that need to be processed (after watermark)
    dates_to_process_base AS (
        SELECT DISTINCT
            DATE({{ source_date_field }}) as process_date           
        FROM {{ source_table }}
        CROSS JOIN watermark_base
        WHERE DATE({{ source_date_field }}) > watermark_base.last_recon_date 
         
        {%- if processed_source_where is not none %}
            AND ({{ processed_source_where }})
        {%- endif %}
        ORDER BY process_date
    ),

    -- Get source data for all files that need processing
    source_base AS (
        SELECT
            DATE(s.{{ source_date_field }}) as process_date,
            s.file_name,                     
            s.record_count as source_record_count,
            s.key_checksum as source_key_checksum
        FROM {{ source_table }} s
        INNER JOIN dates_to_process_base dtp 
            ON DATE(s.{{ source_date_field }}) = dtp.process_date
        WHERE 1=1 
        {%- if processed_source_where is not none %}
            AND ({{ processed_source_where }})
        {%- endif %}
    ),

    -- Get target data for corresponding dates and files
    target_base AS (
        SELECT 
            DATE(t.{{ target_date_field }}) as process_date,
            split_part(t.metadata$filename,'/',-1) AS file_name,
            COUNT(*) as target_record_count,
            {%- if key_cols_clean | length > 0 %}
            SUM(
                ABS(
                    CAST(
                        HASH(
                        {%- for col in key_cols_clean -%}
                            COALESCE(CAST(t.{{ col }} AS STRING), 'NULL')
                            {%- if not loop.last -%},{%- endif -%}
                        {%- endfor -%}
                        ) AS BIGINT
                    )
                )
            ) as target_key_checksum
            {%- else %}
            0 as target_key_checksum
            {%- endif %}
        FROM {{ target_table }} t
        INNER JOIN dates_to_process_base dtp 
            ON DATE(t.{{ target_date_field }}) = dtp.process_date
        WHERE 1=1 
        {%- if processed_target_where is not none %}
            AND ({{ processed_target_where }})
        {%- endif %}
        GROUP BY 
            DATE(t.{{ target_date_field }}),
            t.metadata$filename
    ),

    -- Perform reconciliation for each file
    reconciliation AS (
        SELECT 
            '{{ test_name }}' as test_name,
            s.process_date,
            s.file_name,
            s.source_record_count,
            s.source_key_checksum,
            COALESCE(t.target_record_count, 0) as target_record_count,
            COALESCE(t.target_key_checksum, 0) as target_key_checksum,

            -- Record count reconciliation
            CASE 
                WHEN s.source_record_count = COALESCE(t.target_record_count, 0) THEN 'PASS'
                ELSE 'FAIL'
            END as record_count_status,

            -- Key checksum reconciliation
            CASE 
                WHEN s.source_key_checksum = COALESCE(t.target_key_checksum, 0) THEN 'PASS'
                ELSE 'FAIL'
            END as key_checksum_status,

            -- Overall status
            CASE 
                WHEN s.source_record_count = COALESCE(t.target_record_count, 0)
                    AND s.source_key_checksum = COALESCE(t.target_key_checksum, 0) THEN 'PASS'
                ELSE 'FAIL'
            END as overall_status,

            -- Differences
            s.source_record_count - COALESCE(t.target_record_count, 0) as record_count_diff,
            s.source_key_checksum - COALESCE(t.target_key_checksum, 0) as key_checksum_diff,

            -- Variance percentage calculation (corrected)
            ROUND(
                CASE 
                    WHEN s.source_record_count = 0 AND COALESCE(t.target_record_count, 0) = 0 THEN 0
                    WHEN s.source_record_count = 0 THEN 100.0
                    ELSE (ABS(s.source_record_count - COALESCE(t.target_record_count, 0)) * 100.0) / s.source_record_count
                END, 2
            ) as variance_percentage,

            -- Validation message
            CASE
                WHEN s.source_record_count = COALESCE(t.target_record_count, 0) THEN 'ROW_COUNT_MATCHED'               
                ELSE 'ROW_COUNT_MISMATCHED'
            END as validation_message,

            -- Description with more context
            CASE
                WHEN s.source_record_count = COALESCE(t.target_record_count, 0)
                    AND s.source_key_checksum = COALESCE(t.target_key_checksum, 0)
                THEN CONCAT('Watermark-based reconciliation passed successfully for file : ', s.file_name, ': Source=', 
                           CAST(s.source_record_count AS STRING), ', Target=', 
                           CAST(COALESCE(t.target_record_count, 0) AS STRING),' Source file Extraction Date=',s.process_date)
                WHEN s.source_record_count != COALESCE(t.target_record_count, 0)
                THEN CONCAT('Record count mismatch for file ', s.file_name, ': Source=', 
                           CAST(s.source_record_count AS STRING), ', Target=', 
                           CAST(COALESCE(t.target_record_count, 0) AS STRING),' Source file Extraction Date=',s.process_date)
                WHEN s.source_key_checksum != COALESCE(t.target_key_checksum, 0)
                THEN CONCAT('Key checksum mismatch detected for file', s.file_name, ' - data quality issue suspected', ': Source=', 
                           CAST(s.source_key_checksum AS STRING), ', Target=', 
                           CAST(COALESCE(t.target_key_checksum, 0) AS STRING),'Source file Extraction Date=',s.process_date)
                ELSE 'Unknown reconciliation issue for file: ' || s.file_name
            END as description,

            -- Threshold status (corrected calculation)
            CASE 
                WHEN (
                    CASE 
                        WHEN s.source_record_count = 0 AND COALESCE(t.target_record_count, 0) = 0 THEN 0
                        WHEN s.source_record_count = 0 THEN 100.0
                        ELSE (ABS(s.source_record_count - COALESCE(t.target_record_count, 0)) * 100.0) / s.source_record_count
                    END <= {{ threshold_value_clean }}
                ) THEN 'WITHIN_THRESHOLD'
                ELSE 'EXCEEDS_THRESHOLD'
            END as threshold_status

        FROM source_base s
        LEFT JOIN target_base t 
            ON s.process_date = t.process_date 
            AND s.file_name = t.file_name
    )

    -- Final output with individual file results
    SELECT 
        '{{ test_type }}' as test_type,
        source_record_count as source_result,
        target_record_count as target_result,
        description,
        overall_status as test_passed,
        threshold_status,        
        validation_message,
        record_count_diff as variance_difference,
        variance_percentage,
        process_date as last_file_processed_date,
        {%- if data_date_variable is not none -%}
            TO_DATE('{{ data_date_value }}') as data_date
            {%- else -%}
            DATE('1900-01-01') as data_date
        {%- endif %}
    FROM reconciliation
    ORDER BY process_date, file_name

{% endmacro %}