{% test test_unique_columns(model, columns) %}
 
with grouped as (
    -- Iterate through the array of columns used as the composite key and use them to calculate if more than 1 record is present to fail the test.
    select
        {% for col in columns %}
            {{ col }}{% if not loop.last %}, {% endif %}
        {% endfor %},
        count(*) as count
    from {{ model }}
    group by
        {% for col in columns %}
            {{ col }}{% if not loop.last %}, {% endif %}
        {% endfor %}
)
 
select *
from grouped
where count > 1
 
{% endtest %}