{% docs test_unique_columns___desc %}

Tests for unique records based on the composite key of the model. Fails if a record is returned having a count more than 1.

{% enddocs %}

{% docs test_unique_columns___model %}

This is 'model' argument. This act as first argument to this macro.

This is the model name for which we need to execute this test. for e.g. 'raw___bis___bst_customer'

{% enddocs %}

{% docs test_unique_columns___column %}

This is the column of columns, which are acting as Primary keys for the model.

{% enddocs %}