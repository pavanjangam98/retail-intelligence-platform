{{ config(
    materialized='incremental',
    unique_key=['RELATIONSHIP_TYPE_CODE', 'DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy='merge',
    post_hook=["DELETE FROM {{ this }}
    -- This post hook handles record deletion from type 2 table in RAW layer
        WHERE RELATIONSHIP_TYPE_CODE || dwh_effective_from_tstamp
        IN
      (
        SELECT t.RELATIONSHIP_TYPE_CODE || t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___bis___bst_mcust_relntype') }} s
            ON t.RELATIONSHIP_TYPE_CODE = TRIM(s.relationship_type)
            AND CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', t.dwh_effective_from_tstamp)::TIMESTAMP_LTZ = CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', s.dwh_effective_from_tstamp)::TIMESTAMP_LTZ
        WHERE s.RELATIONSHIP_TYPE IS NULL
      )"
    ]
  )
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build -s foundation___fdp__custmstr___fdp__bis_managed_relationship_type_reference --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build -s foundation___fdp__custmstr___fdp__bis_managed_relationship_type_reference --vars '{ "run_type": "full_data_load" }'
defualt values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}

SELECT
    TRIM(S.RELATIONSHIP_TYPE::VARCHAR) AS RELATIONSHIP_TYPE_CODE,
    TRIM(S.RELN_SHORT_DESC::VARCHAR) AS RELATIONSHIP_TYPE_SHORT_DESC,
    TRIM(S.RELATIONSHIP_DESC::VARCHAR) AS RELATIONSHIP_TYPE_DESC,
    TRIM(S.MANAGEMENT_IND::VARCHAR(5)) AS MANAGED_GROUP_FLAG,
    S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
    S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
    {% if is_incremental() %}
    CASE WHEN T.relationship_type_code IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
      WHEN T.relationship_type_code IS NOT NULL THEN T.dwh_process_insert_id
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.relationship_type_code IS NULL THEN NULL
      WHEN T.relationship_type_code IS NOT NULL
    AND T.dwh_effective_to_tstamp <> CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.dwh_effective_to_tstamp)::TIMESTAMP_LTZ THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
      ELSE T.dwh_process_update_id::VARCHAR
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___bis___bst_mcust_relntype') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
  ON TRIM(S.relationship_type) = T.relationship_type_code
 AND CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.dwh_effective_from_tstamp)::TIMESTAMP_LTZ = T.dwh_effective_from_tstamp::TIMESTAMP_LTZ
{% endif %}

WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}
