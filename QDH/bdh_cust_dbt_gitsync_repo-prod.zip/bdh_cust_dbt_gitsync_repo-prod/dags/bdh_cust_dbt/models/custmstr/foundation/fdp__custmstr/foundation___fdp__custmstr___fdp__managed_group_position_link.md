{% docs foundation___fdp__custmstr___fdp__managed_group_position_link %}

This  Model to load data from a view combining the on-going CDC incoming data with the History provided by the Hadoop Data for FDP__MANAGED_GROUP_POSITION_LINK. Designed to remove overlapping timeframes of data.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__managed_group_position_link___position_id %}

Position number the staff member holds

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__managed_group_position_link___managed_group_id %}

The identifier of a managed group.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__managed_group_position_link___relationship_type_code %}

A unique identifier that defines the type of interest a member of staff may have with a managed customer group.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__managed_group_position_link___relationship_create_date %}

The date this relationship was originally setup.

{% enddocs %}
