{% docs foundation___fdp__custmstr___fdp__party_warning_link %}

This foundation product holds warning type applicable to a customer

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_warning_link__customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_warning_link__warning_code %}

The code which uniquely identifies the warning.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_warning_link__warning_date %}

The effective date of the warning for the customer.

{% enddocs %}
