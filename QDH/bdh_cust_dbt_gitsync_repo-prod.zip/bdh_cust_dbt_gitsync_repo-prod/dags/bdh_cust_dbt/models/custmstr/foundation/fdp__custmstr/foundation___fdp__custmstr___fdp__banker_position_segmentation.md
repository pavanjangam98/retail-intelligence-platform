{% docs foundation___fdp__custmstr___fdp__banker_position_segmentation %}

This foundation product defines the segmentation assigned to organizational position numbers.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__banker_position_segmentation___position_id %}

The bnz position number

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__banker_position_segmentation___segmentation_id %}

The id  of the banker segmentation.  Accepted values are 1, 2, 3, 4, 5, 6, 7, 11, 12, 13.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__banker_position_segmentation___segmentation_desc %}

The description of the banker segmentation.  Accepted values are AGRIBUSINESS, COMMERCIAL, BUSINESS, PRIVATE BANK , PROPERTY FINANCE, COST CENTRE EXPENSES, INSTITUTIONAL BANKING, CORPORATE, Small Business Hub, CONSUMER.

{% enddocs %}