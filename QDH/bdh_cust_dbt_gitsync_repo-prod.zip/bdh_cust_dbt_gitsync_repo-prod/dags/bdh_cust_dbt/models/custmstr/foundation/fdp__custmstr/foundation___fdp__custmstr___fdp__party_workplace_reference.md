{% docs foundation___fdp__custmstr___fdp__party_workplace_reference %}

This foundation product holds details on reference data  related to workplace and workplace code

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_workplace_reference__workplace_code %}

A code to define a workplace that can be associated to a person, e.g.
1 - Academic Colleges of NZ
2 - Access Brokerage Ltd

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_workplace_reference__workplace_desc %}

Description of a workplace that can be associated to a person.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_workplace_reference__end_date %}

The end date that this WORK PERK CODE ends upon
A new column to the table in order that staff can “End” a Work Perk and still keep it available to be reopened ata a later date, with the original Customers still associated to it.

{% enddocs %}
