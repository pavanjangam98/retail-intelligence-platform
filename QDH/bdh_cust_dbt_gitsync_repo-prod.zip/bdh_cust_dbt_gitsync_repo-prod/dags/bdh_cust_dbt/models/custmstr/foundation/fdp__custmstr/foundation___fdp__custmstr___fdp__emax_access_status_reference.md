{% docs foundation___fdp__custmstr___fdp__emax_access_status_reference %}
(AI-Generated) This foundation data product contains the status definitions applied to customer channel access identifiers, sourced from EMAX referred to as Channel Access Status EIT_ACS_STATUS in EMAX. Each record represents a status code and its meaning describing whether a customers channel access is active, restricted, or otherwise controlled by the channel system.
{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_access_status_reference___access_status_code %}

Code that lists access status of a Channel Access Identifier, as controlled by the channel system. Holds a description of each Access Status Code.  E.g. A=Active, H=Hot. Unique Identifier/key to the Access List table - FDP__EMAX_ACCESS_STATUS.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_access_status_reference___channel_access_id_type_code %}

 Channel Access Identifier Type. A code to distinguish Access Number(A), Credit Card (C) and Debit Card(D) identifiers. Unique Identifier/key to the Access List table - FDP__EMAX_ACCESS_STATUS.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_access_status_reference___display_flag %}

Indicates Y or N whether this status should be displayed

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_access_status_reference___access_status_desc %}

Description of the access status, for example, 'Cancelled' or 'Hot'

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_access_status_reference___last_update_tstamp %}

The date and time of the last update to the table.

{% enddocs %}