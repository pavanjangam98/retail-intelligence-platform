{% docs foundation___fdp__custmstr___fdp__bis_country_reference %}

This foundation data product contains country reference records that list recognised countries, referred to as BST_COUNTRY in BIS. A typical record represents one country used to standardise customer address, or tax residency information. 

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__bis_country_reference___country_code %}

Uniquely identifies the a country

Unique Identifier/key of the FDP__BIS_COUNTRY_REFERENCE table

{% enddocs %}


{% docs foundation___fdp__custmstr___fdp__bis_country_reference___country_desc %}

The name of a country.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__bis_country_reference___legacy_non_resident_witholding_tax_rate_percent %}

(AI-Generated) Percentage rate applied for Non-Resident Withholding Tax (NRWT) obligations associated with a country. It supports the calculation and application of tax requirements for non-resident customers. 
Unclear data quality - BIS data dictionary states this field is held redundantly for historical reasons. 
Legacy field - added for Hadoop Exit program. To be used for consumption via QDH and not to be consumed from BDH.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__bis_country_reference___legacy_tax_code %}

(AI-Generated) Standardised code representing a tax classification applicable to a country. It enables consistent interpretation and application of tax-related requirements.
Unclear data quality - PPTE shows only A/B data. 
Legacy field - added for Hadoop Exit program. To be used for consumption via QDH and not to be consumed from BDH.

{% enddocs %}
