{% docs foundation___fdp__custmstr___fdp__party_demographic_link %}

This foundation product holds the link between NABSIC industry code, legacy industry code and a customer.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographic_link__customer_id %}

The customer identifier (New NAB Group 6 digit codes)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographic_link__nabsic_code %}

NABSIC Code (New NAB Group 6 digit codes)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographic_link__bis_legacy_code %}

BIS Code (Legacy BNZ 4 digit codes)

{% enddocs %}
