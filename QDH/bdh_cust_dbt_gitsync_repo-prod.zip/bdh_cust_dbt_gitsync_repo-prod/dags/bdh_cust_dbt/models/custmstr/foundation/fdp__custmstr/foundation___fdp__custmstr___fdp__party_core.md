{% docs fdp__party_core %}

This foundation data product contains Customer details. This is created from BST_CUSTOMER.

{% enddocs %}

{% docs fdp__party_core___customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs fdp__party_core___customer_type_code %}

Identifies the type of customer. 'I' = Individual, 'J' = Joint, 'N' = Non-Personal, 'B'
= Branch

{% enddocs %}

{% docs fdp__party_core___short_name %}

An abbreviated version of the customer's name.

{% enddocs %}

{% docs fdp__party_core___legal_name %}

The full legal name by which a customer is identified.

{% enddocs %}

{% docs fdp__party_core___salutation_name %}

Name that is to appear on correspondance ie Dear < salutation> This contains the full
salutation (title and name), eg 'MR HAYES'.

{% enddocs %}

{% docs fdp__party_core___start_date %}

The date at which the Customer became a customer of the Bank for that specific
application system.

{% enddocs %}

{% docs fdp__party_core___end_date %}

The date on which the consumer ceased to be a customer of the bank.

{% enddocs %}

{% docs fdp__party_core___branch_id %}

The identifying number of a BNZ Branch.

{% enddocs %}

{% docs fdp__party_core___formal_name %}

The formal name by which a Customer is identified.

{% enddocs %}

{% docs fdp__party_core___corporate_id %}

An identifier for a corporate commercial customer for use in systems external to IBIS.

{% enddocs %}

{% docs fdp__party_core___credit_check_code %}

Code indicating status of credit check against the customer

{% enddocs %}

{% docs fdp__party_core___customer_archive_status_code %}

A code to define the archiving status for a customer, i.e. H = Historic A = Archive I =
Inactive??

{% enddocs %}

{% docs fdp__party_core___inland_revenue_department_id %}

The number that uniquely identifies a customer within the Inland \Revenue Department.

{% enddocs %}

{% docs fdp__party_core___lending_category_code %}

Represents customer's "actual" lending category based on current loan limits and security values. It is from a weekly calculation process that runs like this,
 [a] extract loans, product, customer, security and linkages from GDW (once per week, runs on a Sunday evening)
 [b] Run the entire lending portfolio through the LCC calculation (bulk process)
 [c] load via GEP to GDW/FCH (goes into the IP_CUS_SPCF_CLSIF table where CLSIF_TYPE_CDE = 'LNDCAT')
 [d] load to BST_CUSTOMER

{% enddocs %}

{% docs fdp__party_core___non_resident_levy_code %}

Indicates whether the customer has waived Non Resident Withholding Tax in favour of a 2%
tax.

{% enddocs %}

{% docs fdp__party_core___non_resident_code %}

Uniquely identifies the a country

{% enddocs %}

{% docs fdp__party_core___phone_id_text %}

A word or phrase chosen by the customer to identify themselves when telephoning a CEC
(Customer Enquiry Centre).

{% enddocs %}

{% docs fdp__party_core___resident_witholding_tax_exempt_code %}

An indicator to show whether or not this customer is exempt from paying RWT.

{% enddocs %}

{% docs fdp__party_core___tax_code %}

The tax code applicable to residents of the country N = RWT, 21.5 % ( IRD Number known )
O = RWT, 33 % ( IRD Numberunknown ) A = NRWT, 10 % B = NRWT, 15 % C = NRWT, 30 % L =
AIL, 2%

{% enddocs %}

{% docs fdp__party_core___business_purpose_code %}

Business Purpose Code like SI, IN…

{% enddocs %}

{% docs fdp__party_core___last_change_operation_code %}

The operator code of the operator who last updated the customer.

{% enddocs %}

{% docs fdp__party_core___last_change_tstamp %}

A timestamp indicating the time and date an operator last updated this customer.

{% enddocs %}

{% docs fdp__party_core___customer_potential_code %}

The code defining the potential worth that a customer has to the organisation.

{% enddocs %}

{% docs fdp__party_core___legacy_kyc_staff_user_id %}

(AI-Generated) Identifier of the person who performed the Know Your Customer (KYC) action. It supports governance, traceability, and accountability for customer verification activities. 
For individual customers, KYC status should be sourced from FDP__PARTY_PROFILE_SCORE/FDP__PARTY_PROFILE_SCORE_GAP, as legacy KYC fields in bst_customer are inaccurate. 
Legacy field - added for Hadoop Exit program. To be used for consumption via QDH and not to be consumed from BDH.

{% enddocs %}

{% docs fdp__party_core___legacy_kyc_action_date %}

(AI-Generated) Date on which a Know Your Customer (KYC) action was completed. It provides evidence of verification activity and supports lifecycle and compliance monitoring. 
For individual customers, KYC status should be sourced from FDP__PARTY_PROFILE_SCORE/FDP__PARTY_PROFILE_SCORE_GAP, as legacy KYC fields in bst_customer are inaccurate. 
Legacy field - added for Hadoop Exit program. To be used for consumption via QDH and not to be consumed from BDH.

{% enddocs %}
 