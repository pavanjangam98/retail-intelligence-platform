{% docs foundation___fdp__custmstr___fdp__party_workplace_link %}

This foundation product holds relationship between customer and workplace.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_workplace_link___customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_workplace_link___last_update_user_id %}

The user or system id of the last update to the table.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_workplace_link___workplace_code %}

A code to define a workplace that can be associated to a person, e.g.
1 - Academic Colleges of NZ
2 - Access Brokerage Ltd

{% enddocs %}
