{% docs foundation___fdp__custmstr___fdp__party_profile_score %}

This foundation product holds details of KYC scores

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score__customer_id %}

The customer identifier

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score__score_type_code %}

Type of score.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score__is_eligible_for_score_flag %}

Whether customer is eligible for scoring for score type

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score__rule_file_link_text %}

Link to the version of the rules used for score calculation

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score__rule_version_code %}

 Version of the scoring rules used to calculate the score

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score__score_last_updated_tstamp %}

Date and time when the score was last updated

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score__profile_score %}

Customer profile score value between 0 and 1 rounded to two digits

{% enddocs %}
