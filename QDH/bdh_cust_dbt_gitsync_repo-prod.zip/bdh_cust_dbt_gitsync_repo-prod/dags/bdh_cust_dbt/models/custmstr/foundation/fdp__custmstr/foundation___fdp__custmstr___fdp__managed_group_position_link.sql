{{ config(
    materialized='incremental',
    unique_key=['POSITION_ID', 'MANAGED_GROUP_ID', 'RELATIONSHIP_TYPE_CODE',   'DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
    -- This post hook handles record deletion from type 2 table in RAW layer    
        WHERE POSITION_ID || MANAGED_GROUP_ID || RELATIONSHIP_TYPE_CODE ||  dwh_effective_from_tstamp 
        in
      (
        SELECT t.POSITION_ID || t.MANAGED_GROUP_ID || t.RELATIONSHIP_TYPE_CODE ||   t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___bis___bst_mcust_grp_reln') }} s
            ON t.POSITION_ID = Trim(s.POSITION_NO)
		        AND t.MANAGED_GROUP_ID = Trim(s.MANAGED_GROUP_NO)
		        AND t.RELATIONSHIP_TYPE_CODE = Trim(s.RELATIONSHIP_TYPE)
            AND T.dwh_effective_from_tstamp = CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ
        WHERE s.POSITION_NO IS NULL
      )"
    ]
  ) 
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select foundation___fdp__custmstr___fdp__managed_group_position_link --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select foundation___fdp__custmstr___fdp__managed_group_position_link --vars '{ "run_type": "full_data_load" }'
defualt values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else -%}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif -%}

SELECT
    --Standardise column names as a part of foundataional data product.
    TRIM(S.POSITION_NO::VARCHAR) AS POSITION_ID,
	  TRIM(S.MANAGED_GROUP_NO::VARCHAR) AS MANAGED_GROUP_ID,
	  TRIM(S.RELATIONSHIP_TYPE::VARCHAR) AS RELATIONSHIP_TYPE_CODE,
	  TRIM(S.RELN_CREATE_DATE::DATE) AS RELATIONSHIP_CREATE_DATE,
    S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
    S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
    {% if is_incremental() %}
    CASE WHEN T.POSITION_ID IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         WHEN T.POSITION_ID IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.POSITION_ID IS NULL THEN NULL
         WHEN T.POSITION_ID IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> S.DWH_EFFECTIVE_TO_TSTAMP THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}

LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___bis___bst_mcust_grp_reln') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.POSITION_NO) = T.POSITION_ID
AND S.MANAGED_GROUP_NO = T.MANAGED_GROUP_ID
AND TRIM(S.RELATIONSHIP_TYPE) = T.RELATIONSHIP_TYPE_CODE
AND CONVERT_TIMEZONE('UTC', 'Pacific/Auckland', DATEADD(HOUR, -12, S.DWH_EFFECTIVE_FROM_TSTAMP))::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ
{% endif %}

-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}
