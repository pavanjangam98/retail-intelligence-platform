{% docs foundation___fdp__custmstr___fdp__party_address %}

This foundation product holds details of customer postal and physical addresses

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__address_id %}

A unique identifier for a party address

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__customer_id %}

The unique identifier of the customer

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__iso_address_type_code %}

The ISO20022 sub-type that describes the nature of the address (eg. HOME, ADDR, PBOX, BIZZ)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__department_name %}

Identification of a division of a large organisation or building

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__sub_department_name %}

Identification of a sub-division of a large organisation or building

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__room_id %}

The room number in a house or building

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__room_type_code %}

The room type of a house or building

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__floor_name %}

Floor or storey within a building

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__street_name %}

Name of a street or thoroughfare

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__building_number_id %}

Number that identifies the position of a building on a street

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__building_name %}

Name of the building or house

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__postbox_id %}

Numbered box in a post office, assigned to a person or organisation, where letters are kept until called for

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__town_name %}

Name of a built-up area, with defined boundaries, and a local government

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__town_location_name %}

Specific location name within the town

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__district_name %}

A subdivision within a country sub-division

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__country_sub_division_name %}

A subdivision of a country such as state, region, county

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__formatted_address_line_text %}

Information that locates and identifies a specific address, as defined by postal services, presented in free format text

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__address_indicator_code %}

An indicator that further specifies the type of address. e.g. Street Address Private Bag PO-Box Rural DeliveryCounter Delivery.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__address_type_code %}

The type of the party address. It can be physical or postal.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__addressee_name %}

Name by which a party is known and which is usually used to identify that party

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__care_of_name %}

The name of someone who is not the legal occupant of the address. This may also hold any 'preleading' information from the address which does not form part of the structured address

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__address_line_1_text %}

The customer address lines. Min items 1, max items 4

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__address_line_2_text %}

The customer address lines. Min items 1, max items 4

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__address_line_3_text %}

The customer address lines. Min items 1, max items 4

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__address_line_4_text %}

The customer address lines. Min items 1, max items 4

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__postal_district_code %}

The postal district portion of the mailing address NZ postal code

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__postal_code %}

The NZ Post Office code associated with the customer's address details

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__country_code %}

The 2 character ISO country code

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__country_name %}

The country name

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__delivery_point_id %}

A 10-digit unique identifier assigned to each address found in the NZ Postal Address File (PAF)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__deliverable_bitflag %}

An indicator which shows if the address can receive post

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__start_date %}

The first day on which the customer can be contacted at this address. The date format is YYYY-MM-DD.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__validation_request_id %}

The identifier that was used to validate this address. This links together the version of the address prior to validation, and the version after validation.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__validation_outcome_code %}

The outcome of the address validation from party communication address validation service (eg. unvalidated, validated)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__validation_outcome_reason_code %}

The reason for the validation outcome. (eg. validationRequested, validationNotRequested, error, validatedWithoutChanges, validatedWithChanges, noMatchedAddress, invalidAddressForAddressType, validationNotSupportedForCountry)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__validation_tstamp %}

The datetime the address was last validated

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__address_changed_tstamp %}

The datetime the Party Address Service last updated this record. The change could be either an update to the address details, an address validation triggered by the update or possibly from a scheduled workflow task or status update

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__mesh_block_code %}

The smallest geographic unit for which statistical data is collected and processed by Stats NZ

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__street_id %}

Unique numeric identifier for a street defined by New Zealand Post

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__front_of_property_nztm_x_coordinate_location %}

The NZTM Geocode 'X' coordinate for the front of the property

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__front_of_property_nztm_y_coordinate_location %}

The NZTM Geocode 'Y' coordinate for the front of the property

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__centroid_of_property_nztm_x_coordinate_location %}

The NZTM Geocode 'X' coordinate for the centre of the property

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__centroid_of_property_nztm_y_coordinate_location %}

The NZTM Geocode 'Y' coordinate for the centre of the property

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__linz_parcel_id %}

The unique LINZ identifier for spatial object representing land parcel the address resides in

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__property_purpose_type_code %}

The property purpose eg Business, Farm, Holiday Home, Residential or Empty section

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__last_updated_by_name %}

The ID of the entity who last updated the address, it can be staff number, customer number or client id

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__last_updated_by_originator_name %}

The application or system that originated the last update address request

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__last_updated_by_type_code %}

The type of the entity who last updated the address, it can be staff, customer or client

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__last_updated_tstamp %}

The datetime the address was last changed

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__territorial_authority_code %}

Code for Territorial authority which is the second tier of local government in New Zealand, below regional councils

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__territorial_authority_name %}

Name for Territorial authority which is the second tier of local government in New Zealand, below regional councils

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__regional_council_code %}

Code for the regional council for the returned address

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__regional_council_name %}

Name for the regional council for the returned address

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__general_electorate_code %}

Code for the general electorate for the returned address

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__general_electorate_name %}

Name for the general electorate for the returned address

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__maori_electorate_code %}

Unique code of the Maori electorate for the returned address

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__maori_electorate_name %}

Unique name of the Maori electorate for the returned address

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_address__host_address_type_code %}

The address type code used in the legacy host system, deprecated. (eg. I, J, M, N P)

{% enddocs %}
