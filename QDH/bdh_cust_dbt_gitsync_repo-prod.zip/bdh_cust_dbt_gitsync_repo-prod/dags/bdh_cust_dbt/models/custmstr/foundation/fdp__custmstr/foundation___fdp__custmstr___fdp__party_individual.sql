{{ config(
    materialized='incremental',
    unique_key=['CUSTOMER_ID','DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
        -- This post hook handles record deletion from type 2 table in RAW layer
        WHERE customer_id || dwh_effective_from_tstamp IN (
        SELECT t.customer_id || t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___bis___bst_indiv_cust') }} s
            ON t.customer_id = trim(s.customer_no)
            AND t.dwh_effective_from_tstamp = CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ
        WHERE s.customer_no IS NULL
        )"]) 

}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt run --select +foundation___fdp__custmstr___fdp__party_individual+ --vars '{"run_type": "specific_data_load", "days_back": 15}'

Full data set command - dbt build  --select +foundation___fdp__custmstr___fdp__party_individual+ --vars '{ "run_type": "full_data_load" }'

defualt values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}

SELECT
    --Standardise column names as a part of foundataional data product.
    TRIM(S.CUSTOMER_NO::VARCHAR) AS CUSTOMER_ID,
    S.DL_VERSION_NO::NUMBER AS DRIVING_LICENSE_VERSION_ID,
    TRIM(S.BANK_PENSIONER_IND::VARCHAR(5)) AS BANK_PENSIONER_FLAG,
    TRIM(S.BANK_EMPLOYEE_IND::VARCHAR(5)) AS BANK_EMPLOYEE_FLAG,
    TRIM(S.SEX::VARCHAR) AS SEX_CODE,
    TRIM(S.DOB_CONFIRMED_IND::VARCHAR) AS DATE_OF_BIRTH_CONFIRMED_CODE,
    TRIM(S.MARITAL_STATUS::VARCHAR) AS MARITAL_STATUS_CODE,
    S.OCCUPATION_CODE::NUMBER AS OCCUPATION_CODE,
    TRIM(S.CONSENT_IND::VARCHAR) AS CONSENT_CODE,
    TRIM(S.RSDNT_STATUS::VARCHAR) AS RESIDENTIAL_STATUS_CODE,
    S.EMP_INDUSTRY_CODE::NUMBER AS EMPLOYMENT_INDUSTRY_CODE,
    TRIM(S.PRM_ID_TYPE_CODE::VARCHAR) AS PRIMARY_IDENTIFICATION_TYPE_CODE,
    TRIM(S.PRM_ID_DESC::VARCHAR) AS PRIMARY_IDENTIFICATION_DESC,
    TRIM(S.PRM_ID_COUNTRY::VARCHAR) AS PRIMARY_IDENTIFICATION_COUNTRY_CODE,
    TRIM(S.SEC_ID_TYPE_CODE::VARCHAR) AS SECONDARY_IDENTIFICATION_TYPE_CODE,
    TRIM(S.SEC_ID_DESC::VARCHAR) AS SECONDARY_IDENTIFICATION_DESC,
    TRIM(S.SEC_ID_COUNTRY::VARCHAR) AS SECONDARY_IDENTIFICATION_COUNTRY_CODE,
    TRIM(S.EMPLOYER_NAME::VARCHAR) AS EMPLOYER_NAME,
   -- CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.LAST_CHG_TIMESTAMP)::TIMESTAMP_LTZ AS LAST_CHANGE_TSTAMP,
    TRIM(S.INITIALS::VARCHAR) AS INITIAL_NAME,
    TRIM(S.SURNAME::VARCHAR) AS SURNAME_NAME,
    TRIM(S.FORENAME1::VARCHAR) AS FORENAME1_NAME,
    TRIM(S.FORENAME2::VARCHAR) AS FORENAME2_NAME,
    TRIM(S.FORENAME3::VARCHAR) AS FORENAME3_NAME,
    TRIM(S.ADDRESSEE_TITLE::VARCHAR) AS ADDRESSEE_TITLE_DESC,
    S.BIRTH_DATE::DATE AS BIRTH_DATE,
    S.DEATH_DATE::DATE AS DEATH_DATE,
    S.PP_EXPIRY_DATE::DATE AS PASSPORT_EXPIRY_DATE,
    S.DEPENDANTS_COUNT::NUMBER AS DEPENDANTS_COUNT,
    S.GROSS_INCOME_AMT::NUMBER(38, 19) AS GROSS_INCOME_AMOUNT,
    S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
    S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,

    {% if is_incremental() %}
    CASE WHEN T.CUSTOMER_ID IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         WHEN T.CUSTOMER_ID IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.CUSTOMER_ID IS NULL THEN NULL
         WHEN
             T.CUSTOMER_ID IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ
             THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___bis___bst_indiv_cust') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.CUSTOMER_NO) = T.CUSTOMER_ID
AND CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP
{% endif %}
-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}
