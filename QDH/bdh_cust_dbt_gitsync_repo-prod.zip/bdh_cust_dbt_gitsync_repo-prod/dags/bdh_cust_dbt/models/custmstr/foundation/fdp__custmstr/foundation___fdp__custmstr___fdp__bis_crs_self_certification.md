{% docs foundation___fdp__custmstr___fdp__bis_crs_self_certification %}

This foundation data product contains Common Reporting 
Standard (CRS) self certification records collected from new-to-bank customers about their foreign tax residency, referred to as BST_CRS_SELF_CERT in BIS. A typical record represents one customer's self certification submission.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__bis_crs_self_certification___customer_id %}
        
An identifier for each Bank Customer in Customer Information System (CIS).

Unique Identifier/key of the FDP__BIS_CRS_SELF_CERTIFICATION table
Unique Identifier/key to the FDP__PARTY_CORE table (Foreign Key)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__bis_crs_self_certification___delivery_chain_code %}

(AI Generated) The internal ID used to track how and through which delivery workflow the Common Reporting Standard (CRS) self‑certification was issued, returned, and completed.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__bis_crs_self_certification___verification_code %}

Customer Common Reporting Standard (CRS) verification status - V(erified), F(ailed), P(ending), T(emporary)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__bis_crs_self_certification___last_updated_tstamp %}

The date and time of the last update to the table

{% enddocs %}