{{ config(
    materialized='incremental',
    unique_key=['GOVERNED_CUSTOMER_ID', 'AUTHORISED_CUSTOMER_ID', 'DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
    -- This post hook handles record deletion from type 2 table in RAW layer    
        WHERE GOVERNED_CUSTOMER_ID || AUTHORISED_CUSTOMER_ID || dwh_effective_from_tstamp 
        in
      (
        SELECT t.GOVERNED_CUSTOMER_ID || t.AUTHORISED_CUSTOMER_ID || t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___customer_authority_service___customer_authority') }} s
            ON t.GOVERNED_CUSTOMER_ID = TRIM(s.GOVERNEDCUSTOMERNUMBER)
            AND t.AUTHORISED_CUSTOMER_ID = TRIM(s.AUTHORISEDCUSTOMERNUMBER)
            AND T.dwh_effective_from_tstamp = S.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ
        WHERE s.GOVERNEDCUSTOMERNUMBER IS NULL
        and s.AUTHORISEDCUSTOMERNUMBER IS NULL
      )"
    ]
  ) 
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select foundation___fdp__custmstr___fdp__party_authority --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select foundation___fdp__custmstr___fdp__party_authority --vars '{ "run_type": "full_data_load" }'
defualt values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}

SELECT
    --Standardise column names as a part of foundataional data product.
		TRIM(S.GOVERNEDCUSTOMERNUMBER::VARCHAR) AS GOVERNED_CUSTOMER_ID,
		TRIM(S.AUTHORISEDCUSTOMERNUMBER::VARCHAR) AS AUTHORISED_CUSTOMER_ID,
    TRIM(S.OPERATINGAUTHORITYID)::NUMBER AS OPERATING_AUTHORITY_ID,
		TRIM(S.REVISIONNUMBER)::NUMBER AS REVISION_NUMBER_ID,
		TRIM(S.AUTHORISEDCUSTOMERTYPE::VARCHAR) AS AUTHORISED_CUSTOMER_TYPE_CODE,
		TRIM(S.EFFECTIVEFROMDATE)::DATE AS EFFECTIVE_FROM_DATE,
		TRIM(S.EFFECTIVETODATE)::DATE AS EFFECTIVE_TO_DATE,
    S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
    S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
    S.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    S.DWH_EFFECTIVE_TO_TSTAMP::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
    {% if is_incremental() %}
    CASE WHEN T.GOVERNED_CUSTOMER_ID IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         WHEN T.GOVERNED_CUSTOMER_ID IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.GOVERNED_CUSTOMER_ID IS NULL THEN NULL
         WHEN T.GOVERNED_CUSTOMER_ID IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> S.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___customer_authority_service___customer_authority') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.GOVERNEDCUSTOMERNUMBER) = T.GOVERNED_CUSTOMER_ID
AND TRIM(S.AUTHORISEDCUSTOMERNUMBER) = T.AUTHORISED_CUSTOMER_ID
AND S.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP
{% endif %}

-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}
