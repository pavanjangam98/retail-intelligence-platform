{{ config(
    materialized='view',
    secured=true,
    post_hook="alter view {{ this }} set secure;"
)}}

SELECT
    *
FROM {{ ref('foundation___fdp__custmstr___fdp__bis_country_reference') }} S