{{ config(
  materialized='incremental',
  unique_key=['NABSIC_CODE' , 'DWH_EFFECTIVE_FROM_TSTAMP'],
  incremental_strategy = 'merge',
  post_hook=["DELETE FROM {{ this }}
-- This post hook handles record deletion from type 2 table in RAW layer    
      WHERE NABSIC_CODE || DWH_EFFECTIVE_FROM_TSTAMP
      in
    (
      SELECT t.NABSIC_CODE || t.DWH_EFFECTIVE_FROM_TSTAMP
      FROM {{ this }} t
      LEFT JOIN {{ ref('raw___party_demographics_service___customer_partydemographics_industry_reference_data') }} s
            ON t.NABSIC_CODE = trim(s.NABSICCODE)
            AND t.dwh_effective_from_tstamp = s.dwh_effective_from_tstamp::timestamp_ltz
      WHERE s.NABSICCODE IS NULL
        )"])
}}


{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}


SELECT

   TRIM(S.NABSICCODE::VARCHAR) AS NABSIC_CODE,
   TRIM(S.NABSICDESCRIPTION::VARCHAR) AS NABSIC_DESC,
   TRIM(S.AMLRATING::VARCHAR) AS AML_RISK_RATING_CODE,
   TRIM(S.BRIBERYANDCORRUPTIONRATING::VARCHAR) AS BRIBERY_AND_CORRUPTION_RATING_CODE,
   TRIM(S.ESGRATING::VARCHAR) AS ESG_RATING_CODE,
   TRIM(S.SANCTIONSRATING::VARCHAR) AS SANCTIONS_RATING_CODE,
   TRIM(S.TERRORISMFINANCINGRATING::VARCHAR) AS TERRORISM_FINANCING_RATING_CODE,
   (TRIM(S.LEGACYCODE))::NUMBER AS LEGACY_CODE,
   TRIM(S.LEVEL1CODE::VARCHAR) AS LEVEL_1_CODE,
   TRIM(S.LEVEL1DESCRIPTION::VARCHAR) AS LEVEL_1_DESC,
   (TRIM(S.LEVEL2CODE))::NUMBER AS LEVEL_2_CODE,
   TRIM(S.LEVEL2DESCRIPTION::VARCHAR) AS LEVEL_2_DESC,
   (TRIM(S.LEVEL3CODE))::NUMBER AS LEVEL_3_CODE,
   TRIM(S.LEVEL3DESCRIPTION::VARCHAR) AS LEVEL_3_DESC,
   (TRIM(S.LEVEL4CODE))::NUMBER AS LEVEL_4_CODE,
   TRIM(S.LEVEL4DESCRIPTION::VARCHAR) AS LEVEL_4_DESC,
   TRIM(S.DWH_SOURCE_SYSTEM_CODE::VARCHAR) AS DWH_SOURCE_SYSTEM_CODE,
   TRIM(S.DWH_LATEST_DML_TYPE_CODE::VARCHAR) AS DWH_LATEST_DML_TYPE_CODE,
   S.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
   S.DWH_EFFECTIVE_TO_TSTAMP::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
   S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
   S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID, 
   {%- if is_incremental() %}
       CASE WHEN T.NABSIC_CODE IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         WHEN T.NABSIC_CODE IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.NABSIC_CODE IS NULL THEN NULL
         WHEN T.NABSIC_CODE IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> S.DWH_EFFECTIVE_TO_TSTAMP::TIMESTAMP_LTZ
             THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
   {%- endif -%}
   
LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP

FROM {{ ref('raw___party_demographics_service___customer_partydemographics_industry_reference_data') }} AS S
{%- if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.NABSICCODE) = T.NABSIC_CODE
AND S.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP
{% endif %}
-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}
