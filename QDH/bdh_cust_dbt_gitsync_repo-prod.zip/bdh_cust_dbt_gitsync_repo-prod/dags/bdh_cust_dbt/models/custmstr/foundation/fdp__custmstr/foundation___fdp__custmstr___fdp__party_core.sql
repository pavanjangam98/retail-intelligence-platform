{{ config(
    materialized='incremental',
    unique_key=['CUSTOMER_ID','DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
        -- This post hook handles record deletion from type 2 table in RAW layer
        WHERE customer_id || dwh_effective_from_tstamp IN (
        SELECT t.customer_id || t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___bis___bst_customer') }} s
            ON t.customer_id = trim(s.customer_no)
            AND t.dwh_effective_from_tstamp = CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ
        WHERE s.customer_no IS NULL
        )"]) 

}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt run --select foundation___fdp__custmstr___fdp__party_core --vars '{"run_type": "specific_data_load", "days_back": 15}'

Full data set command - dbt build  --select foundation___fdp__custmstr___fdp__party_core --vars '{ "run_type": "full_data_load" }'

defualt values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point
 */

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}

SELECT
    --Standardise column names as a part of foundataional data product.
    TRIM(S.CUSTOMER_NO::VARCHAR) AS CUSTOMER_ID,
    TRIM(S.CUSTOMER_TYPE::VARCHAR) AS CUSTOMER_TYPE_CODE,
    TRIM(S.SHORT_NAME::VARCHAR) AS SHORT_NAME,
    TRIM(S.LEGAL_NAME::VARCHAR) AS LEGAL_NAME,
    TRIM(S.SALUTATION::VARCHAR) AS SALUTATION_NAME,
    S.START_DATE::DATE AS START_DATE,
    S.END_DATE::DATE AS END_DATE,
    S.BRANCH_NO::NUMBER AS BRANCH_ID,
    TRIM(S.FORMAL_NAME::VARCHAR) AS FORMAL_NAME,
    S.CORPORATE_NO::NUMBER AS CORPORATE_ID,
    TRIM(S.CREDIT_CHECK_CODE::VARCHAR) AS CREDIT_CHECK_CODE,
    TRIM(S.CUST_ARCH_STATUS::VARCHAR) AS CUSTOMER_ARCHIVE_STATUS_CODE,
    S.IRD_NO::NUMBER AS INLAND_REVENUE_DEPARTMENT_ID,
    TRIM(S.LEND_CATEGORY_IND::VARCHAR) AS LENDING_CATEGORY_CODE,
    TRIM(S.NON_RES_LEVY_IND::VARCHAR) AS NON_RESIDENT_LEVY_CODE,
    TRIM(S.NON_RESIDENT_CODE::VARCHAR) AS NON_RESIDENT_CODE,
    TRIM(S.PHONE_ID_TEXT::VARCHAR) AS PHONE_ID_TEXT,
    TRIM(S.RWT_EXEMPT_IND::VARCHAR) AS RESIDENT_WITHOLDING_TAX_EXEMPT_CODE,
    TRIM(S.TAX_CODE::VARCHAR) AS TAX_CODE,
    TRIM(S.BUS_PURPOSE_CODE::VARCHAR) AS BUSINESS_PURPOSE_CODE,
    TRIM(S.LAST_CHG_OP_CODE::VARCHAR) AS LAST_CHANGE_OPERATION_CODE,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.LAST_CHG_TIMESTAMP)::TIMESTAMP_LTZ AS LAST_CHANGE_TSTAMP,
    TRIM(S.CUST_POTN_CODE::VARCHAR) AS CUSTOMER_POTENTIAL_CODE,
    TRIM(S.KYC_STAFF_USERID::VARCHAR) AS LEGACY_KYC_STAFF_USER_ID,
    S.KYC_ACTION_DATE AS LEGACY_KYC_ACTION_DATE,
    S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
    S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
    {% if is_incremental() %}
    CASE WHEN T.CUSTOMER_ID IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         WHEN T.CUSTOMER_ID IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.CUSTOMER_ID IS NULL THEN NULL
         WHEN
             T.CUSTOMER_ID IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ
             THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___bis___bst_customer') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.CUSTOMER_NO) = T.CUSTOMER_ID
AND CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP
{% endif %}
-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}
