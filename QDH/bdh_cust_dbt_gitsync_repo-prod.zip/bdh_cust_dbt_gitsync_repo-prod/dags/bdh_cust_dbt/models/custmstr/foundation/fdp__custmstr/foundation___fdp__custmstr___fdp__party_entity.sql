{{ config(
    materialized='incremental',
    unique_key=['CUSTOMER_ID','DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
        -- This post hook handles record deletion from type 2 table in RAW layer
        WHERE customer_id || dwh_effective_from_tstamp IN (
        SELECT t.customer_id || t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___bis___bst_np_customer') }} s
            ON t.customer_id = trim(s.customer_no)
            AND t.dwh_effective_from_tstamp = CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',s.dwh_effective_from_tstamp)::timestamp_ltz
        WHERE s.customer_no IS NULL
        )"]) 
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt run --select foundation___fdp__custmstr___fdp__party_entity --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select foundation___fdp__custmstr___fdp__party_entity+ --vars '{ "run_type": "full_data_load" }' */

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}

SELECT
    --Standardise column names as a part of foundataional data product.
    TRIM(S.CUSTOMER_NO::VARCHAR) AS CUSTOMER_ID,
    TRIM(S.ENTITY_TYPE::VARCHAR) AS ENTITY_TYPE_CODE,
    TRIM(S.NP_CUST_TYPE::VARCHAR) AS PARTY_ENTITY_TYPE_CODE,
    TRIM(S.TRADING_NAME::VARCHAR) AS TRADING_NAME,
    S.FOUNDED_DATE::DATE AS FOUNDED_DATE,
    TRIM(S.CRS_ENTITY_CLASS::VARCHAR) AS CRS_ENTITY_CLASS_CODE,
    TRIM(S.DEED_IND::VARCHAR(5)) AS DEED_FLAG,
    TRIM(S.GII_NO::VARCHAR) AS GLOBAL_INTERMEDIARY_ID,
    S.INCORP_NO::NUMBER AS NZ_INCORPORATION_ID,
    TRIM(S.NON_PROFIT_ORG_IND::VARCHAR(5)) AS NON_PROFIT_ORGANISATION_FLAG,
    TRIM(S.NON_RES_INCORP_CTY::VARCHAR) AS NON_NZ_INCORPORATION_COUNTRY_CODE,
    TRIM(S.NP_CUST_SUBTYPE::VARCHAR) AS ENTITY_SUBTYPE_CODE,
    S.NZ_BUSINESS_NO::NUMBER AS NZ_BUSINESS_ID,
    TRIM(S.OSEAS_INCORP_NO::VARCHAR) AS NON_NZ_INCORPORATION_ID,
    TRIM(S.PARTNERSHIP_TYPE::VARCHAR) AS PARTNERSHIP_TYPE_CODE,
    TRIM(S.TRADING_LOCN::VARCHAR) AS TRADING_LOCATION_CODE,
    TRIM(S.TRADING_IND::VARCHAR(5)) AS TRADING_INDICATOR_FLAG,
    S.END_TRADING_DATE::DATE AS END_TRADING_DATE,
    S.INDUSTRY_CODE AS LEGACY_INDUSTRY_CODE,
    TRIM(S.FIN_YEAR_END_CODE::VARCHAR) AS LEGACY_FINANCIAL_YEAR_END_CODE,
    TRIM(S.DWH_SOURCE_SYSTEM_CODE::VARCHAR) AS DWH_SOURCE_SYSTEM_CODE,
    TRIM(S.DWH_LATEST_DML_TYPE_CODE::VARCHAR) AS DWH_LATEST_DML_TYPE_CODE,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
    {% if is_incremental() %}
    CASE WHEN T.CUSTOMER_ID IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         WHEN T.CUSTOMER_ID IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.CUSTOMER_ID IS NULL THEN NULL
         WHEN
             T.CUSTOMER_ID IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ
             THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___bis___bst_np_customer') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.CUSTOMER_NO) = T.CUSTOMER_ID
AND CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP
{% endif %}
-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}