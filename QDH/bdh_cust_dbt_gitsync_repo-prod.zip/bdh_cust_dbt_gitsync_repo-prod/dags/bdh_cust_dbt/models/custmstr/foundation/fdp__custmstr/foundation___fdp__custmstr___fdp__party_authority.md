{% docs foundation___fdp__custmstr___fdp__party_authority %}

This foundation product holds details of digital customer authority information

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_authority__governed_customer_id %}

Unique identifier of the governed customer

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_authority__authorised_customer_id %}

Unique identifier of the authorised customer

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_authority__operating_authority_id %}

Unique identifier of the active operatig authority containing association

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_authority__revision_number_id %}

the revision number containing associations

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_authority__authorised_customer_type_code %}

The type of the authorised customer

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_authority__effective_from_date %}

Optional effective from date, for indicative purposes

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_authority__effective_to_date %}

Optional effective to date, for indicative purposes

{% enddocs %}
