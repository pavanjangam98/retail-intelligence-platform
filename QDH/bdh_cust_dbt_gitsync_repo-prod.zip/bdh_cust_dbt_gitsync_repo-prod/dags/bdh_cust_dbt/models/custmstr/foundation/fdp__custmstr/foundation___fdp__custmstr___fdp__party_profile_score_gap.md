{% docs foundation___fdp__custmstr___fdp__party_profile_score_gap %}

This foundation product holds details of KYC score gaps

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score_gap__customer_id %}

The customer identifier

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score_gap__score_type_code %}

Type of score.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score_gap__gap_type_code %}

Code for the gap in profile

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_profile_score_gap__gap_status_flag %}

Status of the gap. True if gap exists, false otherwise.

{% enddocs %}
