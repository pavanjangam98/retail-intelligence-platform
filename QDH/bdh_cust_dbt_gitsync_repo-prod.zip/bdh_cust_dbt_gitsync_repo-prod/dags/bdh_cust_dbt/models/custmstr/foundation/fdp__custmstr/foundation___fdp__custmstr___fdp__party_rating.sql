{{ config(
    materialized='incremental',
    unique_key=['CUSTOMER_ID', 'DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
    -- This post hook handles record deletion from type 2 table in RAW layer    
        WHERE CUSTOMER_ID ||  dwh_effective_from_tstamp 
        in
      (
        SELECT t.CUSTOMER_ID ||   t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___bis___pot_cust_rtng') }} s
            ON t.CUSTOMER_ID = trim(s.CNSMR_ID)
            AND t.DWH_EFFECTIVE_FROM_TSTAMP = CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',s.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ
        WHERE s.CNSMR_ID IS NULL
      )"
    ]
  ) 
}}


/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select foundation___fdp__custmstr___fdp__party_rating --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select foundation___fdp__custmstr___fdp__party_rating --vars '{ "run_type": "full_data_load" }'
defualt values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}

SELECT
    --Standardise column names as a part of foundataional data product.
    TRIM(S.CNSMR_ID::VARCHAR) AS CUSTOMER_ID,
  TRIM(S.AUTH_OFFICER_ID::VARCHAR) AS AUTHORITY_OFFICER_ID,
  TRIM(S.ACCT_MGR::VARCHAR) AS ACCOUNT_MANAGER_ID,
  TRIM(S.RATING_OFFICER::VARCHAR) AS RATING_OFFICER_ID,
  TRIM(S.CLOSE_MONITR_IND::VARCHAR(5)) AS CLOSE_MONITOR_FLAG,
  TRIM(S.OVERRIDE_IND::VARCHAR(5)) AS OVERRIDE_FLAG,
  TRIM(S.OVERRIDE_RSN_CD::VARCHAR) AS OVERRIDE_REASON_CODE,
  TRIM(S.RATING_VERS_CD::VARCHAR) AS RATING_VERSION_CODE,
  TRIM(S.CNSMR_RTG_TP_CD::VARCHAR) AS CONSUMER_RATING_TYPE_CODE,
  TRIM(S.IMPAIRD_ASSET_ST::VARCHAR) AS IMPAIRED_ASSET_STATUS_CODE,
  TRIM(S.ASSET_MGR_ID::VARCHAR) AS ASSET_MANAGER_NAME,
  TRIM(S.LOCATION::VARCHAR) AS LOCATION_DESC,
    TRY_TO_DATE(TO_VARCHAR(S.RATING_DT_VAL), 'YYYYMMDD') AS RATING_DATE,
  S.CNSMR_RATING::NUMERIC(38, 0) AS CONSUMER_RATING_SCORE,
  S.DFLT_PROBABILITY::NUMERIC(38, 19) AS DEFAULT_PROBABILITY_RATE,
    TRY_TO_NUMBER(TRIM(S.OLD_CNSMR_RATING), 38, 0) AS OLD_CONSUMER_RATING_SCORE,
    TRIM(S.IND_OCCUP_CD::VARCHAR) AS LEGACY_INDUSTRY_OCCUPATION_CODE,
    S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
    S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
    {% if is_incremental() %}
    CASE WHEN T.CUSTOMER_ID IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         WHEN T.CUSTOMER_ID IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.CUSTOMER_ID IS NULL THEN NULL
         WHEN T.CUSTOMER_ID IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___bis___pot_cust_rtng') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.CNSMR_ID) = T.CUSTOMER_ID
AND CONVERT_TIMEZONE('UTC', 'Pacific/Auckland', DATEADD(HOUR, -12, S.DWH_EFFECTIVE_FROM_TSTAMP))::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ
{% endif %}

-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}