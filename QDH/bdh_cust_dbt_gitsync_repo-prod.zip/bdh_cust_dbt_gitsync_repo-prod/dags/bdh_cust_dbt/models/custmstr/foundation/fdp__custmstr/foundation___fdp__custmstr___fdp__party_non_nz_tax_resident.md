{% docs foundation___fdp__custmstr___fdp__party_non_nz_tax_resident %}

This foundation product hold list of countries that a customer is a tax resident of other than NZ

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_non_nz_tax_resident___customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_non_nz_tax_resident___tax_id %}

Foreign tax identity number eg 1234567890

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_non_nz_tax_resident___country_code %}

Uniquely identifies the a country

{% enddocs %}
