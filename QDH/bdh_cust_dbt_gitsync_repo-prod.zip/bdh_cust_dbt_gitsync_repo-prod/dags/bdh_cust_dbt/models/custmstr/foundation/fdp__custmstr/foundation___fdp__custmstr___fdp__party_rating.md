{% docs foundation___fdp__custmstr___fdp__party_rating %}

This foundation product holds details on customer rating

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___customer_id %}

BIS Customer Number

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___authority_officer_id %}

Authority officer name and staff number.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___account_manager_id %}

Rating Account Manager

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___rating_officer_id %}

Staff number and name of the rating officer

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___close_monitor_flag %}

Indicates Y, N or space whether Close Monitored

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___override_flag %}

Indicates Y or N whether there is an override

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___override_reason_code %}

Code indicating the reason for the override, can be numeric 01-13 or letter A,B,C,D,E,F,G, H,I,L,N,T . Unable to locate meaning for these codes.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___rating_version_code %}

Rating version

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___consumer_rating_type_code %}

Consumer Rating Type Code. Can be B, F ,G ,N ,P ,R ,S

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___impaired_asset_status_code %}

Impaired Asset Status. Usually not populated ('Normal' status), but can contain values of   'R' 'Restructured     'P'      'Default (no loss)'    'N'     'Loss/Non Accrual '  'H'  'Hardship    'W' 'Watch 

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___asset_manager_name %}

Rating's Asset Manager name.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___location_desc %}

Controlling location. Various content - can be country, branch, location code.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___rating_date %}

Rating date

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___consumer_rating_score %}

Consumer Rating number, on a sacle of 1-23, or 98,99

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___default_probability_rate %}

The calculated risk of customer default on a scale of 0-100.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___old_consumer_rating_score %}

Previous customer rating, on a scale of 1-23, and also 98

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_rating___legacy_industry_occupation_code %}

(AI-Generated) Standardised code representing an industry or occupation classification associated with a customer rating record. It supports consistent categorisation of customers based on their business or occupational activity.  
Unclear data quality - BIS data dictionary states this field is rarely populated but can contain ISO Industry Codes. Industry code should be sourced from FDP__PARTY_DEMOGRAPHIC_LINK/FDP__PARTY_DEMOGRAPHICS_INDUSTRY_REFERENCE.
Legacy field - added for Hadoop Exit program. To be used for consumption via QDH and not to be consumed from BDH.

{% enddocs %}