{% docs fdp__party_individual_citizen_link %}

This foundation product holds list of citizenships that a customer has other than their primary citizenship. This will hold any countries of citizenship for a
customer and a customer could be a citizen of more than one country but only primary to one

{% enddocs %}

{% docs fdp__party_individual_citizen_link___customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs fdp__party_individual_citizen_link___country_code %}

Uniquely identifies the country.

{% enddocs %}

{% docs fdp__party_individual_citizen_link___primary_country_flag %}

Primary Country of Citizenship - This field is populated with the Country code of the customer’s country of Citizenship. This column as been added as part of an AML Requirement

{% enddocs %}
