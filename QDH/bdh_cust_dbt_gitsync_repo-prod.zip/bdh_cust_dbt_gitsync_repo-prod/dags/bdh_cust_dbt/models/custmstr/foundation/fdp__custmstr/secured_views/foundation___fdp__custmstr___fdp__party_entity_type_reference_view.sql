{{ config(
    materialized='view',
    secured=true,
    post_hook="alter view {{ this }} set secure;"
)}}

SELECT
    *
from {{ ref('foundation___fdp__custmstr___fdp__party_entity_type_reference') }}