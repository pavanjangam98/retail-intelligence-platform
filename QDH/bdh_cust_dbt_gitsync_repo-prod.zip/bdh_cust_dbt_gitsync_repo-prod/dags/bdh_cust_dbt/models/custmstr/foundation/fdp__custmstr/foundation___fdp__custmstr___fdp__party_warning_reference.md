{% docs foundation___fdp__custmstr___fdp__party_warning_reference %}

This foundation product holds details on warning type reference data  relating to accounts and/or customers

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_warning_reference___warning_code %}

The code which uniquely identifies the warning.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_warning_reference___warning_text %}

The text associated with the warning code that will appear when a warning is displayed.

{% enddocs %}
