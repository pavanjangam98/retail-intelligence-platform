{{ config(
    materialized='incremental',
    unique_key=['CUSTOMER_ID','COUNTRY_CODE','DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
    -- This post hook handles record deletion from type 2 table in RAW layer    
        WHERE customer_id || country_code || dwh_effective_from_tstamp 
        in
      (
        SELECT t.customer_id || t.country_code || t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___bis___bst_non_nz_tax_res') }} s
            ON t.customer_id = trim(s.customer_no)
		        AND t.country_code = trim(s.country_code)
            AND CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',T.dwh_effective_from_tstamp)::TIMESTAMP_LTZ = CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ
        WHERE s.customer_no IS NULL
        and s.country_code IS NULL
      )"
    ]
  ) 
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt run --select foundation___fdp__custmstr___fdp__party_non_nz_tax_resident --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select foundation___fdp__custmstr___fdp__party_non_nz_tax_resident --vars '{ "run_type": "full_data_load" }'
defualt values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else -%}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif -%}

SELECT
    --Standardise column names as a part of foundataional data product.
    TRIM(S.CUSTOMER_NO::VARCHAR) AS CUSTOMER_ID,
		TRIM(S.TAX_ID_NO::VARCHAR) AS TAX_ID,
		TRIM(S.COUNTRY_CODE::VARCHAR) AS COUNTRY_CODE,
    S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
    S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
    {% if is_incremental() %}
    CASE WHEN T.CUSTOMER_ID IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         WHEN T.CUSTOMER_ID IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.CUSTOMER_ID IS NULL THEN NULL
         WHEN
             T.CUSTOMER_ID IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ
             THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}

LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___bis___bst_non_nz_tax_res') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.CUSTOMER_NO) = T.CUSTOMER_ID
AND TRIM(S.COUNTRY_CODE) = T.COUNTRY_CODE
AND CONVERT_TIMEZONE('UTC', 'Pacific/Auckland', DATEADD(HOUR, -12, S.DWH_EFFECTIVE_FROM_TSTAMP))::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ
{% endif %}

-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}
