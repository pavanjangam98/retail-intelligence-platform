{{ config(
    materialized='incremental',
    unique_key=['EMAX_KEY', 'DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
    -- This post hook handles record deletion from type 2 table in RAW layer    
        WHERE EMAX_KEY ||  dwh_effective_from_tstamp 
        in
      (
        SELECT t.EMAX_KEY ||   t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___emax___eit_cust_acs') }} s
            ON t.EMAX_KEY = TRIM(s.EMAX_NO)
            AND T.dwh_effective_from_tstamp = CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ
        WHERE s.EMAX_NO IS NULL
      )"
    ]
  ) 
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select foundation___fdp__custmstr___fdp__emax_customer_access --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select foundation___fdp__custmstr___fdp__emax_customer_access --vars '{ "run_type": "full_data_load" }'
defualt values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else -%}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif -%}

SELECT
    --Standardise column names as a part of foundational data product.
    TRIM(S.EMAX_NO::VARCHAR) AS EMAX_KEY,
    TRIM(S.CUSTOMER_NO::VARCHAR) AS CUSTOMER_ID,
    TRIM(S.D_CHAN_ACS_ID::VARCHAR) AS DEFAULT_CHANNEL_ACCESS_ID,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.LAST_UPDT_TSTAMP)::TIMESTAMP_LTZ AS LAST_UPDATE_TSTAMP,
    S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
    S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
    {% if is_incremental() %}
    CASE WHEN T.EMAX_KEY IS NULL THEN '{{ invocation_id }}' || '.' || '{{ model.unique_id }}'::VARCHAR
         WHEN T.EMAX_KEY IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.EMAX_KEY IS NULL THEN NULL
         WHEN T.EMAX_KEY IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ THEN '{{ invocation_id }}' || '.' || '{{ model.unique_id }}'::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    '{{ invocation_id }}' || '.' || '{{ model.unique_id }}'::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}

LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___emax___eit_cust_acs') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.EMAX_NO) = T.EMAX_KEY
AND CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ
{% endif %}

-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}