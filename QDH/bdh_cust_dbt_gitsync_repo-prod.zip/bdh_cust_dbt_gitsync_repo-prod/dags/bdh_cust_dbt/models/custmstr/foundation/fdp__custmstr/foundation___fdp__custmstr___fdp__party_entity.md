{% docs fdp__party_entity %}

This foundation data product contains NON-PERSONAL CUSTOMER details.
A NON-PERSONAL CUSTOMER is a customer about whom the bank has an interest other than in a personal capacity. Examples are Partnership, Trust, Sole Trader, Group, Informal Group, Estate, Company.This is created from BST_NP_CUSTOMER

{% enddocs %}

{% docs fdp__party_entity___customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs fdp__party_entity___entity_type_code %}

{% enddocs %}

{% docs fdp__party_entity___party_entity_type_code %}

Classification of Non Personal customer by their major characteristics. "C" = Company
"P" = Partnership "S" = Sole Trader "T" = Trust "E" = Estate "F" = Formal Group "G" =
Informal Group "U" = Unknown

{% enddocs %}

{% docs fdp__party_entity___trading_name %}

The commonly used name of the non-personal customer, when different from their formal
name.

{% enddocs %}

{% docs fdp__party_entity___founded_date %}

The date on which the nonpersonal customer came into existance.

{% enddocs %}

{% docs fdp__party_entity___crs_entity_class_code %}

{% enddocs %}

{% docs fdp__party_entity___deed_flag %}

An indication that the bank has sighted or holds a copy of the partnership agreement.

{% enddocs %}

{% docs fdp__party_entity___global_intermediary_id %}

Global Intermediary Identification Number eg 123456-.12345.12.123

{% enddocs %}

{% docs fdp__party_entity___nz_incorporation_id %}

Incorporation number

{% enddocs %}

{% docs fdp__party_entity___non_profit_organisation_flag %}

An indication of whether the Bank regards the customer as a non-profit-making
organisation or not.

{% enddocs %}

{% docs fdp__party_entity___non_nz_incorporation_country_code %}

Country of incorporation if not NZ eg US

{% enddocs %}

{% docs fdp__party_entity___entity_subtype_code %}

Customer Sub-Type “RE, “TR”

{% enddocs %}

{% docs fdp__party_entity___nz_business_id %}

{% enddocs %}

{% docs fdp__party_entity___non_nz_incorporation_id %}

Overseas Incorporation Number - This is the unique ID that is assigned to a non personal
entity in a foreign country (as sited on official documents). This column has been added
as part of an AML Requirement

{% enddocs %}

{% docs fdp__party_entity___partnership_type_code %}

Indicates whether the partnership is a "special" or "general" partnership.

{% enddocs %}

{% docs fdp__party_entity___trading_location_code %}

Trading only within NZ or also Offshore Incorporated in; “NZ”, “OS” or “ ”

{% enddocs %}

{% docs fdp__party_entity___trading_indicator_flag %}

{% enddocs %}

{% docs fdp__party_entity___end_trading_date %}

{% enddocs %}

{% docs fdp__party_entity___legacy_industry_code %}

(AI-Generated) Standardised code identifying the industry in which a non-personal customer primarily operates. It supports segmentation and classification of business entities by economic activity. 
Industry code should be sourced from FDP__PARTY_DEMOGRAPHIC_LINK/FDP__PARTY_DEMOGRAPHICS_INDUSTRY_REFERENCE.
Legacy field - added for Hadoop Exit program. To be used for consumption via QDH and not to be consumed from BDH.

{% enddocs %}

{% docs fdp__party_entity___legacy_financial_year_end_code %}

(AI-Generated) Standardised code identifying the financial year-end period applicable to a non-personal customer. It supports the interpretation and alignment of financial reporting information. 
Unclear data sourcing and quality.
Legacy field - added for Hadoop Exit program. To be used for consumption via QDH and not to be consumed from BDH.

{% enddocs %}