
{% docs fdp__party_individual %}

This Foundational Data Product contains the core attributes of individual customers dealing with BNZ. It focuses on personal customer details, including identification, personal names, and financial information, and may be extended by other foundational products for additional attributes.

{% enddocs %}

{% docs fdp__party_individual___customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs fdp__party_individual___driving_license_version_id %}

Driving License number.

{% enddocs %}

{% docs fdp__party_individual___bank_pensioner_flag %}

An indication of whether the customer is a pensioner of the bank or not.Values: Y,N and Blank

{% enddocs %}

{% docs fdp__party_individual___bank_employee_flag %}

An indication of whether the customer is an employee of the bank or not.Values: N,Y,NULL

{% enddocs %}

{% docs fdp__party_individual___sex_code %}

The sex/gender of a person.

{% enddocs %}

{% docs fdp__party_individual___date_of_birth_confirmed_code %}

An indication as to whether the date of birth has been confirmed by the customer or estimated by the bank. Values: N,Y,NULL

{% enddocs %}

{% docs fdp__party_individual___marital_status_code %}

The current marital status of the person.

{% enddocs %}

{% docs fdp__party_individual___occupation_code %}

The standard classification for a customer's occupation using the NZSCO

{% enddocs %}

{% docs fdp__party_individual___consent_code %}

This indicates whether a signed consent form is held or not .

{% enddocs %}

{% docs fdp__party_individual___residential_status_code %}

The code that has been allocated to the residential status description

{% enddocs %}

{% docs fdp__party_individual___employment_industry_code %}

Code which relates to the employment industry group

{% enddocs %}

{% docs fdp__party_individual___primary_identification_type_code %}

The type of primary identification presented by the customer e.g. passport.  This column has been added as part of an AML requirement.

{% enddocs %}

{% docs fdp__party_individual___primary_identification_desc %}

The actual reference number / details applicable to the primary identification type selected e.g. NZ873094.  This column has been added as part of an AML requirement.

{% enddocs %}

{% docs fdp__party_individual___primary_identification_country_code %}

Country of origin of primary Id if not NZ

{% enddocs %}

{% docs fdp__party_individual___secondary_identification_type_code %}

The type of secondary Identification presented by the customer  e.g. super gold card. This column has been added as part of an AML requirement.

{% enddocs %}

{% docs fdp__party_individual___secondary_identification_desc %}

The actual reference number / details applicable to the secondary identification type selected. This column has been added as part of an AML requirement.

{% enddocs %}

{% docs fdp__party_individual___secondary_identification_country_code %}

Country of origin of secondary ID.

{% enddocs %}

{% docs fdp__party_individual___employer_name %}

The name of the employer of the customer.

{% enddocs %}

{% docs fdp__party_individual___initial_name %}

Initial name, or family name, of person.

{% enddocs %}

{% docs fdp__party_individual___surname_name %}

Surname, or family name, of person.

{% enddocs %}

{% docs fdp__party_individual___forename1_name %}

First forename, Given or Christian name.

{% enddocs %}

{% docs fdp__party_individual___forename2_name %}

Second forename, Given or Christian name.

{% enddocs %}

{% docs fdp__party_individual___forename3_name %}

Third forename, Given or Christian name.

{% enddocs %}

{% docs fdp__party_individual___addressee_title_desc %}

Title or honorific used when forming.

{% enddocs %}

{% docs fdp__party_individual___birth_date %}

The date on which the person was born.

{% enddocs %}

{% docs fdp__party_individual___death_date %}

The date on which the individual died.

{% enddocs %}

{% docs fdp__party_individual___passport_expiry_date %}

Passport expiry date.

{% enddocs %}

{% docs fdp__party_individual___dependants_count %}

The number of people who are dependants of this individual.

{% enddocs %}

{% docs fdp__party_individual___gross_income_amount %}

The actual annual income of an individual used to determine his/her income bracket.

{% enddocs %}
