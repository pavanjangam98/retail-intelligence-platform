{% docs foundation___fdp__custmstr___fdp__party_entity_type_reference %}

This foundation product holds reference data related to classification of a Non-Personal Customer by their major characteristics 

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_entity_type_reference___nonpersonal_customer_type_code %}

Classification of Non Personal customer by their major characteristics.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_entity_type_reference___nonpersonal_customer_desc %}

Description of this classification of Non Personal customer.

{% enddocs %}
