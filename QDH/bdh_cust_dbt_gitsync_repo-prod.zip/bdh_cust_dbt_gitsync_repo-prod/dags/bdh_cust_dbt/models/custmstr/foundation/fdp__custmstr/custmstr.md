{% docs custmstr %}

This Schema is where Customer Master Foundational Products are stored. This relates to
the Key Attributes of the Customer, Party, Entity and Relationships.

{% enddocs %}
