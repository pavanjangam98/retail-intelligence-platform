{{ config(
    materialized='incremental',
    unique_key=['CUSTOMER_ID','DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
        -- This post hook handles record deletion from type 2 table in RAW layer
        WHERE CUSTOMER_ID || dwh_effective_from_tstamp IN (
        SELECT t.CUSTOMER_ID || t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___party_demographics_service___customer_partydemographics_industry') }} s
            ON t.CUSTOMER_ID = trim(s.CUSTOMERNUMBER)
            AND t.dwh_effective_from_tstamp = s.dwh_effective_from_tstamp::timestamp_ltz
        WHERE s.CUSTOMERNUMBER IS NULL
        )"])
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select +foundation___fdp__custmstr___fdp__party_demographic_link --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select +foundation___fdp__custmstr___fdp__party_demographic_link --vars '{ "run_type": "full_data_load" }' */

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}

SELECT
    --Standardise column names as a part of foundataional data product.
    TRIM(S.CUSTOMERNUMBER::VARCHAR) AS CUSTOMER_ID,
	(TRIM(S.CODE))::NUMBER AS NABSIC_CODE,
	(TRIM(S.LEGACYCODE))::NUMBER AS BIS_LEGACY_CODE,
    TRIM(S.DWH_SOURCE_SYSTEM_CODE::VARCHAR) AS DWH_SOURCE_SYSTEM_CODE,
    TRIM(S.DWH_LATEST_DML_TYPE_CODE::VARCHAR) AS DWH_LATEST_DML_TYPE_CODE,
    S.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    S.DWH_EFFECTIVE_TO_TSTAMP::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
    {% if is_incremental() %}
    CASE WHEN T.CUSTOMER_ID IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         WHEN T.CUSTOMER_ID IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.CUSTOMER_ID IS NULL THEN NULL
         WHEN
             T.CUSTOMER_ID IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> S.DWH_EFFECTIVE_TO_TSTAMP::TIMESTAMP_LTZ
             THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___party_demographics_service___customer_partydemographics_industry') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.CUSTOMERNUMBER) = T.CUSTOMER_ID
AND S.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP
{% endif %}
-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}
