{% docs foundation___fdp__custmstr___fdp__party_joint%}

This foundation product details the nature of the joint relationship .

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_joint___customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_joint___joint_customer_type_code %}

Classification of Joint Customer by their relationship.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_joint___relationship_nature_desc %}

Describes the nature of the joint relationship, such as Married, Friends

{% enddocs %}
