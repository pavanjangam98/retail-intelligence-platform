{{ config(
    materialized='incremental',
    unique_key=['POSITION_ID','DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
 -- This post hook handles record deletion from type 2 table in RAW layer
        WHERE position_id || dwh_effective_from_tstamp IN (
        SELECT t.position_id || t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___banker_segment_onprem_file___banker_segment') }} s
            ON t.position_id = s.position_number   
            AND t.dwh_effective_from_tstamp = CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',s.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ
        WHERE s.position_number IS NULL)"]
) }}

/*
There are 5 methods that can be used to run the file based datasets.

Full Run - dbt build -s +foundation___fdp__custmstr___fdp__banker_position_segmentation+ --vars '{"run_type": "full_data_load"}'
This method will process all data available in the S3 bucket. Should only be used for Once off Historical Load,
and will encounter issues if there is data available from before the current dataset loaded.

Incremental - dbt build -s +foundation___fdp__custmstr___fdp__banker_position_segmentation+ --vars '{"run_type": "incremental"}'
This method should be used as the on-going load method, this checks the target table and only tries to load data from after the latest processed dataset.

Load From Date - dbt build -s +foundation___fdp__custmstr___fdp__banker_position_segmentation+ --vars '{"run_type": "from_date", "start_date": ''2025-06-17''}'
This should be used to reprocess historical data that has been modified or inserted late. The variable start_date used should be on or before the data with issues.

--Don't use these for BAU
Specific Date Range -
dbt build -s +foundation___fdp__custmstr___fdp__banker_position_segmentation+ --vars '{"run_type": "specific_date_range", "start_date": ''2025-06-17'', "end_date": ''2025-06-18''}'
This method processes datasets between two specific dates. Shouldn't be used natively, but useful for testing the behaviour of the incremental process

--Don't use these for BAU
Specific Date - dbt build -s +foundation___fdp__custmstr___fdp__banker_position_segmentation+ --vars '{"run_type": "specific_date", "start_date": ''2025-06-17''}'
Used to process a specific date. Shouldn't be used natively, but useful for testing the behaviour of the incremental process

If the correct parameters aren't used for the last two run types this process will fail.

Please Note:
It is not recommended to process data earlier than the latest loaded data.
If data needs to be reprocessed, raw should be removed back until the affected date and reprocessed.
*/

--If no parameters are set default depending on the status of the target table
{% if is_incremental() %}
    {% set run_type = var('run_type', 'incremental') %}
{% else %}
    {% set run_type = var('run_type', 'full_data_load') %}
{% endif %}

--Set date variables to null so that the job fails when variables are incorrectly entered
{% set start_date = var('start_date', null) %}
{% set end_date = var('end_date', null) %}

SELECT
TRIM(S.POSITION_NUMBER)::VARCHAR AS POSITION_ID,
TRIM(S.SEGMENTATION_ID)::NUMBER AS SEGMENTATION_ID,
TRIM(S.SEGMENTATION_DESC)::VARCHAR AS SEGMENTATION_DESC,
S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
/* Since we are executing the jobs in different modes, we had to include this if clause with
respect to run_type. However, the funcationality of this model is to just pull the latest data from
raw table to foundation, the logic will remain the same except when executing the job in full mode
(initial run), where the target table itself is not available.
*/
{% if is_incremental() %}
    {% if run_type == 'incremental' or run_type == 'from_date' or run_type == 'specific_date_range' or run_type == 'specific_date' %}
        CASE WHEN T.POSITION_ID IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
            WHEN T.POSITION_ID IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID::VARCHAR
        END AS DWH_PROCESS_INSERT_ID,
        CASE WHEN T.POSITION_ID IS NULL THEN NULL
            WHEN
                T.POSITION_ID IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ
                 THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
            ELSE T.DWH_PROCESS_UPDATE_ID::VARCHAR
        END AS DWH_PROCESS_UPDATE_ID,
    {% else %}
        ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
        NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
{% endif %}
{% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
{% endif %}
LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___banker_segment_onprem_file___banker_segment') }} AS S

/* Since we are executing the jobs in different modes, we had to include this if clause with
respect to run_type. However, the funcationality of this model is to just pull the latest data from
raw table to foundation, the logic will remain the same except when executing the job in full mode
(initial run), where the target table itself is not available.
*/
{% if is_incremental() %}
    {% if run_type == 'incremental' or run_type == 'from_date' or run_type == 'specific_date_range' or run_type == 'specific_date' %}
        LEFT JOIN {{ this }} AS T
        ON S.POSITION_NUMBER = T.POSITION_ID
        AND CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP
        WHERE S.DWH_PROCESS_TSTAMP > (SELECT MAX(DWH_PROCESS_TSTAMP) FROM {{ this }})
        {% elif run_type == 'full_data_load' %}
                -- No filtering, load all data
                WHERE 1=1        
        {% else %}
                WHERE 1=1
    {% endif %}
{% endif %}
