{% docs foundation___fdp__custmstr___fdp__managed_group_party_link %}

This foundation product represents the membership of a customer in a particular Managed Customer Group

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__managed_group_party_link___managed_group_id %}

The identifier of a managed group.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__managed_group_party_link___customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}
