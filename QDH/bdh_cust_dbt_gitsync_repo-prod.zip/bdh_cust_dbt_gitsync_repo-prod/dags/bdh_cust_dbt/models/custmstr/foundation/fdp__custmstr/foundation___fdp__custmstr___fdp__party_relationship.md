{% docs fdp__party_relationship %}

This foundation data product contains CUSTOMER RELATIONSHIP. It Records a formal relationship between different customers This is created from BST_CUST_RELN.

{% enddocs %}

{% docs fdp__party_relationship___customer_id %}

An identifier for each Bank Customer in CIS. - One of four primary keys in this table.

{% enddocs %}

{% docs fdp__party_relationship___relationship_type_code %}

"Specifies the broard category of relationship. - One of four primary keys in this
table. A two character code. The first character specifies whether it relates to a
formal or informal relationship 'F' = Formal 'I' = Informal The second character relates
to the relationship type. the types are: 'G' = General 'F' = Family 'B' = Business 'P' =
Partnership 'D' = Director 'S' = Sole Trader 'J' = Joint accepted_values: values:
['IG','FP','FJ','FD','FB','IF','FT','FS','IB']  
"

{% enddocs %}

{% docs fdp__party_relationship___relationship_code %}

"Defines a formal relationship between two customers. - One of four primary keys in this
table. Examples are: Related Customer is a director of the customer etc."

{% enddocs %}

{% docs fdp__party_relationship___related_customer_id %}

An identifier for each Bank Customer in CIS. - One of four primary keys in this table.

{% enddocs %}

{% docs fdp__party_relationship___start_date %}

"Relationship Start Date - The date at which a relationship between parties commenced.
This is not the date on which the system was updated with the relationship. This column
has been added as part of an AML Requirement"

{% enddocs %}

{% docs fdp__party_relationship___relation_access_flag %}

Indicates whether the indivdual has access to the joint account (Y) or not (N).
accepted_values: values: ['Y','N',' ']

{% enddocs %}

{% docs fdp__party_relationship___key_contact_flag %}

"NOT IMPLEMENTED (Indicator of Key Contact??)"

{% enddocs %}

{% docs fdp__party_relationship___other_free_text %}

Free format text field which contains a description of a Beneficial relationship, such
as Committee Member, or Accountant

{% enddocs %}

{% docs fdp__party_relationship___last_update_user_id %}

(AI-Generated) Identifier of the person responsible for the most recent update to the customer relationship record. It supports traceability and accountability for changes made to relationship information.

{% enddocs %}


{% docs fdp__party_relationship___last_update_tstamp %}

(AI-Generated) Date and time when the customer relationship record was last updated. It supports auditability and helps determine the recency of the relationship information.

{% enddocs %}
