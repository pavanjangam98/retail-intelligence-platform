{% docs foundation___fdp__custmstr___fdp__party_communication %}

This foundation product holds Customer communication details. Allows for the various methods that a customer may be contacted like

E - Email
T - Text
P - Page
F - Fax
C - Cell
L - Landline

This will be replaced by new source in the future.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_communication___customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_communication___emessage_service_id %}

A number to ensure unique identification for an emessage service.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_communication___emessage_type_code %}

Code that defines the type of electronic message this refers to;
E - Email
T - Text
P - Page
F - Fax
C - Cell
L - Landline

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_communication___priority_code %}

Nominated as preferred communication method, e.g. if 1 = fax then fax number is preferred number.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_communication___location_code %}

Code for the location ie H for Home, P for Personal,W for Work ,A for After Hours,X for Xero Home

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_communication___customer_communication_name %}

A nickname that a customer may associate to a communication method.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_communication___customer_communication_desc %}

Actual detail of a communication method, e.g. the email address, phone number.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_communication___last_update_user_id %}

(AI-Generated) Identifier of the person responsible for the most recent update to the communication record. It supports traceability and accountability for changes made to customer communication information.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_communication___last_update_tstamp %}

(AI-Generated) Date and time when the communication record was last updated. It supports auditability and helps determine the recency of the information.

{% enddocs %}
