{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference %}

This foundation product holds details of the ratings of an industry code and also includes mapping to legacy industry code groupings

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___nabsic_code %}

NABSIC22 Code (New NAB Group 6 digit codes)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___nabsic_desc %}

NABSIC22 Code Description (New NAB Group 6 digit codes)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___aml_risk_rating_code %}

AML Risk Rating (In Use) (Financial Crime Risk)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___bribery_and_corruption_rating_code %}

Bribery & Corruption Industry Risk Rating (Financial Crime Risk)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___esg_rating_code %}

ESG Risk Rating (Environment, Social, Governance Risk Rating)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___sanctions_rating_code %}

Sanctions Industry Risk Rating (Financial Crime Risk)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___terrorism_financing_rating_code %}

Terrorism Financing Risk Rating  (Financial Crime Risk)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___legacy_code %}

BIS Code (Legacy BNZ 4 digit codes)

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___level_1_code %}

ANZSIC93 Div Code (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___level_1_desc %}

ANZSIC93 Div Code Description (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___level_2_code %}

ANZSIC93 Sub Div Code (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___level_2_desc %}

ANZSIC93 Sub Div Code Description (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___level_3_code %}

ANZSIC93 Group Code (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___level_3_desc %}

ANZSIC93 Group Code Description (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___level_4_code %}

ANZSIC93 Class Code (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__party_demographics_industry_reference___level_4_desc %}

ANZSIC93 Class Code Description (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))

{% enddocs %}
