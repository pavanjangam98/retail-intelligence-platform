{% docs foundation___fdp__custmstr___fdp__managed_group_reference %}

This foundation product holds reference data related to a group of customers being managed (and reported upon) as a whole

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__managed_group_reference___managed_group_id %}

The identifier of a managed group.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__managed_group_reference___managed_group_name %}

Descriptive name given to a group by the responsible member of staff.

{% enddocs %}
