{% docs foundation___fdp__custmstr___fdp__emax_access_list %}

(AI-Generated) This foundation data product contains groupings of channel access facilities available to customers, sourced from EMAX referred to as Channel Access List EIT_ACS_LST in EMAX. Each record represents a defined set of facilities that a customer can use when interacting through a specific channel, supporting how access is organised and managed for customer convenience.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_access_list___access_list_key %}

An internally allocated sequence number given on access list creation. Unique Identifier/key to the Access List table - FDP__EMAX_ACCESS_LIST.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_access_list___emax_key %}

System generated unique number. Unique Identifier/key of the Customer Access table - FDP__EMAX_CUSTOMER_ACCESS (Foreign Key).

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_access_list___access_list_code %}

Indicates whether is is an Account (A) or a Bill Payment (B) list.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_access_list___access_list_desc %}

An identifying name given to the list by the customer from a pick list of valid list names.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_access_list___last_updated_tstamp %}

The date and time of the last update to the table.

{% enddocs %}