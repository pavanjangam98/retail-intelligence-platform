{{ config(
    materialized='view',
    secured=true,
    post_hook="alter view {{ this }} set secure;"
)}}

SELECT
    *
FROM {{ ref('foundation___fdp__custmstr___fdp__party_demographics_industry_reference') }} 