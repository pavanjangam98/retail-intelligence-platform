{% docs foundation___fdp__custmstr___fdp__emax_customer_access %}

(AI-Generated) This foundation data product contains customers who have been registered with a channel access identifier, sourced from EMAX referred to as Customer Channel Access EIT_CUST_ACS in EMAX. Each record represents an individual customer who has been assigned a unique customer access identifier (CAID) to interact with banking channels, linking their identity to authorised channel access.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_customer_access___emax_key %}

System generated unique number. Unique Identifier/key to the Customer Access table - FDP__EMAX_CUSTOMER_ACCESS.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_customer_access___customer_id %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_customer_access___default_channel_access_id %}

Default Channel Access Id. This is the Access number for the EMAX user allocated by the system and printed on cards issued to the customer.

{% enddocs %}

{% docs foundation___fdp__custmstr___fdp__emax_customer_access___last_update_tstamp %}

The date and time of the last update to this row.

{% enddocs %}