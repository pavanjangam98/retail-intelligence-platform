{{ config(
    materialized='incremental',
    unique_key=['WARNING_CODE',   'DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    post_hook=["DELETE FROM {{ this }}
    -- This post hook handles record deletion from type 2 table in RAW layer    
        WHERE warning_code || dwh_effective_from_tstamp 
        in
      (
        SELECT t.warning_code || t.dwh_effective_from_tstamp
        FROM {{ this }} t
        LEFT JOIN {{ ref('raw___bis___bst_warning_type') }} s
            ON t.warning_code = trim(s.warning_code)
            AND CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',T.dwh_effective_from_tstamp)::TIMESTAMP_LTZ = CONVERT_TIMEZONE('Pacific/Auckland','Pacific/Auckland',S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ
        WHERE s.warning_code IS NULL
      )"
    ]
  ) 
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select foundation___fdp__custmstr___fdp__party_warning_reference --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select foundation___fdp__custmstr___fdp__party_warning_reference --vars '{ "run_type": "full_data_load" }'
defualt values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", LOCALTIMESTAMP)" %}
{% else -%}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif -%}

SELECT
    --Standardise column names as a part of foundataional data product.
    TRIM(S.WARNING_CODE::VARCHAR) AS WARNING_CODE,
	  TRIM(S.WARNING_TEXT::VARCHAR) AS WARNING_TEXT,
    S.DWH_SOURCE_SYSTEM_CODE::VARCHAR AS DWH_SOURCE_SYSTEM_CODE,
    S.DWH_LATEST_DML_TYPE_CODE::VARCHAR AS DWH_LATEST_DML_TYPE_CODE,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_FROM_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_FROM_TSTAMP,
    CONVERT_TIMEZONE('Pacific/Auckland', 'Pacific/Auckland', S.DWH_EFFECTIVE_TO_TSTAMP)::TIMESTAMP_LTZ AS DWH_EFFECTIVE_TO_TSTAMP,
    S.DWH_IS_DELETED_FLAG::VARCHAR(5) AS DWH_IS_DELETED_FLAG,
    S.DWH_EXTRACTION_ID::VARCHAR AS DWH_EXTRACTION_ID,
    {% if is_incremental() %}
    CASE WHEN T.WARNING_CODE IS NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         WHEN T.WARNING_CODE IS NOT NULL THEN T.DWH_PROCESS_INSERT_ID
    END AS DWH_PROCESS_INSERT_ID,
    CASE WHEN T.WARNING_CODE IS NULL THEN NULL
         WHEN T.WARNING_CODE IS NOT NULL AND T.DWH_EFFECTIVE_TO_TSTAMP <> S.DWH_EFFECTIVE_TO_TSTAMP THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
         ELSE T.DWH_PROCESS_UPDATE_ID
    END AS DWH_PROCESS_UPDATE_ID,
    {% endif %}
    {% if not is_incremental() %}
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS DWH_PROCESS_INSERT_ID,
    NULL AS DWH_PROCESS_UPDATE_ID,
    {% endif %}

LOCALTIMESTAMP AS DWH_PROCESS_TSTAMP
FROM {{ ref('raw___bis___bst_warning_type') }} AS S
{% if is_incremental() %}
LEFT JOIN {{ this }} AS T
ON TRIM(S.WARNING_CODE) = T.WARNING_CODE
AND CONVERT_TIMEZONE('UTC', 'Pacific/Auckland', DATEADD(HOUR, -12, S.DWH_EFFECTIVE_FROM_TSTAMP))::TIMESTAMP_LTZ = T.DWH_EFFECTIVE_FROM_TSTAMP::TIMESTAMP_LTZ
{% endif %}

-- Only consider record that have changed in the RAW Layer within the last x days (Defined as parameter)
WHERE S.DWH_PROCESS_TSTAMP > {{ filter_date }}
