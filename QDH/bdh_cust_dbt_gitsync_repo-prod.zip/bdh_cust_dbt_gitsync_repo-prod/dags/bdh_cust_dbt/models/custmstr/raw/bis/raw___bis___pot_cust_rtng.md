{% docs raw___bis___pot_cust_rtng %}

This raw product holds details on customer rating

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___cnsmr_id %}

BIS Customer Number

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___rating_vers_cd %}

Rating version

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___cnsmr_rating %}

Consumer Rating number, on a sacle of 1-23, or 98,99

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___dflt_probability %}

The calculated risk of customer default on a scale of 0-100.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___srce_sys_cd %}

Source system code. Can be B , BB, M

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___impaird_asset_al %}

Not populated.  Impaired asset alighment.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___rating_dt_val %}

Rating date

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___lending_cat %}

Not populated.  Lending category.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___cnsmr_nm_line_1 %}

Rating Customer's formal name

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___cnsmr_rtg_tp_cd %}

Consumer Rating Type Code. Can be B, F ,G ,N ,P ,R ,S

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___ind_occup_cd %}

Rarely populated but can contain ISO Industry Codes

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___old_cnsmr_rating %}

Previous customer rating, on a scale of 1-23, and also 98

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___old_dflt_prob %}

The old customer default probability, on a scale of 0-100

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___org_type %}

Not populated.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___iso_cntry_cd %}

Uniquely identifies the country. 3 letter ISO country code for the customer.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___brand_id %}

Not populated. Brand Identifier.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___location %}

Controlling location. Various content - can be country, branch, location code.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___rating_officer %}

Staff number and name of the rating officer

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___acct_mgr %}

Rating Account Manager

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___close_monitr_ind %}

Indicates Y, N or space whether Close Monitored

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___ad_data_st %}

Unknown content flag, contains N or Y.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___impaird_asset_st %}

Impaired Asset Status. Usually not populated ('Normal' status), but can contain values of   'R' 'Restructured     'P'      'Default (no loss)'    'N'     'Loss/Non Accrual '  'H'  'Hardship    'W' 'Watch 

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___strategy_cd %}

Strategy Code. Can be space, E or R

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___rsn_non_via_cd %}

Reason for Non viability Code

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___asset_mgr_id %}

Rating's Asset Manager name.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___override_ind %}

Indicates Y or N whether there is an override

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___auth_officer_id %}

Authority officer name and staff number.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___override_rsn_cd %}

Code indicating the reason for the override, can be numeric 01-13 or letter A,B,C,D,E,F,G, H,I,L,N,T . Unable to locate meaning for these codes.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___prnt_cnsmr_id %}

Parent customer number

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___prnt_cnsmr_rtg %}

Parent customer rating

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___prnt_dflt_prob %}

Parent customer default probablity

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___prnt_scoring_mod %}

Not populated.

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___prnt_rtg_dt_val %}

Parent Rating date

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___prnt_lending_cat %}

Parent lending category

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___pc_vers_cd %}

Usually not populated, or contains ECRS01

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___special_lend_ind %}

Special Lending indicator. Contains Y or N, or space

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___sub_class_cd %}

Sub class code, can be   I , O , P

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___model_id %}

Rating model id

{% enddocs %}

{% docs raw___bis___pot_cust_rtng___model_name %}

Rating model name

{% enddocs %}
