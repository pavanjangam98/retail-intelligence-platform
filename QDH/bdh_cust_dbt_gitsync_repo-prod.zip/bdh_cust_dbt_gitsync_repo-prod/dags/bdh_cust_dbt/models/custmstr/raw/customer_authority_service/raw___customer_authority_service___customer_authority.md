{% docs raw___customer_authority_service___customer_authority %}

This raw product holds details of digital customer authority information

{% enddocs %}

{% docs raw___customer_authority_service___customer_authority___operatingauthorityid %}

Unique identifier of the active operatig authority containing association

{% enddocs %}

{% docs raw___customer_authority_service___customer_authority___revisionnumber %}

the revision number containing associations

{% enddocs %}

{% docs raw___customer_authority_service___customer_authority___governedcustomernumber %}

Unique identifier of the governed customer

{% enddocs %}

{% docs raw___customer_authority_service___customer_authority___authorisedcustomernumber %}

Unique identifier of the authorised customer

{% enddocs %}

{% docs raw___customer_authority_service___customer_authority___authorisedcustomertype %}

The type of the authorised customer

{% enddocs %}

{% docs raw___customer_authority_service___customer_authority___effectivefromdate %}

Optional effective from date, for indicative purposes

{% enddocs %}

{% docs raw___customer_authority_service___customer_authority___effectivetodate %}

Optional effective to date, for indicative purposes

{% enddocs %}
