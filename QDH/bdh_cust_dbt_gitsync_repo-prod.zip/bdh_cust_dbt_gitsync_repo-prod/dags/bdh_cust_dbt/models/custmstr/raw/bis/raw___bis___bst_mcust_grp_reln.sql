{% do set_query_tag() %}
{{ config(
    materialized='incremental',
    unique_key=['POSITION_NO', 'MANAGED_GROUP_NO', 'RELATIONSHIP_TYPE',  'DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    tmp_relation_type='table',
    post_hook=["DELETE FROM {{ this }} 
    -- This post hook handles record deletion from source in landing layer    
      where
        POSITION_NO || MANAGED_GROUP_NO || RELATIONSHIP_TYPE ||  dwh_effective_from_tstamp 
        in
      (
        select t.POSITION_NO || t.MANAGED_GROUP_NO || t.RELATIONSHIP_TYPE ||  t.dwh_effective_from_tstamp
        from {{ this }} t left join {{ source('landing__bis', 'BST_MCUST_GRP_RELN') }} s 
        on t.POSITION_NO = coalesce (RECORD_CONTENT:afterState.POSITION_NO,RECORD_CONTENT:beforeState.POSITION_NO)
 	 	 and t.MANAGED_GROUP_NO = coalesce (RECORD_CONTENT:afterState.MANAGED_GROUP_NO,RECORD_CONTENT:beforeState.MANAGED_GROUP_NO)
 	 	 and t.RELATIONSHIP_TYPE = coalesce (RECORD_CONTENT:afterState.RELATIONSHIP_TYPE,RECORD_CONTENT:beforeState.RELATIONSHIP_TYPE)
 	 	 and  t.dwh_effective_from_tstamp = RECORD_CONTENT:metadata.time
        where 
          coalesce (RECORD_CONTENT:afterState.POSITION_NO,RECORD_CONTENT:beforeState.POSITION_NO) is null 
 	 	 and coalesce (RECORD_CONTENT:afterState.MANAGED_GROUP_NO,RECORD_CONTENT:beforeState.MANAGED_GROUP_NO) is null 
 	 	 and coalesce (RECORD_CONTENT:afterState.RELATIONSHIP_TYPE,RECORD_CONTENT:beforeState.RELATIONSHIP_TYPE) is null 
		 	AND dwh_effective_from_tstamp >= DATEADD(DAY, -{{ var('days_back', 30) }} , CURRENT_TIMESTAMP()))"]
  ) 
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select raw___bis___bst_mcust_grp_reln --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build --select  +raw___bis___bst_mcust_grp_reln+ --vars '{ "run_type": "full_data_load", "days_back": 30 }'

default values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point


A full data load will read from the Full Historical View and a Specific Data Load will perform an incremental load directly from the on-going Kafka Landing table.
When deploying, a full data load should be performed before incremental.
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", CURRENT_TIMESTAMP())" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}
/* Setting the "source" based on incremental load vs full data load */
{% if run_type == 'specific_data_load' %}
  {% set source_model = source("landing__bis", "BST_MCUST_GRP_RELN") %}
{% else %} 
  {% set source_model = ref('raw___bis___bst_mcust_grp_reln_full_view') %}
{% endif %}

WITH raw_bst_mcust_grp_reln AS (
   {{
    generate_json_flatten_uptoarray(
    model_name = source_model,
    json_column = 'RECORD_CONTENT')
     }} WHERE metadata_time::TIMESTAMP_NTZ >= {{ filter_date }}
)

--Todo: Raise with source team. Determine if this can be fixed or needs to be handled. Anne is working with BIS team to determine.
--This cte currently performs the date filter and deduplication of the data. If dedupe logic is removed (Qualify), date filter should remain included.
, cte_dedupe AS (
    SELECT * FROM raw_bst_mcust_grp_reln
    -- WHERE metadata_time::TIMESTAMP_NTZ >= {{ filter_date }}
    QUALIFY ROW_NUMBER() OVER (
      PARTITION BY
      COALESCE(afterstate_position_no::VARCHAR, beforestate_position_no::VARCHAR),
 	 	  COALESCE(afterstate_managed_group_no::VARCHAR, beforestate_managed_group_no::VARCHAR),
 	 	  COALESCE(afterstate_relationship_type::VARCHAR, beforestate_relationship_type::VARCHAR),
       metadata_time::TIMESTAMP_NTZ
      ORDER BY metadata_time::TIMESTAMP_NTZ DESC) = 1
)

--Kafka Regular Scenario (afterState populated)
, cte_pre_bst_mcust_grp_reln AS (
    SELECT
      {{ select_bst_mcust_grp_reln_fields('AFTERSTATE') }},
      'BIS' AS dwh_source_system_code,
      metadata_time::TIMESTAMP_NTZ AS updated_at,
      'N' AS dwh_is_deleted_flag,
      metadata_id::VARCHAR(50) AS dwh_extraction_id,
      ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
      null AS dwh_process_update_id,
      CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp
      FROM cte_dedupe
      WHERE NOT IS_NULL_VALUE(record_content:afterState)
      )

--Kafka Delete Scenario (beforeState populated afterState not populated)
--      should AFTERSTATE_CUSTOMER_NO always NULL as where filer IS_NULL_VALUE(RECORD_CONTENT:afterState)
--      CASE WHEN AFTERSTATE_CUSTOMER_NO::NUMBER(10,0) IS NULL THEN 'Y' ELSE 'N' END AS DWH_IS_DELETED_FLAG,
--      AFTERSTATE_CUSTOMER_NO1 already been defined as NUMBER
--      although we have four PKs as the composite key, only check one PK should be enough?
, cte_pre_bst_mcust_grp_reln_delete AS (
    SELECT
      {{ select_bst_mcust_grp_reln_fields('BEFORESTATE') }},
      'BIS' AS dwh_source_system_code,
      metadata_time::TIMESTAMP_NTZ AS updated_at,
      CASE WHEN afterstate_position_no IS null THEN 'Y' ELSE 'N' END AS dwh_is_deleted_flag,
      metadata_id::VARCHAR(50) AS dwh_extraction_id,
      ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
      null AS dwh_process_update_id,
      CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp
      FROM cte_dedupe
      WHERE IS_NULL_VALUE(record_content:afterState)
      )

-- Only check existing records if existing records exist. If they do get the latest record needed to be checked for updates
/*Qestion: wonder if there is any difference in between get old data than before filter_data and use use {{ this }} + data >= filter_date
regarding the performance and cost, especially for large data set?
*/
{% if is_incremental() %}
, cte_old_active_records AS (
    SELECT
			position_no,
			managed_group_no,
			relationship_type,
			reln_create_date,
			management_ind,
			dwh_source_system_code,
			dwh_effective_from_tstamp AS updated_at,
			dwh_is_deleted_flag,
			dwh_extraction_id,
			dwh_process_insert_id,
			dwh_process_update_id,
			dwh_process_tstamp
    FROM {{ this }}
    WHERE dwh_effective_from_tstamp < {{ filter_date }}
    -- AND dwh_effective_to_tstamp = '9999-12-31'::TIMESTAMP_NTZ
    QUALIFY ROW_NUMBER() OVER (PARTITION BY position_no, managed_group_no, relationship_type ORDER BY dwh_effective_from_tstamp DESC) = 1

)
{% endif %}

--Can only combine all three if existing records exist
{% if is_incremental() %}
, cte_combine AS (
    SELECT * FROM cte_pre_bst_mcust_grp_reln
    UNION ALL
    SELECT * FROM cte_pre_bst_mcust_grp_reln_delete
    UNION ALL
    SELECT * FROM cte_old_active_records
)
{% endif %}
 --If existing records don't exist, ignore existing check
{% if not is_incremental() %}
, cte_combine AS (
    SELECT * FROM cte_pre_bst_mcust_grp_reln
    UNION ALL
    SELECT * FROM cte_pre_bst_mcust_grp_reln_delete
)
{% endif %}

 --Calculate the Effective From and Effective To based on the subset of data combined above.
/* METADATA_TIME::TIMESTAMP_NTZ AS UPDATED_AT,
 if incremetnal (exising) DWH_EFFECTIVE_FROM_TSTAMP AS UPDATED_AT,
 the purpose to EXCLUDE UPDATED_AT as we need rename UPDATED_AT AS DWH_EFFECTIVE_FROM_TSTAMP
*/
, cte_dwh_fields AS (
    SELECT
* EXCLUDE updated_at,
    updated_at AS dwh_effective_from_tstamp,
 -- to test if the lead works as expected is DWH_EFFECTIVE_FROM_TSTAMP is null or DWH_EFFECTIVE_TO_TSTAMP is null or DWH_EFFECTIVE_TO_TSTAMP< DWH_EFFECTIVE_FROM_TSTAMP 
       TIMESTAMPADD(MICROSECOND, -1, COALESCE(LEAD(updated_at)
    OVER (PARTITION BY position_no, managed_group_no, relationship_type ORDER BY updated_at ASC)
    , '9999-12-31T00:00:00.000001'::TIMESTAMP_NTZ)) AS dwh_effective_to_tstamp,
    ROW_NUMBER() OVER (PARTITION BY position_no, managed_group_no, relationship_type ORDER BY updated_at ASC) AS record_order,
    LAG(dwh_is_deleted_flag) OVER (PARTITION BY position_no, managed_group_no, relationship_type ORDER BY dwh_effective_from_tstamp ASC) AS prev_delete
    FROM cte_combine
    )

  {% if is_incremental() %}
  --If existing records exist determine records that need to be inserted / updated to limit # of record to merge.
  -- again, in the future, if we have a very large table, how efficient/ what this is cost for using the method below 
, cte_records_to_merge AS (
    SELECT
s.* EXCLUDE (dwh_process_insert_id, dwh_process_update_id, dwh_process_tstamp),
    -- here we only use one of composite key 
    CASE WHEN s.dwh_is_deleted_flag = 'Y' THEN 'D'
         WHEN s.dwh_is_deleted_flag = 'N' AND ((s.record_order = 1 AND COALESCE(t.dwh_latest_dml_type_code, 'I') = 'I')
          OR (prev_delete = 'Y')) THEN 'I'
	      ELSE 'U' END AS dwh_latest_dml_type_code,
     CASE WHEN t.position_no IS null THEN s.dwh_process_insert_id
         WHEN t.position_no IS NOT null THEN t.dwh_process_insert_id END AS dwh_process_insert_id,
    CASE WHEN t.position_no IS null THEN null
         WHEN t.position_no IS NOT null THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR END AS dwh_process_update_id,
	 CASE WHEN t.position_no IS null THEN s.dwh_process_tstamp
         WHEN t.position_no IS NOT null THEN CURRENT_TIMESTAMP()::TIMESTAMP_LTZ END AS dwh_process_tstamp
     FROM cte_dwh_fields AS s
    LEFT JOIN {{ this }} AS t
    ON s.position_no = t.position_no
 	AND s.managed_group_no = t.managed_group_no
 	AND s.relationship_type = t.relationship_type
    AND s.dwh_effective_from_tstamp = t.dwh_effective_from_tstamp
    WHERE (t.position_no IS null --New history scenario
        OR (t.dwh_effective_to_tstamp = '9999-12-31'::TIMESTAMP_NTZ AND s.dwh_effective_to_tstamp <> '9999-12-31'::TIMESTAMP_NTZ) --End dating existing open record
        OR s.dwh_effective_to_tstamp <> t.dwh_effective_to_tstamp) --Missing Record Scenario
)
{% endif %}
{% if not is_incremental() %}
--If existing records do not exist create first version of records.
, cte_records_to_merge AS (
    SELECT
s.*
      , CASE WHEN s.dwh_is_deleted_flag = 'Y' THEN 'D'
         WHEN s.dwh_is_deleted_flag = 'N'
          AND (s.record_order = 1 OR s.prev_delete = 'Y') THEN 'I'
         ELSE 'U' END AS dwh_latest_dml_type_code
    FROM cte_dwh_fields AS s
)
{% endif %}

SELECT
  position_no,
	managed_group_no,
	relationship_type,
	reln_create_date,
	management_ind,
	dwh_source_system_code,
	dwh_latest_dml_type_code,
	dwh_effective_from_tstamp,
	dwh_effective_to_tstamp,
	dwh_is_deleted_flag,
	dwh_extraction_id,
	dwh_process_insert_id,
	dwh_process_update_id,
	dwh_process_tstamp
FROM cte_records_to_merge
