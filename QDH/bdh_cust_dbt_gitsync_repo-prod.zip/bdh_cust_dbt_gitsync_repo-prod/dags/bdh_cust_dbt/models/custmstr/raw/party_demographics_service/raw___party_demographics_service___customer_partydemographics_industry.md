{% docs raw___party_demographics_service___customer_partydemographics_industry %}

This raw product holds the link between NABSIC industry code, legacy industry code and a customer.

{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry___customernumber %}

The customer identifier

{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry___code %}

NABSIC Code (New NAB Group 6 digit codes)

{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry___legacycode %}

BIS Code (Legacy BNZ 4 digit codes)

{% enddocs %}
