{{ config(
    materialized='view'
) }}

-- Determine the earliest record available for each key within the BAU CDC dataset.
WITH cte_cdc_cutoff AS (
    SELECT
      COALESCE(PARSE_JSON(record_content):afterState:RELATIONSHIP_TYPE::VARCHAR,
               PARSE_JSON(record_content):beforeState:RELATIONSHIP_TYPE::VARCHAR
      ) AS relationship_type,
      MIN(PARSE_JSON(record_content):metadata:time::TIMESTAMP_NTZ) AS earliest_record
    FROM {{ source("landing__bis", "BST_MCUST_RELNTYPE") }}
    GROUP BY
      COALESCE(PARSE_JSON(record_content):afterState:RELATIONSHIP_TYPE::VARCHAR,
               PARSE_JSON(record_content):beforeState:RELATIONSHIP_TYPE::VARCHAR)
)

-- Standardise the historical hadoop data to follow the same format as the CDC events.
, cte_standardise_hadoop_data AS (
    SELECT
      PARSE_JSON(value):CDC_SEND_TSTAMP::TIMESTAMP_NTZ AS cdc_send_tstamp,
      PARSE_JSON(value):HDP_DML_CODE::VARCHAR AS hdp_dml_code,
      OBJECT_CONSTRUCT_KEEP_NULL(
          'RELATIONSHIP_TYPE', PARSE_JSON(value):RELATIONSHIP_TYPE,
          'RELN_SHORT_DESC', PARSE_JSON(value):RELN_SHORT_DESC,
          'RELATIONSHIP_DESC', PARSE_JSON(value):RELATIONSHIP_DESC,
          'MANAGEMENT_IND', PARSE_JSON(value):MANAGEMENT_IND
      ) AS value
    FROM {{ source("landing__bis", "BST_MCUST_RELNTYPE_HISTORICAL") }}
)

-- Build hadoop records into the format of beforeState and afterState.
, cte_hadoop_data AS (
    SELECT
      OBJECT_CONSTRUCT_KEEP_NULL() AS record_metadata,
      OBJECT_CONSTRUCT_KEEP_NULL(
              'afterState', CASE WHEN hdp_dml_code IN ('I', 'U', 'RR') THEN value END,
              'beforeState', CASE WHEN hdp_dml_code IN ('U', 'D') THEN value END,
              'metadata', OBJECT_CONSTRUCT_KEEP_NULL(
                              'id', 'hist_record',
                              'source', 'BST_MCUST_RELNTYPE',
                              'subject', NULL,
                              'time', cdc_send_tstamp,
                              'type', 'dwh_history'
                              )
              ) AS record_content
    FROM cte_standardise_hadoop_data AS h
    LEFT JOIN cte_cdc_cutoff AS c
      ON c.relationship_type = h.value:RELATIONSHIP_TYPE::VARCHAR
    WHERE h.cdc_send_tstamp < COALESCE(c.earliest_record, '9999-12-31'::TIMESTAMP_NTZ)
)

-- Union the CDC data and historical data with no overlap.
SELECT * FROM {{ source("landing__bis", "BST_MCUST_RELNTYPE") }}
UNION ALL
SELECT * FROM cte_hadoop_data
