{% docs raw___bis___bst_np_customer %}

This Customer Model to load data from Landing Layer to Raw Layer for BST Non personal
Customer table.

{% enddocs %}

{% docs raw___bis___bst_np_customer___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs raw___bis___bst_np_customer___fin_year_end_code %}

The month, nominated by the customer, for which the last day is their annual balance
date for accounting purposes.

{% enddocs %}

{% docs raw___bis___bst_np_customer___end_trading_date %}

The date on which the customer ceased trading.

{% enddocs %}

{% docs raw___bis___bst_np_customer___trading_name %}

The commonly used name of the non-personal customer, when different from their formal
name.

{% enddocs %}

{% docs raw___bis___bst_np_customer___trading_ind %}

An indication of whether the Bank considers the customer as engaging in trade or not.

{% enddocs %}

{% docs raw___bis___bst_np_customer___pension_scheme_ind %}

Indication that the customer operates a pension scheme or not.

{% enddocs %}

{% docs raw___bis___bst_np_customer___non_profit_org_ind %}

An indication of whether the Bank regards the customer as a non-profit-making
organisation or not.

{% enddocs %}

{% docs raw___bis___bst_np_customer___canvas_ind %}

An indication if it is permissable to market directly to the employees of the customer
or not.

{% enddocs %}

{% docs raw___bis___bst_np_customer___founded_date %}

The date on which the nonpersonal customer came into existance.

{% enddocs %}

{% docs raw___bis___bst_np_customer___emp_count_dat %}

Date on which the number of employees employed by the customer was recorded.

{% enddocs %}

{% docs raw___bis___bst_np_customer___employee_count %}

The number of employees employed by the non-personal customer.

{% enddocs %}

{% docs raw___bis___bst_np_customer___partnership_type %}

Indicates whether the partnership is a 'special' or 'general' partnership.

{% enddocs %}

{% docs raw___bis___bst_np_customer___deed_ind %}

An indication that the bank has sighted or holds a copy of the partnership agreement.

{% enddocs %}

{% docs raw___bis___bst_np_customer___rules_held_ind %}

Indicates whether ruls are held for this customer.

{% enddocs %}

{% docs raw___bis___bst_np_customer___np_cust_type %}

Classification of Non Personal customer by their major characteristics. ""C"" = Company
""P"" = Partnership ""S"" = Sole Trader ""T"" = Trust ""E"" = Estate ""F"" = Formal
Group ""G"" = Informal Group ""U"" = Unknown

{% enddocs %}

{% docs raw___bis___bst_np_customer___industry_code %}

The standard code that best identifies the nature of the business carried out by a
customer.

{% enddocs %}

{% docs raw___bis___bst_np_customer___auto_acc_addr_ind %}

Indicates whether the customer requires different addresses for their accounts. Value: y
= automatic update of account addresses n = requires different addresses so no automatic
update

{% enddocs %}

{% docs raw___bis___bst_np_customer___incorp_no %}

Incorporation number

{% enddocs %}

{% docs raw___bis___bst_np_customer___oseas_incorp_no %}

Overseas Incorporation Number - This is the unique ID that is assigned to a non personal
entity in a foreign country (as sited on official documents). This column has been added
as part of an AML Requirement

{% enddocs %}

{% docs raw___bis___bst_np_customer___non_res_incorp_cty %}

Country of incorporation if not NZ eg US

{% enddocs %}

{% docs raw___bis___bst_np_customer___gii_no %}

Global Intermediary Identification Number eg 123456-.12345.12.123

{% enddocs %}

{% docs raw___bis___bst_np_customer___np_cust_subtype %}

Customer Sub-Type “RE, “TR”

{% enddocs %}

{% docs raw___bis___bst_np_customer___trading_locn %}

Trading only within NZ or also Offshore Incorporated in; “NZ”, “OS” or “ ”

{% enddocs %}

{% docs raw___bis___bst_np_customer___crs_entity_class %}

{% enddocs %}

{% docs raw___bis___bst_np_customer___crs_ent_sub_class %}

Entity sub-classification as defined by the Common Reporting Standard for the purpose of
tax compliance

{% enddocs %}

{% docs raw___bis___bst_np_customer___nz_business_no %}

{% enddocs %}

{% docs raw___bis___bst_np_customer___entity_type %}

{% enddocs %}
