{{ config(
    materialized='view'
) }}

-- Determine the earliest record available for each WORKPLACE_CODE in the CDC dataset
WITH CTE_CDC_CUTOFF AS (
    SELECT
        PARSE_JSON(RECORD_CONTENT):afterState:WORKPLACE_CODE::VARCHAR AS WORKPLACE_CODE,
        MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM {{ source("landing__bis", "BST_WORKPLACE") }}
    GROUP BY PARSE_JSON(RECORD_CONTENT):afterState:WORKPLACE_CODE::VARCHAR
)

-- Standardize the historical Hadoop data to follow the same format as the CDC events
, CTE_STANDARDISE_HADOOP_DATA AS (
    SELECT
    PARSE_JSON(VALUE):CDC_SEND_TSTAMP::VARCHAR AS CDC_SEND_TSTAMP,
    PARSE_JSON(VALUE):HDP_DML_CODE::VARCHAR AS HDP_DML_CODE,
    OBJECT_CONSTRUCT_KEEP_NULL(
        'WORKPLACE_CODE', PARSE_JSON(VALUE):WORKPLACE_CODE,
        'WORKPLACE_DESC', PARSE_JSON(VALUE):WORKPLACE_DESC,
        'END_DATE', PARSE_JSON(VALUE):END_DATE
    ) AS VALUE
    FROM {{ source("landing__bis", "BST_WORKPLACE_HISTORICAL") }}
)

-- Filter Hadoop data to include only records before the earliest CDC record for each WORKPLACE_CODE
, CTE_HADOOP_DATA AS (
    SELECT
    OBJECT_CONSTRUCT_KEEP_NULL() AS RECORD_METADATA,
    OBJECT_CONSTRUCT_KEEP_NULL(
            'afterState', CASE WHEN HDP_DML_CODE IN ('I', 'U', 'RR') THEN VALUE END,
            'beforeState', CASE WHEN HDP_DML_CODE IN ('U', 'D') THEN VALUE END,
            'metadata', OBJECT_CONSTRUCT_KEEP_NULL(
                            'id', 'hist_record',
                            'source', 'BST_WORKPLACE_HISTORICAL',
                            'subject', NULL,
                            'time', CDC_SEND_TSTAMP,
                            'type', 'dwh_history'
                            )
            ) AS RECORD_CONTENT
    FROM CTE_STANDARDISE_HADOOP_DATA
    LEFT JOIN CTE_CDC_CUTOFF AS C
    ON VALUE:WORKPLACE_CODE::VARCHAR = C.WORKPLACE_CODE
    WHERE CDC_SEND_TSTAMP::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

-- Combine the Hadoop and CDC datasets to create the full view
SELECT * FROM {{ source("landing__bis", "BST_WORKPLACE") }}
UNION ALL
SELECT * FROM CTE_HADOOP_DATA
