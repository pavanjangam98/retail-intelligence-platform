{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data %}
This raw product holds details of the ratings of an industry code and also includes mapping to legacy industry code groupings
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___amlrating %}
AML Risk Rating (In Use) (Financial Crime Risk)
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___briberyandcorruptionrating %}
Bribery & Corruption Industry Risk Rating (Financial Crime Risk)
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___esgrating %}
ESG Risk Rating (Environment, Social, Governance Risk Rating)
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___keywordphrasetxt %} 
Not used 
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___legacycode %}
BIS Code (Legacy BNZ 4 digit codes)
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___level1code %}
ANZSIC93 Div Code (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___level1description %}
ANZSIC93 Div Code Description (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___level2code %}
ANZSIC93 Sub Div Code (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___level2description %}
ANZSIC93 Sub Div Code Description (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___level3code %}
ANZSIC93 Group Code (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___level3description %}
ANZSIC93 Group Code Description (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___level4code %}
ANZSIC93 Class Code (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___level4description %}
ANZSIC93 Class Code Description (ANZSIC93 4 digit codes (Code Hierarchy/Mapping))
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___nabsiccode %}
NABSIC22 Code (New NAB Group 6 digit codes)
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___nabsicdescription %}
NABSIC22 Code Description (New NAB Group 6 digit codes)
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___sanctionsrating %}
Sanctions Industry Risk Rating (Financial Crime Risk)
{% enddocs %}

{% docs raw___party_demographics_service___customer_partydemographics_industry_reference_data___terrorismfinancingrating %}
Terrorism Financing Risk Rating  (Financial Crime Risk)
{% enddocs %}
