{% do set_query_tag() %}
    {{ config(
        materialized='incremental',
        unique_key=['nabSicCode', 'DWH_EFFECTIVE_FROM_TSTAMP'],
        incremental_strategy='merge',
        tmp_relation_type='table',
        post_hook=["DELETE FROM {{ this }}
        WHERE nabSicCode || DWH_EFFECTIVE_FROM_TSTAMP IN (
            SELECT t.nabSicCode || DWH_EFFECTIVE_FROM_TSTAMP
            FROM {{ this }} t
            LEFT JOIN {{ source('landing__party_demographics_service', 'CUSTOMER_PARTYDEMOGRAPHICS_INDUSTRY_REFERENCE_DATA') }} s
            ON t.nabSicCode = COALESCE(RECORD_CONTENT:data:stateAfter.industryReference.nabSicCode, RECORD_CONTENT:data:stateBefore.industryReference.nabSicCode)
            AND t.dwh_effective_from_tstamp = RECORD_CONTENT:metadata.time
            WHERE COALESCE(RECORD_CONTENT:data:stateAfter.industryReference.nabSicCode, RECORD_CONTENT:data:stateBefore.industryReference.nabSicCode) IS NULL
	AND dwh_effective_from_tstamp >= DATEADD(DAY, -{{ var('days_back', 30) }} , CURRENT_TIMESTAMP()))"]
    ) }}
/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select raw___party_demographics_service___customer_partydemographics_industry_reference_data --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select +raw___party_demographics_service___customer_partydemographics_industry_reference_data+ --vars '{ "run_type": "full_data_load", "days_back": 30 }'

default values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point

A full data load will read from the Full Historical View and a Specific Data Load will perform an incremental load directly from the on-going Kafka Landing table.
When deploying, a full data load should be performed before incremental.
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}


{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", CURRENT_TIMESTAMP())" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}
/* Setting the "source" based on incremental load vs full data load */
{% if run_type == 'specific_data_load' %}
  {% set source_model = source("landing__party_demographics_service", "CUSTOMER_PARTYDEMOGRAPHICS_INDUSTRY_REFERENCE_DATA") %}
{% else %}
  {% set source_model = ref('raw___party_demographics_service___customer_partydemographics_industry_reference_data_full_view') %}
{% endif %}


WITH raw_customer_partydemographics_industry_reference_data AS (
   {{
    generate_json_flatten_uptoarray(
    model_name = source_model,
    json_column = 'RECORD_CONTENT')
     }} WHERE metadata_time::TIMESTAMP_TZ >= {{ filter_date }}
)

--Todo: Raise with source team. Determine if this can be fixed or needs to be handled. Anne is working with BIS team to determine.
--This cte currently performs the date filter and deduplication of the data. If dedupe logic is removed (Qualify), date filter should remain included.

, cte_dedupe AS (
    SELECT *
    FROM raw_customer_partydemographics_industry_reference_data
    QUALIFY ROW_NUMBER() OVER (
            PARTITION BY COALESCE(record_content:data:stateAfter.industryReference.nabSicCode, record_content:data:stateBefore.industryReference.nabSicCode),
            metadata_time::TIMESTAMP_TZ
        ORDER BY metadata_time::TIMESTAMP_TZ DESC
    ) = 1
)

--Kafka Regular Scenario

, cte_pre_customer_partydemographics_industry_reference_data AS (
    SELECT
     {{ select_party_demographics_service_customer_partydemographics_industry_reference_data_fields('DATA_STATEAFTER_INDUSTRYREFERENCE') }},
      'PARTY_DEMOGRAPHICS_SERVICE' AS dwh_source_system_code,
      metadata_time::TIMESTAMP_TZ AS updated_at,
      'N' AS dwh_is_deleted_flag,
      metadata_id::VARCHAR(50) AS dwh_extraction_id,
      ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
      null AS dwh_process_update_id,
      CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp
      FROM cte_dedupe
      WHERE NOT IS_NULL_VALUE(record_content:data:stateAfter)
      )

--Kafka Delete Scenario (beforeState populated afterState not populated)
--      should data:stateAfter_CUSTOMERNUMBER always NULL as where filer IS_NULL_VALUE(RECORD_CONTENT:data:stateAfter)
--      CASE WHEN data:stateAfter_CUSTOMERNUMBER::NUMBER(10,0) IS NULL THEN 'Y' ELSE 'N' END AS DWH_IS_DELETED_FLAG,
--      data:stateAfter_CUSTOMERNUMBER already been defined as NUMBER
--      although we have four PKs as the composite key, only check one PK should be enough? 

, cte_pre_customer_partydemographics_industry_reference_data_delete AS (
    SELECT
      {{ select_party_demographics_service_customer_partydemographics_industry_reference_data_fields('DATA_STATEBEFORE_INDUSTRYREFERENCE') }},
      'PARTY_DEMOGRAPHICS_SERVICE' AS dwh_source_system_code,
      metadata_time::TIMESTAMP_TZ AS updated_at,
      CASE WHEN data_stateafter_industryreference_nabsiccode IS null THEN 'Y' ELSE 'N' END AS dwh_is_deleted_flag,
      metadata_id::VARCHAR(50) AS dwh_extraction_id,
      ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
      null AS dwh_process_update_id,
      CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp
      FROM cte_dedupe
      WHERE IS_NULL_VALUE(record_content:data:stateAfter)
      )

{% if is_incremental() %}
, cte_old_active_records AS (
    SELECT
    amlrating,
    briberyandcorruptionrating,
    esgrating,
    keywordphrasetxt,
    legacycode,
    level1code,
    level1description,
    level2code,
    level2description,
    level3code,
    level3description,
    level4code,
    level4description,
    nabsiccode,
    nabsicdescription,
    sanctionsrating,
    terrorismfinancingrating,
    dwh_source_system_code,
    dwh_effective_from_tstamp AS updated_at,
    dwh_is_deleted_flag,
    dwh_extraction_id,
    dwh_process_insert_id,
    dwh_process_update_id,
    dwh_process_tstamp
    FROM {{ this }}
    WHERE dwh_effective_from_tstamp < {{ filter_date }}
    QUALIFY ROW_NUMBER() OVER (PARTITION BY nabsiccode ORDER BY dwh_effective_from_tstamp DESC) = 1
)
{% endif %}

--Can only combine all three if existing records exist
{% if is_incremental() %}
, cte_combine AS (
        SELECT * FROM cte_pre_customer_partydemographics_industry_reference_data
        UNION ALL
        SELECT * FROM cte_pre_customer_partydemographics_industry_reference_data_delete
        UNION ALL
        SELECT * FROM cte_old_active_records
)
{% endif %}
 --If existing records don't exist, ignore existing check
{% if not is_incremental() %}
, cte_combine AS (
    SELECT * FROM cte_pre_customer_partydemographics_industry_reference_data
    UNION ALL
    SELECT * FROM cte_pre_customer_partydemographics_industry_reference_data_delete
)
{% endif %}

 --Calculate the Effective From and Effective To based on the subset of data combined above.
/* METADATA_TIME::TIMESTAMP_TZ AS UPDATED_AT,
 if incremetnal (exising) DWH_EFFECTIVE_FROM_TSTAMP AS UPDATED_AT,
 the purpose to EXCLUDE UPDATED_AT as we need rename UPDATED_AT AS DWH_EFFECTIVE_FROM_TSTAMP
*/
    , cte_dwh_fields AS (
        SELECT
            * EXCLUDE updated_at,
            updated_at AS dwh_effective_from_tstamp,
            TIMESTAMPADD(MICROSECOND, -1, COALESCE(
           LEAD(updated_at) OVER (PARTITION BY nabsiccode ORDER BY updated_at ASC),
           '9999-12-31T00:00:00.000001'::TIMESTAMP_TZ
       )) AS dwh_effective_to_tstamp,
       ROW_NUMBER() OVER (PARTITION BY nabsiccode ORDER BY updated_at ASC) AS record_order,
       LAG(dwh_is_deleted_flag) OVER (PARTITION BY nabsiccode ORDER BY dwh_effective_from_tstamp ASC) AS prev_delete
       FROM cte_combine
    )

  {% if is_incremental() %}
  --If existing records exist determine records that need to be inserted / updated to limit # of record to merge.
  -- again, in the future, if we have a very large table, how efficient/ what this is cost for using the method below

 , cte_records_to_merge AS (
    SELECT
        s.* EXCLUDE (dwh_process_insert_id, dwh_process_update_id, dwh_process_tstamp),
        CASE WHEN s.dwh_is_deleted_flag = 'Y' THEN 'D'
             WHEN s.dwh_is_deleted_flag = 'N' AND ((s.record_order = 1 AND COALESCE(t.dwh_latest_dml_type_code, 'I') = 'I') OR (prev_delete = 'Y'))
             THEN 'I'
             ELSE 'U'
        END AS dwh_latest_dml_type_code,
        CASE WHEN t.nabsiccode IS null THEN s.dwh_process_insert_id
             ELSE t.dwh_process_insert_id
        END AS dwh_process_insert_id,
        CASE WHEN t.nabsiccode IS null THEN null
             ELSE ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR
        END AS dwh_process_update_id,
	CASE WHEN t.nabsiccode IS null THEN s.dwh_process_tstamp
         WHEN t.nabsiccode IS NOT null THEN CURRENT_TIMESTAMP()::TIMESTAMP_LTZ END AS dwh_process_tstamp
    FROM cte_dwh_fields AS s
    LEFT JOIN {{ this }} AS t
      ON s.nabsiccode = t.nabsiccode
     AND s.dwh_effective_from_tstamp = t.dwh_effective_from_tstamp
    WHERE (t.nabsiccode IS null
       OR (t.dwh_effective_to_tstamp = '9999-12-31'::TIMESTAMP_TZ AND s.dwh_effective_to_tstamp <> '9999-12-31'::TIMESTAMP_TZ)
       OR s.dwh_effective_to_tstamp <> t.dwh_effective_to_tstamp)
)
{% endif %}
{% if not is_incremental() %}
--If existing records do not exist create first version of records.
, cte_records_to_merge AS (
    SELECT
s.*
      , CASE WHEN s.dwh_is_deleted_flag = 'Y' THEN 'D'
         WHEN s.dwh_is_deleted_flag = 'N'
          AND (s.record_order = 1 OR s.prev_delete = 'Y') THEN 'I'
         ELSE 'U' END AS dwh_latest_dml_type_code
    FROM cte_dwh_fields AS s
)
{% endif %}

SELECT
amlrating
, briberyandcorruptionrating
, esgrating
, keywordphrasetxt
, legacycode
, level1code
, level1description
, level2code
, level2description
, level3code
, level3description
, level4code
, level4description
, nabsiccode
, nabsicdescription
, sanctionsrating
, terrorismfinancingrating
, dwh_source_system_code
, dwh_latest_dml_type_code
, dwh_effective_from_tstamp
, dwh_effective_to_tstamp
, dwh_is_deleted_flag
, dwh_extraction_id
, dwh_process_insert_id
, dwh_process_update_id
, dwh_process_tstamp
FROM cte_records_to_merge
