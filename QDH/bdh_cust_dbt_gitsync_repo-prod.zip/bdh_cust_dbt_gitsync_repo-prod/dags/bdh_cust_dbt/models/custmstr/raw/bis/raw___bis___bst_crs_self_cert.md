{% docs raw___bis___bst_crs_self_cert %}

This data product contains Common Reporting Standard (CRS) self-certification 
records collected from new-to-bank customers about their foreign tax residency, 
referred to as BST_CRS_SELF_CERT in BIS. A typical record represents one 
customer's self-certification submission.

{% enddocs %}

{% docs raw___bis___bst_crs_self_cert___cp_cmp_status_code %}

Refers to the assessment status of the Controlling Person from CRS perspective.

{% enddocs %}

{% docs raw___bis___bst_crs_self_cert___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs raw___bis___bst_crs_self_cert___deliv_chan_id %}

(AI Generated) The internal ID used to track how and through which delivery workflow the CRS self‑certification was issued, returned, and completed.

{% enddocs %}

{% docs raw___bis___bst_crs_self_cert___verification_code %}

Customer Common Reporting Standard (CRS) verification status - V(erified), F(ailed), P(ending), T(emporary)

{% enddocs %}

{% docs raw___bis___bst_crs_self_cert___last_updt_user %}

The user, user access id or system id of the last update to the table.
This column will be used as a
replacement for
LAST_UPDT_USERID and
LAST_UPDT_ACS_ID and
has been created to cater for
the IB access ID

{% enddocs %}

{% docs raw___bis___bst_crs_self_cert___last_updt_tstamp %}

The date and time of the last
update to the table

{% enddocs %}