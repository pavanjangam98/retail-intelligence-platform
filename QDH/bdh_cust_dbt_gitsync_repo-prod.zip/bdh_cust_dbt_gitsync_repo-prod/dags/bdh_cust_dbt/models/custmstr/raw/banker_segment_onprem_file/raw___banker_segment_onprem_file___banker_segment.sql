{% do set_query_tag() %}
{{ config(
    materialized='incremental',
    unique_key=['POSITION_NUMBER','DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    tmp_relation_type='table',
    post_hook=["DELETE FROM {{ this }} t
    -- This post hook handles reprocessing of historical data where the effective timelines overlap
    USING (select t.position_number, t.dwh_effective_from_tstamp
    from {{ this }} t
    QUALIFY dwh_effective_from_tstamp 
    BETWEEN LAG(dwh_effective_from_tstamp) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp) 
    AND LAG(dwh_effective_to_tstamp) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp)
    OR 
    dwh_effective_from_tstamp 
    BETWEEN LAG(dwh_effective_from_tstamp, 2) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp) 
    AND LAG(dwh_effective_to_tstamp, 2) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp)
    ) AS overlapped
    WHERE t.position_number= overlapped.position_number 
    AND t.dwh_effective_from_tstamp = overlapped.dwh_effective_from_tstamp",

        "
        DELETE FROM {{ this }}
    -- This post hook handles record deletion from type 2 table in RAW layer
        WHERE position_number IN (
            SELECT t.position_number
            FROM {{ this }} t
            LEFT JOIN {{ source('landing__banker_segment_onprem_file', 'BANKER_SEGMENT') }} s
                ON t.position_number = trim(s.POSITION_NUMBER) 
            WHERE s.POSITION_NUMBER IS NULL 
        )
        "
    ]
) }}

/*
There are 5 methods that can be used to run the file based datasets.

Full Run - dbt build -s +raw___banker_segment_onprem_file___banker_segment+ --vars '{"run_type": "full_data_load"}'
This method will process all data available in the S3 bucket. Should only be used for Once off Historical Load,
and will encounter issues if there is data available from before the current dataset loaded.

Incremental - dbt build -s +raw___banker_segment_onprem_file___banker_segment+ --vars '{"run_type": "incremental"}'
This method should be used as the on-going load method, this checks the target table and only tries to load data from after the latest processed dataset.

Load From Date - dbt build -s +raw___banker_segment_onprem_file___banker_segment+ --vars '{"run_type": "from_date", "start_date": ''2025-06-17''}'
This should be used to reprocess historical data that has been modified or inserted late. The variable start_date used should be on or before the data with issues.

--Don't use these for BAU
Specific Date Range - dbt build -s +raw___banker_segment_onprem_file___banker_segment+ --vars '{"run_type": "specific_date_range", "start_date": ''2025-06-17'', "end_date": ''2025-06-18''}'
This method processes datasets between two specific dates. Shouldn't be used natively, but useful for testing the behaviour of the incremental process

--Don't use these for BAU
Specific Date - dbt build -s +raw___banker_segment_onprem_file___banker_segment+ --vars '{"run_type": "specific_date", "start_date": ''2025-06-17''}'
Used to process a specific date. Shouldn't be used natively, but useful for testing the behaviour of the incremental process

If the correct parameters aren't used for the last two run types this process will fail.

Please Note:
It is not recommended to process data earlier than the latest loaded data.
If data needs to be reprocessed, raw should be removed back until the affected date and reprocessed.
*/

--If no parameters are set default depending on the status of the target table
{% if is_incremental() %}
    {% set run_type = var('run_type', 'incremental') %}
{% else %}
    {% set run_type = var('run_type', 'full_data_load') %}
{% endif %}

--Set date variables to null so that the job fails when variables are incorrectly entered
{% set start_date = var('start_date', null) %}
{% set end_date = var('end_date', null) %}

--Start logic by getting the set of data to insert utilising the "run_type" parameters to read from external table
WITH cte_source_data AS (
    SELECT
*,
    --We will utilise the filename as the extraction id
     metadata$filename AS filename
    FROM {{ source('landing__banker_segment_onprem_file', 'BANKER_SEGMENT') }}
    --FROM LANDING__DEV.BIS.BANKER_SEGMENT_DUMMY
    {% if run_type == 'incremental' %}
        WHERE load_date > (SELECT MAX(dwh_effective_from_tstamp) FROM {{ this }})
    {% elif run_type == 'from_date' %}
        WHERE LOAD_DATE >= '{{ start_date }}'
    {% elif run_type == 'specific_date_range' %}
        WHERE LOAD_DATE BETWEEN '{{ start_date }}' AND '{{ end_date }}'
    {% elif run_type == 'specific_date' %}
        WHERE LOAD_DATE = '{{ start_date }}'
    {% else %}
        WHERE 1 = 1
    {% endif %}
)

--Populate or create placeholders for the DWH fields to allow for successful UNION later
, cte_dwh_fields AS (
    SELECT
* EXCLUDE (value, filename, load_date),
    'BANKER_SEGMENT_ONPREM_FILE' AS dwh_source_system_code,
    NULL AS dwh_latest_dml_type_code,
    load_date::TIMESTAMP_NTZ AS dwh_effective_from_tstamp,
    NULL AS dwh_effective_to_tstamp,
    NULL AS dwh_is_deleted_flag,
    filename AS dwh_extraction_id,
    ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
    NULL AS dwh_process_update_id,
    CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp,
    SHA2(
    COALESCE(position_number, '')
    || COALESCE(segmentation_id::STRING, '')
    || COALESCE(segmentation_desc::STRING, ''))::VARCHAR AS dwh_hash_key
    FROM cte_source_data
)

--If the target table exists get the latest active record to use as a base
{% if is_incremental() %}
, cte_latest_active AS (
    SELECT *
        --If this record gets updated we will want to update the Process Update ID and Process Timestamp
        REPLACE (
            ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_update_id,
            CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp
        )
    FROM {{ this }}
    --Where the record is older than the data we are looking at and is the currently open record
    WHERE dwh_effective_from_tstamp < (SELECT MIN(dwh_effective_from_tstamp) FROM cte_dwh_fields)
    QUALIFY ROW_NUMBER() OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp DESC) = 1
    --AND dwh_effective_to_tstamp = '9999-12-31'::TIMESTAMP_NTZ
) {% endif %}

--Combine the latest record from the target table with the new dataset to be processed
--This can only be performed if there is a target table to refer to, using the if statement to support all run modes
, cte_combine_target AS (
    SELECT * FROM cte_dwh_fields
    {% if is_incremental() %}
    UNION ALL
    SELECT * FROM cte_latest_active
    {% endif %}
)

--Get the latest file date available from the files that will be processed 
, cte_latest_file_date AS (
    SELECT MAX(load_date) AS latest_file_load_date
    FROM cte_source_data
)

--Calculate the dates that are available within the datasets (This allows for gaps in the files to be handled properly)
, cte_file_dates AS (
    SELECT
    load_date,
    LAG(load_date) OVER (ORDER BY load_date) AS prev_load_date,
    LEAD(load_date) OVER (ORDER BY load_date) AS next_load_date
    --Get distinct dates from the incoming dataset
    FROM (SELECT DISTINCT load_date FROM cte_source_data
            --Combine with the latest date available in the target table (if available)
            {% if is_incremental() %}
            UNION DISTINCT
            SELECT MAX(dwh_effective_from_tstamp)::DATE AS load_date FROM cte_latest_active
            {% endif %}
            )
)

--Check the previous and next records available to determine where a delete or a change of data has occurred
, cte_previous_record_check AS (
    SELECT
*,
    --previous and next hash values
    LAG(dwh_hash_key) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp) AS prev_hash_key,
    LEAD(dwh_hash_key) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp) AS next_hash_key,
    --previous and next DWH_EFFECTIVE_FROM_TIMESTAMPS
    LAG(dwh_effective_from_tstamp) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp) AS prev_from_timestamp,
    LEAD(dwh_effective_from_tstamp) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp) AS next_from_timestamp,
    --previous DML_TYPE
    LAG(dwh_latest_dml_type_code) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp) AS prev_dml_type
    FROM cte_combine_target AS r
    --left join the file_dates cte for processing
    LEFT JOIN cte_file_dates AS d
        ON r.dwh_effective_from_tstamp = d.load_date::TIMESTAMP_NTZ
    --Add the latest file date to each record in the file dates
    INNER JOIN cte_latest_file_date ON 1 = 1
)

--Collect a list of active records and changed records, excluding records where the data is unchanged
, cte_active_records AS (
    SELECT * REPLACE (IFF(dwh_latest_dml_type_code = 'D', 'Y', 'N')::VARCHAR(5) AS dwh_is_deleted_flag)
    FROM cte_previous_record_check
    WHERE
        --The data has changed (regular change or deleted and recreated with different data)
        dwh_hash_key <> prev_hash_key
        --This is the first record in the dataset
        OR prev_hash_key IS NULL
        --The record has the same data but it has been deleted and recreated for a period
        OR prev_dml_type = 'D'
        OR (dwh_hash_key = prev_hash_key
            AND prev_from_timestamp <> prev_load_date::TIMESTAMP_NTZ
            AND prev_from_timestamp >= (SELECT MIN(load_date) FROM cte_file_dates))
)

--Creation of deleted versions of a record where the unique key is now missing from the dataset
, cte_deleted_records AS (
    SELECT *
     --Use the file date from when the record was mising as the effective from timestamp of the deleted record
        REPLACE ('D' AS dwh_latest_dml_type_code, COALESCE(next_load_date::TIMESTAMP_NTZ, latest_file_load_date::TIMESTAMP_NTZ) AS dwh_effective_from_tstamp, 'Y' AS dwh_is_deleted_flag,
('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
        NULL AS dwh_process_update_id)
       FROM cte_previous_record_check
       WHERE COALESCE(dwh_latest_dml_type_code, 'I') <> 'D'
       AND ( --Where it's the last record for the id's but not the latest load time
            dwh_effective_from_tstamp <> latest_file_load_date::TIMESTAMP_NTZ
            AND next_hash_key IS NULL
          )
          OR
          ( --Where there is a gap in the record timeline but not in the file timeline
            next_from_timestamp <> next_load_date::TIMESTAMP_NTZ
          )
)

--Combine the active and deleted records together
, cte_combine_active_deleted AS (
    SELECT * FROM cte_active_records
    UNION ALL
    SELECT * FROM cte_deleted_records
)

--Fix the Effective To Timestamp of all records
, cte_final_dwh_fields AS (
    SELECT *
        REPLACE (
            CASE
                -- Preserve Existing dml type if exists or is delete
                WHEN dwh_latest_dml_type_code IS NOT NULL THEN dwh_latest_dml_type_code
                -- When previous record was deleted and this is a new record
                WHEN COALESCE(LAG(dwh_latest_dml_type_code) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp), 'I') = 'D' THEN 'I'
                -- When this is the first record (no previous hash key)
                WHEN prev_hash_key IS NULL THEN 'I'
                -- When there's a previous record (prev_hash_key is not null) and hash key changed
                WHEN prev_hash_key IS NOT NULL AND dwh_hash_key <> prev_hash_key THEN 'U'
                -- Default case
                ELSE 'U'
            END AS dwh_latest_dml_type_code,
            TIMESTAMPADD(MICROSECOND, -1, COALESCE(
                LEAD(dwh_effective_from_tstamp) OVER (PARTITION BY position_number ORDER BY dwh_effective_from_tstamp ASC),
                '9999-12-31T00:00:00.000001'::TIMESTAMP_NTZ
            )) AS dwh_effective_to_tstamp
        )
    FROM cte_combine_active_deleted
)

, cte_records_to_merge AS (
    SELECT s.*
        --Remove processing only columns from dataset
        EXCLUDE (prev_hash_key
        , next_hash_key
        , prev_from_timestamp
        , next_from_timestamp
        , load_date
        , prev_load_date
        , next_load_date
        , latest_file_load_date
        , prev_dml_type
        )
    FROM cte_final_dwh_fields AS s
{% if is_incremental() %}
    LEFT JOIN {{ this }} AS t
    ON s.position_number = t.position_number
    AND s.dwh_effective_from_tstamp = t.dwh_effective_from_tstamp
    WHERE t.position_number IS NULL
    OR (s.dwh_hash_key <> t.dwh_hash_key
    OR s.dwh_latest_dml_type_code <> t.dwh_latest_dml_type_code
    OR s.dwh_is_deleted_flag <> t.dwh_is_deleted_flag
    OR s.dwh_effective_to_tstamp <> t.dwh_effective_to_tstamp)
    --TODO Incremental check to limit merge records
{% endif %}
)

--Final CTE selection for incremental merge
SELECT
position_number::VARCHAR AS position_number,
segmentation_id,
segmentation_desc,
dwh_source_system_code,
dwh_latest_dml_type_code,
dwh_effective_from_tstamp,
dwh_effective_to_tstamp,
dwh_is_deleted_flag,
dwh_extraction_id,
dwh_process_insert_id,
dwh_process_update_id,
dwh_process_tstamp,
dwh_hash_key
FROM cte_records_to_merge
