{% docs raw___bis___bst_cust_reln %}

This Customer Relation Model to load data from a view combining the on-going CDC
incoming data with the History provided by the Existing Tenancy and the Hadoop Data for
BST_CIST_RELN. Designed to remove overlapping timeframes of data.

{% enddocs %}

{% docs raw___bis___bst_cust_reln___customer1_no %}

An identifier for each Bank Customer in CIS. - One of four primary keys in this table.

{% enddocs %}

{% docs raw___bis___bst_cust_reln___relationship_type %}

"Specifies the broard category of relationship. - One of four primary keys in this
table. A two character code. The first character specifies whether it relates to a
formal or informal relationship 'F' = Formal 'I' = Informal The second character relates
to the relationship type. the types are: 'G' = General 'F' = Family 'B' = Business 'P' =
Partnership 'D' = Director 'S' = Sole Trader 'J' = Joint accepted_values: values:
['IG','FP','FJ','FD','FB','IF','FT','FS','IB']  
"

{% enddocs %}

{% docs raw___bis___bst_cust_reln___relationship_code %}

"Defines a formal relationship between two customers. - One of four primary keys in this
table. Examples are: Related Customer is a director of the customer etc."

{% enddocs %}

{% docs raw___bis___bst_cust_reln___customer2_no %}

An identifier for each Bank Customer in CIS. - One of four primary keys in this table.

{% enddocs %}

{% docs raw___bis___bst_cust_reln___reln_access_ind %}

Indicates whether the indivdual has access to the joint account (Y) or not (N).
accepted_values: values: ['Y','N',' ']

{% enddocs %}

{% docs raw___bis___bst_cust_reln___key_contact_ind %}

"NOT IMPLEMENTED (Indicator of Key Contact??)"

{% enddocs %}

{% docs raw___bis___bst_cust_reln___other_free_text %}

Free format text field which contains a description of a Beneficial relationship, such
as Committee Member, or Accountant

{% enddocs %}

{% docs raw___bis___bst_cust_reln___start_date %}

"Relationship Start Date - The date at which a relationship between parties commenced.
This is not the date on which the system was updated with the relationship. This column
has been added as part of an AML Requirement"

{% enddocs %}

{% docs raw___bis___bst_cust_reln___last_updt_userid %}

The user or system id of the last update to the table.

{% enddocs %}

{% docs raw___bis___bst_cust_reln___last_updt_tstamp %}

The date and time of the last update to the table.

{% enddocs %}
