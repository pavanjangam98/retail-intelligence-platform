{% docs raw___bis___bst_mcust_grp_reln %}

This Managed customer group relationship manager Model to load data from a view combining the on-going CDC incoming data with the History provided by the Hadoop Data for BST_MCUST_GRP_RELN. Designed to remove overlapping timeframes of data.

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_reln___position_no %}

Position number the staff member holds

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_reln___managed_group_no %}

The identifier of a managed group.

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_reln___relationship_type %}

A unique identifier that defines the type of interest a member of staff may have with a managed customer group.

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_reln___reln_create_date %}

The date this relationship was originally setup.

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_reln___management_ind %}

Indicates whether the group is a management group or not. IE Whether a member of staff is the 'relationship manager' or just has some other interest in the customer group. It is assumed that a relationship manager is ultimately responsible for the management of their customers.

{% enddocs %}
