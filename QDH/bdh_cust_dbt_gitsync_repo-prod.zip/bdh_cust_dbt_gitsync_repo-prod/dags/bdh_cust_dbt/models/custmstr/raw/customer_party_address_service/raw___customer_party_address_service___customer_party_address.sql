{% do set_query_tag() %}
{{ config(
    materialized='incremental',
    unique_key=['ADDRESSID', 'DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
	tmp_relation_type='table',
    post_hook=["DELETE FROM {{ this }} 
    -- This post hook handles record deletion from source in landing layer    
      where ADDRESSID || DWH_EFFECTIVE_FROM_TSTAMP 
        in
      (
        select t.addressId ||  t.DWH_EFFECTIVE_FROM_TSTAMP
        from {{ this }} t 
	left join {{ source('landing__customer_party_address_service', 'CUSTOMER_PARTY_ADDRESS') }} s
        on t.addressId = coalesce(RECORD_CONTENT:afterState.addressId, RECORD_CONTENT:beforeState.addressId)
 	and t.dwh_effective_from_tstamp = RECORD_CONTENT:metadata.time
        where 
          coalesce (RECORD_CONTENT:afterState.addressId, RECORD_CONTENT:beforeState.addressId) is null 
	  AND dwh_effective_from_tstamp >= DATEADD(DAY, -{{ var('days_back', 30) }} , CURRENT_TIMESTAMP()))"]
  ) 
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select +raw___customer_party_address_service___customer_party_address+ --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select  +raw___customer_party_address_service___customer_party_address+ --vars '{ "run_type": "full_data_load", "days_back": 30 }'

default values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point


A full data load will read from the Full Historical View and a Specific Data Load will perform an incremental load directly from the on-going Kafka Landing table.
When deploying, a full data load should be performed before incremental.
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", CURRENT_TIMESTAMP())" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}
/* Setting the "source" based on incremental load vs full data load */
{% if run_type == 'specific_data_load' %}
  {% set source_model = source('landing__customer_party_address_service', 'CUSTOMER_PARTY_ADDRESS') %}
{% else %} 
  {% set source_model = ref('raw___customer_party_address_service___customer_party_address_full_view') %}
{% endif %}

WITH raw_customer_party_address AS (
   {{
    generate_json_flatten_uptoarray(
    model_name = source_model,
    json_column = 'RECORD_CONTENT')
     }} WHERE metadata_time::TIMESTAMP_TZ >= {{ filter_date }}
)

--Todo: Raise with source team. Determine if this can be fixed or needs to be handled. Anne is working with customer_party_address_service team to determine.
--This cte currently performs the date filter and deduplication of the data. If dedupe logic is removed (Qualify), date filter should remain included.
, cte_dedupe AS (
    SELECT * FROM raw_customer_party_address
    QUALIFY ROW_NUMBER() OVER (
      PARTITION BY
      COALESCE(afterstate_addressid::VARCHAR, beforestate_addressid::VARCHAR),
       metadata_time::TIMESTAMP_TZ
      ORDER BY metadata_time::TIMESTAMP_TZ DESC) = 1
)

--Kafka Regular Scenario (afterState populated)
, cte_pre_customer_party_address AS (
    SELECT
      {{ select_customer_party_address_fields('AFTERSTATE') }},
      'CUSTOMER_PARTY_ADDRESS_SERVICE' AS dwh_source_system_code,
      metadata_time::TIMESTAMP_TZ AS updated_at,
      'N' AS dwh_is_deleted_flag,
      metadata_id::VARCHAR(50) AS dwh_extraction_id,
      ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
      null AS dwh_process_update_id,
      CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp
      FROM cte_dedupe
      WHERE NOT IS_NULL_VALUE(record_content:afterState)
      )

--Kafka Delete Scenario (beforeState populated afterState not populated)
, cte_pre_customer_party_address_delete AS (
    SELECT
      {{ select_customer_party_address_fields('BEFORESTATE') }},
      'CUSTOMER_PARTY_ADDRESS_SERVICE' AS dwh_source_system_code,
      metadata_time::TIMESTAMP_TZ AS updated_at,
      CASE WHEN afterstate_addressid IS null THEN 'Y' ELSE 'N' END AS dwh_is_deleted_flag,
      metadata_id::VARCHAR(50) AS dwh_extraction_id,
      ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
      null AS dwh_process_update_id,
      CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp
      FROM cte_dedupe
      WHERE IS_NULL_VALUE(record_content:afterState)
      )

-- Only check existing records if existing records exist. If they do get the latest record needed to be checked for updates
/*Qestion: wonder if there is any difference in between get old data than before filter_data and use use {{ this }} + data >= filter_date
regarding the performance and cost, especially for large data set?
*/
{% if is_incremental() %}
, cte_old_active_records AS (
    SELECT
			addresschangedtimestamp,
			addressid,
			addressindcode,
			addressline1,
			addressline2,
			addressline3,
			addressline4,
			addresstype,
			addresseename,
			buildingname,
			buildingnumber,
			careof,
			centroidofpropertynztmxcoordinate,
			centroidofpropertynztmycoordinate,
			countrycode,
			countryname,
			countrysubdivision,
			customernumber,
			deliverableindicator,
			deliverypointidentifier,
			department,
			districtname,
			floor,
			formattedaddressline,
			frontofpropertynztmxcoordinate,
			frontofpropertynztmycoordinate,
			generalelectoratecode,
			generalelectoratename,
			hostaddresstype,
			isoaddresstypecode,
			lastupdatedby,
			lastupdatedbyoriginator,
			lastupdatedbytype,
			lastupdatedtimestamp,
			linzparcelid,
			maorielectoratecode,
			maorielectoratename,
			meshblockcode,
			postbox,
			postalcode,
			postaldistcode,
			propertypurposetype,
			regionalcouncilcode,
			regionalcouncilname,
			room,
			roomtype,
			startdate,
			streetid,
			streetname,
			subdepartment,
			territorialauthoritycode,
			territorialauthorityname,
			townlocationname,
			townname,
			validationoutcome,
			validationoutcomereason,
			validationrequestid,
			validationtimestamp,
			dwh_source_system_code,
			dwh_effective_from_tstamp AS updated_at,
			dwh_is_deleted_flag,
			dwh_extraction_id,
			dwh_process_insert_id,
			dwh_process_update_id,
			dwh_process_tstamp
    FROM {{ this }}
    WHERE dwh_effective_from_tstamp < {{ filter_date }}
	QUALIFY ROW_NUMBER() OVER (PARTITION BY addressid ORDER BY dwh_effective_from_tstamp DESC) = 1
)
{% endif %}

--Can only combine all three if existing records exist
{% if is_incremental() %}
, cte_combine AS (
    SELECT * FROM cte_pre_customer_party_address
    UNION ALL
    SELECT * FROM cte_pre_customer_party_address_delete
    UNION ALL
    SELECT * FROM cte_old_active_records
)
{% endif %}
 --If existing records don't exist, ignore existing check
{% if not is_incremental() %}
, cte_combine AS (
    SELECT * FROM cte_pre_customer_party_address
    UNION ALL
    SELECT * FROM cte_pre_customer_party_address_delete
)
{% endif %}

 --Calculate the Effective From and Effective To based on the subset of data combined above.
/* METADATA_TIME::TIMESTAMP_TZ AS UPDATED_AT,
 if incremetnal (exising) DWH_EFFECTIVE_FROM_TSTAMP AS UPDATED_AT,
 the purpose to EXCLUDE UPDATED_AT as we need rename UPDATED_AT AS DWH_EFFECTIVE_FROM_TSTAMP
*/
, cte_dwh_fields AS (
    SELECT
* EXCLUDE updated_at,
    updated_at AS dwh_effective_from_tstamp,
 -- to test if the lead works as expected is DWH_EFFECTIVE_FROM_TSTAMP is null or DWH_EFFECTIVE_TO_TSTAMP is null or DWH_EFFECTIVE_TO_TSTAMP< DWH_EFFECTIVE_FROM_TSTAMP 
       TIMESTAMPADD(MICROSECOND, -1, COALESCE(LEAD(updated_at)
    OVER (PARTITION BY addressid ORDER BY updated_at ASC)
    , '9999-12-31T00:00:00.000001'::TIMESTAMP_TZ)) AS dwh_effective_to_tstamp,
    ROW_NUMBER() OVER (PARTITION BY addressid ORDER BY updated_at ASC) AS record_order,
    LAG(dwh_is_deleted_flag) OVER (PARTITION BY addressid ORDER BY dwh_effective_from_tstamp ASC) AS prev_delete
    FROM cte_combine
    )

  {% if is_incremental() %}
  --If existing records exist determine records that need to be inserted / updated to limit # of record to merge.
  -- again, in the future, if we have a very large table, how efficient/ what this is cost for using the method below 
, cte_records_to_merge AS (
    SELECT
s.* EXCLUDE (dwh_process_insert_id, dwh_process_update_id, dwh_process_tstamp),
    -- here we only use one of composite key 
    CASE WHEN s.dwh_is_deleted_flag = 'Y' THEN 'D'
         WHEN s.dwh_is_deleted_flag = 'N' AND ((s.record_order = 1 AND COALESCE(t.dwh_latest_dml_type_code, 'I') = 'I')
          OR (prev_delete = 'Y')) THEN 'I'
	      ELSE 'U' END AS dwh_latest_dml_type_code,
     CASE WHEN t.addressid IS null THEN s.dwh_process_insert_id
         WHEN t.addressid IS NOT null THEN t.dwh_process_insert_id END AS dwh_process_insert_id,
    CASE WHEN t.addressid IS null THEN null
         WHEN t.addressid IS NOT null THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR END AS dwh_process_update_id,
	 CASE WHEN t.addressid IS null THEN s.dwh_process_tstamp
         WHEN t.addressid IS NOT null THEN CURRENT_TIMESTAMP()::TIMESTAMP_LTZ END AS dwh_process_tstamp
     FROM cte_dwh_fields AS s
    LEFT JOIN {{ this }} AS t
    ON s.addressid = t.addressid
 		AND s.addressid = t.addressid
    AND s.dwh_effective_from_tstamp = t.dwh_effective_from_tstamp
    WHERE (t.addressid IS null --New history scenario
        OR (t.dwh_effective_to_tstamp = '9999-12-31'::TIMESTAMP_TZ AND s.dwh_effective_to_tstamp <> '9999-12-31'::TIMESTAMP_TZ) --End dating existing open record
        OR s.dwh_effective_to_tstamp <> t.dwh_effective_to_tstamp) --Missing Record Scenario
)
{% endif %}
{% if not is_incremental() %}
--If existing records do not exist create first version of records.
, cte_records_to_merge AS (
    SELECT
s.*
      , CASE WHEN s.dwh_is_deleted_flag = 'Y' THEN 'D'
         WHEN s.dwh_is_deleted_flag = 'N'
          AND (s.record_order = 1 OR s.prev_delete = 'Y') THEN 'I'
         ELSE 'U' END AS dwh_latest_dml_type_code
    FROM cte_dwh_fields AS s
)
{% endif %}

SELECT
  	addresschangedtimestamp::TIMESTAMP_TZ AS addresschangedtimestamp,
	addressid,
	addressindcode,
	addressline1,
	addressline2,
	addressline3,
	addressline4,
	addresstype,
	addresseename,
	buildingname,
	buildingnumber,
	careof,
	centroidofpropertynztmxcoordinate,
	centroidofpropertynztmycoordinate,
	countrycode,
	countryname,
	countrysubdivision,
	customernumber::VARCHAR AS customernumber,
	deliverableindicator::BOOLEAN AS deliverableindicator,
	deliverypointidentifier,
	department,
	districtname,
	floor,
	formattedaddressline,
	frontofpropertynztmxcoordinate,
	frontofpropertynztmycoordinate,
	generalelectoratecode,
	generalelectoratename,
	hostaddresstype,
	isoaddresstypecode,
	lastupdatedby,
	lastupdatedbyoriginator,
	lastupdatedbytype,
	lastupdatedtimestamp::TIMESTAMP_TZ AS lastupdatedtimestamp,
	linzparcelid,
	maorielectoratecode,
	maorielectoratename,
	meshblockcode,
	postbox,
	postalcode,
	postaldistcode,
	propertypurposetype,
	regionalcouncilcode,
	regionalcouncilname,
	room,
	roomtype,
	startdate,
	streetid,
	streetname,
	subdepartment,
	territorialauthoritycode,
	territorialauthorityname,
	townlocationname,
	townname,
	validationoutcome,
	validationoutcomereason,
	validationrequestid,
	validationtimestamp,
	dwh_source_system_code,
	dwh_latest_dml_type_code,
	dwh_effective_from_tstamp,
	dwh_effective_to_tstamp,
	dwh_is_deleted_flag,
	dwh_extraction_id,
	dwh_process_insert_id,
	dwh_process_update_id,
	dwh_process_tstamp
FROM cte_records_to_merge
