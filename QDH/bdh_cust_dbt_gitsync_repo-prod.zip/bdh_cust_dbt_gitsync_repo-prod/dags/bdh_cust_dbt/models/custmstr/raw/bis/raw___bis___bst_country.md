{% docs raw___bis___bst_country %}

This data product contains country reference records that list recognised countries, referred to as BST_COUNTRY in BIS. 
A typical record represents one country used to standardise customer address, or tax residency information

{% enddocs %}

{% docs raw___bis___bst_country___country_code %}

Uniquely identifies the a country

{% enddocs %}

{% docs raw___bis___bst_country___country_desc %}

The name of a country.

{% enddocs %}

{% docs raw___bis___bst_country___nrwt_rate_pcnt %}

NRWT withholding tax rate applied to residents of the country - held redundantly for historical reasons.

{% enddocs %}

{% docs raw___bis___bst_country___tax_code %}

The tax code applicable to residents of the country
The tax code applicable to residents of the country
N	= RWT, 21.5 % ( IRD
Number known )
O	= RWT, 33 % ( IRD Numberunknown ) A = NRWT, 10 %
B	= NRWT, 15 %
C	= NRWT, 30 %
L = AIL, 2%
E = Customer Exempt, 0 %

{% enddocs %}
