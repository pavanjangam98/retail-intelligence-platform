{{ config(
    materialized='view'
) }}


-- Determine the earliest record available for each available Customer Number within the BAU CDC dataset.
WITH CTE_CDC_CUTOFF AS (
    SELECT
        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:POSITION_NO::VARCHAR,
                 PARSE_JSON(RECORD_CONTENT):beforeState:POSITION_NO::VARCHAR
        ) AS POSITION_NO,

        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:MANAGED_GROUP_NO::VARCHAR,
                 PARSE_JSON(RECORD_CONTENT):beforeState:MANAGED_GROUP_NO::VARCHAR
        ) AS MANAGED_GROUP_NO,

        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:RELATIONSHIP_TYPE::VARCHAR,
                 PARSE_JSON(RECORD_CONTENT):beforeState:RELATIONSHIP_TYPE::VARCHAR
        ) AS RELATIONSHIP_TYPE,

        MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM {{ source("landing__bis", "BST_MCUST_GRP_RELN") }}
    GROUP BY
        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:POSITION_NO::VARCHAR,
                  PARSE_JSON(RECORD_CONTENT):beforeState:POSITION_NO::VARCHAR),
        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:MANAGED_GROUP_NO::VARCHAR,
                 PARSE_JSON(RECORD_CONTENT):beforeState:MANAGED_GROUP_NO::VARCHAR),
        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:RELATIONSHIP_TYPE::VARCHAR,
                 PARSE_JSON(RECORD_CONTENT):beforeState:RELATIONSHIP_TYPE::VARCHAR)
)

--Standarise the historical hadoop data to follow the same format as the CDC events, with correct capitilsation.
, CTE_STANDARDISE_HADOOP_DATA AS (
    SELECT
PARSE_JSON(VALUE):CDC_SEND_TSTAMP::VARCHAR AS CDC_SEND_TSTAMP,
    PARSE_JSON(VALUE):HDP_DML_CODE::VARCHAR AS HDP_DML_CODE,
    OBJECT_CONSTRUCT_KEEP_NULL(
        'POSITION_NO', PARSE_JSON(VALUE):POSITION_NO,
        'MANAGED_GROUP_NO', PARSE_JSON(VALUE):MANAGED_GROUP_NO,
        'RELATIONSHIP_TYPE', PARSE_JSON(VALUE):RELATIONSHIP_TYPE,
        'RELN_CREATE_DATE', PARSE_JSON(VALUE):RELN_CREATE_DATE,
        'MANAGEMENT_IND', PARSE_JSON(VALUE):MANAGEMENT_IND
    ) AS VALUE
    FROM {{ source("landing__bis", "BST_MCUST_GRP_RELN_HISTORICAL") }}
)

--Build the Hadoop record into the format of beforeState and afterState, only taking records that are before the combined cutoff earliest record per Customer Number
, CTE_HADOOP_DATA AS (
    SELECT
    OBJECT_CONSTRUCT_KEEP_NULL() AS RECORD_METADATA,
    OBJECT_CONSTRUCT_KEEP_NULL(
            'afterState', CASE WHEN HDP_DML_CODE IN ('I', 'U', 'RR') THEN VALUE END,
            'beforeState', CASE WHEN HDP_DML_CODE IN ('U', 'D') THEN VALUE END,
            'metadata', OBJECT_CONSTRUCT_KEEP_NULL(
                            'id', 'hist_record',
                            'source', 'BST_MCUST_GRP_RELN',
                            'subject', NULL,
                            'time', CDC_SEND_TSTAMP,
                            'type', 'dwh_history'
                            )
            ) AS RECORD_CONTENT
    FROM CTE_STANDARDISE_HADOOP_DATA
    LEFT JOIN CTE_CDC_CUTOFF AS C
    ON VALUE:POSITION_NO::VARCHAR = C.POSITION_NO
    AND VALUE:MANAGED_GROUP_NO = C.MANAGED_GROUP_NO
    AND VALUE:RELATIONSHIP_TYPE = C.RELATIONSHIP_TYPE
    WHERE CDC_SEND_TSTAMP::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

--Union the 3 datasets to get full historical view with no overlaps of data.
SELECT * FROM {{ source("landing__bis", "BST_MCUST_GRP_RELN") }}
UNION ALL
SELECT * FROM CTE_HADOOP_DATA
