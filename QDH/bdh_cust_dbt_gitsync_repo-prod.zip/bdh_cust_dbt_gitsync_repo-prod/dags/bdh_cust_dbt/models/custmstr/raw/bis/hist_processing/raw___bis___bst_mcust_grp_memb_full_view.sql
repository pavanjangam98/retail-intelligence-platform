{{ config(
    materialized='view'
) }}

--  Determine the earliest record available for each combination of Primary keys from Managed customer group member.
WITH CTE_CDC_CUTOFF AS (
SELECT
COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:MANAGED_GROUP_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:MANAGED_GROUP_NO::VARCHAR) AS MANAGED_GROUP_NO,
COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR) AS CUSTOMER_NO,
MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
FROM {{ source("landing__bis", "BST_MCUST_GRP_MEMB") }}
GROUP BY COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:MANAGED_GROUP_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:MANAGED_GROUP_NO::VARCHAR),
COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR)
)

--Standarise the historical hadoop data to follow the same format as the CDC events, with correct capitilsation.

, CTE_STANDARDISE_HADOOP_DATA AS (
SELECT
    PARSE_JSON(VALUE):CDC_SEND_TSTAMP::VARCHAR AS CDC_SEND_TSTAMP,
    PARSE_JSON(VALUE):HDP_DML_CODE::VARCHAR AS HDP_DML_CODE,
    OBJECT_CONSTRUCT_KEEP_NULL(
        'MANAGED_GROUP_NO', PARSE_JSON(VALUE):MANAGED_GROUP_NO,
        'CUSTOMER_NO', PARSE_JSON(VALUE):CUSTOMER_NO,
        'FORMAL_NAME', PARSE_JSON(VALUE):FORMAL_NAME,
        'POSITION_NO', PARSE_JSON(VALUE):POSITION_NO,
        'TRANSFER_IND', PARSE_JSON(VALUE):TRANSFER_IND,
        'PRIMARY_IND', PARSE_JSON(VALUE):PRIMARY_IND
    ) AS VALUE
    FROM {{ source("landing__bis", "BST_MCUST_GRP_MEMB_HISTORICAL") }}
)

--Build the Hadoop record into the format of beforeState and afterState, only taking records that are before the combined cutoff earliest record per each combination of Primary keys

, CTE_HADOOP_DATA AS (
    SELECT
    OBJECT_CONSTRUCT_KEEP_NULL() AS RECORD_METADATA,
    OBJECT_CONSTRUCT_KEEP_NULL(
            'afterState', CASE WHEN HDP_DML_CODE IN ('I', 'U', 'RR') THEN VALUE END,
            'beforeState', CASE WHEN HDP_DML_CODE IN ('U', 'D') THEN VALUE END,
            'metadata', OBJECT_CONSTRUCT_KEEP_NULL(
                            'id', 'hist_record',
                            'source', 'BST_MCUST_GRP_MEMB',
                            'subject', NULL,
                            'time', CDC_SEND_TSTAMP,
                            'type', 'dwh_history'
                            )
            ) AS RECORD_CONTENT
    FROM CTE_STANDARDISE_HADOOP_DATA
    LEFT JOIN CTE_CDC_CUTOFF AS C
    ON C.MANAGED_GROUP_NO = VALUE:MANAGED_GROUP_NO::VARCHAR
    AND C.CUSTOMER_NO = VALUE:CUSTOMER_NO::VARCHAR
  WHERE CDC_SEND_TSTAMP::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

----Union the 2 datasets to get full historical view with no overlaps of data.
SELECT * FROM {{ source("landing__bis", "BST_MCUST_GRP_MEMB") }}
UNION ALL
SELECT * FROM CTE_HADOOP_DATA
