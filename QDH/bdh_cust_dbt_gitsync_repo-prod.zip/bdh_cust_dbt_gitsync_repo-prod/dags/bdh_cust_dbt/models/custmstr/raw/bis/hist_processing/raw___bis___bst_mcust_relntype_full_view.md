{% docs raw___bis___bst_mcust_relntype_full_view %}

A view combining the on-going CDC incoming data with historical data for BST_MCUST_RELNTYPE to remove overlapping timeframes.

{% enddocs %}

{% docs raw___bis___bst_mcust_relntype_full_view___record_metadata %}

Metadata details about the event as it was received by Kafka and processed into the queue.

{% enddocs %}

{% docs raw___bis___bst_mcust_relntype_full_view___record_content %}

Details about the CDC event that happened in the source system, including beforeState or afterState and metadata.

{% enddocs %}