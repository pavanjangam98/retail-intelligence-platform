{% docs raw___bis___bst_np_cust_type %}

This raw product holds reference data related to classification of a Non-Personal Customer by their major characteristics 

{% enddocs %}

{% docs raw___bis___bst_np_cust_type___np_cust_type %}

Classification of Non Personal customer by their major characteristics.

{% enddocs %}

{% docs raw___bis___bst_np_cust_type___np_cust_desc %}

Description of this classification of Non Personal customer.

{% enddocs %}
