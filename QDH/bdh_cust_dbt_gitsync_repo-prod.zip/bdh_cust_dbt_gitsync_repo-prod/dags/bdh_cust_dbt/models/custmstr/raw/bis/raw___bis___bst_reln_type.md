{% docs raw___bis___bst_reln_type %}

This raw table conatins type 2 history about the customer relationship reference data

{% enddocs %}

{% docs raw___bis___bst_reln_type___relationship_type %}

Specifies the broard category of relationship.
A two character code. The first character specifies whether it relates to a formal or informal relationship
'F' = Formal
'I' = Informal
The second character relates to the relationship type. the types are:
'G' = General
'F' = Family
'B' = Business
'P' = Partnership
'D' = Director
'S' = Sole Trader
'J' = Joint

{% enddocs %}

{% docs raw___bis___bst_reln_type___relationship_code %}

Defines a formal relationship between two customers.
Examples are:
Related Customer is a director of the customer etc.

{% enddocs %}

{% docs raw___bis___bst_reln_type___relationship_desc %}

A text description of the Relationship Type.

{% enddocs %}

{% docs raw___bis___bst_reln_type___reverse_reln_code %}

The relationship code that is the reverse of the primary relationship.
For example: if the primary relationship is 'customer is employee of'
then the reverse is 'customer is employer of'.

{% enddocs %}
