{% docs raw___banker_segment_onprem_file___banker_segment %}

This raw product defines the segmentation assigned to organizational position numbers.

{% enddocs %}

{% docs raw___banker_segment_onprem_file___banker_segment___position_number %}

The bnz position number.

{% enddocs %}

{% docs raw___banker_segment_onprem_file___banker_segment___segmentation_id %}

The id  of the banker segmentation.  Accepted values are 1, 2, 3, 4, 5, 6, 7, 11, 12, 13.

{% enddocs %}

{% docs raw___banker_segment_onprem_file___banker_segment___segmentation_desc %}

The description of the banker segmentation.  Accepted values are AGRIBUSINESS, COMMERCIAL, BUSINESS, PRIVATE BANK , PROPERTY FINANCE, COST CENTRE EXPENSES, INSTITUTIONAL BANKING, CORPORATE, Small Business Hub, CONSUMER.

{% enddocs %}