{% docs raw___customer_party_address_service___customer_party_address %}

This raw product holds details of customer postal and physical addresses

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___addresschangedtimestamp %}

The datetime the Party Address Service last updated this record. The change could be either an update to the address details, an address validation triggered by the update or possibly from a scheduled workflow task or status update

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___addressid %}

A unique identifier for a party address

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___addressindcode %}

An indicator that further specifies the type of address. e.g. Street Address Private Bag PO-Box Rural DeliveryCounter Delivery.

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___addressline1 %}

The customer address lines. Min items 1, max items 4

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___addressline2 %}

The customer address lines. Min items 1, max items 4

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___addressline3 %}

The customer address lines. Min items 1, max items 4

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___addressline4 %}

The customer address lines. Min items 1, max items 4

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___addresstype %}

The type of the party address. It can be physical or postal.

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___addresseename %}

Name by which a party is known and which is usually used to identify that party

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___buildingname %}

Name of the building or house

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___buildingnumber %}

Number that identifies the position of a building on a street

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___careof %}

The name of someone who is not the legal occupant of the address. This may also hold any 'preleading' information from the address which does not form part of the structured address

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___centroidofpropertynztmxcoordinate %}

The NZTM Geocode 'X' coordinate for the centre of the property

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___centroidofpropertynztmycoordinate %}

The NZTM Geocode 'Y' coordinate for the centre of the property

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___countrycode %}

The 2 character ISO country code

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___countryname %}

The country name

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___countrysubdivision %}

A subdivision of a country such as state, region, county

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___customernumber %}

The unique identifier of the customer

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___deliverableindicator %}

An indicator which shows if the address can receive post

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___deliverypointidentifier %}

A 10-digit unique identifier assigned to each address found in the NZ Postal Address File (PAF)

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___department %}

Identification of a division of a large organisation or building

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___districtname %}

A subdivision within a country sub-division

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___floor %}

Floor or storey within a building

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___formattedaddressline %}

Information that locates and identifies a specific address, as defined by postal services, presented in free format text

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___frontofpropertynztmxcoordinate %}

The NZTM Geocode 'X' coordinate for the front of the property

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___frontofpropertynztmycoordinate %}

The NZTM Geocode 'Y' coordinate for the front of the property

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___generalelectoratecode %}

Code for the general electorate for the returned address

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___generalelectoratename %}

Name for the general electorate for the returned address

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___hostaddresstype %}

The address type code used in the legacy host system, deprecated. (eg. I, J, M, N P)

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___isoaddresstypecode %}

The ISO20022 sub-type that describes the nature of the address (eg. HOME, ADDR, PBOX, BIZZ)

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___lastupdatedby %}

The ID of the entity who last updated the address, it can be staff number, customer number or client id

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___lastupdatedbyoriginator %}

The application or system that originated the last update address request

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___lastupdatedbytype %}

The type of the entity who last updated the address, it can be staff, customer or client

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___lastupdatedtimestamp %}

The datetime the address was last changed

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___linzparcelid %}

The unique LINZ identifier for spatial object representing land parcel the address resides in

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___maorielectoratecode %}

Unique code of the Maori electorate for the returned address

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___maorielectoratename %}

Unique name of the Maori electorate for the returned address

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___meshblockcode %}

The smallest geographic unit for which statistical data is collected and processed by Stats NZ

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___postbox %}

Numbered box in a post office, assigned to a person or organisation, where letters are kept until called for

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___postalcode %}

The NZ Post Office code associated with the customer's address details

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___postaldistcode %}

The postal district portion of the mailing address NZ postal code

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___propertypurposetype %}

The property purpose eg Business, Farm, Holiday Home, Residential or Empty section

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___regionalcouncilcode %}

Code for the regional council for the returned address

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___regionalcouncilname %}

Name for the regional council for the returned address

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___room %}

The room number in a house or building

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___roomtype %}

The room type of a house or building

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___startdate %}

The first day on which the customer can be contacted at this address. The date format is YYYY-MM-DD.

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___streetid %}

Unique numeric identifier for a street defined by New Zealand Post

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___streetname %}

Name of a street or thoroughfare

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___subdepartment %}

Identification of a sub-division of a large organisation or building

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___territorialauthoritycode %}

Code for Territorial authority which is the second tier of local government in New Zealand, below regional councils

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___territorialauthorityname %}

Name for Territorial authority which is the second tier of local government in New Zealand, below regional councils

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___townlocationname %}

Specific location name within the town

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___townname %}

Name of a built-up area, with defined boundaries, and a local government

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___validationoutcome %}

The outcome of the address validation from party communication address validation service (eg. unvalidated, validated)

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___validationoutcomereason %}

The reason for the validation outcome. (eg. validationRequested, validationNotRequested, error, validatedWithoutChanges, validatedWithChanges, noMatchedAddress, invalidAddressForAddressType, validationNotSupportedForCountry)

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___validationrequestid %}

The identifier that was used to validate this address. This links together the version of the address prior to validation, and the version after validation.

{% enddocs %}

{% docs raw___customer_party_address_service___customer_party_address___validationtimestamp %}

The datetime the address was last validated

{% enddocs %}
