{% docs raw___bis___bst_warning_type %}

This raw product holds details on warning type reference data  relating to accounts and/or customers

{% enddocs %}

{% docs raw___bis___bst_warning_type___warning_code %}

The code which uniquely identifies the warning.

{% enddocs %}

{% docs raw___bis___bst_warning_type___warn_priority_no %}

A number that indicates the priority of the warning.

{% enddocs %}

{% docs raw___bis___bst_warning_type___warning_text %}

The text associated with the warning code that will appear when a warning is displayed.

{% enddocs %}

{% docs raw___bis___bst_warning_type___prtf_priority_no %}

Priority Sequence for Portfolio Management

{% enddocs %}

{% docs raw___bis___bst_warning_type___delay_arch_time %}

This is something to do with whether a customer can be archived or not if they have this warning code. A way to think of it is if the value is 99 then the customer who has this WARNING_CODE cannot be archived

{% enddocs %}
