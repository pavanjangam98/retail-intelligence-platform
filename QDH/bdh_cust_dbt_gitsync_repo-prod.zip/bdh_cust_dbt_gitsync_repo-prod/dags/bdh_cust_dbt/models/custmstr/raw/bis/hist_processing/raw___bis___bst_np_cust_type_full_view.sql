{{ config(
    materialized='view'
) }}

--  Determine the earliest record available for each combination of Primary keys from Np Cust Type table within the BAU CDC dataset.
WITH CTE_CDC_CUTOFF AS (
SELECT
COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:NP_CUST_TYPE::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:NP_CUST_TYPE::VARCHAR) AS NP_CUST_TYPE,
MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
FROM {{ source("landing__bis", "BST_NP_CUST_TYPE") }}
GROUP BY
COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:NP_CUST_TYPE::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:NP_CUST_TYPE::VARCHAR)
)

--Standarise the historical hadoop data to follow the same format as the CDC events, with correct capitilsation.

, CTE_STANDARDISE_HADOOP_DATA AS (
SELECT
    PARSE_JSON(VALUE):CDC_SEND_TSTAMP::VARCHAR AS CDC_SEND_TSTAMP,
    PARSE_JSON(VALUE):HDP_DML_CODE::VARCHAR AS HDP_DML_CODE,
    OBJECT_CONSTRUCT_KEEP_NULL(
        'NP_CUST_TYPE', PARSE_JSON(VALUE):NP_CUST_TYPE,
        'NP_CUST_DESC', PARSE_JSON(VALUE):NP_CUST_DESC
    ) AS VALUE
    FROM {{ source("landing__bis", "BST_NP_CUST_TYPE_HISTORICAL") }}
)

--Build the Hadoop record into the format of beforeState and afterState, only taking records that are before the combined cutoff earliest record per each combination of Primary keys

, CTE_HADOOP_DATA AS (
    SELECT
    OBJECT_CONSTRUCT_KEEP_NULL() AS RECORD_METADATA,
    OBJECT_CONSTRUCT_KEEP_NULL(
            'afterState', CASE WHEN HDP_DML_CODE IN ('I', 'U', 'RR') THEN VALUE END,
            'beforeState', CASE WHEN HDP_DML_CODE IN ('U', 'D') THEN VALUE END,
            'metadata', OBJECT_CONSTRUCT_KEEP_NULL(
                            'id', 'hist_record',
                            'source', 'BST_NP_CUST_TYPE',
                            'subject', NULL,
                            'time', CDC_SEND_TSTAMP,
                            'type', 'dwh_history'
                            )
            ) AS RECORD_CONTENT
    FROM CTE_STANDARDISE_HADOOP_DATA
    LEFT JOIN CTE_CDC_CUTOFF AS C
    ON C.NP_CUST_TYPE = VALUE:NP_CUST_TYPE::VARCHAR
  WHERE CDC_SEND_TSTAMP::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

----Union the 2 datasets to get full historical view with no overlaps of data.
SELECT * FROM {{ source("landing__bis", "BST_NP_CUST_TYPE") }}
UNION ALL
SELECT * FROM CTE_HADOOP_DATA
