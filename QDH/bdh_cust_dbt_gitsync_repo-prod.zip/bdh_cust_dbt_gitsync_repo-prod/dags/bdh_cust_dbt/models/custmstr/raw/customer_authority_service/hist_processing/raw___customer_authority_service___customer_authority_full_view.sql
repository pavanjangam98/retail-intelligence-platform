{{ config(
    materialized='view'
) }}

-- Determine the earliest record available for each combination of Primary keys from Customer Authority table within the BAU CDC dataset.
-- WITH CTE_CDC_CUTOFF AS (
--     SELECT
--         COALESCE(
--             PARSE_JSON(RECORD_CONTENT):data:stateAfter:GOVERNEDCUSTOMERNUMBER::VARCHAR,
--             PARSE_JSON(RECORD_CONTENT):data:stateBefore:GOVERNEDCUSTOMERNUMBER::VARCHAR
--         ) AS GOVERNEDCUSTOMERNUMBER,

--         COALESCE(
--             PARSE_JSON(RECORD_CONTENT):data:stateAfter:AUTHORISEDCUSTOMERNUMBER::VARCHAR,
--             PARSE_JSON(RECORD_CONTENT):data:stateBefore:AUTHORISEDCUSTOMERNUMBER::VARCHAR
--         ) AS AUTHORISEDCUSTOMERNUMBER,
--         RECORD_CONTENT,
--         MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD

--     FROM {{ source("landing__customer_authority_service", "CUSTOMER_AUTHORITY") }}

--     GROUP BY
--         COALESCE(
--             PARSE_JSON(RECORD_CONTENT):data:stateAfter:GOVERNEDCUSTOMERNUMBER::VARCHAR,
--             PARSE_JSON(RECORD_CONTENT):data:stateBefore:GOVERNEDCUSTOMERNUMBER::VARCHAR
--         ),
--         COALESCE(
--             PARSE_JSON(RECORD_CONTENT):data:stateAfter:AUTHORISEDCUSTOMERNUMBER::VARCHAR,
--             PARSE_JSON(RECORD_CONTENT):data:stateBefore:AUTHORISEDCUSTOMERNUMBER::VARCHAR
--         ),
--         RECORD_CONTENT
-- ),

-- FLATTENED AS (
--     SELECT C.*
--     FROM CTE_CDC_CUTOFF AS C
--     LEFT JOIN LATERAL FLATTEN(
--         INPUT => COALESCE(
--             PARSE_JSON(C.RECORD_CONTENT):data:stateAfter:associatedPeople,
--             ARRAY_CONSTRUCT()
--         )
--     )
--     LEFT JOIN LATERAL FLATTEN(
--         INPUT => COALESCE(
--             PARSE_JSON(C.RECORD_CONTENT):data:stateBefore:associatedPeople,
--             ARRAY_CONSTRUCT()
--         )
--     )
-- )

-- SELECT *
-- FROM flattened;

SELECT * FROM {{ source("landing__customer_authority_service", "CUSTOMER_AUTHORITY") }}
