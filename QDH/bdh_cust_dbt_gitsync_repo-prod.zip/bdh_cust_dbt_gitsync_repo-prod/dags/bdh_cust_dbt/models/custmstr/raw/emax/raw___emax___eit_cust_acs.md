{% docs raw___emax___eit_cust_acs %}

A customer who is registered by virtue of being issued a CHAID. A customer must also be an EMAX user in order to have an Access List. An EMAX User is allocated a Customer Access Identifier, CAID.

{% enddocs %}

{% docs raw___emax___eit_cust_acs___emax_no %}

System generated unique number.

{% enddocs %}

{% docs raw___emax___eit_cust_acs___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs raw___emax___eit_cust_acs___d_chan_acs_id %}

Default Channel Access Id. This is the Access number for the EMAX user allocated by the system and printed on cards issued to the customer.

{% enddocs %}

{% docs raw___emax___eit_cust_acs___last_updt_tstamp %}

The date and time of the last update to the table.

{% enddocs %}

{% docs raw___emax___eit_cust_acs___user_id %}

Signon user identify of the operator or process who made the last change to this row.

{% enddocs %}