{% do set_query_tag() %}
{{ config(
    materialized='incremental',
    unique_key=['GOVERNEDCUSTOMERNUMBER', 'AUTHORISEDCUSTOMERNUMBER', 'DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    tmp_relation_type='table',
    post_hook=["DELETE FROM {{ this }}   
      where GOVERNEDCUSTOMERNUMBER || AUTHORISEDCUSTOMERNUMBER || dwh_effective_from_tstamp
        in
      (
        select 
            t.governedCustomerNumber || t.authorisedCustomerNumber || t.dwh_effective_from_tstamp
        from {{ this }} t 
        left join (
            select
                coalesce(
                    RECORD_CONTENT:data:stateAfter.governedCustomerNumber,
                    RECORD_CONTENT:data:stateBefore.governedCustomerNumber
                ) as governedcustomernumber,
                p.value:authorisedCustomerNumber::varchar as authorisedcustomernumber,
                RECORD_CONTENT:metadata.time as metadata_time
            from {{ source('landing__customer_authority_service', 'CUSTOMER_AUTHORITY') }}
            , lateral flatten(
                input => coalesce(
                    RECORD_CONTENT:data:stateAfter.associatedPeople,
                    RECORD_CONTENT:data:stateBefore.associatedPeople,
                    array_construct()
                )
            ) p
        ) s
        on t.governedCustomerNumber = s.governedcustomernumber
     and t.authorisedCustomerNumber = s.authorisedcustomernumber
     and t.dwh_effective_from_tstamp = s.metadata_time
        where 
            s.governedcustomernumber is null
     and s.authorisedcustomernumber is null
    AND dwh_effective_from_tstamp >= DATEADD(DAY, -{{ var('days_back', 30) }} , CURRENT_TIMESTAMP()))"]
  ) 
}}

/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select raw___customer_authority_service___customer_authority --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select  raw___customer_authority_service___customer_authority --vars '{ "run_type": "full_data_load", "days_back": 30 }'

default values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point


A full data load will read from the Full Historical View and a Specific Data Load will perform an incremental load directly from the on-going Kafka Landing table.
When deploying, a full data load should be performed before incremental.
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATEADD(DAY, -" ~ days_back ~ ", CURRENT_TIMESTAMP())" %}
{% else %}
  {% set filter_date = "'1900-01-01 00:00:00'" %}
{% endif %}
/* Setting the "source" based on incremental load vs full data load */
{% if run_type == 'specific_data_load' %}
  {% set source_model = source("landing__customer_authority_service", "CUSTOMER_AUTHORITY") %}
{% else %} 
  {% set source_model = ref('raw___customer_authority_service___customer_authority_full_view') %}
{% endif %}

WITH raw_customer_authority AS (
    SELECT *
    FROM {{ source_model }}
    WHERE record_content:metadata:time::TIMESTAMP_TZ > '1900-01-01 00:00:00'
),

raw_data AS (
    SELECT
        d.*,
        record_content:metadata.time::STRING AS metadata_time,
        record_content:metadata.id::STRING AS metadata_id,
        record_content:data:stateAfter:operatingAuthorityId::NUMBER AS data_stateafter_operatingauthorityid,
        record_content:data:stateAfter:governedCustomerNumber::NUMBER AS data_stateafter_governedcustomernumber,
        record_content:data:stateAfter:revisionNumber::NUMBER AS data_stateafter_revisionnumber,
        record_content:data:stateBefore:operatingAuthorityId::NUMBER AS data_statebefore_operatingauthorityid,
        record_content:data:stateBefore:revisionNumber::NUMBER AS data_statebefore_revisionnumber,
        record_content:data:stateBefore:governedCustomerNumber::NUMBER AS data_statebefore_governedcustomernumber,
        -- stateAfter associatedPeople
        sa.value:authorisedCustomerNumber::NUMBER AS data_stateafter_associatedpeople_authorisedcustomernumber,
        sa.value:authorisedCustomerType::STRING AS data_stateafter_associatedpeople_authorisedcustomertype,
        sa.value:effectiveFromDate::DATE AS data_stateafter_associatedpeople_effectivefromdate,
        sa.value:effectiveToDate::DATE AS data_stateafter_associatedpeople_effectivetodate,
        -- -- stateBefore associatedPeople
        sb.value:authorisedCustomerNumber::NUMBER AS data_statebefore_associatedpeople_authorisedcustomernumber,
        sb.value:authorisedCustomerType::STRING AS data_statebefore_associatedpeople_authorisedcustomertype,
        sb.value:effectiveFromDate::DATE AS data_statebefore_associatedpeople_effectivefromdate,
        sb.value:effectiveToDate::DATE AS data_statebefore_associatedpeople_effectivetodate
    FROM raw_customer_authority AS d
    , LATERAL FLATTEN(
        INPUT => d.record_content:data:stateAfter:associatedPeople,
        OUTER => TRUE
    ) AS sa
      , LATERAL FLATTEN(
         INPUT =>
             d.record_content:data:stateBefore:associatedPeople,
             OUTER => TRUE
 ) AS sb
)

--Todo: Raise with source team. Determine if this can be fixed or needs to be handled. Anne is working with CUSTOMER_AUTHORITY_SERVICE team to determine.
--This cte currently performs the date filter and deduplication of the data. If dedupe logic is removed (Qualify), date filter should remain included.
, cte_dedupe AS (
    SELECT * FROM raw_data
    WHERE metadata_time::TIMESTAMP_TZ >= {{ filter_date }}
    QUALIFY ROW_NUMBER() OVER (
      PARTITION BY
      COALESCE(
            PARSE_JSON(record_content):data:stateAfter:GOVERNEDCUSTOMERNUMBER::VARCHAR,
            PARSE_JSON(record_content):data:stateBefore:GOVERNEDCUSTOMERNUMBER::VARCHAR
        ),
        COALESCE(
            PARSE_JSON(record_content):data:stateAfter:AUTHORISEDCUSTOMERNUMBER::VARCHAR,
            PARSE_JSON(record_content):data:stateBefore:AUTHORISEDCUSTOMERNUMBER::VARCHAR
        ),
      metadata_time::TIMESTAMP_TZ
      ORDER BY metadata_time::TIMESTAMP_TZ DESC) = 1
)

--Kafka Regular Scenario (data:stateAfter populated)
, cte_pre_customer_authority AS (
    SELECT
      {{ select_customer_authority_fields('DATA_STATEAFTER') }},
      'CUSTOMER_AUTHORITY_SERVICE' AS dwh_source_system_code,
      metadata_time::TIMESTAMP_TZ AS updated_at,
      'N' AS dwh_is_deleted_flag,
      metadata_id::VARCHAR(50) AS dwh_extraction_id,
      ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
      NULL AS dwh_process_update_id,
      CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp
      FROM cte_dedupe
      WHERE NOT IS_NULL_VALUE(record_content:data:stateAfter) AND data_stateafter_associatedpeople_authorisedcustomernumber::VARCHAR IS NOT NULL
      )

--Kafka Delete Scenario (data:stateBefore populated date:stateAfter not populated)
--      should stateAfter_GOVERNEDCUSTOMERNUMBER always NULL as where filer IS_NULL_VALUE(RECORD_CONTENT:stateAfter)
--      CASE WHEN stateAfter_CGOVERNEDCUSTOMERNUMBER::VARCHAR IS NULL THEN 'Y' ELSE 'N' END AS DWH_IS_DELETED_FLAG,
--      stateAfter_GOVERNEDCUSTOMERNUMBER already been defined as VARCHAR
--      although we have four PKs as the composite key, only check one PK should be enough?
, cte_pre_customer_authority_delete AS (
    SELECT
      {{ select_customer_authority_fields('DATA_STATEBEFORE') }},
      'CUSTOMER_AUTHORITY_SERVICE' AS dwh_source_system_code,
      metadata_time::TIMESTAMP_TZ AS updated_at,
      CASE WHEN data_stateafter_governedcustomernumber IS NULL THEN 'Y' ELSE 'N' END AS dwh_is_deleted_flag,
      metadata_id::VARCHAR(50) AS dwh_extraction_id,
      ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
      NULL AS dwh_process_update_id,
      CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp
      FROM cte_dedupe
      WHERE IS_NULL_VALUE(record_content:data:stateAfter) AND data_statebefore_associatedpeople_authorisedcustomernumber::VARCHAR IS NOT NULL
      )

-- Only check existing records if existing records exist. If they do get the latest record needed to be checked for updates
/*Qestion: wonder if there is any difference in between get old data than before filter_data and use use {{ this }} + data >= filter_date
regarding the performance and cost, especially for large data set?
*/
{% if is_incremental() %}
, cte_old_active_records AS (
    SELECT
			operatingauthorityid,
			revisionnumber,
			governedcustomernumber,
			authorisedcustomernumber,
			authorisedcustomertype,
			effectivefromdate,
			effectivetodate,
			dwh_source_system_code,
			dwh_effective_from_tstamp AS updated_at,
			dwh_is_deleted_flag,
			dwh_extraction_id,
			dwh_process_insert_id,
			dwh_process_update_id,
			dwh_process_tstamp
    FROM {{ this }}
    WHERE dwh_effective_from_tstamp < {{ filter_date }}
    QUALIFY ROW_NUMBER() OVER (PARTITION BY governedcustomernumber, authorisedcustomernumber ORDER BY dwh_effective_from_tstamp DESC) = 1
)
{% endif %}

--Can only combine all three if existing records exist
{% if is_incremental() %}
, cte_combine AS (
    SELECT * FROM cte_pre_customer_authority
    UNION ALL
    SELECT * FROM cte_pre_customer_authority_delete
    UNION ALL
    SELECT * FROM cte_old_active_records
)
{% endif %}
 --If existing records don't exist, ignore existing check
{% if not is_incremental() %}
, cte_combine AS (
    SELECT * FROM cte_pre_customer_authority
    UNION ALL
    SELECT * FROM cte_pre_customer_authority_delete
)
{% endif %}

 --Calculate the Effective From and Effective To based on the subset of data combined above.
/* METADATA_TIME::TIMESTAMP_TZ AS UPDATED_AT,
 if incremetnal (exising) DWH_EFFECTIVE_FROM_TSTAMP AS UPDATED_AT,
 the purpose to EXCLUDE UPDATED_AT as we need rename UPDATED_AT AS DWH_EFFECTIVE_FROM_TSTAMP
*/
, cte_dwh_fields AS (
    SELECT
* EXCLUDE updated_at,
    updated_at AS dwh_effective_from_tstamp,
 -- to test if the lead works as expected is DWH_EFFECTIVE_FROM_TSTAMP is null or DWH_EFFECTIVE_TO_TSTAMP is null or DWH_EFFECTIVE_TO_TSTAMP< DWH_EFFECTIVE_FROM_TSTAMP 
       TIMESTAMPADD(MICROSECOND, -1, COALESCE(LEAD(updated_at)
    OVER (PARTITION BY governedcustomernumber, authorisedcustomernumber ORDER BY updated_at ASC)
    , '9999-12-31T00:00:00.000001'::TIMESTAMP_TZ)) AS dwh_effective_to_tstamp,
    ROW_NUMBER() OVER (PARTITION BY governedcustomernumber, authorisedcustomernumber ORDER BY updated_at ASC) AS record_order,
    LAG(dwh_is_deleted_flag) OVER (PARTITION BY governedcustomernumber, authorisedcustomernumber ORDER BY dwh_effective_from_tstamp ASC) AS prev_delete
    FROM cte_combine
    )

  {% if is_incremental() %}
  --If existing records exist determine records that need to be inserted / updated to limit # of record to merge.
  -- again, in the future, if we have a very large table, how efficient/ what this is cost for using the method below 
, cte_records_to_merge AS (
    SELECT
s.* EXCLUDE (dwh_process_insert_id, dwh_process_update_id, dwh_process_tstamp),
    -- here we only use one of composite key 
    CASE WHEN s.dwh_is_deleted_flag = 'Y' THEN 'D'
         WHEN s.dwh_is_deleted_flag = 'N' AND ((s.record_order = 1 AND COALESCE(t.dwh_latest_dml_type_code, 'I') = 'I')
          OR (prev_delete = 'Y')) THEN 'I'
	      ELSE 'U' END AS dwh_latest_dml_type_code,
     CASE WHEN t.governedcustomernumber IS NULL THEN s.dwh_process_insert_id
         WHEN t.governedcustomernumber IS NOT NULL THEN t.dwh_process_insert_id END AS dwh_process_insert_id,
    CASE WHEN t.governedcustomernumber IS NULL THEN NULL
         WHEN t.governedcustomernumber IS NOT NULL THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR END AS dwh_process_update_id,
    CASE WHEN t.governedcustomernumber IS NULL THEN s.dwh_process_tstamp
         WHEN t.governedcustomernumber IS NOT NULL THEN CURRENT_TIMESTAMP()::TIMESTAMP_LTZ END AS dwh_process_tstamp
     FROM cte_dwh_fields AS s
    LEFT JOIN {{ this }} AS t
    ON s.governedcustomernumber = t.governedcustomernumber
 		AND s.authorisedcustomernumber = t.authorisedcustomernumber
    AND s.dwh_effective_from_tstamp = t.dwh_effective_from_tstamp
    WHERE (t.governedcustomernumber IS NULL --New history scenario
        OR (t.dwh_effective_to_tstamp = '9999-12-31'::TIMESTAMP_TZ AND s.dwh_effective_to_tstamp <> '9999-12-31'::TIMESTAMP_TZ) --End dating existing open record
        OR s.dwh_effective_to_tstamp <> t.dwh_effective_to_tstamp) --Missing Record Scenario
)
{% endif %}
{% if not is_incremental() %}
--If existing records do not exist create first version of records.
, cte_records_to_merge AS (
    SELECT
s.*
      , CASE WHEN s.dwh_is_deleted_flag = 'Y' THEN 'D'
         WHEN s.dwh_is_deleted_flag = 'N'
          AND (s.record_order = 1 OR s.prev_delete = 'Y') THEN 'I'
         ELSE 'U' END AS dwh_latest_dml_type_code
    FROM cte_dwh_fields AS s
)
{% endif %}

SELECT
  operatingauthorityid,
	revisionnumber,
	governedcustomernumber,
	authorisedcustomernumber,
	authorisedcustomertype,
	effectivefromdate,
	effectivetodate,
	dwh_source_system_code,
	dwh_latest_dml_type_code,
	dwh_effective_from_tstamp,
	dwh_effective_to_tstamp,
	dwh_is_deleted_flag,
	dwh_extraction_id,
	dwh_process_insert_id,
	dwh_process_update_id,
	dwh_process_tstamp
FROM cte_records_to_merge
