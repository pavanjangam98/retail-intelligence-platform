{% docs raw___bis___bst_occupation %}

This raw product holds reference data related to a recognized classification of occupation.

This will be replaced by customer master microservice in the future
{% enddocs %}

{% docs raw___bis___bst_occupation___occupation_code %}

The standard classification for a customer's occupation using the NZSCO code. The Bank uses a subset of the total set of NZSCO codes. For example: '413' = Flying Instructor '3313' = Bank Teller '1327' = Homemaker '325' = Cartographical Draftsman

{% enddocs %}

{% docs raw___bis___bst_occupation___occupation_desc %}

Description of the Occupation Code . example 'Civil Engineer'

{% enddocs %}
