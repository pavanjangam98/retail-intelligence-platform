{% docs raw___bis___bst_cust_wkplce %}

This raw product holds relationship between customer and workplace.

{% enddocs %}

{% docs raw___bis___bst_cust_wkplce___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs raw___bis___bst_cust_wkplce___workplace_code %}

A code to define a workplace that can be associated to a person, e.g.
1 - Academic Colleges of NZ
2 - Access Brokerage Ltd

{% enddocs %}

{% docs raw___bis___bst_cust_wkplce___last_updt_userid %}

The user or system id of the last update to the table.

{% enddocs %}

{% docs raw___bis___bst_cust_wkplce___last_updt_tstamp %}

The date and time of the last update to the table.

{% enddocs %}
