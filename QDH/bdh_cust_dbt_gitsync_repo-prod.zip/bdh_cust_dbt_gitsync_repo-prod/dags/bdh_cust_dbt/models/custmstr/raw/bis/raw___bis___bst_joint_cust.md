{% docs raw___bis___bst_joint_cust %}

BST Joint CUSTOMER Table.

{% enddocs %}

{% docs raw___bis___bst_joint_cust___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs raw___bis___bst_joint_cust___reln_nature_desc %}

Describes the nature of the joint relationship, such as Married, Friends

{% enddocs %}

{% docs raw___bis___bst_joint_cust___occupation_code %}

The standard classification for a customer's occupation using the NZSCO code. The Bank uses a subset of the total set of NZSCO codes.

{% enddocs %}

{% docs raw___bis___bst_joint_cust___jnt_cust_type %}

Classification of Joint Customer by their relationship.

{% enddocs %}
