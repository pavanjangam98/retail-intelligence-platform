{{ config(
    materialized='view'
) }}
 
WITH CTE_CDC_CUTOFF AS (
SELECT
    COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:EMAX_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:EMAX_NO::VARCHAR) AS EMAX_NO,
	MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM {{ source("landing__emax", "EIT_CUST_ACS") }}
    GROUP BY
	COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:EMAX_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:EMAX_NO::VARCHAR)
	)
 
--Standarise the historical hadoop data to follow the same format as the CDC events, with correct capitilsation.
 
, CTE_STANDARDISE_HADOOP_DATA AS (
SELECT
        CASE
        WHEN PARSE_JSON(VALUE):HDP_LAST_UPDT_TSTAMP::VARCHAR LIKE '%-%'
        THEN TO_TIMESTAMP(
                 PARSE_JSON(VALUE):HDP_LAST_UPDT_TSTAMP::VARCHAR,
                 'YYYY-MM-DD HH24:MI:SS'
             )
        WHEN PARSE_JSON(VALUE):HDP_LAST_UPDT_TSTAMP::VARCHAR LIKE '%/%'
        THEN TO_TIMESTAMP(
                 PARSE_JSON(VALUE):HDP_LAST_UPDT_TSTAMP::VARCHAR,
                 'MM/DD/YYYY HH24:MI'
             )
    END AS HDP_LAST_UPDT_TSTAMP,
    PARSE_JSON(VALUE):HDP_DML_CODE::VARCHAR AS HDP_DML_CODE,
    OBJECT_CONSTRUCT_KEEP_NULL(
        'EMAX_NO', PARSE_JSON(VALUE):EMAX_NO,
        'CUSTOMER_NO', PARSE_JSON(VALUE):CUSTOMER_NO,
        'D_CHAN_ACS_ID', PARSE_JSON(VALUE):D_CHAN_ACS_ID,
        'LAST_UPDT_TSTAMP', PARSE_JSON(VALUE):LAST_UPDT_TSTAMP,
        'USER_ID', PARSE_JSON(VALUE):USER_ID
    ) AS VALUE
    FROM {{ source("landing__emax", "EIT_CUST_ACS_HADOOP_HISTORICAL") }} WHERE VALUE:LAST_UPDT_TSTAMP IS NULL
)
 
--Build the Hadoop record into the format of beforeState and afterState, only taking records that are before the combined cutoff earliest record per each combination of Primary keys
 
, CTE_HADOOP_DATA AS (
    SELECT
    OBJECT_CONSTRUCT_KEEP_NULL() AS RECORD_METADATA,
    OBJECT_CONSTRUCT_KEEP_NULL(
            'afterState', CASE WHEN HDP_DML_CODE IN ('I', 'U', 'RR') THEN VALUE END,
            'beforeState', CASE WHEN HDP_DML_CODE IN ('U', 'D') THEN VALUE END,
            'metadata', OBJECT_CONSTRUCT_KEEP_NULL(
                            'id', 'hist_record',
                            'source', 'EIT_CUST_ACS',
                            'subject', NULL,
                            'time', HDP_LAST_UPDT_TSTAMP,
                            'type', 'dwh_history'
                            )
            ) AS RECORD_CONTENT
    FROM CTE_STANDARDISE_HADOOP_DATA
    LEFT JOIN CTE_CDC_CUTOFF AS C
    ON C.EMAX_NO = VALUE:EMAX_NO::VARCHAR
  WHERE HDP_LAST_UPDT_TSTAMP < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
  --Exclude incorrect Hadoop data where LAST_UPDT_TSTAMP is null so it does not fail the not_null test in the raw model
  AND NOT IS_NULL_VALUE(VALUE:LAST_UPDT_TSTAMP)
)
 
 
select * from {{ source("landing__emax", "EIT_CUST_ACS") }}
UNION ALL
SELECT * FROM CTE_HADOOP_DATA
 