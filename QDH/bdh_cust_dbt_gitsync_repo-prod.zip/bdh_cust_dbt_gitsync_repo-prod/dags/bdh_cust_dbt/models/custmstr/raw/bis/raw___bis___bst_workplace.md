{% docs raw___bis___bst_workplace %}

This raw product holds details on reference data related to workplace and workplace code

{% enddocs %}

{% docs raw___bis___bst_workplace___workplace_code %}

A code to define a workplace that can be associated to a person, e.g.
1 - Academic Colleges of NZ
2 - Access Brokerage Ltd

{% enddocs %}

{% docs raw___bis___bst_workplace___workplace_desc %}

Description of a workplace that can be associated to a person.

{% enddocs %}

{% docs raw___bis___bst_workplace___end_date %}

The end date that this WORK PERK CODE ends upon
A new column to the table in order that staff can “End” a Work Perk and still keep it available to be reopened ata a later date, with the original Customers still associated to it.

{% enddocs %}
