{% docs raw___bis___bst_indiv_cust %}

This Individual Customer Model to load data from a view combining the on-going CDC
incoming data with the History provided by the Existing Tenancy and the Hadoop Data for
BST_CIST_RELN. Designed to remove overlapping timeframes of data.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___sex %}

The sex/gender of a person.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___birth_date %}

The date on which the person was born.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___dob_confirmed_ind %}

An indication as to whether the date of birth has been confirmed by the customer or estimated by the bank.
Values: yes (confirmed), no (estimated)

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___death_date %}

The date on which the individual died.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___dependants_count %}

The number of people who are dependants of this individual.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___bank_pensioner_ind %}

An indication of whether the customer is a pensioner of the bank or not.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___genl_comm1_text %}

A description of any other physical characteristics of the individual
used to assist in identifying the individual.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___genl_comm2_text %}

Any comments the bank wishes to record related to this customer.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___genl_comm3_text %}

Any comments the bank wishes to record related to this customer.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___gross_income_amt %}

The actual annual income of an individual used to determine his/her income bracket.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___gross_income_date %}

The Date that the Gross

Income details were recorded.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___bank_employee_ind %}

An indication of whether the customer is an employee of the bank or not.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___marital_status %}

The current marital status of the person.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___m_status_conf_date %}

The date on which the current marital status of the person was recorded.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___emp_start_date %}

The date on which the customer commenced employment in this position or the date on which the customer advised the bank of this employment.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___employer_name %}

The name of the employer of the customer.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___occupation_code %}

The standard classification for a customer's occupation using the NZSCO code. The Bank uses a subset of the total set of NZSCO codes. For example:
'413' = Flying Instructor
'3313' = Bank Teller
'1327' = Homemaker
'325' = Cartographical
Draftsman

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___consent_ind %}

This indicates whether a signed consent form is held (Y) or not (N).

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___employment_type %}

The code allocated to identify the employment type of an individual customer.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___empld_since_date %}

Date on which current employment started.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___salary_freq_code %}

The code allocated to salary frequency description

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___rsdnt_status %}

The code that has been allocated to the residential status description

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___rsdng_since_date %}

Date on which current residential status started.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___addressee_title %}

Title or honorific used when forming an addressee line on a letter etc.
Eg. Mr, Mrs, Hon, Lord, Miss, Madam.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___initials %}

Initials of each forename in person full name.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___surname %}

Surname, or family name, of person.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___forename1 %}

First forename, Given or Christian name.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___forename2 %}

Second forename, Given or Christian name

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___forename3 %}

Third forename, Given or Christian name

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___partner_name %}

Name of partner or spouse.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___emp_industry_code %}

Code which relates to the employment industry group

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___prm_id_type_code %}

The type of primary identification presented by the customer e.g. passport. This column has been added as part of an AML requirement.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___prm_id_desc %}

The actual reference number / details applicable to the primary identification type selected e.g. NZ873094.  This column has been added as part of an AML requirement.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___sec_id_type_code %}

The type of secondary Identification presented by the customer  e.g. super gold card. This column has been added as part of an AML requirement.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___sec_id_desc %}

The actual reference number / details applicable to the secondary identification type selected. This column has been added as part of an AML requirement.

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___pref_language_code %}

Preferred Language (if not English) = “GER”, “JPN” or “CAN” etc.. (see BST_LANGUAGE)

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___prm_id_country %}

Country of origin of primary Id if not NZ

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___sec_id_country %}

Country of origin of secondary ID if not NZ

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___dl_version_no %}

Driving License number

{% enddocs %}

{% docs raw___bis___bst_indiv_cust___pp_expiry_date %}

Passport expiry date

{% enddocs %}
