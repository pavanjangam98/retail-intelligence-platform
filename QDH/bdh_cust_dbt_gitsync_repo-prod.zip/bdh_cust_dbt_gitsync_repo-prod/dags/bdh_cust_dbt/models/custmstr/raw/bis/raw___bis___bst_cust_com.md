{% docs raw___bis___bst_cust_com %}

Table for Cust Com

{% enddocs %}

{% docs raw___bis___bst_cust_com___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs raw___bis___bst_cust_com___emsg_type_code %}

Code that defines the type of electronic message this refers to;
E - Email
T - Text
P - Page
F - Fax
C - Cell
L - Landline

{% enddocs %}

{% docs raw___bis___bst_cust_com___emsg_serv_no %}

A number to ensure unique identification for an emessage service.

{% enddocs %}

{% docs raw___bis___bst_cust_com___location_code %}

Code for the location ie H for Home, P for Personal,W for Work ,A for After Hours,X for Xero Home

{% enddocs %}

{% docs raw___bis___bst_cust_com___cust_com_nickname %}

A nickname that a customer may associate to a communication method.

{% enddocs %}

{% docs raw___bis___bst_cust_com___cust_com_desc %}

Actual detail of a communication method, e.g. the email address, phone number.

{% enddocs %}

{% docs raw___bis___bst_cust_com___priority_no %}

Nominated as preferred communication method, e.g. if 1 = fax then fax number is
preferred number.

{% enddocs %}

{% docs raw___bis___bst_cust_com___last_updt_tstamp %}

The date and time of the last update to the table.

{% enddocs %}

{% docs raw___bis___bst_cust_com___last_updt_userid %}

The user or system id of the last update to the table.

{% enddocs %}
