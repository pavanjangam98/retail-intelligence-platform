{% do set_query_tag() %}

{{ config(
    materialized='incremental',
    unique_key=['CUSTOMERNUMBER', 'SCORETYPE', 'DWH_EFFECTIVE_FROM_TSTAMP'],
    incremental_strategy = 'merge',
    tmp_relation_type='table'
 
  ) 
}}

/* Due to increase processing requirement of post hook, it has been removed and will need to be run as manual process wherever applicable. */
/*We can process 'specific set of data' Or 'Full data' based on our requirement in
'Incremental mode'.
days_back - This param will determine the 'days' we want to go backwards in time.

when we want to process entire data vs specific set of data, we should run following commands
Specific data set command - dbt build --select raw___customer_profile_score_service___customer_profile_score --vars '{"run_type": "specific_data_load", "days_back": 15}'
Full data set command - dbt build  --select  raw___customer_profile_score_service___customer_profile_score --vars '{ "run_type": "full_data_load", "days_back": 30 }'

--Don't use these for BAU
Specific Date Range - dbt build -s +raw___customer_profile_score_service___customer_profile_score+ --vars '{"run_type": "specific_date_range", "days_back": 10, "end_date": ''2025-06-18''}'

default values for the defined variables below:
Since these will be set via Airflow, these default values will not be important. However During Performance testing on a full dataset we can refine what a good "increment" looks like.
A month seemed like an appropriate starting point


A full data load will read from the Full Historical View and a Specific Data Load will perform an incremental load directly from the on-going Kafka Landing table.
When deploying, a full data load should be performed before incremental.
*/

{% set run_type = var('run_type', 'specific_data_load') %}
{% set days_back = var('days_back', 30) %}
{% set end_date = var('end_date', '9999-12-31') %}

{% if run_type == 'specific_data_load' %}
  {% set filter_date = "DATE_PART('epoch_millisecond',DATEADD(day, -" ~ days_back ~ ", CURRENT_TIMESTAMP()))" %}
{% elif run_type == 'specific_date_range' %}
  {% set filter_date = "DATE_PART('epoch_millisecond',DATEADD(day, -" ~ days_back ~ ", '" ~ end_date ~"'::TIMESTAMP))" %} 
{% else %} 
  {% set filter_date = "DATE_PART('epoch_millisecond', TO_TIMESTAMP_NTZ('1970-01-02 00:00:00'))" %}
{% endif %}

{{ log("filter date: " ~ filter_date) }}

{% if run_type == 'specific_data_load' %}
  {% set source_model = source("landing__customer_profile_score_service", "CUSTOMER_PROFILE_SCORE") %}
{% else %} 
  {% set source_model = ref('raw___customer_profile_score_service___customer_profile_score_full_view') %}
{% endif %}


WITH raw_customer_profile_score AS (
    SELECT record_content
    FROM {{ source_model }} --
   -- LANDING__DEV.CUSTOMER_PROFILE_SCORE_SERVICE.CUSTOMER_PROFILE_SCORE 

 {% if run_type == 'specific_data_load' %}
        WHERE record_content:metadata:time::NUMBER > {{ filter_date }}
    {% elif run_type == 'specific_date_range' %}
        WHERE RECORD_CONTENT:metadata:time::NUMBER BETWEEN {{ filter_date }} AND  DATE_PART('epoch_millisecond', TO_TIMESTAMP_NTZ('{{ end_date }}'))
    {% else %}
        WHERE 1=1
    {% endif %}
)

, raw_data AS (SELECT
    PARSE_JSON(record_content):data:customerNumber::VARCHAR AS customernumber,
    profilescore.value:isEligible::VARCHAR AS iseligible,
    profilescore.value:ruleFileLocation::VARCHAR AS rulefilelocation,
    profilescore.value:ruleVersion::VARCHAR AS ruleversion,
    profilescore.value:scoreLastUpdatedDateTime::TIMESTAMP_TZ AS scorelastupdateddatetime,
    profilescore.value:scoreType::VARCHAR AS scoretype,
    profilescore.value:scoreValue::NUMBER(38, 19) AS scorevalue,
    record_content:metadata.id::VARCHAR AS metadata_id,
    record_content:metadata.time::VARCHAR AS metadata_time
FROM raw_customer_profile_score,
    LATERAL FLATTEN(
        INPUT => PARSE_JSON(record_content):data:profileScores
    ) AS profilescore
)

--Todo: Raise with source team. Determine if this can be fixed or needs to be handled. Anne is working with customer_profile_score_service team to determine.
--This cte currently performs the date filter and deduplication of the data. If dedupe logic is removed (Qualify), date filter should remain included.
, cte_dedupe AS (
    SELECT * FROM raw_data
    -- WHERE METADATA_TIME::TIMESTAMP_NTZ >= '1900-01-01 00:00:00'
    QUALIFY ROW_NUMBER() OVER (
      PARTITION BY (
      customernumber, scoretype,
       metadata_time::TIMESTAMP_NTZ)
      ORDER BY metadata_time::TIMESTAMP_NTZ DESC) = 1
)

--Kafka Regular Scenario (afterState populated)
, cte_pre_customer_profile_score AS (
    SELECT
      * EXCLUDE (metadata_id, metadata_time),
      'CUSTOMER_PROFILE_SCORE_SERVICE' AS dwh_source_system_code,
      metadata_time::TIMESTAMP_TZ AS updated_at,
      'N' AS dwh_is_deleted_flag,
      metadata_id::VARCHAR(50) AS dwh_extraction_id,
      ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR AS dwh_process_insert_id,
      null AS dwh_process_update_id,
      CURRENT_TIMESTAMP()::TIMESTAMP_LTZ AS dwh_process_tstamp
      FROM cte_dedupe
      )
-- Only check existing records if existing records exist. If they do get the latest record needed to be checked for updates
/*Qestion: wonder if there is any difference in between get old data than before filter_data and use use {{ this }} + data >= filter_date
regarding the performance and cost, especially for large data set?
*/
{% if is_incremental() %}
, cte_old_active_records AS (
    SELECT
   customernumber,
   iseligible,
   rulefilelocation,
   ruleversion,
   scorelastupdateddatetime,
   scoretype,
   scorevalue,
   dwh_source_system_code,
   dwh_effective_from_tstamp AS updated_at,
   dwh_is_deleted_flag,
   dwh_extraction_id,
   dwh_process_insert_id,
   dwh_process_update_id,
   dwh_process_tstamp
    FROM {{ this }}
    WHERE DATE_PART('epoch_millisecond', dwh_effective_from_tstamp) < {{ filter_date }}
    -- AND dwh_effective_to_tstamp = '9999-12-31'::TIMESTAMP_NTZ
    QUALIFY ROW_NUMBER() OVER (PARTITION BY customernumber, scoretype ORDER BY dwh_effective_from_tstamp DESC) = 1
)
{% endif %}

--Can only combine all three if existing records exist
{% if is_incremental() %}
, cte_combine AS (
    SELECT * FROM cte_pre_customer_profile_score
    UNION ALL
    SELECT * FROM cte_old_active_records
)
{% endif %}
 --If existing records don't exist, ignore existing check
{% if not is_incremental() %}
, cte_combine AS (
    SELECT * FROM cte_pre_customer_profile_score
)
{% endif %}

 --Calculate the Effective From and Effective To based on the subset of data combined above.
/* METADATA_TIME::TIMESTAMP_NTZ AS UPDATED_AT,
 if incremetnal (exising) DWH_EFFECTIVE_FROM_TSTAMP AS UPDATED_AT,
 the purpose to EXCLUDE UPDATED_AT as we need rename UPDATED_AT AS DWH_EFFECTIVE_FROM_TSTAMP
*/
, cte_dwh_fields AS (
    SELECT
* EXCLUDE updated_at,
    updated_at AS dwh_effective_from_tstamp,
 -- to test if the lead works as expected is DWH_EFFECTIVE_FROM_TSTAMP is null or DWH_EFFECTIVE_TO_TSTAMP is null or DWH_EFFECTIVE_TO_TSTAMP< DWH_EFFECTIVE_FROM_TSTAMP 
    COALESCE(LEAD(TIMESTAMPADD(MICROSECOND, -1, updated_at)) OVER (PARTITION BY customernumber, scoretype ORDER BY updated_at), '9999-12-31') AS dwh_effective_to_tstamp,
    ROW_NUMBER() OVER (PARTITION BY customernumber, scoretype ORDER BY updated_at ASC) AS record_order,
    LAG(dwh_is_deleted_flag) OVER (PARTITION BY customernumber, scoretype ORDER BY dwh_effective_from_tstamp ASC) AS prev_delete
    FROM cte_combine
    )

  {% if is_incremental() %}
  --If existing records exist determine records that need to be inserted / updated to limit # of record to merge.
  -- again, in the future, if we have a very large table, how efficient/ what this is cost for using the method below 
, cte_records_to_merge AS (
    SELECT
s.* EXCLUDE (dwh_process_insert_id, dwh_process_update_id, dwh_process_tstamp),
    -- here we only use one of composite key 
    CASE WHEN s.dwh_is_deleted_flag = 'Y' THEN 'D'
         WHEN s.dwh_is_deleted_flag = 'N' AND ((s.record_order = 1 AND COALESCE(t.dwh_latest_dml_type_code, 'I') = 'I')
          OR (prev_delete = 'Y')) THEN 'I'
       ELSE 'U' END AS dwh_latest_dml_type_code,
     CASE WHEN t.customernumber IS null THEN s.dwh_process_insert_id
         WHEN t.customernumber IS NOT null THEN t.dwh_process_insert_id END AS dwh_process_insert_id,
    CASE WHEN t.customernumber IS null THEN null
         WHEN t.customernumber IS NOT null THEN ('{{ invocation_id }}' || '.' || '{{ model.unique_id }}')::VARCHAR END AS dwh_process_update_id,
         CASE WHEN t.customernumber IS null THEN s.dwh_process_tstamp
         WHEN t.customernumber IS NOT null THEN CURRENT_TIMESTAMP()::TIMESTAMP_LTZ END AS dwh_process_tstamp
     FROM cte_dwh_fields AS s
    LEFT JOIN {{ this }} AS t
    ON s.customernumber = t.customernumber
   AND s.scoretype = t.scoretype
    AND s.dwh_effective_from_tstamp = t.dwh_effective_from_tstamp
    WHERE (t.customernumber IS null --New history scenario
        OR (t.dwh_effective_to_tstamp = '9999-12-31'::TIMESTAMP_TZ AND s.dwh_effective_to_tstamp <> '9999-12-31'::TIMESTAMP_TZ) --End dating existing open record
        OR s.dwh_effective_to_tstamp <> t.dwh_effective_to_tstamp) --Missing Record Scenario
)
{% endif %}
{% if not is_incremental() %}
--If existing records do not exist create first version of records.
, cte_records_to_merge AS (
    SELECT
s.*
      , CASE WHEN s.dwh_is_deleted_flag = 'Y' THEN 'D'
         WHEN s.dwh_is_deleted_flag = 'N'
          AND (s.record_order = 1 OR s.prev_delete = 'Y') THEN 'I'
         ELSE 'U' END AS dwh_latest_dml_type_code
    FROM cte_dwh_fields AS s
)
{% endif %}

SELECT
 customernumber,
 iseligible,
 rulefilelocation,
 ruleversion,
 scorelastupdateddatetime::TIMESTAMP_TZ AS scorelastupdateddatetime,
 scoretype,
 scorevalue,
 dwh_source_system_code,
 dwh_latest_dml_type_code,
 dwh_effective_from_tstamp,
 dwh_effective_to_tstamp,
 dwh_is_deleted_flag,
 dwh_extraction_id,
 dwh_process_insert_id,
 dwh_process_update_id,
 dwh_process_tstamp
FROM cte_records_to_merge
