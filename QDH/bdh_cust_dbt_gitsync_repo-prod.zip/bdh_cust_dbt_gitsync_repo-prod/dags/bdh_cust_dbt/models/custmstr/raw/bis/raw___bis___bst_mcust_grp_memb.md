{% docs raw___bis___bst_mcust_grp_memb %}

This raw product represents the membership of a customer in a particular Managed Customer Group

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_memb___managed_group_no %}

The identifier of a managed group.

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_memb___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_memb___formal_name %}

The formal name by which a Customer is identified.

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_memb___position_no %}

Position number the staff member holds

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_memb___transfer_ind %}

Indicates Y N or space whether a transfer

{% enddocs %}

{% docs raw___bis___bst_mcust_grp_memb___primary_ind %}

This indicator specifies the
'Primary Customer" in a Managed Group.
Only one customer will be a primary customer within a Managed Group.

{% enddocs %}
