{{ config(
    materialized='view'
) }}

WITH CTE_CDC_CUTOFF AS (
    SELECT
        COALESCE(
  PARSE_JSON(RECORD_CONTENT):data:stateAfter:industry:customerNumber::VARCHAR,
  PARSE_JSON(RECORD_CONTENT):data:stateBefore:industry:customerNumber::VARCHAR
  ) AS CUSTOMERNUMBER,
        MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM {{ source("landing__party_demographics_service", "CUSTOMER_PARTYDEMOGRAPHICS_INDUSTRY") }}
    GROUP BY COALESCE(
   PARSE_JSON(RECORD_CONTENT):data:stateAfter:industry:customerNumber::VARCHAR,
  PARSE_JSON(RECORD_CONTENT):data:stateBefore:industry:customerNumber::VARCHAR
  )
),

CTE_ET_DATA AS (
    SELECT D.* FROM {{ source("landing__party_demographics_service", "CUSTOMER_PARTYDEMOGRAPHICS_INDUSTRY_CDC_HISTORICAL") }} AS D
    LEFT JOIN CTE_CDC_CUTOFF AS C ON
    COALESCE(
   PARSE_JSON(RECORD_CONTENT):data:stateAfter:industry:customerNumber::VARCHAR,
  PARSE_JSON(RECORD_CONTENT):data:stateBefore:industry:customerNumber::VARCHAR
  ) = C.CUSTOMERNUMBER
    WHERE PARSE_JSON(D.RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

SELECT * FROM {{ source("landing__party_demographics_service", "CUSTOMER_PARTYDEMOGRAPHICS_INDUSTRY") }}
UNION ALL
SELECT * FROM CTE_ET_DATA
