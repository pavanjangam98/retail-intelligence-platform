{% docs raw___emax___eit_acs_status_full_view %}

A view combining the on-going CDC incoming data with the History provided by the
 Hadoop. Designed to remove overlapping timeframes of data.

{% enddocs %}

{% docs raw___emax___eit_acs_status_full_view___record_metadata %}

Details about the Event as it was received by Kafka and processed into the Kafka Queue

{% enddocs %}

{% docs raw___emax___eit_acs_status_full_view___record_content %}

Details about the change data capture (CDC) event that happened in the source system.
The incoming data may be received in various formats, such as beforeState + afterState,
or data with a changeHeader There is also metadata included for the CDC event in this
object.

{% enddocs %}