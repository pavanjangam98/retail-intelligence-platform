{% docs raw___bis___bst_mcust_relntype %}

This data product contains managed customer relationship type records that define how a staff member is associated with a managed customer group, referred to as BST_MCUST_RELNTYPE in BIS. A typical record represents one relationship category (for example, BUSINESS PERSONAL BANKERS, ASSET QUALITY MNGER - PERSONAL, or COLLECTIONS OFFICER). 

{% enddocs %}

{% docs raw___bis___bst_mcust_relntype___relationship_type %}

A unique identifier that defines the type of interest a member of staff the type of interest a member of staff may have with a managed customer group.

{% enddocs %}

{% docs raw___bis___bst_mcust_relntype___relationship_desc %}

A text description of the Relationship Type.

{% enddocs %}

{% docs raw___bis___bst_mcust_relntype___reln_short_desc %}

An abbreviated text description of the Relationship Type.

{% enddocs %}

{% docs raw___bis___bst_mcust_relntype___management_ind %}

Indicates whether the group is a management group or not. IE Whether a member of staff is the 'relationship manager' or just has some other interest in the customer group. It is assumed that a relationship manager is ultimately responsible for the management of their customers.

{% enddocs %}