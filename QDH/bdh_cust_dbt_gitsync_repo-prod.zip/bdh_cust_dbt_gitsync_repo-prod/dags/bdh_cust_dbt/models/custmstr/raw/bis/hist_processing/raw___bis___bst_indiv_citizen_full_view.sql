{{ config(
    materialized='view'
) }}

--  Determine the earliest record available for each combination of Primary keys from Cust Indiv. Citizen table within the BAU CDC dataset.
WITH CTE_CDC_CUTOFF AS (
SELECT
COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:COUNTRY_CODE::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:COUNTRY_CODE::VARCHAR) AS COUNTRY_CODE,
COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR) AS CUSTOMER_NO,
MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
FROM {{ source("landing__bis", "BST_INDIV_CITIZEN") }}
GROUP BY COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:COUNTRY_CODE::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:COUNTRY_CODE::VARCHAR),
COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR)
)

--Standarise the historical hadoop data to follow the same format as the CDC events, with correct capitilsation.

, CTE_STANDARDISE_HADOOP_DATA AS (
SELECT
    PARSE_JSON(VALUE):CDC_SEND_TSTAMP::TIMESTAMP_NTZ AS CDC_SEND_TSTAMP,
    PARSE_JSON(VALUE):HDP_DML_CODE::VARCHAR AS HDP_DML_CODE,
    OBJECT_CONSTRUCT_KEEP_NULL(
        'COUNTRY_CODE', PARSE_JSON(VALUE):COUNTRY_CODE,
        'CUSTOMER_NO', PARSE_JSON(VALUE):CUSTOMER_NO,
        'PRIMARY_IND', PARSE_JSON(VALUE):PRIMARY_IND
    ) AS VALUE
    FROM {{ source("landing__bis", "BST_INDIV_CITIZEN_HISTORICAL") }}
)

--Build the Hadoop record into the format of beforeState and afterState, only taking records that are before the combined cutoff earliest record per each combination of Primary keys

, CTE_HADOOP_DATA AS (
    SELECT
    OBJECT_CONSTRUCT_KEEP_NULL() AS RECORD_METADATA,
    OBJECT_CONSTRUCT_KEEP_NULL(
            'afterState', CASE WHEN HDP_DML_CODE IN ('I', 'U', 'RR') THEN VALUE END,
            'beforeState', CASE WHEN HDP_DML_CODE IN ('U', 'D') THEN VALUE END,
            'metadata', OBJECT_CONSTRUCT_KEEP_NULL(
                            'id', 'hist_record',
                            'source', 'BST_INDIV_CITIZEN',
                            'subject', NULL,
                            'time', CDC_SEND_TSTAMP,
                            'type', 'dwh_history'
                            )
            ) AS RECORD_CONTENT
    FROM CTE_STANDARDISE_HADOOP_DATA
    LEFT JOIN CTE_CDC_CUTOFF AS C
    ON C.COUNTRY_CODE = VALUE:COUNTRY_CODE::VARCHAR
    AND C.CUSTOMER_NO = VALUE:CUSTOMER_NO::VARCHAR
  WHERE CDC_SEND_TSTAMP < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

----Union the 2 datasets to get full historical view with no overlaps of data.
SELECT * FROM {{ source("landing__bis", "BST_INDIV_CITIZEN") }}
UNION ALL
SELECT * FROM CTE_HADOOP_DATA
