{% docs raw___emax___eit_acs_status %}
The access status of a Channel Access Identifier, as controlled by the channel system. Holds a description of each Access Status Code. E.g. A=Active, H=Hot
{% enddocs %}

{% docs raw___emax___eit_acs_status___access_status %}

 Code that lists access status of a Channel Access Identifier, as controlled by the channel system. Holds a description of each Access Status Code.  E.g. A=Active, H=Hot.

{% enddocs %}

{% docs raw___emax___eit_acs_status___chaid_type %}

 Channel Access Identifier Type. A code to distinguish Access Number(A), Credit Card (C) and Debit Card(D) identifiers.

{% enddocs %}

{% docs raw___emax___eit_acs_status___status_desc %}

Description of the access status, for example, 'Cancelled' or 'Hot'

{% enddocs %}

{% docs raw___emax___eit_acs_status___last_updt_tstamp %}

The date and time of the last update to the table.

{% enddocs %}

{% docs raw___emax___eit_acs_status___user_id %}

Signon user identify of the operator or process who made the last change to this row.

{% enddocs %}

{% docs raw___emax___eit_acs_status___display_ind %}

Indicates Y or N whether this status should be displayed

{% enddocs %}