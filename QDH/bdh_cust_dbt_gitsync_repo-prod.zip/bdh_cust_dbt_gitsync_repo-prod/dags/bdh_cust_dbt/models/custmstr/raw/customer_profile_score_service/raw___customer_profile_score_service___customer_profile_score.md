{% docs raw___customer_profile_score_service___customer_profile_score %}

This raw product holds details of KYC scores

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score___customernumber %}

The customer identifier

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score___iseligible %}

Whether customer is eligible for scoring for score type

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score___rulefilelocation %}

Link to the version of the rules used for score calculation

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score___ruleversion %}

 Version of the scoring rules used to calculate the score

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score___scorelastupdateddatetime %}

Date and time when the score was last updated

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score___scoretype %}

Type of score.

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score___scorevalue %}

Customer profile score value between 0 and 1 rounded to two digits

{% enddocs %}
