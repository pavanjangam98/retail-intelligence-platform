{% docs raw___bis___bst_customer %}

This Customer Model to load data from Landing Layer to Raw Layer for Bst_Customer table.

{% enddocs %}

{% docs raw___bis___bst_customer___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs raw___bis___bst_customer___customer_type %}

Identifies the type of customer. 'I' = Individual, 'J' = Joint, 'N' = Non-Personal, 'B'
= Branch

{% enddocs %}

{% docs raw___bis___bst_customer___short_name %}

An abbreviated version of the customer's name.

{% enddocs %}

{% docs raw___bis___bst_customer___legal_name %}

The full legal name by which a customer is identified.

{% enddocs %}

{% docs raw___bis___bst_customer___salutation %}

Name that is to appear on correspondance ie Dear < salutation> This contains the full
salutation (title and name), eg 'MR HAYES'.

{% enddocs %}

{% docs raw___bis___bst_customer___start_date %}

The date at which the Customer became a customer of the Bank for that specific
application system.

{% enddocs %}

{% docs raw___bis___bst_customer___end_date %}

The date on which the consumer ceased to be a customer of the bank.

{% enddocs %}

{% docs raw___bis___bst_customer___branch_no %}

The identifying number of a BNZ Branch.

{% enddocs %}

{% docs raw___bis___bst_customer___bus_purpose_code %}

Business Purpose Code like SI, IN…

{% enddocs %}

{% docs raw___bis___bst_customer___formal_name %}

The formal name by which a Customer is identified.

{% enddocs %}

{% docs raw___bis___bst_customer___corporate_no %}

An identifier for a corporate commercial customer for use in systems external to IBIS.

{% enddocs %}

{% docs raw___bis___bst_customer___credit_check_code %}

Code indicating status of credit check against the customer

{% enddocs %}

{% docs raw___bis___bst_customer___cus_rate_sorc_code %}

Tracks the origin of a Credit Rating Score. Who set it: 'QS' = question set from banker
'AS' = application scoring from TRANSACT

{% enddocs %}

{% docs raw___bis___bst_customer___cus_segment_code %}

The code allocated to identify the customer segment the customer belongs to

{% enddocs %}

{% docs raw___bis___bst_customer___cust_arch_status %}

A code to define the archiving status for a customer, i.e. H = Historic A = Archive I =
Inactive??

{% enddocs %}

{% docs raw___bis___bst_customer___cust_potn_code %}

The code defining the potential worth that a customer has to the organisation.

{% enddocs %}

{% docs raw___bis___bst_customer___cust_rating_ind %}

Customer Credit Rating on a scale of 1 to 9. 1 is strongly rated and 9 is doubtful.

{% enddocs %}

{% docs raw___bis___bst_customer___ibis_base_no %}

The IBIS Base Number under which all of a customers new TD/TL accounts will be created.

{% enddocs %}

{% docs raw___bis___bst_customer___ird_no %}

The number that uniquely identifies a customer within the Inland \Revenue Department.

{% enddocs %}

{% docs raw___bis___bst_customer___key_customer_ind %}

An indication of whether the Bank considers this customer to be a Key customer or not.

{% enddocs %}

{% docs raw___bis___bst_customer___kyc_action_date %}

KYC Action Date - The date upon which the Know Your Customer activity was completed. A
history of this activity is to be stored in BIS. This column has been added as part of
an AML Requirement

{% enddocs %}

{% docs raw___bis___bst_customer___kyc_staff_userid %}

KYC StaffID - The staff ID as recorded in BIS of the user that performed the Know your
customer activity. A history of this activity is to be stored in BIS. This column has
been added as part of an AML Requirement

{% enddocs %}

{% docs raw___bis___bst_customer___last_chg_op_code %}

The operator code of the operator who last updated the customer.

{% enddocs %}

{% docs raw___bis___bst_customer___last_chg_timestamp %}

A timestamp indicating the time and date an operator last updated this customer.

{% enddocs %}

{% docs raw___bis___bst_customer___lend_category_ind %}

Indicates a lending category that is relevant for a cusotmer.

{% enddocs %}

{% docs raw___bis___bst_customer___mrkt_segm_code %}

Marketing segment code defined in the Global Data Warehouse (GDW).

{% enddocs %}

{% docs raw___bis___bst_customer___mrkt_segment_code %}

The code representing a particular market segment. F=Farming, M=Middle Business,
P=Personal, S= Small Business, W= Wholesale.

{% enddocs %}

{% docs raw___bis___bst_customer___non_res_levy_ind %}

Indicates whether the customer has waived Non Resident Withholding Tax in favour of a 2%
tax.

{% enddocs %}

{% docs raw___bis___bst_customer___non_resident_code %}

Uniquely identifies the a country

{% enddocs %}

{% docs raw___bis___bst_customer___origin_code %}

Origin Code for customer like BK for Broker

{% enddocs %}

{% docs raw___bis___bst_customer___phone_id_text %}

A word or pharase chosen by the customer to identify themselves when telephoning a CEC
(Customer Enquiry Centre).

{% enddocs %}

{% docs raw___bis___bst_customer___prtf_status_code %}

The code allocated to the portfolio status description

{% enddocs %}

{% docs raw___bis___bst_customer___prtf_status_date %}

Date a portfolio status is allocated to a customer.

{% enddocs %}

{% docs raw___bis___bst_customer___reas_lost_bus_desc %}

The reason why the business of the customer was lost by the Bank.

{% enddocs %}

{% docs raw___bis___bst_customer___reas_win_bus_desc %}

The reason why the business of the customer was obtained by the Bank.

{% enddocs %}

{% docs raw___bis___bst_customer___rwt_exempt_ind %}

An indicator to show whether or not this customer is exempt from paying RWT.

{% enddocs %}

{% docs raw___bis___bst_customer___tax_code %}

The tax code applicable to residents of the country The tax code applicable to residents
of the country N = RWT, 21.5 % ( IRD Number known ) O = RWT, 33 % ( IRD Numberunknown )
A = NRWT, 10 % B = NRWT, 15 % C = NRWT, 30 % L = AIL, 2% E = Custo

{% enddocs %}
