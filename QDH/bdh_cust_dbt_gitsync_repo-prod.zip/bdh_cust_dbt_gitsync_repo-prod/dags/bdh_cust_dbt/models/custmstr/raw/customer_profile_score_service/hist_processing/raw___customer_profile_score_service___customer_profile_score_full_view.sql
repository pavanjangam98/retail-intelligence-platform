{{ config(
    materialized='view'
) }}

-- Determine the earliest record available for each combination of Primary keys from Customer Profile Score table within the BAU CDC dataset.
WITH CTE_CDC_CUTOFF AS (
    SELECT
        PARSE_JSON(RECORD_CONTENT):data:customerNumber::VARCHAR AS CUSTOMERNUMBER,
         MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM {{ source("landing__customer_profile_score_service", "CUSTOMER_PROFILE_SCORE") }}
    GROUP BY
        PARSE_JSON(RECORD_CONTENT):data:customerNumber::VARCHAR
)

-- Gather all available records from the Existing Tenancy that occur before earliest record as calculated above.
, CTE_ET_DATA AS (
    SELECT D.*
    FROM {{ source("landing__customer_profile_score_service", "CUSTOMER_PROFILE_SCORE_CDC_HISTORICAL") }} AS D
    LEFT JOIN CTE_CDC_CUTOFF AS C
        ON C.CUSTOMERNUMBER = PARSE_JSON(D.RECORD_CONTENT):data:customerNumber::VARCHAR
    WHERE PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

-- Final union
SELECT * FROM {{ source("landing__customer_profile_score_service", "CUSTOMER_PROFILE_SCORE") }}
UNION ALL
SELECT * FROM CTE_ET_DATA
