{{ config(
    materialized='view'
) }}

--Hadoop data has been removed from processing due to the large volume of records needed to be processed.

-- Determine the earliest record available for each available Customer Number within the BAU CDC dataset.
WITH CTE_CDC_CUTOFF AS (
    SELECT
        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR,
                 PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR
        ) AS CUSTOMER_NO,

        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:EMSG_TYPE_CODE::VARCHAR,
                 PARSE_JSON(RECORD_CONTENT):beforeState:EMSG_TYPE_CODE::VARCHAR
        ) AS EMSG_TYPE_CODE,

        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:EMSG_SERV_NO::VARCHAR,
                 PARSE_JSON(RECORD_CONTENT):beforeState:EMSG_SERV_NO::VARCHAR
        ) AS EMSG_SERV_NO,

        MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM {{ source("landing__bis", "BST_CUST_COM") }}
    GROUP BY
        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR,
                  PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR),
        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:EMSG_TYPE_CODE::VARCHAR,
                 PARSE_JSON(RECORD_CONTENT):beforeState:EMSG_TYPE_CODE::VARCHAR),
        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:EMSG_SERV_NO::VARCHAR,
                 PARSE_JSON(RECORD_CONTENT):beforeState:EMSG_SERV_NO::VARCHAR)
)

-- Gather all available records from the Existing Tenancy that occure before earliest record as calculated above.
, CTE_ET_DATA AS (
    SELECT D.* FROM {{ source("landing__bis", "BST_CUST_COM_CDC_HIST_SYST02") }} AS D
    LEFT JOIN CTE_CDC_CUTOFF AS C
    ON COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR) = C.CUSTOMER_NO
    AND COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:EMSG_TYPE_CODE::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:EMSG_TYPE_CODE::VARCHAR) = C.EMSG_TYPE_CODE
    AND COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:EMSG_SERV_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:EMSG_SERV_NO::VARCHAR) = C.EMSG_SERV_NO
    WHERE PARSE_JSON(D.RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

--Union the 3 datasets to get full historical view with no overlaps of data.
SELECT * FROM {{ source("landing__bis", "BST_CUST_COM") }}
UNION ALL
SELECT * FROM CTE_ET_DATA
