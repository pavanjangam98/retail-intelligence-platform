{% docs raw___bis___bst_indiv_citizen %}

This Customer Individual Model to load data from a view combining the on-going CDC
incoming data with the History provided by the Existing Hadoop Data for
BST_INDIV_CITIZEN. Designed to  remove overlapping timeframes of data.

{% enddocs %}

{% docs raw___bis___bst_indiv_citizen___country_code %}

Uniquely identifies the country. 

{% enddocs %}

{% docs raw___bis___bst_indiv_citizen___primary_ind %}

Primary Country of Citizenship - This field is populated with the Country code of the customer’s country of Citizenship. This column has been added as part of an AML Requirement.

{% enddocs %}

{% docs raw___bis___bst_indiv_citizen___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}
