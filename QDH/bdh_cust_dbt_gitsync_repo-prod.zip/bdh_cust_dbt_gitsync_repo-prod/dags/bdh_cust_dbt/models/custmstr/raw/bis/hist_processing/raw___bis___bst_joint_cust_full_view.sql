{{ config(
    materialized='view'
) }}


-- Determine the earliest record available for each available Customer Number within the BAU CDC dataset.
WITH CTE_CDC_CUTOFF AS (
    SELECT
        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR) AS CUSTOMER_NO,
        MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM {{ source("landing__bis", "BST_JOINT_CUST") }}
    GROUP BY COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR)
)

-- Gather all available records from the Existing Tenancy that occure before earliest record as calculated above.
 , CTE_ET_DATA AS (
     SELECT D.* FROM {{ source("landing__bis", "BST_JOINT_CUST_CDC_HIST_SYST02") }} AS D
     LEFT JOIN CTE_CDC_CUTOFF AS C
     ON COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR) = C.CUSTOMER_NO
     WHERE PARSE_JSON(D.RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
 )

-- Determine the earliest record available for each available Customer Number within the Existing Tenancy Dataset.
, CTE_ET_CUTOFF AS (
    SELECT
        COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR) AS CUSTOMER_NO,
        MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM CTE_ET_DATA
    GROUP BY COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR)
)

-- Combine CDC Cutoff with the ET cutoff to get the earliest record per Customer Number across both datasets.
, CTE_CUTOFF_COMB AS (
SELECT
	COALESCE(C.CUSTOMER_NO, E.CUSTOMER_NO) AS CUSTOMER_NO,
	LEAST(COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ), COALESCE(E.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)) AS EARLIEST_RECORD
    FROM CTE_CDC_CUTOFF AS C
    FULL OUTER JOIN CTE_ET_CUTOFF AS E
    ON C.CUSTOMER_NO = E.CUSTOMER_NO
)

--Standarise the historical hadoop data to follow the same format as the CDC events, with correct capitilsation.
, CTE_STANDARDISE_HADOOP_DATA AS (
    SELECT
	PARSE_JSON(VALUE):CDC_SEND_TSTAMP::VARCHAR AS CDC_SEND_TSTAMP,
    PARSE_JSON(VALUE):HDP_DML_CODE::VARCHAR AS HDP_DML_CODE,
    OBJECT_CONSTRUCT_KEEP_NULL(
        'CUSTOMER_NO', PARSE_JSON(VALUE):CUSTOMER_NO,
		'RELN_NATURE_DESC', PARSE_JSON(VALUE):RELN_NATURE_DESC,
        'OCCUPATION_CODE', PARSE_JSON(VALUE):OCCUPATION_CODE,
        'JNT_CUST_TYPE', PARSE_JSON(VALUE):JNT_CUST_TYPE

    ) AS VALUE
    FROM {{ source("landing__bis", "BST_JOINT_CUST_HISTORICAL") }}

)

--Build the Hadoop record into the format of beforeState and afterState, only taking records that are before the combined cutoff earliest record per Customer Number
, CTE_HADOOP_DATA AS (
    SELECT
    OBJECT_CONSTRUCT_KEEP_NULL() AS RECORD_METADATA,
    OBJECT_CONSTRUCT_KEEP_NULL(
            'afterState', CASE WHEN HDP_DML_CODE IN ('I', 'U', 'RR') THEN VALUE END,
            'beforeState', CASE WHEN HDP_DML_CODE IN ('U', 'D') THEN VALUE END,
            'metadata', OBJECT_CONSTRUCT_KEEP_NULL(
                            'id', 'hist_record',
                            'source', 'BST_JOINT_CUST',
                            'subject', NULL,
                            'time', CDC_SEND_TSTAMP,
                            'type', 'dwh_history'
                            )
            ) AS RECORD_CONTENT
    FROM CTE_STANDARDISE_HADOOP_DATA
    LEFT JOIN CTE_CUTOFF_COMB AS C
    ON VALUE:CUSTOMER_NO::VARCHAR = C.CUSTOMER_NO
    WHERE CDC_SEND_TSTAMP::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

--Union the 3 datasets to get full historical view with no overlaps of data.
SELECT * FROM {{ source("landing__bis", "BST_JOINT_CUST") }}
UNION ALL
SELECT * FROM CTE_ET_DATA
UNION ALL
SELECT * FROM CTE_HADOOP_DATA
