{% docs raw___customer_profile_score_service___customer_profile_score_gap %}

This raw product holds details of KYC score gaps

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score_gap___customernumber %}

The customer identifier

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score_gap___scoretype %}

Type of score.

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score_gap___gapstatus %}

Status of the gap. True if gap exists, false otherwise.

{% enddocs %}

{% docs raw___customer_profile_score_service___customer_profile_score_gap___gaptype %}

Code for the gap in profile

{% enddocs %}
