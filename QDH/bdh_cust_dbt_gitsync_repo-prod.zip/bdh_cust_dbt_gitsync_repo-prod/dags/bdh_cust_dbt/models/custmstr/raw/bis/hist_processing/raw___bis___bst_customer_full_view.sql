{{ config(
    materialized='view'
) }}

--Hadoop data has been removed from processing due to the large volume of records needed to be processed.


-- Determine the earliest record available for each available Customer Number within the BAU CDC dataset.
WITH CTE_CDC_CUTOFF AS (
    SELECT
    COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR) AS CUSTOMER_NO,
    MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM {{ source("landing__bis", "BST_CUSTOMER") }}
    GROUP BY COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR)
)

-- Gather all available records from the Existing Tenancy that occure before earliest record as calculated above.
, CTE_ET_DATA AS (
    SELECT D.* FROM {{ source("landing__bis", "BST_CUSTOMER_CDC_HIST_SYST02") }} AS D
    LEFT JOIN CTE_CDC_CUTOFF AS C
    ON COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:CUSTOMER_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:CUSTOMER_NO::VARCHAR) = C.CUSTOMER_NO
    WHERE PARSE_JSON(D.RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

--Union the 2 datasets to get full historical view with no overlaps of data.
SELECT * FROM {{ source("landing__bis", "BST_CUSTOMER") }}
UNION ALL
SELECT * FROM CTE_ET_DATA
