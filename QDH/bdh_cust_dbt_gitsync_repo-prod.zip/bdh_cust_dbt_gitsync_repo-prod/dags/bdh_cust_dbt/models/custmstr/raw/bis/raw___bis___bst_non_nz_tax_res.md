{% docs raw___bis___bst_non_nz_tax_res %}

This raw product hold list of countries that a customer is a tax resident of other than NZ

{% enddocs %}

{% docs raw___bis___bst_non_nz_tax_res___country_code %}

Uniquely identifies the a country

{% enddocs %}

{% docs raw___bis___bst_non_nz_tax_res___tax_id_no %}

Foreign tax identity number eg 1234567890

{% enddocs %}

{% docs raw___bis___bst_non_nz_tax_res___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}
