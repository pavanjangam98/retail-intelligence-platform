{% docs raw___emax___eit_acs_lst %}

A grouping of facilities for the convenience of a customer using a channel

{% enddocs %}

{% docs raw___emax___eit_acs_lst___access_list_no %}

An internally allocated sequence number given on access list creation.

{% enddocs %}

{% docs raw___emax___eit_acs_lst___emax_no %}

System generated unique number

{% enddocs %}

{% docs raw___emax___eit_acs_lst___access_list_desc %}

An identifying name given to the list by the customer from a pick list of valid list names.

{% enddocs %}

{% docs raw___emax___eit_acs_lst___access_list_type %}

Indicates whether is is an Account (A) or a Bill Payment (B) list.

{% enddocs %}

{% docs raw___emax___eit_acs_lst___last_updt_tstamp %}

The date and time of the last update to the table.

{% enddocs %}

{% docs raw___emax___eit_acs_lst___user_id %}

Signon user identify of the operator or process who made the last change to this row.

{% enddocs %}

{% docs raw___emax___eit_acs_lst___converted_ind %}

The converted indicator shows whether or not an account list was created by the conversion process or by the online system.  It will have values of Y(es) or N(o), and the default value will be N(o).

{% enddocs %}