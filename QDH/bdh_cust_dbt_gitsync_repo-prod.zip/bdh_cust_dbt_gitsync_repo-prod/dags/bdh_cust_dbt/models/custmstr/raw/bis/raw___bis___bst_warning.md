{% docs raw___bis___bst_warning %}

This raw product holds warning type applicable to a customer

{% enddocs %}

{% docs raw___bis___bst_warning___customer_no %}

An identifier for each Bank Customer in CIS.

{% enddocs %}

{% docs raw___bis___bst_warning___warning_date %}

The effective date of the warning for the customer.

{% enddocs %}

{% docs raw___bis___bst_warning___warning_code %}

The code which uniquely identifies the warning.

{% enddocs %}

{% docs raw___bis___bst_warning___created_userid %}

The user id of a person or program that creates a record.

{% enddocs %}
