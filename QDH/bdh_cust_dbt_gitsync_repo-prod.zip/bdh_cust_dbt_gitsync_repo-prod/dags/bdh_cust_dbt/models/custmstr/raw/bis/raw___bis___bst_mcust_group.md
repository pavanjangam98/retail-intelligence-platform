{% docs raw___bis___bst_mcust_group %}

This raw product holds reference data related to a group of customers being managed (and reported upon) as a whole

{% enddocs %}

{% docs raw___bis___bst_mcust_group___managed_group_no %}

The identifier of a managed group.

{% enddocs %}

{% docs raw___bis___bst_mcust_group___managed_group_name %}

Descriptive name given to a group by the responsible member of staff.

{% enddocs %}

{% docs raw___bis___bst_mcust_group___group_type %}

Type of Group.

{% enddocs %}

{% docs raw___bis___bst_mcust_group___position_no %}

Position number the staff member holds

{% enddocs %}

{% docs raw___bis___bst_mcust_group___transfer_ind %}

Indicator to show whether this CLuster or Group has been tagged for transfer.

{% enddocs %}

{% docs raw___bis___bst_mcust_group___grp_potn_code %}

Group Indicator

{% enddocs %}

{% docs raw___bis___bst_mcust_group___last_updt_tstamp %}

The date and time of the last update to the table.

{% enddocs %}
