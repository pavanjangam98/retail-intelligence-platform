{{ config(
    materialized='view'
) }}

WITH CTE_CDC_CUTOFF AS (
SELECT
    COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:ACCESS_LIST_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:ACCESS_LIST_NO::VARCHAR) AS ACCESS_LIST_NO,
	MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM {{ source("landing__emax", "EIT_ACS_LST") }}
    GROUP BY
	COALESCE(PARSE_JSON(RECORD_CONTENT):afterState:ACCESS_LIST_NO::VARCHAR, PARSE_JSON(RECORD_CONTENT):beforeState:ACCESS_LIST_NO::VARCHAR)
	)

--Standarise the historical hadoop data to follow the same format as the CDC events, with correct capitilsation.

, CTE_STANDARDISE_HADOOP_DATA AS (
SELECT
    CASE
        WHEN PARSE_JSON(VALUE):HDP_LAST_UPDT_TSTAMP::VARCHAR LIKE '%-%'
        THEN TO_TIMESTAMP(
                 PARSE_JSON(VALUE):HDP_LAST_UPDT_TSTAMP::VARCHAR,
                 'YYYY-MM-DD HH24:MI:SS'
             )
        WHEN PARSE_JSON(VALUE):HDP_LAST_UPDT_TSTAMP::VARCHAR LIKE '%/%'
        THEN TO_TIMESTAMP(
                 PARSE_JSON(VALUE):HDP_LAST_UPDT_TSTAMP::VARCHAR,
                 'MM/DD/YYYY HH24:MI'
             )
    END AS HDP_LAST_UPDT_TSTAMP,    
    PARSE_JSON(VALUE):HDP_DML_CODE::VARCHAR AS HDP_DML_CODE,
    OBJECT_CONSTRUCT_KEEP_NULL(
        'ACCESS_LIST_NO', PARSE_JSON(VALUE):ACCESS_LIST_NO,
        'EMAX_NO', PARSE_JSON(VALUE):EMAX_NO,
        'ACCESS_LIST_DESC', PARSE_JSON(VALUE):ACCESS_LIST_DESC,
        'ACCESS_LIST_TYPE', PARSE_JSON(VALUE):ACCESS_LIST_TYPE,
        'LAST_UPDT_TSTAMP', PARSE_JSON(VALUE):LAST_UPDT_TSTAMP,
        'USER_ID', PARSE_JSON(VALUE):USER_ID,
		'CONVERTED_IND', PARSE_JSON(VALUE):CONVERTED_IND
    ) AS VALUE
    FROM {{ source("landing__emax", "EIT_ACS_LST_HADOOP_HISTORICAL") }} where VALUE:LAST_UPDT_TSTAMP IS NOT NULL
)

--Build the Hadoop record into the format of beforeState and afterState, only taking records that are before the combined cutoff earliest record per each combination of Primary keys

, CTE_HADOOP_DATA AS (
    SELECT
    OBJECT_CONSTRUCT_KEEP_NULL() AS RECORD_METADATA,
    OBJECT_CONSTRUCT_KEEP_NULL(
            'afterState', CASE WHEN HDP_DML_CODE IN ('I', 'U', 'RR') THEN VALUE END,
            'beforeState', CASE WHEN HDP_DML_CODE IN ('U', 'D') THEN VALUE END,
            'metadata', OBJECT_CONSTRUCT_KEEP_NULL(
                            'id', 'hist_record',
                            'source', 'BST_CRS_SELF_CERT',
                            'subject', NULL,
                            'time', HDP_LAST_UPDT_TSTAMP,
                            'type', 'dwh_history'
                            )
            ) AS RECORD_CONTENT
    FROM CTE_STANDARDISE_HADOOP_DATA
    LEFT JOIN CTE_CDC_CUTOFF AS C
    ON C.ACCESS_LIST_NO = VALUE:ACCESS_LIST_NO::VARCHAR
  WHERE HDP_LAST_UPDT_TSTAMP < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
   --Exclude incorrect Hadoop data where LAST_UPDT_TSTAMP is null so it does not fail the not_null test in the raw model
  AND NOT IS_NULL_VALUE(VALUE:LAST_UPDT_TSTAMP)
)
, CTE_UNIONED AS(
    SELECT * FROM {{ source("landing__emax", "EIT_ACS_LST") }}
    UNION ALL
    SELECT * FROM CTE_HADOOP_DATA
)
SELECT * FROM CTE_UNIONED
