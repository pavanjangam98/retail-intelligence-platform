{{ config(
    materialized='view'
) }}

-- Determine the earliest record available for each combination of Primary keys from Cust relation table within the BAU CDC dataset.
WITH CTE_CDC_CUTOFF AS (
    SELECT
    COALESCE(
    PARSE_JSON(RECORD_CONTENT):afterState:addressId::VARCHAR,
    PARSE_JSON(RECORD_CONTENT):beforeState:addressId::VARCHAR
    ) AS ADDRESSID,
    MIN(PARSE_JSON(RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ) AS EARLIEST_RECORD
    FROM {{ source("landing__customer_party_address_service", "CUSTOMER_PARTY_ADDRESS") }}
	GROUP BY
 	COALESCE(
	PARSE_JSON(RECORD_CONTENT):afterState:addressId::VARCHAR,
	PARSE_JSON(RECORD_CONTENT):beforeState:addressId::VARCHAR
	)
)

-- Gather all available records from the Existing Tenancy that occure before earliest record as calculated above.
, CTE_ET_DATA AS (
    SELECT D.* FROM {{ source("landing__customer_party_address_service", "CUSTOMER_PARTY_ADDRESS_CDC_HISTORICAL") }} AS D
    LEFT JOIN CTE_CDC_CUTOFF AS C ON
    COALESCE(
    PARSE_JSON(RECORD_CONTENT):afterState:addressId::VARCHAR,
    PARSE_JSON(RECORD_CONTENT):beforeState:addressId::VARCHAR
    ) = C.ADDRESSID
    WHERE PARSE_JSON(D.RECORD_CONTENT):metadata:time::TIMESTAMP_NTZ < COALESCE(C.EARLIEST_RECORD, '9999-12-31'::TIMESTAMP_NTZ)
)

--Union the 3 datasets to get full historical view with no overlaps of data.
SELECT * FROM {{ source("landing__customer_party_address_service", "CUSTOMER_PARTY_ADDRESS") }}
UNION ALL
SELECT * FROM CTE_ET_DATA
