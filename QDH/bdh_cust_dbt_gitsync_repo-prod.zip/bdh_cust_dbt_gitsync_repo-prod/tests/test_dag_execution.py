import pytest
import sys
import os
from unittest.mock import patch, mock_open
import json

def test_import_party_workplace_link_dag():
    """Test importing and executing party_workplace_link DAG"""
    config_data = json.dumps({
        "raw___bis___bst_cust_wkplce": {
            "load_type": "incremental",
            "days_back": 7,
            "tool_name": "airflow"
        }
    })
    
    with patch('builtins.open', mock_open(read_data=config_data)):
        # Import the module which will execute the code
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "party_workplace_link",
            "dags/cust_lndgtofndn_custmstr_party_workplace_link.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules['party_workplace_link'] = module
        spec.loader.exec_module(module)
        
        # Verify the DAG was created
        assert hasattr(module, 'cust_lndgtofndn_custmstr_party_workplace_link')

def test_import_partycommunication_dag():
    """Test importing and executing partycommunication DAG"""
    config_data = json.dumps({
        "raw___bis___bst_cust_com": {
            "load_type": "incremental",
            "days_back": 5,
            "tool_name": "airflow"
        }
    })
    
    with patch('builtins.open', mock_open(read_data=config_data)):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "partycommunication",
            "dags/cust_lndgtofndn_custmstr_partycommunication.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules['partycommunication'] = module
        spec.loader.exec_module(module)
        
        # Verify the DAG was created
        assert hasattr(module, 'cust_lndgtofndn_custmstr_partycommunication')

def test_import_partycore_dag():
    """Test importing partycore DAG"""
    config_data = json.dumps({
        "raw___bis___bst_cust": {
            "load_type": "incremental",
            "days_back": 5,
            "tool_name": "airflow"
        }
    })
    
    with patch('builtins.open', mock_open(read_data=config_data)):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "partycore",
            "dags/cust_lndgtofndn_custmstr_partycore.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules['partycore'] = module
        spec.loader.exec_module(module)

def test_import_partyentity_dag():
    """Test importing partyentity DAG"""
    config_data = json.dumps({
        "raw___bis___bst_cust_entt": {
            "load_type": "incremental",
            "days_back": 5,
            "tool_name": "airflow"
        }
    })
    
    with patch('builtins.open', mock_open(read_data=config_data)):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "partyentity",
            "dags/cust_lndgtofndn_custmstr_partyentity.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules['partyentity'] = module
        spec.loader.exec_module(module)

def test_import_partyindividual_dag():
    """Test importing partyindividual DAG"""
    config_data = json.dumps({
        "raw___bis___bst_cust_ind": {
            "load_type": "incremental",
            "days_back": 5,
            "tool_name": "airflow"
        }
    })
    
    with patch('builtins.open', mock_open(read_data=config_data)):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "partyindividual",
            "dags/cust_lndgtofndn_custmstr_partyindividual.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules['partyindividual'] = module
        spec.loader.exec_module(module)

def test_import_partyjoint_dag():
    """Test importing partyjoint DAG"""
    config_data = json.dumps({
        "raw___bis___bst_cust_jnt": {
            "load_type": "incremental",
            "days_back": 5,
            "tool_name": "airflow"
        }
    })
    
    with patch('builtins.open', mock_open(read_data=config_data)):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "partyjoint",
            "dags/cust_lndgtofndn_custmstr_partyjoint.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules['partyjoint'] = module
        spec.loader.exec_module(module)

def test_import_partyrelationship_dag():
    """Test importing partyrelationship DAG"""
    config_data = json.dumps({
        "raw___bis___bst_cust_rl": {
            "load_type": "incremental",
            "days_back": 5,
            "tool_name": "airflow"
        }
    })
    
    with patch('builtins.open', mock_open(read_data=config_data)):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "partyrelationship",
            "dags/cust_lndgtofndn_custmstr_partyrelationship.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules['partyrelationship'] = module
        spec.loader.exec_module(module)

def test_import_party_workplace_reference_dag():
    """Test importing party_workplace_reference DAG"""
    config_data = json.dumps({
        "raw___bis___bst_cust_wkplce_ref": {
            "load_type": "incremental",
            "days_back": 5,
            "tool_name": "airflow"
        }
    })
    
    with patch('builtins.open', mock_open(read_data=config_data)):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "party_workplace_reference",
            "dags/cust_lndgtofndn_custmstr_party_workplace_reference.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules['party_workplace_reference'] = module
        spec.loader.exec_module(module)

def test_environment_variables_loaded():
    """Test that environment variables are properly set"""
    assert os.getenv("AIRFLOW_HOME") == "/usr/local/airflow"
    assert os.getenv("IS_AIRFLOW") == "true"
    assert os.getenv("TARGET_NAME") == "DEV"
    assert os.getenv("SCHEMA_NAME") == "TEST"