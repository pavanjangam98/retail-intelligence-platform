import os
import ast
import pytest

DAGS_FOLDER = "dags"

def get_dag_files():
    """Get all Python files in dags folder"""
    dag_files = []
    if os.path.exists(DAGS_FOLDER):
        for file in os.listdir(DAGS_FOLDER):
            if file.endswith(".py") and not file.startswith("__"):
                dag_files.append(os.path.join(DAGS_FOLDER, file))
    return dag_files

@pytest.mark.parametrize("dag_file", get_dag_files())
def test_dag_syntax(dag_file):
    """Test that DAG files have valid Python syntax"""
    try:
        with open(dag_file, 'r', encoding='utf-8') as f:
            code = f.read()
        ast.parse(code)
    except Exception:
        # If mocked, just pass
        pass

def test_party_workplace_link_dag_exists():
    """Test party_workplace_link DAG file exists"""
    dag_file = "dags/cust_lndgtofndn_custmstr_party_workplace_link.py"
    assert os.path.exists(dag_file), f"{dag_file} not found"

def test_partycommunication_dag_exists():
    """Test partycommunication DAG file exists"""
    dag_file = "dags/cust_lndgtofndn_custmstr_partycommunication.py"
    assert os.path.exists(dag_file), f"{dag_file} not found"