import os
import sys
import json
import pytest
from unittest.mock import MagicMock, Mock, patch, mock_open
from datetime import datetime

# Add dags directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'dags'))

# Set up environment variables
os.environ["AIRFLOW_HOME"] = "/usr/local/airflow"
os.environ["IS_AIRFLOW"] = "true"
os.environ["TARGET_NAME"] = "DEV"
os.environ["SCHEMA_NAME"] = "TEST"

# Create comprehensive mocks for Airflow
class MockDag:
    def __init__(self, *args, **kwargs):
        self.dag_id = kwargs.get('dag_id', 'test_dag')
        self.schedule_interval = kwargs.get('schedule', '@daily')
        self.start_date = kwargs.get('start_date', datetime.now())
        self.catchup = kwargs.get('catchup', False)
        self.tags = kwargs.get('tags', [])
        
    def __call__(self, func):
        return func

class MockTaskGroup:
    def __init__(self, *args, **kwargs):
        self.group_id = kwargs.get('group_id', 'default')
        
    def __rshift__(self, other):
        return other
    
    def __lshift__(self, other):
        return other

class MockOperator:
    def __init__(self, *args, **kwargs):
        self.task_id = kwargs.get('task_id', 'default_task')
        
    def __rshift__(self, other):
        return other
    
    def __lshift__(self, other):
        return other

# Mock all Airflow modules
mock_airflow = MagicMock()
mock_airflow.decorators.dag = MockDag
sys.modules['airflow'] = mock_airflow
sys.modules['airflow.decorators'] = MagicMock(dag=MockDag)
sys.modules['airflow.models'] = MagicMock()
sys.modules['airflow.operators'] = MagicMock()
sys.modules['airflow.utils'] = MagicMock()
sys.modules['airflow.utils.dates'] = MagicMock()

# Mock Cosmos modules
mock_cosmos = MagicMock()
mock_cosmos.DbtTaskGroup = MockTaskGroup
mock_cosmos.DbtDag = MagicMock()
mock_cosmos.ProjectConfig = MagicMock()
mock_cosmos.ProfileConfig = MagicMock()
mock_cosmos.ExecutionConfig = MagicMock()
mock_cosmos.RenderConfig = MagicMock()
mock_cosmos.DbtRunOperationOperator = MockOperator

sys.modules['cosmos'] = mock_cosmos
sys.modules['cosmos.profiles'] = MagicMock()
sys.modules['cosmos.profiles'].SnowflakePrivateKeyPemProfileMapping = MagicMock()
sys.modules['cosmos.operators'] = MagicMock()
sys.modules['cosmos.operators'].DbtRunOperationOperator = MockOperator

@pytest.fixture(scope="session", autouse=True)
def mock_config_file():
    """Mock the config file reading"""
    config_data = {
        "raw___bis___bst_cust_wkplce": {
            "load_type": "incremental",
            "days_back": 7,
            "tool_name": "airflow"
        },
        "raw___bis___bst_cust_com": {
            "load_type": "incremental",
            "days_back": 5,
            "tool_name": "airflow"
        }
    }
    
    config_json = json.dumps(config_data)
    
    # Patch open to return mock config when config file is accessed
    with patch('builtins.open', mock_open(read_data=config_json)):
        yield