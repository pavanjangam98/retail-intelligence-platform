from pathlib import Path
import os
import yaml
 
PROJECT_DIR = Path().resolve()
def generate_profiles_yml():
    profile_name = "{{ cookiecutter.project_slug }}"
    profiles_content = {
        profile_name: {
            "outputs": {
                "DEV": {
                    "type": "snowflake",
                    "account": "{{ cookiecutter.snowflake_account }}",
                    "user": "{{ cookiecutter.author_email }}",
                    "role": "{{ cookiecutter.snowflake_role }}",
                    "warehouse": "{{ cookiecutter.snowflake_warehouse }}",
                    "database": "{{ cookiecutter.snowflake_database }}",
                    "schema": "{{ cookiecutter.snowflake_schema }}",
                    "threads": 1,
                    "authenticator": "externalbrowser"
                }
            },
            "target": "DEV",
            "tracking": {"enabled": False}
        }
    }
    with open(PROJECT_DIR / "profiles.yml", "w") as f:
        yaml.dump(profiles_content, f, default_flow_style=False)
def init_git():
    if "{{ cookiecutter.include_git_setup }}".lower() == "yes":
        os.system("git init")
def main():
    generate_profiles_yml()
    init_git()
if __name__ == "__main__":

    main()
 
