
# {{ cookiecutter.project_name }}

{{ cookiecutter.description }}

**Database:** {{ cookiecutter.database_type }}  
**DBT Version:** {{ cookiecutter.dbt_version }}  
**Maintained by:** {{ cookiecutter.author_name }} ({{ cookiecutter.author_email }})

## Project Structure

```
├── models/
│   ├── curated/        
│   ├── foundation/     
│   ├── landing/        
│   └── raw/            
├── macros/             # Reusable SQL macros
├── tests/              # Custom data quality tests
├── snapshots/          # Type-2 slowly changing dimensions
├── analyses/           # Ad-hoc analytical queries
├── seeds/              # CSV reference data
└── dbt_project.yml     # Project configuration
```

## Getting Started

### 1. Install Dependencies

```bash
# Install dbt packages
dbt deps
```

### 2. Configure Profile

Create or update `~/.dbt/profiles.yml` with your connection details:

```yaml
{{ cookiecutter.project_slug }}:
  target: dev
  outputs:
    dev:
      type: {{ cookiecutter.database_type }}
      # Add your connection parameters here
```

Refer to [dbt profiles documentation](https://docs.getdbt.com/docs/core/connect-data-platform/profiles.yml) for your specific database.

### 3. Test Connection

```bash
dbt debug
```

### 4. Run Models

```bash
# Run all models
dbt run

# Run specific models
dbt run --select landing.*
dbt run --select raw.*

# Run with full refresh
dbt run --full-refresh
```

### 5. Test Data Quality

```bash
# Run all tests
dbt test

# Test specific models
dbt test --select staging.*
```

## Documentation

### Generate Documentation

```bash
dbt docs generate
dbt docs serve
```

This will start a local web server at `http://localhost:8080` with your project documentation.

## Development Workflow

### Model Development Process

1. Create staging models for new sources
2. Add schema documentation and tests
3. Build intermediate transformations
4. Create marts (facts/dimensions)
5. Document and test thoroughly
6. Submit PR for review

### Best Practices

- All models must have descriptions
- Add tests for primary keys (unique, not_null)
- Document all columns in schema.yml files
- Use CTEs for readability
- Follow the staging → intermediate → marts pattern
- Use macros for repeated logic

## CI/CD Integration

This project is designed to work with CI/CD pipelines:

```bash
# Run in CI environment
dbt run --target prod
dbt test --target prod
```

## Common Commands

```bash
# Compile SQL without running
dbt compile

# Show compiled SQL
dbt show --select model_name

# Run specific tag
dbt run --select tag:staging

# List all models
dbt list

# Clean target directory
dbt clean

# Run freshness checks
dbt source freshness
```

##  Troubleshooting

### Connection Issues
```bash
dbt debug --config-dir
```

### Performance Issues
- Use `--threads` to control parallelization
- Add indexes in your data warehouse
- Use incremental materializations

### Failed Tests
```bash
# Run with detailed logs
dbt test --debug
```

## Resources

- [dbt Documentation](https://docs.getdbt.com/)
- [dbt Discourse](https://discourse.getdbt.com/)
- [dbt Slack Community](https://www.getdbt.com/community/)

## Support

For questions or issues, contact {{ cookiecutter.author_name }} at {{ cookiecutter.author_email }}
