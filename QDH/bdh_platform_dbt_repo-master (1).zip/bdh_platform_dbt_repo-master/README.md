# BDH Platform Repository
 
## Overview
This repository serves as the central platform for dbt (data build tool) development, providing reusable components and standardized project templates. It contains two main components:
1. **bdh_platform_dbt** - A library of reusable dbt macros and artifacts
2. **cookiecutter** - A project template generator for creating new dbt projects
## Repository Structure
```

platform-repo/
├── bdh_platform_dbt/          # Reusable macros and artifacts
│   ├── macros/                # Custom dbt macros
│   ├── models/                # Reference models (if any)
│   └── ...
├── cookiecutter/              # Cookiecutter template for new projects
│   ├── {{cookiecutter.project_name}}/
│   └── cookiecutter.json
└── README.md                  # This file
```
---
 
## bdh_platform_dbt
The `bdh_platform_dbt` folder contains a centralized collection of reusable dbt macros and artifacts that can be imported into any dbt project. This promotes code reusability, consistency, and best practices across all projects.
 
### Purpose
- Provides reusable dbt macros for common transformations
- Contains artifacts and templates for standardization
- Ensures consistency across all dbt projects
- Reduces code duplication
 
### Available Components
- **Macros**: Custom Jinja macros for common transformations and utilities
- **Artifacts**: Reusable model configurations and templates
- **Utilities**: Helper functions for data quality, testing, and documentation

### How to Import Macros
 
#### Option 1: Using dbt Packages (Recommended)
Add the following to your project's `packages.yml`:
```yaml
packages:
  - local: ../bdh_platform_dbt  # Adjust path relative to your project

```
Then run:
```bash
dbt deps
```
 
#### Option 2: Direct Path Reference
If you're using git submodules or have the platform repo cloned alongside your project:
```yaml

packages:
  - git: "https://your-git-url/platform-repo.git"
    subdirectory: "bdh_platform_dbt"
    revision: main  # or specific tag/branch
```
 
### Usage Example
 
Once imported, you can use any macro from the platform:
```sql
-- In your dbt model
{{ bdh_platform.macro_name(parameters) }}
```
### Available Macros
 
| Macro Name | Description | Parameters |
|------------|-------------|------------|
| `generate_schema_name` | Custom schema naming logic | `custom_schema_name`, `node` |
| `audit_columns` | Adds standard audit columns | None |
| `date_spine` | Generates a date dimension | `start_date`, `end_date` |
| *Add more macros as applicable* | | |
 
---
 
## Cookiecutter Template
The `cookiecutter` folder contains a template for quickly scaffolding new dbt projects with a standardized structure, configurations, and best practices built-in.
 
### Purpose
- Quickly create new dbt projects with standardized structure
- Include best practices and configurations out-of-the-box
- Ensure consistency across all new projects
- Reduce setup time for new dbt projects
 
### Prerequisites
 
- Python 3.7 or higher
- Cookiecutter installed
Install cookiecutter if you haven't already:
 
```bash
pip install cookiecutter
```
 
### Creating a New Project
Navigate to the directory where you want to create your new project and run:
```bash
cookiecutter path/to/platform-repo/cookiecutter
``` 
Or if using from a git repository:
```bash
cookiecutter https://your-git-url/platform-repo.git --directory="cookiecutter"
```
 
### Configuration Prompts
 
You'll be prompted to provide the following information:

- **project_name**: Name of your dbt project
- **project_slug**: URL-friendly version (auto-generated)
- **description**: Brief description of the project
- **author_name**: Your name or team name
- **database_name**: Target database name
- **schema_name**: Default schema name
 
### Generated Project Structure
The cookiecutter template will create:
```
your-new-project/

├── dbt_project.yml
├── packages.yml              # Pre-configured with bdh_platform_dbt
├── models/
│   ├── curated/
│   ├── foundation/
│   ├── landing/
│   └── raw/
├── macros/
├── tests/
├── snapshots/
├── analyses/
├── seeds/
└── README.md
``` 
---
 
## Getting Started
 
### For New Projects
1. Use the cookiecutter template to create a new project structure
2. The generated project will automatically include references to `bdh_platform_dbt` macros
3. Run `dbt deps` to install dependencies
4. Configure your `profiles.yml` for your data warehouse connection
5. Start building models!
### For Existing Projects
1. Add `bdh_platform_dbt` to your `packages.yml` file
2. Run `dbt deps` to import the macros
3. Reference platform macros in your models as needed
---
 
## Contributing
 
### Adding New Macros to bdh_platform_dbt
1. Create your macro in the appropriate subfolder under `bdh_platform_dbt/macros/`
2. Document the macro with clear comments including:
   - Purpose
   - Parameters
   - Return value
   - Usage examples
3. Update the "Available Macros" table in this README
4. Test the macro in a sample project
5. Submit a pull request for review
 
### Updating the Cookiecutter Template
1. Make changes to the template structure in `cookiecutter/{{cookiecutter.project_name}}/`
2. Update `cookiecutter.json` if adding new prompts
3. Test by generating a new project
4. Document any changes in this README
5. Submit a pull request for review
---
 
## Best Practices
 
### Using Platform Macros 
- Always import the latest version of `bdh_platform_dbt` macros
- Follow the naming conventions established in the platform
- Document any custom macros you create
 
### Project Structure
- Keep your project structure aligned with the cookiecutter template
- Use the standard folder organization (staging, intermediate, marts)
- Run `dbt deps` after pulling updates to the platform repository
---
 
## Support & Contact
 
### Getting Help
 
For questions, issues, or contributions:
- **Email**: [your-team-email@company.com]
- **Slack Channel**: #data-engineering
- **Documentation**: [Link to your internal documentation]
- **Issues**: [Link to issue tracker if applicable]
---
 

 
