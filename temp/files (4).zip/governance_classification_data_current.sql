{{
    config(
        schema      = 'governance_classification',
        materialized= 'view'
    )
}}

/*
    Current-record view on top of the SCD2 history table.

    Returns exactly ONE active row per classification_id — the most
    recently opened, non-deleted version.

    Filter logic:
      1. is_active = 'Y'                   → open / non-expired rows only
      2. dwh_change_type in ('NEW','CHANGED')→ exclude rows that never changed
                                              (pure pass-through unchanged rows)
      3. is_src_deleted is not true         → exclude soft-deleted source records
                                              (cast-safe: handles both BOOLEAN
                                               and VARCHAR 'Y'/'TRUE'/'1' values)

    Point-in-time queries (closed-open interval pattern — FIX [6]):
      For historical lookups use the history table directly:
        WHERE dwh_effective_from_tstamp <= <as_of_ts>
          AND dwh_effective_to_tstamp   >  <as_of_ts>
*/

select
    dbt_scd_id,
    classification_id,
    db_name,
    schema_name,
    table_name,
    column_name,
    security_classification_code,
    source_system,
    zone_name,
    env_name,
    is_business_key,
    is_primary_key,
    is_src_deleted,
    source_ds_update,
    dwh_effective_from_tstamp,
    dwh_effective_to_tstamp,
    dwh_change_type,
    dwh_attribute_hash,
    is_active,
    dwh_process_tstamp

from {{ ref('governance_classification___governance_classification_data_history') }}

where
    -- 1. only currently open rows
    is_active = 'Y'

    -- 2. exclude pass-through unchanged records
    and dwh_change_type in ('NEW', 'CHANGED')

    -- 3. exclude soft-deleted source columns
    --    handles BOOLEAN true and VARCHAR 'Y' / 'TRUE' / '1' defensively
    and not (
            try_cast(is_src_deleted as boolean) = true
        or  upper(cast(is_src_deleted as varchar)) in ('Y', 'YES', 'TRUE', '1')
    )
