"""
snowflake_bulk_ingestion.py
===========================
Airflow DAG — Snowflake Bulk Ingestion Framework

WHAT THIS FILE DOES
-------------------
This file ONLY orchestrates. It contains no SQL and no data logic.
All the real work is in the helper classes under plugins/ingestion/.

    get_configs         → reads INGEST_CONFIG from Snowflake
    validate_table      → dry-run COPY check before loading
    load_table          → runs the actual COPY INTO
    send_summary_email  → emails a completion table after all tasks finish

Each table from INGEST_CONFIG becomes its own independent Airflow task
via .expand() (dynamic task mapping). They all run in parallel.

TO ADD A NEW TABLE
------------------
INSERT a row into INGEST_CONFIG. No code change needed.

    INSERT INTO INGEST_CONFIG (TABLE_NAME, STAGE_NAME, FILE_FORMAT, LOAD_MODE)
    VALUES ('MY_TABLE', '@RAW.MY_STAGE', 'CSV_FORMAT', 'APPEND');

TO ADD CDC / MERGE
------------------
Open plugins/ingestion/snowflake_loader.py and implement the
_merge_load() method that is already stubbed there. Then set
LOAD_MODE = 'MERGE' for the relevant tables in INGEST_CONFIG.

WHERE TO LOOK WHEN SOMETHING FAILS
-----------------------------------
1. Airflow UI  → task log → look for [Loader] FAILURE or [AuditLogger] FAILURE
2. Snowflake   → SELECT * FROM V_OPEN_ERRORS;
3. Snowflake   → SELECT * FROM ETL_COPY_RESULTS WHERE RUN_ID = '<id>';
   (run_id is printed in the Airflow task log at the start of load_table)
"""

import logging
import uuid
from datetime import datetime, timedelta

from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
from airflow.utils.email import send_email

# Helper classes — each one owns one responsibility
from ingestion import AuditLogger, SnowflakeLoader, CopyResultsWriter

log = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Config — change these in Airflow UI: Admin → Variables
# ─────────────────────────────────────────────────────────────────────────────
SNOWFLAKE_CONN_ID = Variable.get("SNOWFLAKE_CONN_ID",  default_var="snowflake_default")
ALERT_EMAIL       = Variable.get("ALERT_EMAIL",         default_var="")
ENABLE_VALIDATION = Variable.get("ENABLE_VALIDATION",   default_var="true").lower() == "true"

DEFAULT_ARGS = {
    "owner"                    : "data-engineering",
    "depends_on_past"          : False,
    "email"                    : [ALERT_EMAIL] if ALERT_EMAIL else [],
    "email_on_failure"         : bool(ALERT_EMAIL),
    "email_on_retry"           : False,
    "retries"                  : 3,
    "retry_delay"              : timedelta(minutes=5),
    "retry_exponential_backoff": True,  # retries at 5m, 10m, 20m
}


# ─────────────────────────────────────────────────────────────────────────────
# DAG
# ─────────────────────────────────────────────────────────────────────────────
@dag(
    dag_id         = "snowflake_bulk_ingestion",
    description    = "Metadata-driven Snowflake bulk ingestion",
    schedule       = "@daily",
    start_date     = datetime(2025, 1, 1),
    catchup        = False,
    default_args   = DEFAULT_ARGS,
    max_active_runs= 1,
    tags           = ["snowflake", "ingestion", "etl"],
)
def snowflake_bulk_ingestion():

    # ──────────────────────────────────────────────────────────────────
    # TASK 1: get_configs
    #
    # Reads all IS_ACTIVE=TRUE rows from INGEST_CONFIG and returns
    # them as a list of plain Python dicts.
    #
    # Airflow passes this list to validate_table.expand(config=...)
    # which fans it out into N parallel tasks — one per table.
    # ──────────────────────────────────────────────────────────────────
    @task
    def get_configs(**context) -> list[dict]:
        hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
        records = hook.get_records("""
            SELECT
                TABLE_NAME,
                STAGE_NAME,
                FILE_FORMAT,
                COALESCE(FILE_PATTERN,  '.*')      AS FILE_PATTERN,
                COALESCE(TARGET_SCHEMA, 'PUBLIC')   AS TARGET_SCHEMA,
                COALESCE(LOAD_MODE,     'APPEND')   AS LOAD_MODE
            FROM INGEST_CONFIG
            WHERE IS_ACTIVE = TRUE
            ORDER BY COALESCE(PRIORITY, 100) ASC, TABLE_NAME ASC
        """)

        if not records:
            log.warning("[get_configs] No active rows in INGEST_CONFIG — nothing to load.")
            return []

        configs = [
            {
                "table_name"    : r[0],
                "stage_name"    : r[1],
                "file_format"   : r[2],
                "file_pattern"  : r[3],
                "target_schema" : r[4],
                "load_mode"     : r[5],
                # Pass Airflow context so ETL_AUDIT links back to the Airflow run
                "airflow_run_id": context["run_id"],
                "dag_id"        : context["dag"].dag_id,
            }
            for r in records
        ]

        log.info("[get_configs] Found %d active table(s): %s",
                 len(configs), [c["table_name"] for c in configs])
        return configs

    # ──────────────────────────────────────────────────────────────────
    # TASK 2: validate_table
    #
    # Runs COPY INTO with VALIDATION_MODE = RETURN_ERRORS.
    # This does NOT load any data — it checks whether Snowflake can
    # parse the files without format errors.
    #
    # Think of it as a compiler check before the actual run.
    # Catches "wrong delimiter" or "missing column" before you find
    # out mid-load that half the files are unreadable.
    #
    # Returns the config dict unchanged so load_table receives it next.
    # ──────────────────────────────────────────────────────────────────
    @task
    def validate_table(config: dict) -> dict:
        if not ENABLE_VALIDATION:
            log.info("[validate_table] Validation disabled — skipping table=%s",
                     config["table_name"])
            return config

        table_name   = config["table_name"]
        target_schema= config["target_schema"]
        stage_name   = config["stage_name"]
        file_format  = config["file_format"]
        file_pattern = config.get("file_pattern", ".*")

        log.info("[validate_table] Dry-run check: table=%s stage=%s",
                 table_name, stage_name)

        hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)

        try:
            error_rows = hook.get_records(f"""
                COPY INTO {target_schema}.{table_name}
                FROM   {stage_name}
                FILE_FORMAT          = (FORMAT_NAME = {file_format})
                PATTERN              = '{file_pattern}'
                MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
                VALIDATION_MODE      = RETURN_ERRORS
            """)
        except Exception as exc:
            # Snowflake raises when RETURN_ERRORS finds errors — this is expected
            raise ValueError(
                f"Validation failed for table={table_name}. "
                f"Fix files in stage {stage_name} before loading. "
                f"Original error: {exc}"
            )

        if error_rows:
            raise ValueError(
                f"Validation found {len(error_rows)} error(s) for table={table_name}. "
                f"Fix files in stage {stage_name} and re-trigger the DAG."
            )

        log.info("[validate_table] Passed — no errors found for table=%s", table_name)
        return config

    # ──────────────────────────────────────────────────────────────────
    # TASK 3: load_table
    #
    # The actual data load. This task:
    #   1. Generates a unique run_id (printed in the log — copy it for SQL)
    #   2. Records STARTED in ETL_AUDIT
    #   3. Calls SnowflakeLoader.load() — dispatches by load_mode
    #   4. Saves per-file COPY results to ETL_COPY_RESULTS
    #   5a. On success → update ETL_AUDIT to SUCCESS
    #   5b. On failure → write ETL_ERROR_LOG + update ETL_AUDIT to FAILED
    #
    # If it fails, Airflow retries up to 3 times with exponential back-off.
    # The run_id in ETL_AUDIT will show all retry attempts.
    # ──────────────────────────────────────────────────────────────────
    @task
    def load_table(config: dict) -> None:
        run_id     = str(uuid.uuid4())
        table_name = config["table_name"]

        # Print run_id at the very start so you can query ETL tables immediately
        log.info("=" * 60)
        log.info("[load_table] START  table=%s  run_id=%s", table_name, run_id)
        log.info("[load_table]        mode=%s  stage=%s",
                 config.get("load_mode"), config.get("stage_name"))
        log.info("=" * 60)

        # One shared hook for the entire task — one connection, all writes
        hook   = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
        logger = AuditLogger(hook, run_id, config)
        loader = SnowflakeLoader(hook)
        writer = CopyResultsWriter(hook)

        logger.start()   # always do this first

        try:
            # Run COPY INTO (dispatches to APPEND or TRUNCATE_LOAD or future CDC)
            result = loader.load(config)

            # Save per-file details (useful for debugging partial loads)
            writer.write(run_id, table_name, result.file_results)

            # Record success
            logger.success(
                rows_loaded  = result.total_rows_loaded,
                files_loaded = result.total_files_loaded,
                bytes_loaded = result.bytes_loaded,
            )

            if result.had_file_errors:
                # Some files loaded, some failed — log a warning but don't fail the task
                # (ON_ERROR=CONTINUE means Snowflake skips bad files, not the task)
                log.warning(
                    "[load_table] Partial load: files_ok=%d  files_failed=%d  rows=%d",
                    result.total_files_loaded, result.total_files_failed,
                    result.total_rows_loaded
                )
            else:
                log.info(
                    "[load_table] SUCCESS  files=%d  rows=%d",
                    result.total_files_loaded, result.total_rows_loaded
                )

        except Exception as exc:
            logger.failure(exc)     # writes ETL_ERROR_LOG + marks FAILED in ETL_AUDIT
            log.error("[load_table] FAILED  table=%s  run_id=%s", table_name, run_id)
            raise                   # Airflow sees the failure and schedules retry

    # ──────────────────────────────────────────────────────────────────
    # TASK 4: send_summary_email
    #
    # trigger_rule="all_done" means this runs even if some load tasks
    # failed — you still get the summary so you know which tables to fix.
    # ──────────────────────────────────────────────────────────────────
    @task(trigger_rule="all_done")
    def send_summary_email(**context) -> None:
        if not ALERT_EMAIL:
            return

        airflow_run_id = context["run_id"]
        hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)

        rows = hook.get_records(f"""
            SELECT TABLE_NAME, STATUS, ROWS_LOADED, DURATION_SECS, ERROR_MESSAGE
            FROM   ETL_AUDIT
            WHERE  AIRFLOW_RUN_ID = '{airflow_run_id}'
            ORDER  BY STATUS, TABLE_NAME
        """)

        table_rows = ""
        for r in rows:
            tbl, status, loaded, dur, err = r
            color = "var(--color-text-success)" if status == "SUCCESS" else "var(--color-text-danger)"
            table_rows += (
                f"<tr>"
                f"<td>{tbl}</td>"
                f"<td style='color:{color};font-weight:500'>{status}</td>"
                f"<td>{loaded or 0:,}</td>"
                f"<td>{dur or '—'}s</td>"
                f"<td style='color:#c62828'>{(err or '')[:150]}</td>"
                f"</tr>"
            )

        run_date = context["logical_date"].strftime("%Y-%m-%d")
        html = f"""
        <h2 style='font-family:sans-serif'>Snowflake Ingestion — {run_date}</h2>
        <p style='font-family:sans-serif;color:#555'>
            Airflow run ID: <code>{airflow_run_id}</code>
        </p>
        <table border='1' cellpadding='8' cellspacing='0'
               style='border-collapse:collapse;font-family:sans-serif;font-size:14px'>
            <thead style='background:#f5f5f5'>
                <tr><th>Table</th><th>Status</th><th>Rows</th><th>Duration</th><th>Error</th></tr>
            </thead>
            <tbody>{table_rows}</tbody>
        </table>
        <p style='font-family:sans-serif;font-size:12px;color:#888;margin-top:16px'>
            Debug: Snowflake → ETL_AUDIT, ETL_ERROR_LOG, ETL_COPY_RESULTS
        </p>
        """

        send_email(
            to           = ALERT_EMAIL,
            subject      = f"[Snowflake Ingestion] {run_date} batch summary",
            html_content = html,
        )

    # ── Wire the tasks together ────────────────────────────────────────
    configs   = get_configs()
    validated = validate_table.expand(config=configs)    # N tasks in parallel
    loaded    = load_table.expand(config=validated)      # N tasks in parallel
    loaded >> send_summary_email()


dag = snowflake_bulk_ingestion()
