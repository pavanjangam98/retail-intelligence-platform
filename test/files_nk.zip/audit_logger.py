"""
audit_logger.py
===============
Handles every write to ETL_AUDIT and ETL_ERROR_LOG.

WHY THIS EXISTS AS A SEPARATE FILE
-----------------------------------
In the original single-file DAG, audit SQL was mixed inside the load
logic. When an audit write failed, it was hard to tell if the load had
failed or just the audit update.

By putting all audit writes here:
  - The DAG task only calls  logger.start() / logger.success() / logger.failure()
  - All SQL for audit tables lives in one place
  - Unit tests can verify audit behaviour without touching load logic
  - If you change the ETL_AUDIT schema, you only change this file

USAGE IN A DAG TASK
-------------------
    hook   = SnowflakeHook(snowflake_conn_id="snowflake_default")
    logger = AuditLogger(hook, run_id="abc-123", config=config)

    logger.start()          # inserts STARTED row — call this FIRST
    try:
        ... do your work ...
        logger.success(rows_loaded=5000, files_loaded=3)
    except Exception as e:
        logger.failure(e)   # writes error log + marks FAILED
        raise               # re-raise so Airflow retries the task
"""

import logging
import traceback

log = logging.getLogger(__name__)


class AuditLogger:

    def __init__(self, hook, run_id: str, config: dict):
        """
        Parameters
        ----------
        hook    : SnowflakeHook — already instantiated, reuse the same connection
        run_id  : str           — unique UUID for this task run (generated in DAG)
        config  : dict          — the row from INGEST_CONFIG for this table
        """
        self.hook           = hook
        self.run_id         = run_id
        self.table_name     = config["table_name"]
        self.stage_name     = config["stage_name"]
        self.file_format    = config["file_format"]
        self.load_mode      = config.get("load_mode", "APPEND")
        self.airflow_run_id = config.get("airflow_run_id", "")
        self.dag_id         = config.get("dag_id", "")

    # ──────────────────────────────────────────────────────────────────
    # Public API  (these are the only methods the DAG should call)
    # ──────────────────────────────────────────────────────────────────

    def start(self):
        """
        Insert a STARTED row into ETL_AUDIT.
        Always call this first so the run is visible even if it crashes.
        """
        log.info("[AuditLogger] START  table=%s  run_id=%s", self.table_name, self.run_id)
        self.hook.run(f"""
            INSERT INTO ETL_AUDIT
                (RUN_ID, AIRFLOW_RUN_ID, DAG_ID,
                 TABLE_NAME, STAGE_NAME, FILE_FORMAT, LOAD_MODE,
                 START_TIME, STATUS)
            VALUES
                ('{self._esc(self.run_id)}',
                 '{self._esc(self.airflow_run_id)}',
                 '{self._esc(self.dag_id)}',
                 '{self._esc(self.table_name)}',
                 '{self._esc(self.stage_name)}',
                 '{self._esc(self.file_format)}',
                 '{self._esc(self.load_mode)}',
                 CURRENT_TIMESTAMP(),
                 'STARTED')
        """)

    def success(self, rows_loaded: int = 0, files_loaded: int = 0, bytes_loaded: int = 0):
        """Update the ETL_AUDIT row to SUCCESS and record counts."""
        log.info("[AuditLogger] SUCCESS table=%s  rows=%d", self.table_name, rows_loaded)
        self.hook.run(f"""
            UPDATE ETL_AUDIT
            SET
                END_TIME     = CURRENT_TIMESTAMP(),
                STATUS       = 'SUCCESS',
                ROWS_LOADED  = {rows_loaded},
                FILES_LOADED = {files_loaded},
                BYTES_LOADED = {bytes_loaded}
            WHERE RUN_ID = '{self._esc(self.run_id)}'
        """)

    def failure(self, exc: Exception):
        """
        1. Write full error details to ETL_ERROR_LOG
        2. Update ETL_AUDIT to FAILED

        Call this before re-raising so the error is captured even if
        Airflow marks the task as failed before the except block finishes.

        Note: this method never raises — it silently logs if the audit
        writes themselves fail, so the original exception is always visible.
        """
        error_msg  = self._esc(str(exc))
        error_type = self._esc(type(exc).__name__)
        stack      = self._esc(traceback.format_exc())

        log.error("[AuditLogger] FAILURE table=%s  error=%s", self.table_name, str(exc)[:300])

        # Write error log first (most important)
        try:
            self.hook.run(f"""
                INSERT INTO ETL_ERROR_LOG
                    (RUN_ID, AIRFLOW_RUN_ID, DAG_ID,
                     TABLE_NAME, STAGE_NAME,
                     ERROR_TYPE, ERROR_MESSAGE, STACK_TRACE)
                VALUES
                    ('{self._esc(self.run_id)}',
                     '{self._esc(self.airflow_run_id)}',
                     '{self._esc(self.dag_id)}',
                     '{self._esc(self.table_name)}',
                     '{self._esc(self.stage_name)}',
                     '{error_type}',
                     '{error_msg}',
                     '{stack}')
            """)
        except Exception as inner:
            # Never let an audit failure hide the original load error
            log.error("[AuditLogger] Could not write ETL_ERROR_LOG: %s", inner)

        # Update audit row to FAILED
        try:
            self.hook.run(f"""
                UPDATE ETL_AUDIT
                SET
                    END_TIME      = CURRENT_TIMESTAMP(),
                    STATUS        = 'FAILED',
                    ERROR_MESSAGE = '{error_msg}'
                WHERE RUN_ID = '{self._esc(self.run_id)}'
            """)
        except Exception as inner:
            log.error("[AuditLogger] Could not update ETL_AUDIT to FAILED: %s", inner)

    # ──────────────────────────────────────────────────────────────────
    # Private helpers
    # ──────────────────────────────────────────────────────────────────

    @staticmethod
    def _esc(value: str) -> str:
        """
        Escape single quotes so they don't break SQL string literals.
        Values come from internal config tables, not user input, so this
        is defensive rather than a security control.
        """
        return str(value).replace("'", "''")
