"""
tests/test_helpers.py
=====================
Unit tests for AuditLogger, SnowflakeLoader, and CopyResultsWriter.

These tests run WITHOUT a real Airflow or Snowflake connection.
The Snowflake hook is replaced with a mock that records which SQL
was passed to it — then assertions check the SQL content.

Run:
    pytest tests/test_helpers.py -v

Why unit tests matter for beginners:
- You can prove a bug is fixed without running the whole DAG
- You can understand what each helper class does by reading the test
- They catch regressions when you add CDC logic later
"""

import sys
import os
import pytest
from unittest.mock import MagicMock

# Add the plugins folder to Python path so imports work
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../plugins"))

from ingestion.audit_logger import AuditLogger
from ingestion.snowflake_loader import SnowflakeLoader, FileResult
from ingestion.copy_results_writer import CopyResultsWriter


# ─────────────────────────────────────────────────────────────────────────────
# Shared test fixtures
# ─────────────────────────────────────────────────────────────────────────────

def make_config(**overrides) -> dict:
    """Minimal valid config dict. Override any field via kwargs."""
    base = {
        "table_name"    : "CUSTOMER",
        "stage_name"    : "@RAW.CUSTOMER_STAGE",
        "file_format"   : "CSV_FORMAT",
        "file_pattern"  : ".*\\.csv",
        "target_schema" : "PUBLIC",
        "load_mode"     : "APPEND",
        "airflow_run_id": "manual__2025-01-01",
        "dag_id"        : "snowflake_bulk_ingestion",
    }
    base.update(overrides)
    return base


def make_hook() -> MagicMock:
    """
    A fake SnowflakeHook.
    - hook.run(sql)            → records the call, returns None
    - hook.get_records(sql)    → returns [] by default
    """
    hook = MagicMock()
    hook.run.return_value         = None
    hook.get_records.return_value = []
    return hook


# ─────────────────────────────────────────────────────────────────────────────
# AuditLogger
# ─────────────────────────────────────────────────────────────────────────────

class TestAuditLogger:

    def test_start_inserts_started_row(self):
        """start() must INSERT a row with STATUS='STARTED'."""
        hook   = make_hook()
        logger = AuditLogger(hook, "run-001", make_config())
        logger.start()

        hook.run.assert_called_once()
        sql = hook.run.call_args[0][0]
        assert "ETL_AUDIT" in sql
        assert "STARTED"   in sql
        assert "CUSTOMER"  in sql
        assert "run-001"   in sql

    def test_success_updates_to_success(self):
        """success() must UPDATE ETL_AUDIT to STATUS='SUCCESS' with row counts."""
        hook   = make_hook()
        logger = AuditLogger(hook, "run-001", make_config())
        logger.success(rows_loaded=9999, files_loaded=2)

        sql = hook.run.call_args[0][0]
        assert "UPDATE ETL_AUDIT" in sql
        assert "SUCCESS"          in sql
        assert "9999"             in sql

    def test_failure_writes_error_log_then_updates_audit(self):
        """
        failure() must:
        1. INSERT into ETL_ERROR_LOG (first call)
        2. UPDATE ETL_AUDIT to FAILED (second call)
        """
        hook   = make_hook()
        logger = AuditLogger(hook, "run-001", make_config())
        logger.failure(ValueError("bad column type"))

        assert hook.run.call_count == 2
        first_sql  = hook.run.call_args_list[0][0][0]
        second_sql = hook.run.call_args_list[1][0][0]

        assert "ETL_ERROR_LOG"   in first_sql
        assert "bad column type" in first_sql
        assert "FAILED"          in second_sql

    def test_single_quotes_in_error_are_escaped(self):
        """A quote in the error message must not break the SQL INSERT."""
        hook   = make_hook()
        logger = AuditLogger(hook, "run-001", make_config())
        logger.failure(ValueError("it's a bad value"))

        sql = hook.run.call_args_list[0][0][0]
        assert "it''s a bad value" in sql    # double-quoted → safe SQL

    def test_failure_in_audit_write_does_not_hide_original_error(self):
        """
        If the ETL_ERROR_LOG INSERT itself fails (e.g. Snowflake is down),
        failure() must silently swallow that inner error — NOT raise it.
        The caller re-raises the original exception after calling failure().
        """
        hook = make_hook()
        hook.run.side_effect = [Exception("connection lost"), None]
        logger = AuditLogger(hook, "run-001", make_config())
        logger.failure(ValueError("original load error"))   # must not raise


# ─────────────────────────────────────────────────────────────────────────────
# SnowflakeLoader
# ─────────────────────────────────────────────────────────────────────────────

class TestSnowflakeLoader:

    # ── Load mode dispatch ─────────────────────────────────────────

    def test_append_does_not_call_truncate(self):
        """APPEND mode must never call TRUNCATE TABLE."""
        hook   = make_hook()
        hook.get_records.return_value = []   # empty stage
        SnowflakeLoader(hook).load(make_config(load_mode="APPEND"))

        hook.run.assert_not_called()         # no TRUNCATE

    def test_truncate_load_truncates_before_copy(self):
        """TRUNCATE_LOAD must call TRUNCATE TABLE before COPY INTO."""
        hook   = make_hook()
        hook.get_records.return_value = []
        SnowflakeLoader(hook).load(make_config(load_mode="TRUNCATE_LOAD"))

        hook.run.assert_called_once()
        assert "TRUNCATE TABLE" in hook.run.call_args[0][0]

    def test_unknown_mode_raises_valueerror(self):
        """An unrecognised load_mode must raise ValueError immediately."""
        hook = make_hook()
        with pytest.raises(ValueError, match="Unknown load_mode"):
            SnowflakeLoader(hook).load(make_config(load_mode="MAGIC"))

    # ── COPY SQL contents ──────────────────────────────────────────

    def test_copy_sql_has_all_required_clauses(self):
        """COPY INTO must include all critical clauses."""
        hook   = make_hook()
        hook.get_records.return_value = []
        SnowflakeLoader(hook).load(make_config())

        sql = hook.get_records.call_args[0][0]
        assert "COPY INTO"              in sql
        assert "PUBLIC.CUSTOMER"        in sql
        assert "@RAW.CUSTOMER_STAGE"    in sql
        assert "CSV_FORMAT"             in sql
        assert "MATCH_BY_COLUMN_NAME"   in sql
        assert "ON_ERROR"               in sql

    # ── Result parsing ─────────────────────────────────────────────

    def test_two_loaded_files_rows_are_summed(self):
        """rows and file counts must sum across all LOADED files."""
        hook   = make_hook()
        hook.get_records.return_value = [
            ("file1.csv", "LOADED", 1000, 1000, 0, 0, None, None, None, None),
            ("file2.csv", "LOADED",  500,  500, 0, 0, None, None, None, None),
        ]
        result = SnowflakeLoader(hook).load(make_config())

        assert result.total_rows_loaded  == 1500
        assert result.total_files_loaded == 2
        assert result.total_files_failed == 0
        assert result.had_file_errors    is False

    def test_failed_file_counted_separately(self):
        """A LOAD_FAILED file must increment total_files_failed, not total_files_loaded."""
        hook   = make_hook()
        hook.get_records.return_value = [
            ("file1.csv", "LOADED",      1000, 1000, 0,  0, None,        None, None, None),
            ("file2.csv", "LOAD_FAILED",  500,    0, 0, 10, "bad column", 5,    3,   "ID"),
        ]
        result = SnowflakeLoader(hook).load(make_config())

        assert result.total_files_loaded == 1
        assert result.total_files_failed == 1
        assert result.had_file_errors    is True

    def test_empty_stage_returns_zero_result(self):
        """An empty stage (no files) must return a zero LoadResult, not crash."""
        hook   = make_hook()
        hook.get_records.return_value = []
        result = SnowflakeLoader(hook).load(make_config())

        assert result.total_rows_loaded  == 0
        assert result.total_files_loaded == 0

    def test_short_result_row_does_not_crash(self):
        """
        Older Snowflake connector versions may return fewer columns.
        The parser must handle short rows gracefully.
        """
        hook   = make_hook()
        hook.get_records.return_value = [("file.csv", "LOADED", 100, 100)]  # only 4 cols
        result = SnowflakeLoader(hook).load(make_config())                   # must not raise

        assert result.total_rows_loaded == 100


# ─────────────────────────────────────────────────────────────────────────────
# CopyResultsWriter
# ─────────────────────────────────────────────────────────────────────────────

class TestCopyResultsWriter:

    def test_writes_all_file_results_in_one_call(self):
        """All FileResult rows must be inserted in a single SQL call."""
        hook = make_hook()
        file_results = [
            FileResult(file_name="a.csv", status="LOADED",      rows_parsed=100, rows_loaded=100),
            FileResult(file_name="b.csv", status="LOAD_FAILED",  rows_parsed=50,  rows_loaded=0),
        ]
        CopyResultsWriter(hook).write("run-001", "CUSTOMER", file_results)

        hook.run.assert_called_once()
        sql = hook.run.call_args[0][0]
        assert "ETL_COPY_RESULTS" in sql
        assert "a.csv"            in sql
        assert "b.csv"            in sql

    def test_empty_results_skips_write(self):
        """No SQL should be executed if file_results is empty."""
        hook = make_hook()
        CopyResultsWriter(hook).write("run-001", "CUSTOMER", [])
        hook.run.assert_not_called()

    def test_long_error_message_is_trimmed(self):
        """first_error longer than 2000 chars must be trimmed before INSERT."""
        hook = make_hook()
        fr   = FileResult(
            file_name="x.csv", status="LOAD_FAILED",
            rows_parsed=0, rows_loaded=0,
            first_error="x" * 5000   # 5000 chars — too long
        )
        CopyResultsWriter(hook).write("run-001", "CUSTOMER", [fr])

        sql = hook.run.call_args[0][0]
        assert "x" * 2001 not in sql    # trimmed to 2000
