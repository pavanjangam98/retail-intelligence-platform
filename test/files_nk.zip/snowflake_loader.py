"""
snowflake_loader.py
===================
Owns ALL the COPY INTO logic and result parsing.

WHY THIS EXISTS AS A SEPARATE FILE
-----------------------------------
COPY INTO returns a result set (one row per file). Parsing that result
set and deciding what counts as success vs partial failure is real logic
that deserves its own home. Burying it inside a DAG task makes it hard
to test and hard to change.

HOW TO USE
----------
    loader = SnowflakeLoader(hook)
    result = loader.load(config)   # dispatches by config["load_mode"]

    print(result.total_rows_loaded)   # 5000
    print(result.total_files_loaded)  # 3
    print(result.had_file_errors)     # False

HOW TO ADD CDC / MERGE (future)
--------------------------------
1. Add your method below the "FUTURE CDC METHODS" comment block.
2. Add the new load_mode string to the dispatch table in load().
3. Set LOAD_MODE = 'MERGE' for any table in INGEST_CONFIG.
No DAG changes needed.
"""

import logging
from dataclasses import dataclass, field
from typing import List, Optional

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Data classes for COPY results — typed so IDE autocomplete works
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class FileResult:
    """
    One row from the COPY INTO result set.
    Snowflake returns one of these per file in the stage.
    """
    file_name    : str
    status       : str          # LOADED | LOAD_FAILED | PARTIALLY_LOADED
    rows_parsed  : int  = 0
    rows_loaded  : int  = 0
    errors_seen  : int  = 0
    first_error  : str  = ""    # e.g. "Field delimiter not found"
    error_line   : Optional[int] = None   # line number in the file
    error_char   : Optional[int] = None   # character position
    error_column : str  = ""    # column name that caused the error


@dataclass
class LoadResult:
    """
    Summary returned by every load method.
    The DAG task passes these numbers to AuditLogger.success().
    """
    total_rows_loaded  : int = 0
    total_files_loaded : int = 0
    total_files_failed : int = 0
    bytes_loaded       : int = 0   # Snowflake does not always populate this
    file_results       : List[FileResult] = field(default_factory=list)

    @property
    def had_file_errors(self) -> bool:
        """True if at least one file failed or partially loaded."""
        return self.total_files_failed > 0


# ──────────────────────────────────────────────────────────────────────────────
# Main loader
# ──────────────────────────────────────────────────────────────────────────────

class SnowflakeLoader:

    def __init__(self, hook):
        """
        Parameters
        ----------
        hook : SnowflakeHook — pass the same hook instance used by AuditLogger
               so all SQL in one task shares a single connection.
        """
        self.hook = hook

    # ──────────────────────────────────────────────────────────────────
    # Public entry point
    # ──────────────────────────────────────────────────────────────────

    def load(self, config: dict) -> LoadResult:
        """
        Read config["load_mode"] and dispatch to the right private method.

        Supported modes now:
            APPEND         — add new rows; already-loaded files are skipped
            TRUNCATE_LOAD  — wipe table first, then load all files

        To add a new mode:
            elif load_mode == "MERGE":
                return self._merge_load(config)
        """
        load_mode = config.get("load_mode", "APPEND").upper()
        log.info("[Loader] load_mode=%s  table=%s", load_mode, config["table_name"])

        if load_mode == "APPEND":
            return self._append_load(config)

        elif load_mode == "TRUNCATE_LOAD":
            return self._truncate_and_load(config)

        # ── ADD NEW MODES HERE ────────────────────────────────────────
        # elif load_mode == "MERGE":
        #     return self._merge_load(config)
        #
        # elif load_mode == "STREAM_CDC":
        #     return self._stream_cdc_load(config)
        # ─────────────────────────────────────────────────────────────

        else:
            raise ValueError(
                f"Unknown load_mode='{load_mode}' for table={config['table_name']}. "
                f"Allowed values: APPEND, TRUNCATE_LOAD"
            )

    # ──────────────────────────────────────────────────────────────────
    # APPEND mode
    # ──────────────────────────────────────────────────────────────────

    def _append_load(self, config: dict) -> LoadResult:
        """
        Runs COPY INTO without any pre-truncation.

        Snowflake tracks which files it has already loaded (via a file
        metadata cache). With FORCE=FALSE (default), it skips files it
        has seen before. This makes APPEND safe to run repeatedly —
        re-running the DAG after a partial failure won't double-load rows.
        """
        log.info("[Loader] APPEND: stage=%s → table=%s",
                 config["stage_name"], config["table_name"])
        sql = self._build_copy_sql(config, force=False)
        return self._execute_copy(config["table_name"], sql)

    # ──────────────────────────────────────────────────────────────────
    # TRUNCATE_LOAD mode
    # ──────────────────────────────────────────────────────────────────

    def _truncate_and_load(self, config: dict) -> LoadResult:
        """
        Truncates the target table first, then loads all files.

        Use this for small dimension tables that are fully replaced each day
        (e.g. PRODUCTS, CATEGORIES). Do NOT use for large fact tables —
        you will lose all data if the load fails after the truncate.

        FORCE=TRUE is set here because after a truncate, the file metadata
        cache still says those files were loaded — FORCE overrides that.
        """
        full_table = f"{config['target_schema']}.{config['table_name']}"
        log.info("[Loader] TRUNCATE_LOAD: truncating %s first", full_table)
        self.hook.run(f"TRUNCATE TABLE {full_table}")

        log.info("[Loader] TRUNCATE_LOAD: running COPY INTO after truncate")
        sql = self._build_copy_sql(config, force=True)
        return self._execute_copy(config["table_name"], sql)

    # ──────────────────────────────────────────────────────────────────
    # FUTURE CDC METHODS — add your implementations here
    # ──────────────────────────────────────────────────────────────────
    #
    # def _merge_load(self, config: dict) -> LoadResult:
    #     """
    #     CDC upsert using MERGE INTO. Steps:
    #     1. COPY INTO a temp staging table (same schema as target)
    #     2. MERGE staging INTO target ON merge_keys
    #        WHEN MATCHED     → UPDATE SET col = staging.col, ...
    #        WHEN NOT MATCHED → INSERT VALUES (staging.*)
    #     3. DROP the staging table
    #
    #     Add "merge_keys" column to INGEST_CONFIG to specify which
    #     columns identify a unique record (e.g. "CUSTOMER_ID").
    #     """
    #     staging = f"STG_{config['table_name']}_{uuid.uuid4().hex[:8]}"
    #     merge_keys = config.get("merge_keys", "ID")
    #     ...
    #
    # def _stream_cdc_load(self, config: dict) -> LoadResult:
    #     """
    #     Read from a Snowflake Stream (captures INSERT/UPDATE/DELETE).
    #     MERGE the stream changes into the target table.
    #     Stream is consumed (offset advances) only after successful MERGE.
    #
    #     Requires a Stream to be pre-created:
    #         CREATE STREAM str_orders ON TABLE ORDERS_RAW;
    #     """
    #     stream_name = f"STR_{config['table_name']}"
    #     ...
    # ─────────────────────────────────────────────────────────────────

    # ──────────────────────────────────────────────────────────────────
    # SQL builder — one place to change COPY INTO options
    # ──────────────────────────────────────────────────────────────────

    def _build_copy_sql(self, config: dict, force: bool = False) -> str:
        """
        Builds the COPY INTO SQL from the config dict.
        All COPY options are set here — no hardcoding in the DAG.

        Parameters
        ----------
        config : dict  — row from INGEST_CONFIG
        force  : bool  — True for TRUNCATE_LOAD (override file cache)
        """
        full_table   = f"{config['target_schema']}.{config['table_name']}"
        stage_name   = config["stage_name"]
        file_format  = config["file_format"]
        file_pattern = config.get("file_pattern", ".*")

        sql = f"""
        COPY INTO {full_table}
        FROM   {stage_name}
        FILE_FORMAT          = (FORMAT_NAME = {file_format})
        PATTERN              = '{file_pattern}'
        MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
        ON_ERROR             = CONTINUE
        FORCE                = {'TRUE' if force else 'FALSE'}
        """
        log.debug("[Loader] Built COPY SQL:\n%s", sql.strip())
        return sql

    # ──────────────────────────────────────────────────────────────────
    # Execute COPY and parse the result set
    # ──────────────────────────────────────────────────────────────────

    def _execute_copy(self, table_name: str, copy_sql: str) -> LoadResult:
        """
        Runs COPY INTO and parses the per-file result rows into a
        typed LoadResult.

        COPY INTO result columns (in order):
          0  file            — stage path of the file
          1  status          — LOADED / LOAD_FAILED / PARTIALLY_LOADED
          2  rows_parsed     — rows Snowflake attempted to parse
          3  rows_loaded     — rows actually written to the table
          4  error_limit     — configured error limit (usually 1 or 0)
          5  errors_seen     — number of errors encountered
          6  first_error     — description of the first error
          7  first_error_line
          8  first_error_character
          9  first_error_column_name
        """
        log.info("[Loader] Executing COPY INTO for table=%s", table_name)
        raw_rows = self.hook.get_records(copy_sql)

        if not raw_rows:
            log.warning(
                "[Loader] COPY INTO returned no rows for table=%s. "
                "Stage may be empty, or all files were already loaded (FORCE=FALSE).",
                table_name
            )
            return LoadResult()

        result = LoadResult()
        for row in raw_rows:
            fr = self._parse_one_file_row(row)
            result.file_results.append(fr)

            if fr.status == "LOADED":
                result.total_rows_loaded  += fr.rows_loaded
                result.total_files_loaded += 1
            else:
                # LOAD_FAILED or PARTIALLY_LOADED
                result.total_rows_loaded  += fr.rows_loaded   # count partial rows
                result.total_files_failed += 1
                log.warning(
                    "[Loader] File error: file=%s status=%s errors=%d "
                    "first_error=%s line=%s col=%s",
                    fr.file_name, fr.status, fr.errors_seen,
                    fr.first_error[:200], fr.error_line, fr.error_column
                )

        log.info(
            "[Loader] Done: files_ok=%d  files_failed=%d  rows=%d",
            result.total_files_loaded, result.total_files_failed, result.total_rows_loaded
        )
        return result

    @staticmethod
    def _parse_one_file_row(row: tuple) -> FileResult:
        """
        Safely extract one COPY result row into a FileResult.
        Uses index-safe access so older Snowflake driver versions
        that return fewer columns don't crash the parse.
        """
        def get(idx, default=""):
            try:
                v = row[idx]
                return v if v is not None else default
            except IndexError:
                return default

        return FileResult(
            file_name    = str(get(0)),
            status       = str(get(1, "UNKNOWN")),
            rows_parsed  = int(get(2, 0) or 0),
            rows_loaded  = int(get(3, 0) or 0),
            errors_seen  = int(get(5, 0) or 0),
            first_error  = str(get(6)),
            error_line   = get(7) or None,
            error_char   = get(8) or None,
            error_column = str(get(9)),
        )
