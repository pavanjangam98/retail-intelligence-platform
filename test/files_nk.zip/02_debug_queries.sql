-- =============================================================
-- 02_debug_queries.sql
-- Step-by-step playbook for investigating a failed load.
-- Run in Snowsight. Replace <RUN_ID> with the ID from the task log.
-- =============================================================

USE DATABASE RAMU;
USE SCHEMA PUBLIC;


-- ═══════════════════════════════════════════════════════════════
-- STEP 1: What failed in the last 24 hours?
-- Start here. Get the RUN_ID for the failing table.
-- ═══════════════════════════════════════════════════════════════
SELECT
    TABLE_NAME,
    STATUS,
    START_TIME,
    END_TIME,
    DURATION_SECS,
    ERROR_MESSAGE
FROM ETL_AUDIT
WHERE STATUS     = 'FAILED'
  AND START_TIME >= DATEADD('hour', -24, CURRENT_TIMESTAMP())
ORDER BY START_TIME DESC;


-- ═══════════════════════════════════════════════════════════════
-- STEP 2: Which FILES caused the failure?
-- Replace <RUN_ID> with value from STEP 1.
-- This tells you the exact file name, line number, and bad column.
-- ═══════════════════════════════════════════════════════════════
SELECT
    FILE_NAME,
    STATUS,
    ROWS_PARSED,
    ROWS_LOADED,
    ERRORS_SEEN,
    FIRST_ERROR,
    FIRST_ERROR_LINE,
    FIRST_ERROR_CHARACTER,
    ERROR_COLUMN_NAME
FROM ETL_COPY_RESULTS
WHERE RUN_ID = '<RUN_ID>'
ORDER BY STATUS DESC, FILE_NAME;


-- ═══════════════════════════════════════════════════════════════
-- STEP 3: Full Python traceback
-- If STEP 2 does not explain the failure (e.g. connection error,
-- SQL syntax error), get the full traceback here.
-- ═══════════════════════════════════════════════════════════════
SELECT
    ERROR_TYPE,
    ERROR_MESSAGE,
    STACK_TRACE,
    CREATED_AT
FROM ETL_ERROR_LOG
WHERE RUN_ID = '<RUN_ID>';


-- ═══════════════════════════════════════════════════════════════
-- STEP 4: Check what files are actually in the stage
-- ═══════════════════════════════════════════════════════════════
-- LIST @RAW.CUSTOMER_STAGE;    -- replace with your stage name


-- ═══════════════════════════════════════════════════════════════
-- STEP 5: Dry-run validation without loading
-- Run this to see exactly which rows would fail before doing a real load.
-- ═══════════════════════════════════════════════════════════════
-- COPY INTO PUBLIC.CUSTOMER
-- FROM @RAW.CUSTOMER_STAGE
-- FILE_FORMAT = (FORMAT_NAME = CSV_FORMAT)
-- VALIDATION_MODE = RETURN_ERRORS;


-- ─────────────────────────────────────────────────────────────────
-- OPERATIONAL: All tables — current status
-- ─────────────────────────────────────────────────────────────────
SELECT * FROM V_LATEST_STATUS ORDER BY TABLE_NAME;


-- OPERATIONAL: All unresolved errors
SELECT * FROM V_OPEN_ERRORS;


-- OPERATIONAL: Daily batch summary (last 14 days)
SELECT * FROM V_DAILY_SUMMARY LIMIT 14;


-- OPERATIONAL: Mark an error resolved after fixing it
-- UPDATE ETL_ERROR_LOG
-- SET IS_RESOLVED = TRUE,
--     RESOLVED_AT = CURRENT_TIMESTAMP(),
--     RESOLVED_BY = 'your_name'
-- WHERE ERROR_ID = <ERROR_ID>;


-- ─────────────────────────────────────────────────────────────────
-- PERFORMANCE: Slowest tables over last 30 days
-- ─────────────────────────────────────────────────────────────────
SELECT
    TABLE_NAME,
    COUNT(*)                     AS RUNS,
    ROUND(AVG(DURATION_SECS), 1) AS AVG_SECS,
    MAX(DURATION_SECS)           AS MAX_SECS,
    ROUND(AVG(ROWS_LOADED))      AS AVG_ROWS
FROM ETL_AUDIT
WHERE STATUS     = 'SUCCESS'
  AND START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY TABLE_NAME
ORDER BY AVG_SECS DESC;


-- ─────────────────────────────────────────────────────────────────
-- CONFIG: What tables are currently configured?
-- ─────────────────────────────────────────────────────────────────
SELECT
    TABLE_NAME, STAGE_NAME, FILE_FORMAT,
    LOAD_MODE, PRIORITY, IS_ACTIVE, NOTES
FROM INGEST_CONFIG
ORDER BY IS_ACTIVE DESC, PRIORITY, TABLE_NAME;
