-- =============================================================
-- 01_setup_objects.sql
-- Run this ONCE in Snowflake before deploying the DAG.
-- Open in Snowsight → select all → Run
-- =============================================================

USE ROLE ACCOUNTADMIN;
CREATE DATABASE IF NOT EXISTS RAMU;
USE DATABASE RAMU;
CREATE SCHEMA IF NOT EXISTS PUBLIC;
CREATE SCHEMA IF NOT EXISTS RAW;    -- stages live here
USE SCHEMA PUBLIC;

CREATE WAREHOUSE IF NOT EXISTS COMPUTE_WH
    WAREHOUSE_SIZE = 'XSMALL'
    AUTO_SUSPEND   = 60
    AUTO_RESUME    = TRUE;

-- ── File formats ──────────────────────────────────────────────────────────
-- One per file type. Match FILE_FORMAT column in INGEST_CONFIG exactly.

CREATE OR REPLACE FILE FORMAT CSV_FORMAT
    TYPE                         = CSV
    SKIP_HEADER                  = 1
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    NULL_IF                      = ('NULL', 'null', '')
    EMPTY_FIELD_AS_NULL          = TRUE;

CREATE OR REPLACE FILE FORMAT PARQUET_FORMAT
    TYPE = PARQUET;

CREATE OR REPLACE FILE FORMAT JSON_FORMAT
    TYPE              = JSON
    STRIP_OUTER_ARRAY = TRUE;   -- files are JSON arrays, not one object per line

-- ── INGEST_CONFIG — the control table ────────────────────────────────────
-- One row per table you want to load.
-- The DAG reads this at runtime — no code change needed to add a table.

CREATE OR REPLACE TABLE INGEST_CONFIG (
    CONFIG_ID     NUMBER        AUTOINCREMENT PRIMARY KEY,
    TABLE_NAME    VARCHAR(255)  NOT NULL,
    STAGE_NAME    VARCHAR(500)  NOT NULL,        -- e.g. @RAW.CUSTOMER_STAGE
    FILE_FORMAT   VARCHAR(100)  NOT NULL,        -- must match a FILE FORMAT name above
    FILE_PATTERN  VARCHAR(500)  DEFAULT '.*',    -- regex filter, e.g. '.*orders.*\\.csv'
    TARGET_SCHEMA VARCHAR(100)  DEFAULT 'PUBLIC',
    -- LOAD_MODE values:
    --   APPEND        — add new rows; skips already-loaded files automatically
    --   TRUNCATE_LOAD — wipe table first, then load (use for small dimension tables)
    --   MERGE         — CDC upsert (stub exists in snowflake_loader.py, not yet active)
    LOAD_MODE     VARCHAR(20)   DEFAULT 'APPEND'
                  CHECK (LOAD_MODE IN ('APPEND', 'TRUNCATE_LOAD', 'MERGE')),
    IS_ACTIVE     BOOLEAN       DEFAULT TRUE,
    PRIORITY      NUMBER        DEFAULT 100,     -- lower number = loads first
    NOTES         VARCHAR(1000),
    CREATED_AT    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP()
);

-- Sample data — replace with your real tables
INSERT INTO INGEST_CONFIG (TABLE_NAME, STAGE_NAME, FILE_FORMAT, LOAD_MODE, PRIORITY, NOTES)
VALUES
    ('CUSTOMER', '@RAW.CUSTOMER_STAGE', 'CSV_FORMAT',     'APPEND',        10, 'Daily customer feed'),
    ('ORDERS',   '@RAW.ORDERS_STAGE',   'PARQUET_FORMAT', 'APPEND',        20, 'Daily orders feed'),
    ('PRODUCTS', '@RAW.PRODUCT_STAGE',  'JSON_FORMAT',    'TRUNCATE_LOAD', 30, 'Full product refresh');

-- ── ETL_AUDIT — one row per task run ─────────────────────────────────────
-- Primary table for monitoring. Check this first when something looks wrong.

CREATE OR REPLACE TABLE ETL_AUDIT (
    AUDIT_ID       NUMBER       AUTOINCREMENT PRIMARY KEY,
    RUN_ID         VARCHAR(64)  NOT NULL,        -- UUID printed in Airflow task log
    AIRFLOW_RUN_ID VARCHAR(500),                 -- links to Airflow UI
    DAG_ID         VARCHAR(255),
    TABLE_NAME     VARCHAR(255) NOT NULL,
    STAGE_NAME     VARCHAR(500),
    FILE_FORMAT    VARCHAR(100),
    LOAD_MODE      VARCHAR(20),
    START_TIME     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP(),
    END_TIME       TIMESTAMP,
    DURATION_SECS  NUMBER       GENERATED ALWAYS AS              -- auto-calculated
                   (DATEDIFF('second', START_TIME, END_TIME)) VIRTUAL,
    STATUS         VARCHAR(20)  CHECK (STATUS IN ('STARTED', 'SUCCESS', 'FAILED', 'SKIPPED')),
    ROWS_LOADED    NUMBER,
    FILES_LOADED   NUMBER,
    BYTES_LOADED   NUMBER,
    ERROR_MESSAGE  VARCHAR(5000),
    CREATED_AT     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP()
);

-- ── ETL_ERROR_LOG — full error detail on failure ─────────────────────────
-- Contains the full Python traceback. Check this when ETL_AUDIT shows FAILED.

CREATE OR REPLACE TABLE ETL_ERROR_LOG (
    ERROR_ID       NUMBER        AUTOINCREMENT PRIMARY KEY,
    RUN_ID         VARCHAR(64),
    AIRFLOW_RUN_ID VARCHAR(500),
    DAG_ID         VARCHAR(255),
    TABLE_NAME     VARCHAR(255),
    STAGE_NAME     VARCHAR(500),
    ERROR_TYPE     VARCHAR(100),    -- Python exception class, e.g. "ProgrammingError"
    ERROR_MESSAGE  VARCHAR(5000),
    STACK_TRACE    VARCHAR(10000),  -- full Python traceback
    IS_RESOLVED    BOOLEAN         DEFAULT FALSE,
    RESOLVED_AT    TIMESTAMP,
    RESOLVED_BY    VARCHAR(100),
    CREATED_AT     TIMESTAMP       DEFAULT CURRENT_TIMESTAMP()
);

-- ── ETL_COPY_RESULTS — per-file COPY INTO output ─────────────────────────
-- Most detailed debug table. If a file fails, check here for the exact
-- line number, character position, and column name that caused the error.

CREATE OR REPLACE TABLE ETL_COPY_RESULTS (
    RESULT_ID             NUMBER AUTOINCREMENT PRIMARY KEY,
    RUN_ID                VARCHAR(64),
    TABLE_NAME            VARCHAR(255),
    FILE_NAME             VARCHAR(1000),
    STATUS                VARCHAR(50),    -- LOADED | LOAD_FAILED | PARTIALLY_LOADED
    ROWS_PARSED           NUMBER,
    ROWS_LOADED           NUMBER,
    ERRORS_SEEN           NUMBER,
    FIRST_ERROR           VARCHAR(2000),  -- e.g. "Field delimiter not found"
    FIRST_ERROR_LINE      NUMBER,         -- line number in the file
    FIRST_ERROR_CHARACTER NUMBER,         -- character position on that line
    ERROR_COLUMN_NAME     VARCHAR(255),   -- which column rejected the value
    CREATED_AT            TIMESTAMP       DEFAULT CURRENT_TIMESTAMP()
);

-- ── Reporting views ───────────────────────────────────────────────────────

CREATE OR REPLACE VIEW V_DAILY_SUMMARY AS
SELECT
    DATE_TRUNC('day', START_TIME)                            AS RUN_DATE,
    COUNT(*)                                                 AS TOTAL_TABLES,
    SUM(CASE WHEN STATUS = 'SUCCESS' THEN 1 ELSE 0 END)     AS SUCCESS,
    SUM(CASE WHEN STATUS = 'FAILED'  THEN 1 ELSE 0 END)     AS FAILED,
    SUM(ROWS_LOADED)                                         AS TOTAL_ROWS,
    ROUND(AVG(DURATION_SECS), 1)                             AS AVG_DURATION_SECS
FROM ETL_AUDIT
GROUP BY 1 ORDER BY 1 DESC;

-- Latest status per table (one row each — useful for a monitoring dashboard)
CREATE OR REPLACE VIEW V_LATEST_STATUS AS
SELECT
    TABLE_NAME,
    MAX_BY(STATUS,        START_TIME) AS LAST_STATUS,
    MAX(START_TIME)                   AS LAST_RUN_AT,
    MAX_BY(ROWS_LOADED,   START_TIME) AS LAST_ROWS,
    MAX_BY(DURATION_SECS, START_TIME) AS LAST_DURATION_SECS
FROM ETL_AUDIT
GROUP BY TABLE_NAME;

-- All unresolved failures with full error detail
CREATE OR REPLACE VIEW V_OPEN_ERRORS AS
SELECT
    e.ERROR_ID,
    e.TABLE_NAME,
    e.CREATED_AT           AS ERROR_TIME,
    e.ERROR_TYPE,
    e.ERROR_MESSAGE,
    e.STACK_TRACE,
    a.AIRFLOW_RUN_ID
FROM ETL_ERROR_LOG e
JOIN ETL_AUDIT     a ON e.RUN_ID = a.RUN_ID
WHERE e.IS_RESOLVED = FALSE
ORDER BY e.CREATED_AT DESC;
