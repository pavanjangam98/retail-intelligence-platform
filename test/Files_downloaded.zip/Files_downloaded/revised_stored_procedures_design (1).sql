
-- REVISED STORED PROCEDURE DESIGN SUMMARY

-- sp_load_table:
-- Read config:
-- SOURCE_SCHEMA,TABLE_NAME,TARGET_SCHEMA,STAGE_NAME,FILE_FORMAT,
-- FILE_PATTERN,LOAD_MODE,MERGE_KEYS,CDC_OP_COLUMN,
-- STAGING_TABLE,WAREHOUSE_NAME,ON_ERROR
-- Dispatch:
-- FULL_LOAD -> sp_full_load(..., on_error)
-- INCREMENTAL -> sp_incremental_load(..., on_error)
-- CDC_APPEND -> sp_cdc_append(...)

-- sp_incremental_load:
-- COPY INTO target
-- ON_ERROR from metadata
-- FORCE=FALSE
-- Update watermark

-- sp_full_load:
-- TRUNCATE target
-- COPY INTO target
-- ON_ERROR from metadata

-- sp_cdc_append:
-- Load stage into STAGING_TABLE
-- Compute HASH_KEY
-- Compare against latest target record by business key
-- Classify INSERT / UPDATE / DELETE
-- INSERT events into target history table
-- No MERGE
-- No UPDATE
-- No DELETE

-- sp_load_batch:
-- ORDER BY BATCH_GROUP, TABLE_NAME
-- USE WAREHOUSE from metadata
-- Read ON_ERROR
-- Fix file_results loop

