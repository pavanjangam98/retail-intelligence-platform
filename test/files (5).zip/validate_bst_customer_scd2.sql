{#
================================================================================
MACRO : validate_bst_customer_scd2
FILE  : macros/validate_bst_customer_scd2.sql

Thin BST_CUSTOMER wrapper around validate_scd2_src_vs_tgt().

Reads the real landing JSON table exactly as the dbt model does:
  • RECORD_CONTENT:metadata.time          → version timestamp
  • RECORD_CONTENT:afterState.*           → INSERT / UPDATE attributes
  • RECORD_CONTENT:beforeState.*          → DELETE attributes
  • IS_NULL_VALUE(afterState)             → DELETE detection  (same as model)

De-duplicates with the identical QUALIFY / ROW_NUMBER as cte_dedupe.

PARAMETERS
────────────────────────────────────────────────────────────────────────────────
  run_type   'specific_data_load'  → reads live landing table, last N days
             'full_data_load'      → reads full historical view
  days_back  integer (default 30), used only for specific_data_load

USAGE
────────────────────────────────────────────────────────────────────────────────
  {{ validate_bst_customer_scd2(run_type='full_data_load') }}
  {{ validate_bst_customer_scd2(run_type='specific_data_load', days_back=15) }}
================================================================================
#}

{% macro validate_bst_customer_scd2(run_type='specific_data_load', days_back=30) %}

-- ── Configuration
{% if run_type == 'specific_data_load' %}
    {% set filter_date  = "DATEADD(DAY, -" ~ days_back ~ ", CURRENT_TIMESTAMP())" %}
    {% set src_relation = source('landing__bis', 'BST_CUSTOMER') %}
{% else %}
    {% set filter_date  = "'1900-01-01 00:00:00'" %}
    {% set src_relation = ref('raw___bis___bst_customer_full_view') %}
{% endif %}

-- ── Attribute columns to diff (src vs tgt). Must match model's SELECT list.
{% set compare_columns = [
    'customer_type',     'short_name',         'legal_name',
    'salutation',        'start_date',          'end_date',
    'branch_no',         'bus_purpose_code',    'formal_name',
    'corporate_no',      'credit_check_code',   'cus_rate_sorc_code',
    'cus_segment_code',  'cust_arch_status',    'cust_potn_code',
    'cust_rating_ind',   'ibis_base_no',        'ird_no',
    'key_customer_ind',  'kyc_action_date',     'kyc_staff_userid',
    'last_chg_op_code',  'last_chg_timestamp',  'lend_category_ind',
    'mrkt_segm_code',    'mrkt_segment_code',   'non_res_levy_ind',
    'non_resident_code', 'origin_code',         'phone_id_text',
    'prtf_status_code',  'prtf_status_date',    'reas_lost_bus_desc',
    'reas_win_bus_desc', 'rwt_exempt_ind',      'tax_code'
] %}

-- ── Source subquery
--    Mirrors the model's raw_customer → cte_dedupe → cte_pre_customer /
--    cte_pre_customer_delete logic, but flattens the JSON ourselves so we
--    don't depend on generate_json_flatten_uptoarray at validation time.
{% set source_cte %}
(
    WITH raw_landing AS (

        SELECT
            -- ── Version key (drives effective_from)
            RECORD_CONTENT:metadata.time::TIMESTAMP_NTZ            AS src_metadata_time,

            -- ── Entity key — same COALESCE as model's cte_dedupe
            COALESCE(
                RECORD_CONTENT:afterState.CUSTOMER_NO::VARCHAR,
                RECORD_CONTENT:beforeState.CUSTOMER_NO::VARCHAR
            )                                                       AS src_business_key,

            -- ── Delete detection — mirrors IS_NULL_VALUE(record_content:afterState)
            CASE
                WHEN RECORD_CONTENT:afterState IS NULL
                  OR IS_NULL_VALUE(RECORD_CONTENT:afterState)       THEN 'Y'
                ELSE                                                      'N'
            END                                                     AS src_is_deleted,

            -- ────────────────────────────────────────────────────────────────
            -- afterState attributes  (INSERT / UPDATE rows)
            -- ────────────────────────────────────────────────────────────────
            RECORD_CONTENT:afterState.CUSTOMER_TYPE::VARCHAR        AS src_aft_customer_type,
            RECORD_CONTENT:afterState.SHORT_NAME::VARCHAR           AS src_aft_short_name,
            RECORD_CONTENT:afterState.LEGAL_NAME::VARCHAR           AS src_aft_legal_name,
            RECORD_CONTENT:afterState.SALUTATION::VARCHAR           AS src_aft_salutation,
            RECORD_CONTENT:afterState.START_DATE::DATE              AS src_aft_start_date,
            RECORD_CONTENT:afterState.END_DATE::DATE                AS src_aft_end_date,
            RECORD_CONTENT:afterState.BRANCH_NO::NUMBER             AS src_aft_branch_no,
            RECORD_CONTENT:afterState.BUS_PURPOSE_CODE::VARCHAR     AS src_aft_bus_purpose_code,
            RECORD_CONTENT:afterState.FORMAL_NAME::VARCHAR          AS src_aft_formal_name,
            RECORD_CONTENT:afterState.CORPORATE_NO::NUMBER          AS src_aft_corporate_no,
            RECORD_CONTENT:afterState.CREDIT_CHECK_CODE::VARCHAR    AS src_aft_credit_check_code,
            RECORD_CONTENT:afterState.CUS_RATE_SORC_CODE::VARCHAR   AS src_aft_cus_rate_sorc_code,
            RECORD_CONTENT:afterState.CUS_SEGMENT_CODE::VARCHAR     AS src_aft_cus_segment_code,
            RECORD_CONTENT:afterState.CUST_ARCH_STATUS::VARCHAR     AS src_aft_cust_arch_status,
            RECORD_CONTENT:afterState.CUST_POTN_CODE::VARCHAR       AS src_aft_cust_potn_code,
            RECORD_CONTENT:afterState.CUST_RATING_IND::VARCHAR      AS src_aft_cust_rating_ind,
            RECORD_CONTENT:afterState.IBIS_BASE_NO::NUMBER          AS src_aft_ibis_base_no,
            RECORD_CONTENT:afterState.IRD_NO::VARCHAR               AS src_aft_ird_no,
            RECORD_CONTENT:afterState.KEY_CUSTOMER_IND::VARCHAR     AS src_aft_key_customer_ind,
            RECORD_CONTENT:afterState.KYC_ACTION_DATE::DATE         AS src_aft_kyc_action_date,
            RECORD_CONTENT:afterState.KYC_STAFF_USERID::VARCHAR     AS src_aft_kyc_staff_userid,
            RECORD_CONTENT:afterState.LAST_CHG_OP_CODE::VARCHAR     AS src_aft_last_chg_op_code,
            RECORD_CONTENT:afterState.LAST_CHG_TIMESTAMP::TIMESTAMP_NTZ AS src_aft_last_chg_timestamp,
            RECORD_CONTENT:afterState.LEND_CATEGORY_IND::VARCHAR    AS src_aft_lend_category_ind,
            RECORD_CONTENT:afterState.MRKT_SEGM_CODE::VARCHAR       AS src_aft_mrkt_segm_code,
            RECORD_CONTENT:afterState.MRKT_SEGMENT_CODE::VARCHAR    AS src_aft_mrkt_segment_code,
            RECORD_CONTENT:afterState.NON_RES_LEVY_IND::VARCHAR     AS src_aft_non_res_levy_ind,
            RECORD_CONTENT:afterState.NON_RESIDENT_CODE::VARCHAR    AS src_aft_non_resident_code,
            RECORD_CONTENT:afterState.ORIGIN_CODE::VARCHAR          AS src_aft_origin_code,
            RECORD_CONTENT:afterState.PHONE_ID_TEXT::VARCHAR        AS src_aft_phone_id_text,
            RECORD_CONTENT:afterState.PRTF_STATUS_CODE::VARCHAR     AS src_aft_prtf_status_code,
            RECORD_CONTENT:afterState.PRTF_STATUS_DATE::DATE        AS src_aft_prtf_status_date,
            RECORD_CONTENT:afterState.REAS_LOST_BUS_DESC::VARCHAR   AS src_aft_reas_lost_bus_desc,
            RECORD_CONTENT:afterState.REAS_WIN_BUS_DESC::VARCHAR    AS src_aft_reas_win_bus_desc,
            RECORD_CONTENT:afterState.RWT_EXEMPT_IND::VARCHAR       AS src_aft_rwt_exempt_ind,
            RECORD_CONTENT:afterState.TAX_CODE::VARCHAR             AS src_aft_tax_code,

            -- ────────────────────────────────────────────────────────────────
            -- beforeState attributes  (DELETE rows — afterState is null)
            -- ────────────────────────────────────────────────────────────────
            RECORD_CONTENT:beforeState.CUSTOMER_TYPE::VARCHAR       AS src_bef_customer_type,
            RECORD_CONTENT:beforeState.SHORT_NAME::VARCHAR          AS src_bef_short_name,
            RECORD_CONTENT:beforeState.LEGAL_NAME::VARCHAR          AS src_bef_legal_name,
            RECORD_CONTENT:beforeState.SALUTATION::VARCHAR          AS src_bef_salutation,
            RECORD_CONTENT:beforeState.START_DATE::DATE             AS src_bef_start_date,
            RECORD_CONTENT:beforeState.END_DATE::DATE               AS src_bef_end_date,
            RECORD_CONTENT:beforeState.BRANCH_NO::NUMBER            AS src_bef_branch_no,
            RECORD_CONTENT:beforeState.BUS_PURPOSE_CODE::VARCHAR    AS src_bef_bus_purpose_code,
            RECORD_CONTENT:beforeState.FORMAL_NAME::VARCHAR         AS src_bef_formal_name,
            RECORD_CONTENT:beforeState.CORPORATE_NO::NUMBER         AS src_bef_corporate_no,
            RECORD_CONTENT:beforeState.CREDIT_CHECK_CODE::VARCHAR   AS src_bef_credit_check_code,
            RECORD_CONTENT:beforeState.CUS_RATE_SORC_CODE::VARCHAR  AS src_bef_cus_rate_sorc_code,
            RECORD_CONTENT:beforeState.CUS_SEGMENT_CODE::VARCHAR    AS src_bef_cus_segment_code,
            RECORD_CONTENT:beforeState.CUST_ARCH_STATUS::VARCHAR    AS src_bef_cust_arch_status,
            RECORD_CONTENT:beforeState.CUST_POTN_CODE::VARCHAR      AS src_bef_cust_potn_code,
            RECORD_CONTENT:beforeState.CUST_RATING_IND::VARCHAR     AS src_bef_cust_rating_ind,
            RECORD_CONTENT:beforeState.IBIS_BASE_NO::NUMBER         AS src_bef_ibis_base_no,
            RECORD_CONTENT:beforeState.IRD_NO::VARCHAR              AS src_bef_ird_no,
            RECORD_CONTENT:beforeState.KEY_CUSTOMER_IND::VARCHAR    AS src_bef_key_customer_ind,
            RECORD_CONTENT:beforeState.KYC_ACTION_DATE::DATE        AS src_bef_kyc_action_date,
            RECORD_CONTENT:beforeState.KYC_STAFF_USERID::VARCHAR    AS src_bef_kyc_staff_userid,
            RECORD_CONTENT:beforeState.LAST_CHG_OP_CODE::VARCHAR    AS src_bef_last_chg_op_code,
            RECORD_CONTENT:beforeState.LAST_CHG_TIMESTAMP::TIMESTAMP_NTZ AS src_bef_last_chg_timestamp,
            RECORD_CONTENT:beforeState.LEND_CATEGORY_IND::VARCHAR   AS src_bef_lend_category_ind,
            RECORD_CONTENT:beforeState.MRKT_SEGM_CODE::VARCHAR      AS src_bef_mrkt_segm_code,
            RECORD_CONTENT:beforeState.MRKT_SEGMENT_CODE::VARCHAR   AS src_bef_mrkt_segment_code,
            RECORD_CONTENT:beforeState.NON_RES_LEVY_IND::VARCHAR    AS src_bef_non_res_levy_ind,
            RECORD_CONTENT:beforeState.NON_RESIDENT_CODE::VARCHAR   AS src_bef_non_resident_code,
            RECORD_CONTENT:beforeState.ORIGIN_CODE::VARCHAR         AS src_bef_origin_code,
            RECORD_CONTENT:beforeState.PHONE_ID_TEXT::VARCHAR       AS src_bef_phone_id_text,
            RECORD_CONTENT:beforeState.PRTF_STATUS_CODE::VARCHAR    AS src_bef_prtf_status_code,
            RECORD_CONTENT:beforeState.PRTF_STATUS_DATE::DATE       AS src_bef_prtf_status_date,
            RECORD_CONTENT:beforeState.REAS_LOST_BUS_DESC::VARCHAR  AS src_bef_reas_lost_bus_desc,
            RECORD_CONTENT:beforeState.REAS_WIN_BUS_DESC::VARCHAR   AS src_bef_reas_win_bus_desc,
            RECORD_CONTENT:beforeState.RWT_EXEMPT_IND::VARCHAR      AS src_bef_rwt_exempt_ind,
            RECORD_CONTENT:beforeState.TAX_CODE::VARCHAR            AS src_bef_tax_code

        FROM {{ src_relation }}
        WHERE RECORD_CONTENT:metadata.time::TIMESTAMP_NTZ >= {{ filter_date }}
    ),

    -- Mirror of model's cte_dedupe
    deduped AS (
        SELECT *
        FROM raw_landing
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY src_business_key, src_metadata_time
            ORDER BY src_metadata_time DESC
        ) = 1
    ),

    -- Resolve: INSERT/UPDATE rows use afterState; DELETE rows fall back to beforeState
    -- This mirrors cte_pre_customer UNION ALL cte_pre_customer_delete
    resolved AS (
        SELECT
            src_business_key,
            src_metadata_time,
            src_is_deleted,

            -- For each attribute: afterState takes precedence; beforeState used for deletes
            COALESCE(src_aft_customer_type,     src_bef_customer_type)     AS src_customer_type,
            COALESCE(src_aft_short_name,        src_bef_short_name)        AS src_short_name,
            COALESCE(src_aft_legal_name,        src_bef_legal_name)        AS src_legal_name,
            COALESCE(src_aft_salutation,        src_bef_salutation)        AS src_salutation,
            COALESCE(src_aft_start_date,        src_bef_start_date)        AS src_start_date,
            COALESCE(src_aft_end_date,          src_bef_end_date)          AS src_end_date,
            COALESCE(src_aft_branch_no,         src_bef_branch_no)         AS src_branch_no,
            COALESCE(src_aft_bus_purpose_code,  src_bef_bus_purpose_code)  AS src_bus_purpose_code,
            COALESCE(src_aft_formal_name,       src_bef_formal_name)       AS src_formal_name,
            COALESCE(src_aft_corporate_no,      src_bef_corporate_no)      AS src_corporate_no,
            COALESCE(src_aft_credit_check_code, src_bef_credit_check_code) AS src_credit_check_code,
            COALESCE(src_aft_cus_rate_sorc_code,src_bef_cus_rate_sorc_code) AS src_cus_rate_sorc_code,
            COALESCE(src_aft_cus_segment_code,  src_bef_cus_segment_code)  AS src_cus_segment_code,
            COALESCE(src_aft_cust_arch_status,  src_bef_cust_arch_status)  AS src_cust_arch_status,
            COALESCE(src_aft_cust_potn_code,    src_bef_cust_potn_code)    AS src_cust_potn_code,
            COALESCE(src_aft_cust_rating_ind,   src_bef_cust_rating_ind)   AS src_cust_rating_ind,
            COALESCE(src_aft_ibis_base_no,      src_bef_ibis_base_no)      AS src_ibis_base_no,
            COALESCE(src_aft_ird_no,            src_bef_ird_no)            AS src_ird_no,
            COALESCE(src_aft_key_customer_ind,  src_bef_key_customer_ind)  AS src_key_customer_ind,
            COALESCE(src_aft_kyc_action_date,   src_bef_kyc_action_date)   AS src_kyc_action_date,
            COALESCE(src_aft_kyc_staff_userid,  src_bef_kyc_staff_userid)  AS src_kyc_staff_userid,
            COALESCE(src_aft_last_chg_op_code,  src_bef_last_chg_op_code)  AS src_last_chg_op_code,
            COALESCE(src_aft_last_chg_timestamp,src_bef_last_chg_timestamp) AS src_last_chg_timestamp,
            COALESCE(src_aft_lend_category_ind, src_bef_lend_category_ind) AS src_lend_category_ind,
            COALESCE(src_aft_mrkt_segm_code,    src_bef_mrkt_segm_code)    AS src_mrkt_segm_code,
            COALESCE(src_aft_mrkt_segment_code, src_bef_mrkt_segment_code) AS src_mrkt_segment_code,
            COALESCE(src_aft_non_res_levy_ind,  src_bef_non_res_levy_ind)  AS src_non_res_levy_ind,
            COALESCE(src_aft_non_resident_code, src_bef_non_resident_code) AS src_non_resident_code,
            COALESCE(src_aft_origin_code,       src_bef_origin_code)       AS src_origin_code,
            COALESCE(src_aft_phone_id_text,     src_bef_phone_id_text)     AS src_phone_id_text,
            COALESCE(src_aft_prtf_status_code,  src_bef_prtf_status_code)  AS src_prtf_status_code,
            COALESCE(src_aft_prtf_status_date,  src_bef_prtf_status_date)  AS src_prtf_status_date,
            COALESCE(src_aft_reas_lost_bus_desc,src_bef_reas_lost_bus_desc) AS src_reas_lost_bus_desc,
            COALESCE(src_aft_reas_win_bus_desc, src_bef_reas_win_bus_desc) AS src_reas_win_bus_desc,
            COALESCE(src_aft_rwt_exempt_ind,    src_bef_rwt_exempt_ind)    AS src_rwt_exempt_ind,
            COALESCE(src_aft_tax_code,          src_bef_tax_code)          AS src_tax_code
        FROM deduped
    )

    SELECT * FROM resolved
)
{% endset %}

-- ── Call the generic validation macro
{{ validate_scd2_src_vs_tgt(
    source_cte       = source_cte,
    target_relation  = ref('raw___bis___bst_customer'),
    business_key     = 'customer_no',
    compare_columns  = compare_columns
) }}

{% endmacro %}
