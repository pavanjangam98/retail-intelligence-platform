-- ============================================================================
-- FILE    : analyses/audit_bst_customer_summary.sql
-- PURPOSE : Summary dashboard — pass/fail counts per scenario (INSERT /
--           UPDATE / DELETE) and per failure type.
--           Run this first; drill into audit_bst_customer_detail.sql for rows.
-- ============================================================================

WITH validation AS (
    {{ validate_bst_customer_scd2(run_type='full_data_load') }}
)

SELECT
    scenario,
    COUNT(*)                                                          AS total_versions,
    SUM(CASE WHEN final_result = 'PASS'                THEN 1 END)   AS passed,
    SUM(CASE WHEN final_result <> 'PASS'               THEN 1 END)   AS failed,
    ROUND(SUM(CASE WHEN final_result = 'PASS' THEN 1 ELSE 0 END)
          / NULLIF(COUNT(*), 0) * 100, 2)                            AS pass_pct,

    -- Breakdown by failure type
    SUM(CASE WHEN final_result LIKE '%missing in target%'   THEN 1 END) AS fail_row_missing,
    SUM(CASE WHEN final_result LIKE '%effective_from%'      THEN 1 END) AS fail_effective_from,
    SUM(CASE WHEN final_result LIKE '%effective_to%'        THEN 1 END) AS fail_effective_to,
    SUM(CASE WHEN final_result LIKE '%is_deleted_flag%'     THEN 1 END) AS fail_deleted_flag,
    SUM(CASE WHEN final_result LIKE '%attribute mismatch%'  THEN 1 END) AS fail_attributes

FROM validation
GROUP BY 1
ORDER BY 1
