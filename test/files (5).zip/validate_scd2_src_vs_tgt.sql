{#
================================================================================
MACRO : validate_scd2_src_vs_tgt
FILE  : macros/validate_scd2_src_vs_tgt.sql

WHAT IT DOES
────────────────────────────────────────────────────────────────────────────────
Compares a SOURCE (any flat/pre-extracted CTE or subquery) against a TARGET
SCD2 table for INSERT and UPDATE scenarios.

The macro re-derives the EXPECTED SCD2 dates using the same LEAD() window
logic as the dbt model, then:

  ┌─────────────┬──────────────────────────────────────────────────────────┐
  │ Scenario    │ What is checked                                          │
  ├─────────────┼──────────────────────────────────────────────────────────┤
  │ INSERT      │ Target row exists; effective_from = metadata_time;       │
  │ (1st ver.)  │ effective_to = 9999-12-31; is_deleted = 'N';            │
  │             │ ALL attribute columns match source                       │
  ├─────────────┼──────────────────────────────────────────────────────────┤
  │ UPDATE      │ Previous row closed correctly (effective_to = new_time   │
  │ (2nd+ ver.) │ - 1 microsecond); new row opens (effective_to = 9999);  │
  │             │ ALL attribute columns match source                       │
  ├─────────────┼──────────────────────────────────────────────────────────┤
  │ DELETE      │ is_deleted_flag = 'Y'; effective_to closed correctly     │
  └─────────────┴──────────────────────────────────────────────────────────┘

OUTPUT COLUMNS (one row per source version per entity)
────────────────────────────────────────────────────────────────────────────────
  business_key          entity key (customer_no etc.)
  record_order          1 = first version, 2 = second version, …
  scenario              INSERT | UPDATE | DELETE
  ── SOURCE (expected) ──────────────────────────────────────────────────────
  src_metadata_time     the version timestamp from source
  exp_effective_from    = src_metadata_time
  exp_effective_to      derived via LEAD() — what target MUST have
  src_is_deleted        'Y' / 'N'
  ── TARGET (actual) ────────────────────────────────────────────────────────
  act_effective_from    what is in target
  act_effective_to      what is in target
  act_is_deleted        what is in target
  ── INDIVIDUAL CHECKS ──────────────────────────────────────────────────────
  chk_row_exists        PASS / FAIL
  chk_effective_from    PASS / FAIL / N/A
  chk_effective_to      PASS / FAIL / N/A   ← key SCD2 closure check
  chk_deleted_flag      PASS / FAIL / N/A
  chk_attributes        PASS / FAIL / N/A
  mismatched_columns    ARRAY of attribute names that differ (empty = all OK)
  ── ROLLUP ─────────────────────────────────────────────────────────────────
  final_result          PASS  /  FAIL – <specific reason>

PARAMETERS
────────────────────────────────────────────────────────────────────────────────
  source_cte        Parenthesised subquery that must expose:
                      • src_business_key   (entity identifier, VARCHAR)
                      • src_metadata_time  (TIMESTAMP_NTZ, drives effective_from)
                      • src_is_deleted     ('Y' / 'N')
                      • src_<col>          for every col in compare_columns

  target_relation   ref() to the flattened SCD2 model

  business_key      Column name (same in source alias and target table)
                    e.g. 'customer_no'

  compare_columns   List of business attribute column names to diff.
                    Source must expose them as src_<col>.
                    Target must have them with the same name.

  effective_from_col  default 'dwh_effective_from_tstamp'
  effective_to_col    default 'dwh_effective_to_tstamp'
  is_deleted_col      default 'dwh_is_deleted_flag'

USAGE
────────────────────────────────────────────────────────────────────────────────
  See validate_bst_customer_scd2() — the BST_CUSTOMER-specific wrapper.
================================================================================
#}

{% macro validate_scd2_src_vs_tgt(
    source_cte,
    target_relation,
    business_key,
    compare_columns,
    effective_from_col = 'dwh_effective_from_tstamp',
    effective_to_col   = 'dwh_effective_to_tstamp',
    is_deleted_col     = 'dwh_is_deleted_flag'
) %}

-- ── Step 1: Bring in source, compute expected SCD2 dates via LEAD()
WITH src AS (
    SELECT
        src_business_key::VARCHAR                       AS business_key,
        src_metadata_time::TIMESTAMP_NTZ                AS src_metadata_time,
        src_is_deleted                                  AS src_is_deleted,
        {% for col in compare_columns %}
        src_{{ col }}{{ "," if not loop.last }}
        {% endfor %}
    FROM {{ source_cte }}
),

src_with_expected AS (
    SELECT
        *,

        -- same ROW_NUMBER as model's record_order
        ROW_NUMBER() OVER (
            PARTITION BY business_key
            ORDER BY src_metadata_time ASC
        )                                                AS record_order,

        -- same LEAD() logic as cte_dwh_fields in the model
        TIMESTAMPADD(MICROSECOND, -1,
            COALESCE(
                LEAD(src_metadata_time) OVER (
                    PARTITION BY business_key
                    ORDER BY src_metadata_time ASC
                ),
                '9999-12-31T00:00:00.000001'::TIMESTAMP_NTZ
            )
        )                                                AS exp_effective_to,

        CASE
            WHEN ROW_NUMBER() OVER (
                     PARTITION BY business_key
                     ORDER BY src_metadata_time ASC
                 ) = 1              THEN 'INSERT'
            WHEN src_is_deleted = 'Y' THEN 'DELETE'
            ELSE                          'UPDATE'
        END                                              AS scenario

    FROM src
),

-- ── Step 2: Target
tgt AS (
    SELECT
        {{ business_key }}::VARCHAR       AS business_key,
        {{ effective_from_col }}          AS act_effective_from,
        {{ effective_to_col }}            AS act_effective_to,
        {{ is_deleted_col }}              AS act_is_deleted,
        {% for col in compare_columns %}
        {{ col }}                         AS tgt_{{ col }}{{ "," if not loop.last }}
        {% endfor %}
    FROM {{ target_relation }}
),

-- ── Step 3: Join source (expected) → target (actual)
--           Match on business_key + effective_from = src_metadata_time
comparison AS (
    SELECT
        s.business_key                                   AS {{ business_key }},
        s.record_order,
        s.scenario,

        -- ── Expected (from source)
        s.src_metadata_time                              AS exp_effective_from,
        s.exp_effective_to,
        s.src_is_deleted                                 AS exp_is_deleted,

        -- ── Actual (from target)
        t.act_effective_from,
        t.act_effective_to,
        t.act_is_deleted,

        -- ────────────────────────────────────────────────────────────────────
        -- Individual checks
        -- ────────────────────────────────────────────────────────────────────

        -- CHECK 1: Does the row exist in target at all?
        CASE
            WHEN t.business_key IS NULL THEN 'FAIL'
            ELSE                             'PASS'
        END                                              AS chk_row_exists,

        -- CHECK 2: effective_from matches source metadata_time
        CASE
            WHEN t.business_key IS NULL              THEN 'N/A'
            WHEN s.src_metadata_time = t.act_effective_from THEN 'PASS'
            ELSE                                          'FAIL'
        END                                              AS chk_effective_from,

        -- CHECK 3: effective_to = expected (key SCD2 closure check)
        --   INSERT  → must be 9999-12-31
        --   UPDATE  → prior row must be closed to (next.metadata_time - 1µs)
        CASE
            WHEN t.business_key IS NULL              THEN 'N/A'
            WHEN s.exp_effective_to = t.act_effective_to THEN 'PASS'
            ELSE                                          'FAIL'
        END                                              AS chk_effective_to,

        -- CHECK 4: is_deleted_flag
        CASE
            WHEN t.business_key IS NULL              THEN 'N/A'
            WHEN s.src_is_deleted = t.act_is_deleted THEN 'PASS'
            ELSE                                          'FAIL'
        END                                              AS chk_deleted_flag,

        -- CHECK 5: every business attribute matches source
        CASE
            WHEN t.business_key IS NULL THEN 'N/A'
            WHEN ARRAY_SIZE(ARRAY_CONSTRUCT_COMPACT(
                {% for col in compare_columns %}
                CASE WHEN s.src_{{ col }} IS DISTINCT FROM t.tgt_{{ col }}
                     THEN '{{ col }}' END{{ "," if not loop.last }}
                {% endfor %}
            )) = 0                      THEN 'PASS'
            ELSE                             'FAIL'
        END                                              AS chk_attributes,

        -- Array of column names that don't match (empty = all good)
        ARRAY_CONSTRUCT_COMPACT(
            {% for col in compare_columns %}
            CASE WHEN s.src_{{ col }} IS DISTINCT FROM t.tgt_{{ col }}
                 THEN '{{ col }}' END{{ "," if not loop.last }}
            {% endfor %}
        )                                                AS mismatched_columns,

        -- ────────────────────────────────────────────────────────────────────
        -- Final rolled-up verdict
        -- ────────────────────────────────────────────────────────────────────
        CASE
            WHEN t.business_key IS NULL
                THEN 'FAIL – Row missing in target'

            WHEN s.src_metadata_time <> t.act_effective_from
                THEN 'FAIL – effective_from mismatch'
                     || ' (exp: ' || s.src_metadata_time::VARCHAR
                     || ', act: ' || t.act_effective_from::VARCHAR || ')'

            WHEN s.exp_effective_to <> t.act_effective_to
                THEN 'FAIL – effective_to mismatch'
                     || ' (exp: ' || s.exp_effective_to::VARCHAR
                     || ', act: ' || t.act_effective_to::VARCHAR || ')'

            WHEN s.src_is_deleted <> t.act_is_deleted
                THEN 'FAIL – is_deleted_flag mismatch'
                     || ' (exp: ' || s.src_is_deleted
                     || ', act: ' || t.act_is_deleted || ')'

            WHEN ARRAY_SIZE(ARRAY_CONSTRUCT_COMPACT(
                {% for col in compare_columns %}
                CASE WHEN s.src_{{ col }} IS DISTINCT FROM t.tgt_{{ col }}
                     THEN '{{ col }}' END{{ "," if not loop.last }}
                {% endfor %}
            )) > 0
                THEN 'FAIL – attribute mismatch in: '
                     || ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
                         {% for col in compare_columns %}
                         CASE WHEN s.src_{{ col }} IS DISTINCT FROM t.tgt_{{ col }}
                              THEN '{{ col }}' END{{ "," if not loop.last }}
                         {% endfor %}
                     ), ', ')

            ELSE 'PASS'
        END                                              AS final_result

    FROM src_with_expected s
    LEFT JOIN tgt t
        ON  s.business_key      = t.business_key
        AND s.src_metadata_time = t.act_effective_from   -- version-level join
)

SELECT * FROM comparison
ORDER BY {{ business_key }}, record_order

{% endmacro %}
