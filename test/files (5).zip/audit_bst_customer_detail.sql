-- ============================================================================
-- FILE    : analyses/audit_bst_customer_detail.sql
-- PURPOSE : Row-level detail — one row per source version per customer.
--           Shows exactly which check failed and which columns don't match.
--
-- Run:  dbt compile --select audit_bst_customer_detail
--       then execute compiled SQL in Snowflake
--   or: dbt show   --select audit_bst_customer_detail --limit 500
-- ============================================================================

/*
OUTPUT COLUMNS
──────────────────────────────────────────────────────────────────────────────
customer_no          entity key
record_order         1 = INSERT version, 2 = first UPDATE, …
scenario             INSERT | UPDATE | DELETE

── Source / Expected ─────────────────────────────────────────────
exp_effective_from   = source metadata.time
exp_effective_to     what target dwh_effective_to_tstamp SHOULD be
                       INSERT  → 9999-12-31
                       UPDATE  → next version's metadata.time - 1 microsecond
exp_is_deleted       'Y' / 'N'

── Target / Actual ───────────────────────────────────────────────
act_effective_from   actual dwh_effective_from_tstamp in target
act_effective_to     actual dwh_effective_to_tstamp   in target
act_is_deleted       actual dwh_is_deleted_flag        in target

── Individual Checks ─────────────────────────────────────────────
chk_row_exists       PASS / FAIL
chk_effective_from   PASS / FAIL / N/A
chk_effective_to     PASS / FAIL / N/A   ← SCD2 closure check
chk_deleted_flag     PASS / FAIL / N/A
chk_attributes       PASS / FAIL / N/A

mismatched_columns   ARRAY of attribute names where src ≠ tgt (empty = OK)

final_result         PASS  /  FAIL – <specific reason + values>
*/

-- Full historical audit (all versions, all customers)
{{ validate_bst_customer_scd2(run_type='full_data_load') }}

-- ─── Alternatives ────────────────────────────────────────────────────────────
-- Last 15 days only (faster for daily spot-checks):
-- {{ validate_bst_customer_scd2(run_type='specific_data_load', days_back=15) }}

-- Only FAILs:
-- SELECT * FROM ( {{ validate_bst_customer_scd2(run_type='full_data_load') }} )
-- WHERE final_result <> 'PASS'

-- Only a specific customer:
-- SELECT * FROM ( {{ validate_bst_customer_scd2(run_type='full_data_load') }} )
-- WHERE customer_no = '1237650522'
