-- ============================================================================
-- FILE    : tests/assert_bst_customer_scd2_valid.sql
-- PURPOSE : dbt singular test.  Returns ONLY failing rows.
--           The dbt test framework fails this test if ANY rows are returned.
--
-- Run:  dbt test --select assert_bst_customer_scd2_valid
-- ============================================================================

SELECT *
FROM (
    {{ validate_bst_customer_scd2(run_type='full_data_load') }}
)
WHERE final_result <> 'PASS'
